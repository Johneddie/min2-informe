package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.ibatis.ibator.api.Ibator;
import org.apache.ibatis.ibator.config.IbatorConfiguration;
import org.apache.ibatis.ibator.config.xml.IbatorConfigurationParser;
import org.apache.ibatis.ibator.exception.InvalidConfigurationException;
import org.apache.ibatis.ibator.exception.XMLParserException;
import org.apache.ibatis.ibator.internal.DefaultShellCallback;
import org.apache.ibatis.ibator.internal.util.messages.Messages;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoFilepatternException;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.SharedlibConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.config.ProjectContext;
import pe.gob.sunat.tecnologia2.generador.project.util.Constantes;
import pe.gob.sunat.tecnologia2.generador.project.util.TextUtil;

/**
 * 
 * @author jquispecoi
 *
 */
public class ProcesoServiceImpl implements ProcesoService {
	
	public static void main(String[] args) {
        List<String> warnings = new ArrayList<String>();
        String configfile = "D:\\REPO_GEN_PROY\\TEST\\configurador.xml";
        File configurationFile = new File(configfile);
        Set<String> contexts = new HashSet<String>();
        Set<String> fullyqualifiedTables = new HashSet<String>();
        
        try {
            IbatorConfigurationParser cp = new IbatorConfigurationParser(warnings);
            IbatorConfiguration config = cp.parseIbatorConfiguration(configurationFile);
            
            ProjectContext pjc = config.getProjectContext();
            SharedlibConfiguration sc = pjc.getSharedlibConfiguration();
            ArtefactoConfiguration ac = pjc.getArtefactoConfiguration();
            ProcesoConfiguration pc = pjc.getProcesoConfiguration(); 
            String location = ac.getLocation();
            if(sc != null){
	            //descarga
	            System.out.println("Inicio de clonaci�n...");
	    		GitService gitService = new GitServiceImpl("ccaciquey","Sunat2017");
	    		FileService fileServiceUtil = new FileServiceImpl();
	    		String nombreProyecto = gitService.cloneRepo(Constantes.URL_REMOTE_SHAREDLIB, ac);
	    		fileServiceUtil.borrarDirectorio(new File(location + "\\" + nombreProyecto + "\\.git"));
	    		System.out.println("Fin de clonaci�n...");
	            
	            //renombrado
	    		System.out.println("Inicio de renombrado...");
	    		FormatoService p = new FormatoServiceImpl(pc, ac);
	    		TextUtil.replaceNameFolder(location, Constantes.TEXT_PROY_SHAREDLIB, pc.getNameSharedlib());
	    		p.renombrarSharedLib(location + "\\" + pc.getNameSharedlib());
	    		System.out.println("Fin de renombrado...");
	    		
	    		//configuraciones
	    		System.out.println("Inicio de configuraci�n...");
	    		SharedlibServiceImp s = new SharedlibServiceImp(config);
	    		s.configurarSharedlib();
	    		System.out.println("Fin de configuraci�n...");
            }
            
            
            //archivos ibatis
            DefaultShellCallback callback = new DefaultShellCallback(true);
            Ibator ibator = new Ibator(config, callback, warnings);
            ibator.generate(null, contexts, fullyqualifiedTables);
            
        } catch (XMLParserException e) {
        	writeLine(Messages.getString("Progress.3")); //$NON-NLS-1$
        	writeLine();
            for (String error : e.getErrors()) {
                writeLine(error);
            }
            
            return;
        } catch (SQLException e) {
            e.printStackTrace();
            return;
        } catch (IOException e) {
            e.printStackTrace();
            return;
        } catch (InvalidConfigurationException e) {
            e.printStackTrace();
            return;
        } catch (InterruptedException e) {
            // ignore (will never happen with the DefaultShellCallback)
            ;
        } catch (NoFilepatternException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (GitAPIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        for (String warning : warnings) {
            writeLine(warning);
        }
        
        if (warnings.size() == 0) {
        	writeLine(Messages.getString("Progress.4")); //$NON-NLS-1$
        } else {
        	writeLine();
        	writeLine(Messages.getString("Progress.5")); //$NON-NLS-1$
        }
	}
	
	private static void writeLine(String message) {
		System.out.println(message);
	}

	private static void writeLine() {
		System.out.println();
	}
	
	

}
