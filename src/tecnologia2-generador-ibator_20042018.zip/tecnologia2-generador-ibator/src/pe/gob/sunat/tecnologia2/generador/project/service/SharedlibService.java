package pe.gob.sunat.tecnologia2.generador.project.service;

/**
 * 
 * @author jquispecoi
 *
 */
public interface SharedlibService {

}
