package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;

/**
 * 
 * @author jquispecoi
 *
 */
public interface FileService {

	public void renombrarSharedlib(String pathSharedlib);
	public void renombrarContenidoSharedlib(String pathSharedlib);
	public void borrarDirectorio(File directorio);
	
}
