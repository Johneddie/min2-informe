package pe.gob.sunat.tecnologia2.generador.project.bean;

/**
 * 
 * @author jquispecoi
 *
 */
public class DaoConfiguration {
	private String daoType;
	private String domainObjectName;
	
	public String getDaoType() {
		return daoType;
	}
	public void setDaoType(String daoType) {
		this.daoType = daoType;
	}
	public String getDomainObjectName() {
		return domainObjectName;
	}
	public void setDomainObjectName(String domainObjectName) {
		this.domainObjectName = domainObjectName;
	}
	
}
