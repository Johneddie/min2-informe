package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.ibator.config.IbatorConfiguration;
import org.apache.ibatis.ibator.config.IbatorContext;
import org.apache.ibatis.ibator.config.TableConfiguration;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.DaoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ServiceConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.SharedlibConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.config.ProjectContext;
import pe.gob.sunat.tecnologia2.generador.project.util.Constantes;
import pe.gob.sunat.tecnologia2.generador.project.util.TextUtil;
import pe.gob.sunat.tecnologia2.generador.project.util.XmlConstantes;
import static pe.gob.sunat.tecnologia2.generador.project.util.Constantes.*;

/**
 * 
 * @author jquispecoi
 *
 */
public class SharedlibServiceImp {
	private IbatorConfiguration ibatorConfiguration;
	
	public SharedlibServiceImp(IbatorConfiguration ibatorConfiguration){
		this.ibatorConfiguration = ibatorConfiguration;
	}
	
	public boolean configurarSharedlib(){
		//ubicar folder
		ArtefactoConfiguration artefactoConfiguration = ibatorConfiguration.getProjectContext().getArtefactoConfiguration();
		ProcesoConfiguration procesoConfiguration = ibatorConfiguration.getProjectContext().getProcesoConfiguration();
		String location = artefactoConfiguration.getLocation();
		String sharedlib = procesoConfiguration.getNameSharedlib();
		String pathResource = location + "\\" + sharedlib + "\\"; //path project
		
		configurarDataXml(pathResource);
		configurarSqlmapconfigXml(pathResource);
		
		configurarServiceXml(pathResource);
		configurarServiceImpJava(pathResource);
		configurarServiceIfzJava(pathResource);
		
		return true;
	}
	
	//======================================================================================================
	//dao
	//======================================================================================================
	
	public boolean configurarSqlmapconfigXml(String pathResource){
		boolean result = false;
		try{
			//ubicar folder
			pathResource = pathResource	+ FOLDER_SL_DAOIMP_JAR + "\\" + PATH_SRC_RESOURCES ;
					
			//reemplazar nombre
			File fil = new File(pathResource + FILE_SL_SQLMAP_XML);
			fil.delete();
					
			//modificar texto
			List<IbatorContext> contexts = ibatorConfiguration.getIbatorContexts();
			for(IbatorContext ic:contexts)
				agregarTextoSqlmapconfigXml(pathResource, ic);
			
	    }catch(Exception e){
	        System.out.println("Error occured in configurarSqlmapconfigXml: " + e.getMessage());
	        result = false;
	    }
		return result;
				
	}
	
	private void agregarTextoSqlmapconfigXml(String nombreFolder, IbatorContext ic) throws IOException {
		ProjectContext pjc = ibatorConfiguration.getProjectContext();
		ProcesoConfiguration pc = pjc.getProcesoConfiguration(); 
		
        String cadena;
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("<!DOCTYPE sqlMapConfig PUBLIC \"-//iBATIS.com//DTD SQL Map Config 2.0//EN\" \"http://www.ibatis.com/dtd/sql-map-config-2.dtd\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("<sqlMapConfig>\r\n");
		sbContenido.append("\t<settings cacheModelsEnabled=\"true\" enhancementEnabled=\"true\" useStatementNamespaces=\"true\" maxSessions=\"64\" maxTransactions=\"8\" maxRequests=\"128\" />\r\n");
		sbContenido.append("\r\n");
		
		List<TableConfiguration> tables = ic.getTableConfigurations();
		for(TableConfiguration t:tables){
			cadena = XmlConstantes.TEXT_SQLMAP_RESOURCE;
			cadena = cadena.replace("{pathSunat}", "pe/gob/sunat/").replace("{table}", t.getTableName().toLowerCase()).replace("{nameProcesoPath}", pc.getNameProcesoSlash());
			sbContenido.append(cadena);
		}
		sbContenido.append("\r\n");
		
		sbContenido.append("</sqlMapConfig>");
		String nameFile = "sql-map-config-" + ic.getId() + ".xml";
		TextUtil.writeToFile(nombreFolder + nameFile, sbContenido);
	}
	
	public boolean configurarDataXml(String pathResource){
		boolean result = false;
		try{
			//ubicar folder
			pathResource = pathResource	+ FOLDER_SL_DAOIMP_JAR + "\\" + PATH_SRC_RESOURCES ;
					
			//reemplazar nombre
			String nameFileDataXml = ibatorConfiguration.getProjectContext().getProcesoConfiguration().getFormatoGuionMacPro() +"-data.xml";
			TextUtil.replaceNameFile(pathResource, FILE_SL_DATA_XML, nameFileDataXml);
					
			//modificar texto 
			agregarTextoDataXml(pathResource + nameFileDataXml);
			
	    }catch(Exception e){
	        System.out.println("Error occured in configurarDataXml: " + e.getMessage());
	        result = false;
	    }
		return result;
				
	}
	
	private void agregarTextoDataXml(String nombreArch) throws IOException {
		List<IbatorContext> contexts = ibatorConfiguration.getIbatorContexts();
		ProjectContext pjc = ibatorConfiguration.getProjectContext();
		ProcesoConfiguration pc = pjc.getProcesoConfiguration(); 
		
        String cadena;
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<beans xmlns=\"http://www.springframework.org/schema/beans\"\r\n");
		sbContenido.append("     xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("     xmlns:context=\"http://www.springframework.org/schema/context\"\r\n");
		sbContenido.append("     xmlns:jee=\"http://www.springframework.org/schema/jee\"\r\n");
		sbContenido.append("     xsi:schemaLocation=\"http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-2.5.xsd\r\n");
		sbContenido.append("         http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd\r\n");
		sbContenido.append("         http://www.springframework.org/schema/jee http://www.springframework.org/schema/jee/spring-jee-2.5.xsd\" default-lazy-init=\"true\">\r\n");
		sbContenido.append("\r\n");
		
		for(IbatorContext c:contexts){
			cadena = XmlConstantes.TEXT_DATA_JNDI;
			cadena = cadena.replace("{proceso}", pc.getProceso()).replace("{database}", c.getId());
			sbContenido.append(cadena);
		}
		sbContenido.append("\r\n");
		
		for(IbatorContext c:contexts){
			cadena = XmlConstantes.TEXT_DATA_CONFIGLOCATION;
			cadena = cadena.replace("{database}", c.getId());
			sbContenido.append(cadena);
		}
		sbContenido.append("\r\n");
		
		for(IbatorContext c:contexts){
			cadena = XmlConstantes.TEXT_DATA_SQLMAPCLIENT;
			cadena = cadena.replace("{proceso}", pc.getProceso()).replace("{database}", c.getId());
			sbContenido.append(cadena);
		}
		sbContenido.append("\r\n");
		
		for(IbatorContext c:contexts){
			cadena = XmlConstantes.TEXT_DATA_BASEDAO;
			cadena = cadena.replace("{proceso}", pc.getProceso()).replace("{database}", c.getId());
			sbContenido.append(cadena);
		}
		sbContenido.append("\r\n");
		
		for(IbatorContext c:contexts){
			List<TableConfiguration> tables = c.getTableConfigurations();
			for(TableConfiguration t:tables){
				cadena = XmlConstantes.TEXT_DATA_DAO;
				cadena = cadena.replace("{proceso}", pc.getProceso()).replace("{database}", c.getId()).replace("{entidad}", t.getDomainObjectName()).replace("{nameProcesoPoint}", pc.getNameProcesoPoint());
				sbContenido.append(cadena);
			}
			sbContenido.append("\r\n");
		}
		sbContenido.append("</beans>");

		TextUtil.writeToFile(nombreArch, sbContenido);
	}
	

	
	//======================================================================================================
	//service
	//======================================================================================================
	
	public boolean configurarServiceXml(String pathProject){
		boolean result = false;
		try{
			//ubicar ruta
			String pathFolder = pathProject + FOLDER_SL_SERVICEIMP_JAR + "\\" + PATH_SRC_RESOURCES;
			
			//cambiar nombre file
			ProcesoConfiguration pc = ibatorConfiguration.getProjectContext().getProcesoConfiguration();
			String nameFileServiceXml = pc.getFormatoGuionMacPro() +"-service.xml";
			TextUtil.replaceNameFile(pathFolder, Constantes.FILE_SL_SERVICE_XML, nameFileServiceXml);
			
			//reemplazo de texto
			String pathFile = pathFolder + "\\" + nameFileServiceXml;
			File file = new File(pathFile);
    		StringBuilder strFileContent = TextUtil.readContentFile(file);
    		TextUtil.replaceAll(strFileContent, MACPRO+"-"+PROCES, pc.getFormatoGuionMacPro());
    		TextUtil.replaceAll(strFileContent, MEGPRO2+"."+MACPRO+"."+PROCES, pc.getFormatoPointMeg2MacPro());
    		TextUtil.writeToFile(file, strFileContent);
			
		}catch(Exception e){
	        System.out.println("Error occured in configurarServiceXml: " + e.getMessage());
	        result = false;
	    }
		return result;
	}
	
	
	public boolean configurarServiceImpJava(String pathProject){
		boolean result = false;
		String entidad;
		try{
			ProcesoConfiguration pc = ibatorConfiguration.getProjectContext().getProcesoConfiguration();
			String packageProceso = "pe.gob.sunat." + pc.getFormatoPointMeg2MacPro();
			String pathImpFolder = pathProject + FOLDER_SL_SERVICEIMP_JAR + "\\" + PATH_SRC_JAVA + "\\" + PATH_SUNAT + "\\" + pc.getFormatoBackslashMeg2MacPro() + "\\service";
			TextUtil.deleteFiles(new File(pathImpFolder));
			
			List<ServiceConfiguration> lstServices = ibatorConfiguration.getProjectContext().getSharedlibConfiguration().getServices();
			for(ServiceConfiguration sc:lstServices){
				//package
				StringBuilder strServiceImp = new StringBuilder();
				strServiceImp.append("package "+packageProceso+".service;\r\n");
				strServiceImp.append("\r\n");
				
				//import
				strServiceImp.append("import org.apache.commons.logging.Log;\r\n");
				strServiceImp.append("import org.apache.commons.logging.LogFactory;\r\n");
				strServiceImp.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
				strServiceImp.append("import org.springframework.stereotype.Service;\r\n");
				strServiceImp.append("\r\n");
				List<DaoConfiguration> lstDaos = sc.getDaos();
				for(DaoConfiguration dc:lstDaos)
					strServiceImp.append("import "+packageProceso+".model."+dc.getDomainObjectName()+";\r\n");
				for(DaoConfiguration dc:lstDaos)
					strServiceImp.append("import "+packageProceso+".model.dao."+dc.getDomainObjectName()+"DAO;\r\n");
				
				//class
				strServiceImp.append("\r\n");
				String strNombreService = sc.getServiceName().substring(0,1).toLowerCase() + sc.getServiceName().substring(1);
				strServiceImp.append("@Service(\"" + strNombreService + "\")\r\n");
				strServiceImp.append("public class "+sc.getServiceName()+"Impl implements "+sc.getServiceName()+" {\r\n");
				strServiceImp.append("\r\n");
				strServiceImp.append("\tprotected final Log log = LogFactory.getLog(getClass());\r\n");
				strServiceImp.append("\r\n");
				
				//atributes
				for(DaoConfiguration dc:lstDaos){
					strServiceImp.append("\t@Autowired\r\n");
					String strNombreDao = dc.getDomainObjectName().substring(0,1).toLowerCase() + dc.getDomainObjectName().substring(1);
					strServiceImp.append("\t"+dc.getDomainObjectName()+"DAO "+strNombreDao+"DAO;\r\n");
					strServiceImp.append("\r\n");
				}
				
				//methods
				for(DaoConfiguration dc:lstDaos){
					entidad = dc.getDomainObjectName();
					if("crud".equals(dc.getDaoType())) {
						String strNombreDao = dc.getDomainObjectName().substring(0,1).toLowerCase() + dc.getDomainObjectName().substring(1);
						
						strServiceImp.append("\tpublic "+entidad+" obtener"+entidad+"(Integer key){\r\n");
						strServiceImp.append("\t\treturn "+strNombreDao+"DAO.selectByPrimaryKey(key);\r\n");
						strServiceImp.append("\t}\r\n\r\n");
						
						strServiceImp.append("\tpublic int eliminar"+entidad+"(Integer key){\r\n");
						strServiceImp.append("\t\treturn "+strNombreDao+"DAO.deleteByPrimaryKey(key);\r\n");
						strServiceImp.append("\t}\r\n\r\n");
						
						strServiceImp.append("\tpublic int actualizar"+entidad+"("+entidad+" entidad){\r\n");
						strServiceImp.append("\t\treturn "+strNombreDao+"DAO.updateByPrimaryKeySelective(entidad);\r\n");
						strServiceImp.append("\t}\r\n\r\n");
						
						strServiceImp.append("\tpublic void insertar"+entidad+"("+entidad+" entidad){\r\n");
						strServiceImp.append("\t\t"+strNombreDao+"DAO.insertSelective(entidad);\r\n");
						strServiceImp.append("\t}\r\n\r\n");
					}
				}
				strServiceImp.append("}\r\n");
				
				//file
				String nameFileServiceJava = sc.getServiceName() +"Impl.java";
				String pathFile = pathImpFolder + "\\" + nameFileServiceJava;
				File file = new File(pathFile);
				TextUtil.writeToFile(file, strServiceImp);
			}
			
		}catch(Exception e){
	        System.out.println("Error occured in configurarServiceXml: " + e.getMessage());
	        result = false;
	    }
		return result;
	}
	
	public boolean configurarServiceIfzJava(String pathProject){
		boolean result = false;
		String entidad;
		try{
			ProcesoConfiguration pc = ibatorConfiguration.getProjectContext().getProcesoConfiguration();
			String packageProceso = "pe.gob.sunat." + pc.getFormatoPointMeg2MacPro();
			String pathImpFolder = pathProject + FOLDER_SL_SERVICEIFZ_JAR + "\\" + PATH_SRC_JAVA + "\\" + PATH_SUNAT + "\\" + pc.getFormatoBackslashMeg2MacPro() + "\\service";
			TextUtil.deleteFiles(new File(pathImpFolder));
			
			List<ServiceConfiguration> lstServices = ibatorConfiguration.getProjectContext().getSharedlibConfiguration().getServices();
			for(ServiceConfiguration sc:lstServices){
				//package
				StringBuilder strServiceImp = new StringBuilder();
				strServiceImp.append("package "+packageProceso+".service;\r\n\r\n");
				
				//imports
				List<DaoConfiguration> lstDaos = sc.getDaos();
				for(DaoConfiguration dc:lstDaos)
					if("crud".equals(dc.getDaoType())) 
						strServiceImp.append("import "+packageProceso+".model."+dc.getDomainObjectName()+";\r\n");
				strServiceImp.append("\r\n");
				
				//interface
				strServiceImp.append("public interface "+sc.getServiceName()+" {\r\n\r\n");
				
				//methods
				for(DaoConfiguration dc:lstDaos){
					entidad = dc.getDomainObjectName();
					if("crud".equals(dc.getDaoType())) {
						strServiceImp.append("\tpublic "+entidad+" obtener"+entidad+"(Integer key);\r\n\r\n");
						strServiceImp.append("\tpublic int eliminar"+entidad+"(Integer key);\r\n\r\n");
						strServiceImp.append("\tpublic int actualizar"+entidad+"("+entidad+" entidad);\r\n\r\n");
						strServiceImp.append("\tpublic void insertar"+entidad+"("+entidad+" entidad);\r\n\r\n");
					}
				}
				strServiceImp.append("}\r\n");
				
				//file
				String nameFileServiceJava = sc.getServiceName() +".java";
				String pathFile = pathImpFolder + "\\" + nameFileServiceJava;
				TextUtil.writeToFile(new File(pathFile), strServiceImp);
			}
			
			result = true;
		}catch(Exception e){
	        System.out.println("Error occured in configurarServiceIfxJava: " + e.getMessage());
	    }
		return result;
	}
	
	
	
	
}
