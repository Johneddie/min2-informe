package pe.gob.sunat.tecnologia2.generador.project.bean;

import pe.gob.sunat.tecnologia2.generador.project.util.Constantes;
import static pe.gob.sunat.tecnologia2.generador.project.util.Constantes.*;

/**
 * 
 * @author jquispecoi
 *
 */
public class FormatoPath {
	
	private String pathModel;
	private String pathDao;
	private String pathIbatis;
	private String pathSqlmap;
	private String pathProceso;
	
	public FormatoPath(ProcesoConfiguration formatoProceso){
		StringBuilder sb = new StringBuilder(Constantes.PATH_SUNAT);
		sb.append(formatoProceso.getMegaproceso() + FRAME + "\\");
		sb.append(formatoProceso.getMacroproceso() + "\\");
		sb.append(formatoProceso.getProceso());
		this.pathProceso = sb.toString();
		
		pathModel = pathProceso + "\\model";
		pathDao = pathProceso + "\\model\\dao";
		pathIbatis = pathProceso + "\\model\\dao\\ibatis";
		pathSqlmap = pathProceso + "\\model\\dao\\ibatis\\maps";
	}
	
	public String getPathModel(){
		return pathModel;
	}
	
	public String getPathDao(){
		return pathDao;
	}
	
	public String getPathIbatis(){
		return pathIbatis;
	}
	
	public String getPathSqlmap(){
		return pathSqlmap;
	}
	
	public String getPathModelPackage(){
		return pathModel.replace("\\", ".");
	}
	public String getPathDaoPackage(){
		return pathDao.replace("\\", ".");
	}
	public String getPathIbatisPackage(){
		return pathIbatis.replace("\\", ".");
	}
	public String getPathSqlmapPackage(){
		return pathSqlmap.replace("\\", ".");
	}

}
