package pe.gob.sunat.tecnologia2.generador.project.util;

/**
 * 
 * @author jquispecoi
 *
 */
public class XmlConstantes {
	public static final String TEXT_DATA_JNDI= "\t<jee:jndi-lookup id=\"{proceso}.{database}Escritura\"    jndi-name=\"jdbc/dg{database}\" />\r\n";
	
	public static final String TEXT_DATA_CONFIGLOCATION = "\t<bean id=\"{database}.configlocation\" class=\"java.lang.String\" >\r\n"
															+ "\t\t<constructor-arg value=\"classpath:sql-map-config-{database}.xml\"/>\r\n"
															+ "\t</bean>\r\n";
	public static final String TEXT_DATA_SQLMAPCLIENT = "\t<bean id=\"{proceso}.{database}.sqlMapClientEscritura\" class=\"org.springframework.orm.ibatis.SqlMapClientFactoryBean\">\r\n"
														+ "\t\t<property name=\"configLocation\" ref=\"{database}.configlocation\" />\r\n"
														+ "\t\t<property name=\"dataSource\" ref=\"{proceso}.{database}Escritura\" />\r\n"
														+ "\t</bean>\r\n";
	public static final String TEXT_DATA_BASEDAO = "\t<bean id=\"{proceso}.{database}EscrituraBaseDAO\" abstract=\"true\">\r\n"
														+ "\t\t<property name=\"sqlMapClient\" ref=\"{proceso}.{database}.sqlMapClientEscritura\"/>\r\n"
														+ "\t\t<property name=\"dataSource\" ref=\"{proceso}.{database}Escritura\"/>\r\n"
														+ "\t</bean>\r\n";
	public static final String TEXT_DATA_DAO = "\t<bean id=\"{proceso}.{entidad}DAO\" class=\"pe.gob.sunat.{nameProcesoPoint}.model.dao.ibatis.SqlMap{entidad}DAO\" parent=\"{proceso}.{database}EscrituraBaseDAO\"/>\r\n";
	
	public static final String TEXT_SQLMAP_RESOURCE = "\t<sqlMap resource=\"{pathSunat}{nameProcesoPath}/model/dao/ibatis/maps/{table}.xml\" />\r\n";
	
}
