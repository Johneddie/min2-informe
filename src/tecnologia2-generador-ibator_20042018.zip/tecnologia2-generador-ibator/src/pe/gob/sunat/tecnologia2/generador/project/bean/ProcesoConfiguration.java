package pe.gob.sunat.tecnologia2.generador.project.bean;

import static pe.gob.sunat.tecnologia2.generador.project.util.Constantes.*;

/**
 * 
 * @author jquispecoi
 *
 */
public class ProcesoConfiguration  {

	private String megaproceso;
	private String macroproceso;
	private String proceso;
	
	public ProcesoConfiguration(){
		
	}
	
	public ProcesoConfiguration(String megaproceso, String macroproceso, String proceso){
		this.megaproceso = megaproceso;
		this.macroproceso = macroproceso;
		this.proceso = proceso;
	}

	public String getMegaproceso() {
		return megaproceso;
	}

	public void setMegaproceso(String megaproceso) {
		this.megaproceso = megaproceso;
	}

	public String getMacroproceso() {
		return macroproceso;
	}

	public void setMacroproceso(String macroproceso) {
		this.macroproceso = macroproceso;
	}

	public String getProceso() {
		return proceso;
	}

	public void setProceso(String proceso) {
		this.proceso = proceso;
	}
	
	public String getFormatoGuionMeg2MacPro() {
		return  megaproceso + FRAME + "-" + macroproceso + "-" + proceso;
	}
	
	public String getFormatoPointMeg2MacPro() {
		return megaproceso + FRAME + "." + macroproceso + "." + proceso;
	}
	
	public String getFormatoBackslashMeg2MacPro() {
		return megaproceso + FRAME + "\\" + macroproceso + "\\" + proceso;
	}
	
	public String getFormatoPointMeg2Mac() {
		return megaproceso + FRAME + "." + macroproceso;
	}
	
	public String getFormatoGuionMacPro(){
		return macroproceso + "-" + proceso;
	}
	
	public String getNameSharedlib(){
		return megaproceso + FRAME + "-" + macroproceso + "-" + proceso + "-" + TEXT_SHAREDLIB;
	}
	
	public String getNameProcesoPoint(){
		return megaproceso + FRAME + "." + macroproceso + "." + proceso;
	}

	public String getNameProcesoSlash(){
		return megaproceso + FRAME + "/" + macroproceso + "/" + proceso;
	}
}
