package pe.gob.sunat.tecnologia2.generador.project.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jquispecoi
 *
 */
public class ServiceConfiguration {
	private String serviceName;
	private String serviceType;
	private List<DaoConfiguration> daos;
	
	public ServiceConfiguration(){
		daos = new ArrayList<DaoConfiguration>();
	}
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public List<DaoConfiguration> getDaos() {
		return daos;
	}
	public void setDaos(List<DaoConfiguration> daos) {
		this.daos = daos;
	}

	public void addDaoConfiguration(DaoConfiguration dao){
		daos.add(dao);
	}
	
}
