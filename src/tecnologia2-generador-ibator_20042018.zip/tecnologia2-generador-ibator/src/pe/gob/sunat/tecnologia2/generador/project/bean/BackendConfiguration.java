package pe.gob.sunat.tecnologia2.generador.project.bean;

/**
 * 
 * @author jquispecoi
 *
 */
public class BackendConfiguration {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
