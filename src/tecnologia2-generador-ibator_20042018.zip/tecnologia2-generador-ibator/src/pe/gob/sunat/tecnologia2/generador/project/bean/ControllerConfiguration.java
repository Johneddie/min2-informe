package pe.gob.sunat.tecnologia2.generador.project.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jquispecoi
 *
 */
public class ControllerConfiguration {
	private String controllerName;
	private List<ServiceConfiguration> services;
	
	public ControllerConfiguration(){
		services = new ArrayList<ServiceConfiguration>();
	}
	public String getControllerName() {
		return controllerName;
	}
	public void setControllerName(String controllerName) {
		this.controllerName = controllerName;
	}
	public List<ServiceConfiguration> getServices() {
		return services;
	}
	public void setServices(List<ServiceConfiguration> services) {
		this.services = services;
	}
	
	public void addServiceConfiguration(ServiceConfiguration service){
		services.add(service);
	}
	
}
