package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;
import java.io.IOException;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoFilepatternException;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.util.Constantes;


public class GitServiceImpl implements GitService{
	
    private CredentialsProvider credenciales;

    public GitServiceImpl(String user, String pass) throws IOException {
    	credenciales = new UsernamePasswordCredentialsProvider(user, pass);
    }

    @Override
    public String cloneRepo(String remotePath, ArtefactoConfiguration ac) throws IOException, NoFilepatternException, GitAPIException {
    	//1. clonamos el repositorio mastes
    	int index0 = remotePath.lastIndexOf("/");
    	int index1 = remotePath.lastIndexOf(".git");
    	String nombreProyecto = remotePath.substring(index0+1, index1);
        Git.cloneRepository().setCredentialsProvider(credenciales)
                .setURI(remotePath)
                .setDirectory(new File(ac.getLocation() + "\\" + nombreProyecto))
                .call().close();
        //2. borramos el directio .git y todo su contenido para eliminar el
        return nombreProyecto;
    }
    
    
    public static void main(String[] args){
    	try{
    		GitService gitService = new GitServiceImpl("ccaciquey","Sunat2017");
    		FileService fileServiceUtil = new FileServiceImpl();
    		ArtefactoConfiguration ac = new ArtefactoConfiguration();
    		ac.setLocation(Constantes.PATH_LOCAL_CHECKOUT);
    		
    		System.out.println("Inicio de clonaci�n...");
    		String nombreProyecto = gitService.cloneRepo(Constantes.URL_REMOTE_SHAREDLIB, ac);
    		fileServiceUtil.borrarDirectorio(new File(Constantes.PATH_LOCAL_CHECKOUT+nombreProyecto+"\\.git"));//borrado del directorio .git
    		
    		nombreProyecto = gitService.cloneRepo(Constantes.URL_REMOTE_WEBAPP, ac);
    		fileServiceUtil.borrarDirectorio(new File(Constantes.PATH_LOCAL_CHECKOUT+nombreProyecto+"\\.git"));//borrado del directorio .git
    		
    		nombreProyecto = gitService.cloneRepo(Constantes.URL_REMOTE_BACKEND, ac);
    		fileServiceUtil.borrarDirectorio(new File(Constantes.PATH_LOCAL_CHECKOUT+nombreProyecto+"\\.git"));//borrado del directorio .git
    		
    		nombreProyecto = gitService.cloneRepo(Constantes.URL_REMOTE_BATCH, ac);
    		fileServiceUtil.borrarDirectorio(new File(Constantes.PATH_LOCAL_CHECKOUT+nombreProyecto+"\\.git"));//borrado del directorio .git
    		
    		System.out.println("Repositorio clonado.");
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }

}









