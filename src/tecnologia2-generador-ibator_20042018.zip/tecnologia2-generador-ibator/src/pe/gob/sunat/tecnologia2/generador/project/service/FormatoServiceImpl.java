package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.util.Constantes;
import pe.gob.sunat.tecnologia2.generador.project.util.TextUtil;

/**
 * 
 * @author jquispecoi
 *
 */
public class FormatoServiceImpl implements FormatoService{
	ProcesoConfiguration formatoProceso;
	ArtefactoConfiguration formatoPase;
	
	FormatoServiceImpl(ProcesoConfiguration formatoProceso, ArtefactoConfiguration formatoPase){
		this.formatoProceso = formatoProceso;
		this.formatoPase = formatoPase;
	}
	
	public boolean renombrarSharedLib(String remotePath) throws FileNotFoundException, IOException{
		System.out.println("inicio procesarSharedLib");
		StringBuilder strFileContent = new StringBuilder();
		File root = new File( remotePath );
        File[] list = root.listFiles();
        

        if (list == null) return false;

        for ( File f : list ) {
            if ( f.isDirectory() ) {
            	// folders 
            	TextUtil.replaceNamesFolder(f, formatoProceso, true);
            	if(Constantes.FOLDER_SL_DAOIFZ_JAR.equals(f.getName()) || 
            			Constantes.FOLDER_SL_DAOIMP_JAR.equals(f.getName()) ||
            			Constantes.FOLDER_SL_SERVICEIFZ_JAR.equals(f.getName()) ||
            			Constantes.FOLDER_SL_SERVICEIMP_JAR.equals(f.getName()) ||
            			Constantes.FOLDER_SL_SLB_EAR.equals(f.getName())){
            		
            		TextUtil.replaceTextFile(f, Constantes.FILE_SL_BUILD_GRADLE, "macroproceso-proceso", formatoProceso.getFormatoGuionMacPro());
            		
            		if(Constantes.FOLDER_SL_DAOIMP_JAR.equals(f.getName())){
            			TextUtil.replaceNamesFolder(f, formatoProceso, false); //folder xml
            		}
            		
            	}

            } else {
            	// files
            	if(Constantes.FILE_SL_SETTINGS_GRADLE.equals(f.getName())){
            		strFileContent = TextUtil.readContentFile(f);
            		TextUtil.replaceAll(strFileContent, "megaproceso2-macroproceso-proceso", formatoProceso.getFormatoGuionMeg2MacPro());
            		TextUtil.replaceAll(strFileContent, "macroproceso-proceso", formatoProceso.getFormatoGuionMacPro());
            		TextUtil.writeToFile(f.toString(), strFileContent);
            	}else if(Constantes.FILE_SL_BUILD_GRADLE.equals(f.getName())){
            		strFileContent = TextUtil.readContentFile(f);
            		TextUtil.replaceAll(strFileContent, "megaproceso2-macroproceso-proceso", formatoProceso.getFormatoGuionMeg2MacPro());
            		TextUtil.replaceAll(strFileContent, "megaproceso2.macroproceso", formatoProceso.getFormatoPointMeg2Mac());
            		TextUtil.replaceAll(strFileContent, Constantes.TEXT_VERSION, formatoPase.getVersion());
            		TextUtil.replaceAll(strFileContent, Constantes.TEXT_PASENRO, formatoPase.getPaseNro());
            		TextUtil.writeToFile(f.toString(), strFileContent);
            	}
            	
            }
        }
        System.out.println("fin procesarSharedLib");
        
		return false;
	}
	
	public boolean procesarBackend(String remotePath){
		return false;
	}
	
	public static void main(String[] args){
		ProcesoConfiguration formatoProceso = new ProcesoConfiguration("recurso","humano","asistencia");
		ArtefactoConfiguration formatoPase = new ArtefactoConfiguration("1.0.3","PAS20165E200000999");
		FormatoService p = new FormatoServiceImpl(formatoProceso, formatoPase);
		try {
			p.renombrarSharedLib("D:\\REPO_GEN_PROY\\TEST\\megaproceso2-macroproceso-proceso-sharedlib");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	

}









