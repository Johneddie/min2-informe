package pe.gob.sunat.tecnologia2.generador.project.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import static pe.gob.sunat.tecnologia2.generador.project.util.Constantes.*;

/**
 * 
 * @author jquispecoi
 *
 */
public class TextUtil {
	
	public static void replaceAll(StringBuilder builder, String from, String to){
	    int index = builder.indexOf(from);
	    while(index != -1){
	        builder.replace(index, index + from.length(), to);
	        index += to.length();
	        index = builder.indexOf(from,index);
	    }
	}
	
	public static void writeToFile(String filename, StringBuilder sbword) throws IOException{
		   try{
		    File file1 = new File(filename);
		    BufferedWriter bufwriter = new BufferedWriter(new FileWriter(file1));
		    bufwriter.write(sbword.toString());
		    bufwriter.close();

		    }catch(Exception e){
		         System.out.println("Error occured while attempting to write to file: " + e.getMessage());
		    }
		}
	
	public static void writeToFile(File file1, StringBuilder sbword) throws IOException{
		   try{
		    BufferedWriter bufwriter = new BufferedWriter(new FileWriter(file1));
		    bufwriter.write(sbword.toString());
		    bufwriter.close();

		    }catch(Exception e){
		         System.out.println("Error occured while attempting to write to file: " + e.getMessage());
		    }
		}
	
	public static StringBuilder readContentFile(File f){
		String line = null;
		StringBuilder strFileContent = new StringBuilder();
	    strFileContent.setLength(0); 
	    try{
		    BufferedReader br = new BufferedReader(new FileReader(f));
		    line = br.readLine();
		    while(line != null){
		        strFileContent.append(line).append("\r\n");
		        line = br.readLine();
		    }
	    }catch(Exception e){
	        System.out.println("Error occured while attempting to read file: " + e.getMessage());
	    }
	    return strFileContent;
	}
	
	public static StringBuilder readContentFile(String path){
		String line = null;
		StringBuilder strFileContent = new StringBuilder();
	    strFileContent.setLength(0); 
	    
	    File f = new File(path);
	    try{
		    BufferedReader br = new BufferedReader(new FileReader(f));
		    line = br.readLine();
		    while(line != null){
		        strFileContent.append(line).append("\r\n");
		        line = br.readLine();
		    }
	    }catch(Exception e){
	        System.out.println("Error occured while attempting to read file: " + e.getMessage());
	    }
	    return strFileContent;
	}
	
	/**
	 * 
	 * @param folderRoot
	 * @param formatoProceso
	 * @param isJava
	 * @return
	 */
	public static boolean replaceNamesFolder(File folderRoot, ProcesoConfiguration formatoProceso, boolean isJava){
		String strPath;
		if(isJava) 
			strPath = folderRoot.getAbsolutePath() + "\\" + Constantes.PATH_SRC_JAVA + Constantes.PATH_SUNAT;
		else
			strPath = folderRoot.getAbsolutePath() + "\\" + Constantes.PATH_SRC_RESOURCES + Constantes.PATH_SUNAT;
		
		String strPathMega_from;
		String strPathMega_to;
		String strPathMacro_from;
		String strPathMacro_to;
		String strPathProc_from;
		String strPathProc_to;
		boolean result = false;
		try{
			File filDaoifz_me_from = new File(strPathMega_from = strPath + MEGPRO + FRAME);
			File filDaoifz_me_to = new File(strPathMega_to = strPath + formatoProceso.getMegaproceso() + FRAME);
			filDaoifz_me_from.renameTo(filDaoifz_me_to);
			File filDaoifz_ma_from = new File(strPathMacro_from = strPathMega_to + "\\" + MACPRO );
			File filDaoifz_ma_to = new File(strPathMacro_to = strPathMega_to + "\\" + formatoProceso.getMacroproceso() );
			filDaoifz_ma_from.renameTo(filDaoifz_ma_to);
			File filDaoifz_pr_from = new File(strPathProc_from = strPathMacro_to + "\\" + PROCES );
			File filDaoifz_pr_to = new File(strPathProc_to = strPathMacro_to + "\\" + formatoProceso.getProceso() );
			filDaoifz_pr_from.renameTo(filDaoifz_pr_to);
			result = true;
	    }catch(Exception e){
	        System.out.println("Error occured while attempting to read file: " + e.getMessage());
	        result = false;
	    }
		
		return result;
	}
	
	public static boolean replaceNameFolder(String location, String nameOld, String nameNew){
		boolean result = false;
		try{
			File fileOld = new File(location + "\\" + nameOld);
			File fileNew = new File(location + "\\" + nameNew);
			fileOld.renameTo(fileNew);
	    }catch(Exception e){
	        System.out.println("Error occured in replaceNameFolder: " + e.getMessage());
	        result = false;
	    }
		return result;
	}
	
	public static boolean replaceNameFile(String location, String nameOld, String nameNew){
		boolean result = false;
		try{
			File fileOld = new File(location + "\\" + nameOld);
			File fileNew = new File(location + "\\" + nameNew);
			result = fileOld.renameTo(fileNew);
	    }catch(Exception e){
	        System.out.println("Error occured in replaceNameFolder: " + e.getMessage());
	        result = false;
	    }
		return result;
	}
	
	public static void replaceTextFile(File folder, String nameFile, String from, String to) throws IOException{
		File file = new File (folder.getAbsolutePath() + "/" + nameFile);
		StringBuilder strFileContent = readContentFile(file);
		TextUtil.replaceAll(strFileContent, from, to);
		TextUtil.writeToFile(file.toString(), strFileContent);
	}
	
	/**
	 * Delete files from folder
	 * @param folder 
	 */
	public static void deleteFiles(File folder){
		//System.out.println("folder: " + folder.getAbsolutePath() );
		File[] lstFiles = folder.listFiles();
	    for ( File f : lstFiles ) 
            if ( !f.isDirectory() ) 
            	f.delete();
	}
	
}
