package pe.gob.sunat.tecnologia2.generador.project.bean;

/**
 * 
 * @author jquispecoi
 *
 */
public class ArtefactoConfiguration {
	private String version;
	private String paseNro;
	private String location;
	
	public ArtefactoConfiguration(){
		
	}
	
	public ArtefactoConfiguration(String version, String paseNro){
		this.version = version;
		this.paseNro = paseNro;
	}
	
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getPaseNro() {
		return paseNro;
	}
	public void setPaseNro(String paseNro) {
		this.paseNro = paseNro;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
}
