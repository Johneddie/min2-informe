package pe.gob.sunat.tecnologia2.generador.project.config;

import org.apache.ibatis.ibator.config.PropertyHolder;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.BackendConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.BatchConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.FormatoPath;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.SharedlibConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.WebappConfiguration;

/**
 * 
 * @author jquispecoi
 *
 */
public class ProjectContext extends PropertyHolder {
	
    private String id;

    private ProcesoConfiguration procesoConfiguration;

    private ArtefactoConfiguration artefactoConfiguration;
    
    private FormatoPath formatoPath;
    
    private SharedlibConfiguration sharedlibConfiguration;
    
    private WebappConfiguration webappConfiguration;
    
    private BackendConfiguration backendConfiguration;
    
    private BatchConfiguration batchConfiguration;
    
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public ProcesoConfiguration getProcesoConfiguration() {
		return procesoConfiguration;
	}

	public void setProcesoConfiguration(ProcesoConfiguration procesoConfiguration) {
		this.procesoConfiguration = procesoConfiguration;
	}

	public ArtefactoConfiguration getArtefactoConfiguration() {
		return artefactoConfiguration;
	}

	public void setArtefactoConfiguration(
			ArtefactoConfiguration artefactoConfiguration) {
		this.artefactoConfiguration = artefactoConfiguration;
	}

	public FormatoPath getFormatoPath() {
		return formatoPath;
	}

	public void setFormatoPath(FormatoPath formatoPath) {
		this.formatoPath = formatoPath;
	}

	public SharedlibConfiguration getSharedlibConfiguration() {
		return sharedlibConfiguration;
	}

	public void setSharedlibConfiguration(
			SharedlibConfiguration sharedlibConfiguration) {
		this.sharedlibConfiguration = sharedlibConfiguration;
	}

	public WebappConfiguration getWebappConfiguration() {
		return webappConfiguration;
	}

	public void setWebappConfiguration(WebappConfiguration webappConfiguration) {
		this.webappConfiguration = webappConfiguration;
	}

	public BackendConfiguration getBackendConfiguration() {
		return backendConfiguration;
	}

	public void setBackendConfiguration(BackendConfiguration backendConfiguration) {
		this.backendConfiguration = backendConfiguration;
	}

	public BatchConfiguration getBatchConfiguration() {
		return batchConfiguration;
	}

	public void setBatchConfiguration(BatchConfiguration batchConfiguration) {
		this.batchConfiguration = batchConfiguration;
	}
	
	
	
    
}
