package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.File;

/**
 * 
 * @author jquispecoi
 *
 */
public class FileServiceImpl implements FileService {

	private String megaproceso;
	private String macroproceso;
	private String proceso;
	
	FileServiceImpl(){
		
	}
	
	FileServiceImpl(String megaproceso,String macroproceso,String proceso){
		this.megaproceso = megaproceso;
		this.macroproceso = macroproceso;
		this.proceso = proceso;
	}
	
	@Override
	public void borrarDirectorio(File directorio) {
		File[] files = directorio.listFiles();
	    if(files!=null) { 
	        for(File f: files) {
	            if(f.isDirectory()) {
	            	borrarDirectorio(f);
	            } else {
	                f.delete();
	            }
	        }
	    }
	    directorio.delete();
	}
	
	@Override
	public void renombrarSharedlib(String pathSharedlib) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void renombrarContenidoSharedlib(String pathSharedlib) {
		// TODO Auto-generated method stub
		
	}

	public String getMegaproceso() {
		return megaproceso;
	}

	public void setMegaproceso(String megaproceso) {
		this.megaproceso = megaproceso;
	}

	public String getMacroproceso() {
		return macroproceso;
	}

	public void setMacroproceso(String macroproceso) {
		this.macroproceso = macroproceso;
	}

	public String getProceso() {
		return proceso;
	}

	public void setProceso(String proceso) {
		this.proceso = proceso;
	}

}
