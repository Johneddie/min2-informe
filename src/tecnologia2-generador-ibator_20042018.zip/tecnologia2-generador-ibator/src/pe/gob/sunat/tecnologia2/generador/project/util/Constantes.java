package pe.gob.sunat.tecnologia2.generador.project.util;

public class Constantes {

	public static String URL_REMOTE_SHAREDLIB = "http://gitlab.insi.sunat.peru/tecnologia-arquitectura/megaproceso2-macroproceso-proceso-sharedlib.git";
	public static String URL_REMOTE_WEBAPP = "http://gitlab.insi.sunat.peru/tecnologia-arquitectura/megaproceso2-macroproceso-proceso-webapp.git";
	public static String URL_REMOTE_BACKEND = "http://gitlab.insi.sunat.peru/tecnologia-arquitectura/megaproceso2-macroproceso-proceso-backend.git";
	public static String URL_REMOTE_BATCH = "http://gitlab.insi.sunat.peru/tecnologia-arquitectura/megaproceso2-macroproceso-proceso-batch.git";
	public static String PATH_LOCAL_CHECKOUT = "D:\\generador\\checkout\\tecnologia.arquitectura\\";
	
	public static final String TEXT_PROY_SHAREDLIB = "megaproceso2-macroproceso-proceso-sharedlib";
	public static final String TEXT_PROY_BACKEND = "megaproceso2-macroproceso-proceso-backend";
	public static final String TEXT_PROY_WEBAPP = "megaproceso2-macroproceso-proceso-webapp";
	public static final String TEXT_PROY_BATCH = "megaproceso2-macroproceso-proceso-batch";
	public static final String TEXT_VERSION = "1.0.0";
	public static final String TEXT_PASENRO = "PAS20165E200000000";
	public static final String MEGPRO = "megaproceso";
	public static final String MEGPRO2 = "megaproceso2";
	public static final String MACPRO = "macroproceso";
	public static final String PROCES = "proceso";
	public static final String FRAME = "2";
	
	public static final String TEXT_SHAREDLIB = "sharedlib";
	public static final String TEXT_WEBAPP = "webapp";
	public static final String TEXT_BACKEND = "backend";
	public static final String TEXT_BATCH = "batch";
	
	public static final String FOLDER_SL_DAOIFZ_JAR = "dao-ifz.jar";
	public static final String FOLDER_SL_DAOIMP_JAR = "dao-imp.jar";
	public static final String FOLDER_SL_MODEL_JAR = "model.jar";
	public static final String FOLDER_SL_SERVICEIFZ_JAR = "service-ifz.jar";
	public static final String FOLDER_SL_SERVICEIMP_JAR = "service-imp.jar";
	public static final String FOLDER_SL_SLB_EAR = "slb.ear";
	
	public static final String FILE_SL_SETTINGS_GRADLE = "settings.gradle";
	public static final String FILE_SL_BUILD_GRADLE = "build.gradle";
	public static final String FILE_SL_DATA_XML = "macroproceso-proceso-data.xml";
	public static final String FILE_SL_SQLMAP_XML = "sql-map-config-proceso.xml";
	public static final String FILE_SL_SERVICE_XML = "macroproceso-proceso-service.xml";
	
	public static final String PATH_SRC_JAVA = "src\\main\\java\\";
	public static final String PATH_SRC_RESOURCES = "src\\main\\resources\\";
	public static final String PATH_SUNAT = "pe\\gob\\sunat\\";
	
}
