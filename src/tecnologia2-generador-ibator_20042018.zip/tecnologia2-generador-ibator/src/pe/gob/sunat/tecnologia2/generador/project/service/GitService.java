package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.IOException;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.api.errors.NoFilepatternException;

import pe.gob.sunat.tecnologia2.generador.project.bean.ArtefactoConfiguration;
import pe.gob.sunat.tecnologia2.generador.project.bean.ProcesoConfiguration;

public interface GitService {

	public String cloneRepo(String remotePath, ArtefactoConfiguration ac) throws IOException, NoFilepatternException, GitAPIException;
	
}
