package pe.gob.sunat.tecnologia2.generador.project.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author jquispecoi
 *
 */
public class SharedlibConfiguration {
	List<ServiceConfiguration> services;

	public SharedlibConfiguration(){
		services = new ArrayList<ServiceConfiguration>();
	}
	
	public List<ServiceConfiguration> getServices() {
		return services;
	}

	public void setServices(List<ServiceConfiguration> services) {
		this.services = services;
	}
	
	public void addServiceConfiguration(ServiceConfiguration service){
		services.add(service);
	}
}
