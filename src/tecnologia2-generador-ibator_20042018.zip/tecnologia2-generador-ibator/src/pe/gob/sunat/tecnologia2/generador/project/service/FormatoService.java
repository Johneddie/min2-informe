package pe.gob.sunat.tecnologia2.generador.project.service;

import java.io.FileNotFoundException;
import java.io.IOException;


/**
 * 
 * @author jquispecoi
 *
 */
public interface FormatoService {
	public boolean renombrarSharedLib(String remotePath) throws FileNotFoundException, IOException;

	
}
