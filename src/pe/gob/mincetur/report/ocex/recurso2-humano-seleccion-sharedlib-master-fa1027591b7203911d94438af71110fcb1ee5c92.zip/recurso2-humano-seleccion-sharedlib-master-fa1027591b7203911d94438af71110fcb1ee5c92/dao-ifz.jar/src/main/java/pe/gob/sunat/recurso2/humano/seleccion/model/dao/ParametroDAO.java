package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;



public interface ParametroDAO {

	Parametro selectByPrimaryKey(String codParametro, String codDataParametro);
	List<Parametro> listarPreguntasDeclaracionJurada(Parametro params);
	
}
