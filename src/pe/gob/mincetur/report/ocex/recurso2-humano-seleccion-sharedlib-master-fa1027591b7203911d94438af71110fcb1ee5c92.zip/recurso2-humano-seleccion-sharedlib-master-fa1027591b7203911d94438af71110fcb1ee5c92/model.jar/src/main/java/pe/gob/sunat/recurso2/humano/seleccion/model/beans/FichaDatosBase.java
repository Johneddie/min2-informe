package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

public class FichaDatosBase {
	
	private Short codCat;
	private String codPuesto;
	private Short numCorrel;
	
	public Short getCodCat() {
		return codCat;
	}
	public void setCodCat(Short codCat) {
		this.codCat = codCat;
	}
	public String getCodPuesto() {
		return codPuesto;
	}
	public void setCodPuesto(String codPuesto) {
		this.codPuesto = codPuesto;
	}
	public Short getNumCorrel() {
		return numCorrel;
	}
	public void setNumCorrel(Short numCorrel) {
		this.numCorrel = numCorrel;
	}		
}
