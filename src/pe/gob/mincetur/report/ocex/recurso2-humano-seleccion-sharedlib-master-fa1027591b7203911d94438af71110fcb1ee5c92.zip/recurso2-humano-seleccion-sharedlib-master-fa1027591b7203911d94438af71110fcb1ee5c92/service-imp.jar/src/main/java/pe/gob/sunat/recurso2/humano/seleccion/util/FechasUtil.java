package pe.gob.sunat.recurso2.humano.seleccion.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FechasUtil {
	
	private static final Log log = LogFactory.getLog("pe.gob.sunat.recurso2.humano.seleccion.util.FechasUtil");
	
	
	/**
	 * Retorna una fecha del tipo date dado una en formato string, si no cumple con el formato retorna null.
	 * */
	public static Date getDateFromString(String fechaString){
		Date fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
			 fechaSalida = formateadorDDMMYYYY.parse(fechaString);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	
	public static String getStringFromDate(Date fechaDate){
		String fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
			 fechaSalida = formateadorDDMMYYYY.format(fechaDate);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	public static Date getSoloFechaDesde(Date date){
		  Date ret = null;
		  if (date != null) {
			  Calendar cal = Calendar.getInstance();
			  cal.setTime(date);
			  cal.set(Calendar.HOUR_OF_DAY, 0);
			  cal.set(Calendar.MINUTE, 0);
			  cal.set(Calendar.SECOND, 0);
			  cal.set(Calendar.MILLISECOND, 0);
			  ret = cal.getTime();
		  }
		  return ret;
	}
	
	
	public static long diferenciaDias(Date dateFin, Date dateInicio){
		long diasDateFin = dateFin.getTime()/1000/60/60/24;
		long diasDateInicio = dateInicio.getTime()/1000/60/60/24;
		return diasDateFin - diasDateInicio;
	}
	
	public static String getFechaString(Date dteFecha) {
		String strFecha = null;
		if(dteFecha != null){
			strFecha = (new SimpleDateFormat("yyyy-MM-dd")).format(dteFecha);
		}
		return strFecha;
	}
	
	public static String getStringLargeFromDate(Date fechaDate){
		String fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYYHHMMSS = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aaa");
			 fechaSalida = formateadorDDMMYYYYHHMMSS.format(fechaDate);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	public static String getStringToken(Date fechaDate){
		String fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYYHHMMSSToken = new SimpleDateFormat("ddMMyyyyHHmmss");
			 fechaSalida = formateadorDDMMYYYYHHMMSSToken.format(fechaDate);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	public static Date getDateToken(String fechaString){
		Date fechaSalida = null;
		try{
			 SimpleDateFormat formateadorDDMMYYYYHHMMSSToken = new SimpleDateFormat("ddMMyyyyHHmmss");
			 fechaSalida = formateadorDDMMYYYYHHMMSSToken.parse(fechaString);
		}catch(Exception e){
			log.debug("error",e);
		}
		return fechaSalida; 
	}
	
	
	
	public static Short getAnioFromDate(Date date){ 
		Short anio = null;
		try{	
			if(date!=null){
				Calendar calFecha = Calendar.getInstance();
				calFecha.setTime(date);
				anio = Short.parseShort(Integer.toString(calFecha.get(Calendar.YEAR)));
				if(anio == 1)
					anio = null;
			}
		}catch(Exception e){
			log.debug("error",e);
		}
		return anio; 
	}
	 
	 public static String getDateDifferenceInDDMMYYYY(Date dteInicio, Date dteFin) {
	        Calendar fecInicio=Calendar.getInstance();
	        Calendar fecFin=Calendar.getInstance();
	        fecInicio.setTime(dteInicio);
	        fecFin.setTime(dteFin);
	        
	        Integer annInicio;
	        Integer mesInicio; 
	        Integer diaInicio;
	        Integer annFin; 
	        Integer mesFin;
	        Integer diaFin;
	        Integer diasMaa;
	        
	        Integer cntAnios;
	        Integer cntMeses;
	        Integer cntDias;

	        if (fecFin.before(fecInicio)) {
	        	return "0-0-0";
	        }

	        annInicio = fecInicio.get(Calendar.YEAR);
	        mesInicio = fecInicio.get(Calendar.MONTH)+1;
	        diaInicio = fecInicio.get(Calendar.DAY_OF_MONTH);
	        
	        annFin = fecFin.get(Calendar.YEAR);
	        mesFin = fecFin.get(Calendar.MONTH)+1;
	        diaFin = fecFin.get(Calendar.DAY_OF_MONTH);

	        cntAnios = annFin - annInicio;
	        cntMeses = mesFin - mesInicio;
	        cntDias = diaFin - diaInicio + 1;

	        diasMaa = obtenerNumeroDias(annFin, mesFin);

	        if (cntDias < 0) {
                cntDias = diasMaa + cntDias;
                cntMeses = cntMeses - 1;
	        }else if (cntDias >=  diasMaa){
                cntDias = cntDias - diasMaa;
                cntMeses = cntMeses + 1;
	        }

	        if (cntMeses < 0){
                cntMeses = 12 + cntMeses;
                cntAnios = cntAnios - 1;
	        }else if (cntMeses >= 12) {
                cntMeses = 12 - cntMeses;
                cntAnios = cntAnios + 1;
	        }
	        
	        return cntAnios + "-" + cntMeses + "-" + cntDias;

	    }
	 
		public static String getStringFromDateReporte(Date fechaDate){
			SimpleDateFormat formateadorDDMMYYYY = new SimpleDateFormat("dd/MM/yyyy");
			String fechaSalida = null;
			try{
				Calendar calendar = new GregorianCalendar();
				calendar.setTime(fechaDate);
				int year = calendar.get(Calendar.YEAR);
				
				if(year != 1)
					fechaSalida = formateadorDDMMYYYY.format(fechaDate);
				else
					fechaSalida = "-";
			}catch(Exception e){
				log.debug("error",e);
			}
			return fechaSalida; 
		}
		
		public static int obtenerNumeroDias(int anio, int mes){
			int dias = 31;
	        if(mes == 4|| mes == 6|| mes == 9|| mes == 11)
	        	dias = 30;
	        if(mes == 2){
	        	if(anio % 4 == 0) 
	        		dias = 29;
	        	else 
	        		dias = 28;
	        }
	        return dias;
		}

}

