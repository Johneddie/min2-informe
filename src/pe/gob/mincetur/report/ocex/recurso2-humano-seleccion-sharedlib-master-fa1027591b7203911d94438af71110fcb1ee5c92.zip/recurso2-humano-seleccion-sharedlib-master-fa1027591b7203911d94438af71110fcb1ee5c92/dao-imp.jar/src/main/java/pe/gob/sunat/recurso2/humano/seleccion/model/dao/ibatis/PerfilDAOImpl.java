package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.HashMap;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Perfil;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PerfilDAO;

public class PerfilDAOImpl extends SqlMapDAOBase implements PerfilDAO{

	@Override
	public Perfil selectByPrimaryKey(Integer codProceso) {
		Map<String,Object> param = new HashMap<>();
		param.put("codProceso", codProceso);
		return (Perfil)getSqlMapClientTemplate().queryForObject("t9033perfilh.selectByPrimaryKey",param);
	}
}
