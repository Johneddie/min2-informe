package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Derivacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DetalleFase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Empleado;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Fase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
//Codigo practicante Jean Pierre
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ReporteHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Revision;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.SeccionEvaluacion;
////Fin Codigo practicante Jean Pierre

public interface RevisionIncorporacionService {

	List<PuestoProceso> listarProcesosPorUnidad(String codUuoo, String codPersona);

	List<FichaHistorico> listarPostulantesPorProceso(Short codCat,
			String codPuesto);

	//Codigo practicante Jean Pierre
	
	//Para Datos Academmicos
	List<FichaEducacion> listarDatosEducativos(Short codCat,
			String codPuesto, Integer numPostulante);
	//Para especialidad y Para certificacion
	List<FichaEspecialidad> listarEstudiosEspecializacion(Short codCat,
			String codPuesto, Integer numPostulante,String indCertificacion);	
	//para conocimiento informatico
	List<FichaConocimiento> listarConocimiento(Integer numPostulante,Short codCat,
			String codPuesto);
	//para experiencia laboral
	List<FichaExperiencia> listarExperienciaLaboral(Short codCat,
			String codPuesto, Integer numPostulante);
	
	String getCodigoUltimaFase(Short codCat);
	
	SeccionEvaluacion getSeccionEvaluacion(Short codCat, String codSeccion);
	
	//para reporte historico
	
	//List<ReporteHistorico> listarReporteHistorico(Integer numArcPostula);
	List<ReporteHistorico> listarReporteHistorico(Integer numArcPostula);
	
	
	List<Derivacion> listarDerivaciones(Derivacion derivacion);
		
	Empleado buscarEmpleado(String codEmpleado);
	
	List<Empleado> buscarEmpleados(String codRegistro, String apePaterno, String apeMaterno, String nombres, Short codCat);//Se busca por al menos uno de los 3
	
	List<Empleado> buscarEmpleadosAsignados(String codRegistro, String apePaterno, String apeMaterno, String nombres, Short codCat);//Se busca por al menos uno de los 3
	
	boolean esRevisorDeProceso(String codUnidad, String codEmpleado);
	
	void registrarActualizarDerivacion(Derivacion derivacion, String indTipo);
	
	Revision registrarActualizarRevision(Revision revision);
	
	List<String> registrarActualizarRevisionPostulante(DetalleFase revisionPostulante);
	
	
	void finalizarProcesoPostulacion(Fase fase);
	
	boolean validarProcesoPostulacion(Fase fase);
	
	void devolverProcesoPostulacion(Fase fase);
	
	boolean seccionRevisada(Revision revision);
	
	Revision getUltimaRevisionSeccion(Revision revision);
	
	Map<String,Object> getUltimaRevisionPostulante(Revision revisionParam);
	
}


