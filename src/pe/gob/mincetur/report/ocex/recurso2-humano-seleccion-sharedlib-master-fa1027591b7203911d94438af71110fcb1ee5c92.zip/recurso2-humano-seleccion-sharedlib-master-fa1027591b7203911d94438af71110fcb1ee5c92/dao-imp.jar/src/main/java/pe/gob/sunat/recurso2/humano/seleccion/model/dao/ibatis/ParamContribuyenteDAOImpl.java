package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParamContribuyenteDAO;

public class ParamContribuyenteDAOImpl extends SqlMapDAOBase implements ParamContribuyenteDAO{

	
	public ParamContribuyenteDAOImpl() {
        super();
    }
	
	@Override
	public List<Parametro> listarDepartamentos() {
		return getSqlMapClientTemplate().queryForList("t01param.listarDepartamentos");
	}

	@Override
	public List<Parametro> listarProvincias(String codDepartamento) {
		Parametro param = new Parametro();
		param.setCodParametro(codDepartamento);
		return getSqlMapClientTemplate().queryForList("t01param.listarProvincias",param);
	}

	@Override
	public List<Parametro> listarDistritos(String codProvincia) {
		Parametro param = new Parametro();
		param.setCodParametro(codProvincia);
		return getSqlMapClientTemplate().queryForList("t01param.listarDistritos",param);
	}

	@Override
	public List<Parametro> listarParametros(String codParametro) {
		Parametro param = new Parametro();
		param.setCodParametro(codParametro);
		return getSqlMapClientTemplate().queryForList("t01param.listarParametros",param);
	}

}
