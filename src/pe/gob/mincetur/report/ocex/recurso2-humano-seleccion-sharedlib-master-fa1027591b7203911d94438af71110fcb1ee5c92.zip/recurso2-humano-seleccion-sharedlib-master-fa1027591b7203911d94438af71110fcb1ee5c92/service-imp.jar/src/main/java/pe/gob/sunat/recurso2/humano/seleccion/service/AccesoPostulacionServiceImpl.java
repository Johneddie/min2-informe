package pe.gob.sunat.recurso2.humano.seleccion.service;


import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.core.dao.DAOException;
import pe.gob.sunat.framework.spring.util.security.HashPass;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.UsuarioDAO;
import pe.gob.sunat.servicio2.registro.model.dao.T733DAO;

@Service("accesoPostulacionService")
public class AccesoPostulacionServiceImpl implements AccesoPostulacionService {

	@Autowired
	private UsuarioDAO usuarioDAO;
	
	@Autowired
	private T733DAO t733DAO; 
	
	public final Log log = LogFactory.getLog(getClass());	
	
	/***
	 * return: 
	 * 0: Login OK
	 * 1: clave incorrecta
	 * 3: usuario no encontrado
	 * 4: Clave vacia
	 * 5 : login OK estado temporal validar clave de acceso 
	 *
	 * 10: Login OK bloqueado
	 * 11: clave acceso incorrecta
	 * 14: Clave acceso vacia
	 * 15: Clave acceso vencida
	 */
	
	public int procesarLogin(String uid, String pwd){
		int retorno = 1;
		
		try {
			Map<String, Object> map = usuarioDAO.selectByEmail(uid.toUpperCase());
			if ((map != null) && (!map.isEmpty())) {
				String indEstado = (String)map.get("ind_estado");
				if("T".equals(indEstado) || "D".equals(indEstado)) {
					String key = (String)map.get("nom_clave");
					if ((key == null) || "".equals(key)) { 
						retorno = 4;
					} else {
						HashPass hashPWD = new HashPass();
						String hash = hashPWD.passWord(pwd, hashPWD.getSaltString(key));
						if (key.equals(hash)) {
							if("D".equals(indEstado)) {
								retorno = 0; 
							} else {
								retorno = 5; 
							}
						} else {
							if("D".equals(indEstado)) {
								retorno = 1; 
							} else {
								retorno = 6; 
							}
						}
					}
				} else if("B".equals(indEstado)) { // validacion del token cuando se encuentra bloqueado
					String key = (String)map.get("cod_token");
					if ((key == null) || ("".equals(key))) { 
						retorno = 14;
					} else {
						if (key.equals(pwd)) {
							
							Date fecToken = (Date)map.get("fec_generatoken");
							Calendar cal = Calendar.getInstance();
							cal.add(Calendar.DAY_OF_MONTH, -1);
							Date fecBefore1days = cal.getTime();
							if(fecBefore1days.after(fecToken)){
								updateClaveAcceso(map, "REGISTRO DE LA POSTULACION - OLVIDO CLAVE", "B");
								retorno = 15;
							} else {
								retorno = 10;
							}
						} else {
							retorno = 11;
						}
					}
				}
			} else {
				retorno = 3;
			}
		} catch (Exception e)  {
			log.info("Ocurri� una excepcion al procesar el login .",e);
			throw new DAOException(this, e.getMessage());
	    }
		return retorno;
	}
	

	/**
	 * 
	 * ** SOLO EN ESTADO TEMPORAL
	 *  return:
	 *  0: validacion ok
	 *  1: validacion incorrecta
	 *  2: estado distinto de temporal
	 *  3: usuario no encontrado
	 *  4: Clave vacia
	 *  5: vencido: Se pasaron las 24 horas para la clave de acceso 
	 * */
	public int validaClaveAccesoInicial(String uid, String claveAcceso){
		int retorno = 1;
		
		try {
			Map<String, Object> map = usuarioDAO.selectByEmail(uid.toUpperCase());
			if ((map != null) && (!map.isEmpty())) {
				
				Date fecToken = (Date)map.get("fec_generatoken");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DAY_OF_MONTH, -1);
				Date fecBefore1days = cal.getTime();
				
				if (!("T".equals((String)map.get("ind_estado")))) {
					retorno = 2; // usuario no es temporal
				} else {
					String key = (String)map.get("cod_token");
					if ((key == null) || ("".equals(key))) { 
						retorno = 4;
					} else {
						if (key.equalsIgnoreCase(claveAcceso)) {
							if(fecBefore1days.after(fecToken)){
								updateClaveAcceso(map, "REGISTRO DE LA POSTULACION - CLAVE INICIAL", "T");
								return 5;
							} else {
								retorno = 0; 
								// se actualiza el estado a definitivo 
								Integer id = (Integer)map.get("num_postulante");
								Usuario param = new Usuario();
								param.setNumPostulante(id);
								param.setIndEstado("D");
								param.setCodUsumodif(map.get("num_postulante").toString());
								param.setFecModif(new Date());
								usuarioDAO.updateByPrimaryKeySelective(param);
							}
							
						} else {
							retorno = 1;
						}
					}
				}
			} else {
				retorno = '3';
			}
		} catch (Exception e)  {
			log.info("Ocurri� una excepcion al validar la clave de acceso inicial .",e);
			throw new DAOException(this, e.getMessage());
	    }
		return retorno;
	}
	
	
	/**
	 * 
	 * ** SOLO EN ESTADO TEMPORAL
	 *  return:
	 *  1: cambio de estado, generacion de clave acceso y envio de correo OK
	 *  2: correo no existe
	 * */
	public Map<String, Object> olvidoClave(String nomEmail) {
		
		Map<String, Object> result = new HashMap<>();
		Map<String, Object> user = usuarioDAO.selectByEmail(nomEmail.toUpperCase());
		
		if(user==null){
			log.debug("Correo no  existe: " + nomEmail );
			result.put("codigo", 2);
			return result;
		}
		
		//cambia estado a bloqueado y genera clave acceso
		updateOlvidoClave(user, "SOLICITUD DE RECUPERAR CLAVE", "B");
		
		result.put("codigo", 1);
		return result;
	}
	
	//cambia estado a bloqueado y genera clave acceso
	public void updateClaveAcceso(Map<String, Object> user, String asunto, String estado){
		//cambia estado a bloqueado y genera clave acceso
		String nomEmail = (String)user.get("nom_email");
		Integer id = (Integer)user.get("num_postulante");
		String generaClaveAcceso = generaClaveAcceso();
		Usuario param = new Usuario();
		param.setNumPostulante(id);
		param.setCodToken(generaClaveAcceso);
		param.setFecGeneratoken(new Date());
		param.setIndEstado(estado);
		param.setCodUsumodif(String.valueOf(id));
		param.setFecModif(new Date());
		usuarioDAO.updateByPrimaryKeySelective(param);

		String nombreCompleto;
		if(user.get("ape_materno")==null){
			nombreCompleto = user.get("ape_paterno").toString() + " " + user.get("nom_postulante").toString();
		}else{
			nombreCompleto =   user.get("ape_paterno").toString() + " " +  user.get("ape_materno").toString() + " " + user.get("nom_postulante").toString();
		}
				
		try {
			sendCorreoOlvidoClave(generaClaveAcceso, nomEmail, nombreCompleto, asunto);	
		}catch(Exception e) {
			log.info("Ocurri� una excepcion al enviar el correo.",e);
		}
		
	}

	
	//cambia estado a bloqueado y genera clave acceso
	public void updateOlvidoClave(Map<String, Object> user, String asunto, String estado){
		//cambia estado a bloqueado y genera clave acceso
		String nomEmail = (String)user.get("nom_email");
		Integer id = (Integer)user.get("num_postulante");
		String generaClaveAcceso = generaClaveAcceso();
		Usuario param = new Usuario();
		param.setNumPostulante(id);
		param.setCodToken(generaClaveAcceso);
		param.setFecGeneratoken(new Date());
		param.setIndEstado(estado);
		param.setCodUsumodif(String.valueOf(id));
		param.setFecModif(new Date());
		usuarioDAO.updateByPrimaryKeySelective(param);

		String nombreCompleto;
		if(user.get("ape_materno")==null){
			nombreCompleto = user.get("ape_paterno").toString() + " " + user.get("nom_postulante").toString();
		}else{
			nombreCompleto =   user.get("ape_paterno").toString() + " " +  user.get("ape_materno").toString() + " " + user.get("nom_postulante").toString();
		}
				
		try {
			sendCorreoOlvidoClave(generaClaveAcceso, nomEmail.toUpperCase(), nombreCompleto, asunto);	
		}catch(Exception e) {
			log.info("Ocurri� una excepcion al enviar el correo.",e);
		}
		
	}
	
	/***
	 * genera token
	 * 
	 */
	public String generaClaveAcceso(){ 
		Random r = new Random( System.currentTimeMillis() );
	    return String.valueOf((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));	
	}
	
	/**
	 *  return:
	 * 1: correcto
	 * 2: usuario con correo ya existe, estado X
	 * 3: numero de documento ya existe, estado X
	 * 4: numero de documento no se encuentra en RENIEC
	 * 
	 */
	
	public Usuario getUsuario(String nomEmail){
		Map<String, Object> user = usuarioDAO.selectByEmail(nomEmail.toUpperCase());
		return usuarioDAO.selectByPrimaryKey((Integer)user.get("num_postulante"));
	}
	
	
	public int validarMail(String nomEmail){
		
		
		Map<String, Object> user = usuarioDAO.selectByEmail(nomEmail.toUpperCase());
		
		if(user!=null && MapUtils.isNotEmpty(user)){
			log.debug("Usuario ya existe: " + nomEmail+ ", estado: " + user.get("IND_ESTADO"));
			return 2;
		}
			return 0;	
	}
	
	
	public int validarDocumento(String codtipdoc, String numdoc){
		
		
		Usuario param = new Usuario();
		param.setCodTipoDoc(codtipdoc);
		param.setNumDocId(numdoc.toUpperCase());
		
		List<Usuario> lst = usuarioDAO.selectBySelective(param);
		if(CollectionUtils.isNotEmpty(lst)){
			Usuario guardado = lst.get(0);
			log.debug("Usuario ya existe: codtipdoc: " + codtipdoc + ", numDoc: " + numdoc.toUpperCase() + ", estado: " + guardado.getIndEstado());
			return 3;
		}
		return 0;	
	}
	
	
	public int crearCuenta(Usuario usuario){
		
		String nomEmail = usuario.getNomEmail();
		
		Map<String, Object> user = usuarioDAO.selectByEmail(nomEmail);
		
		if(user!=null){
			log.debug("Usuario ya existe: " + usuario.getNomEmail() + ", estado: " + user.get("IND_ESTADO"));
			return 2;
		}
		
		
		Usuario param = new Usuario();
		param.setCodTipoDoc(usuario.getCodTipoDoc());
		param.setNumDocId(usuario.getNumDocId());
		
		List<Usuario> lst = usuarioDAO.selectBySelective(param);
		if(CollectionUtils.isNotEmpty(lst)){
			Usuario guardado = lst.get(0);
			log.debug("Usuario ya existe: codtipdoc: " + usuario.getCodTipoDoc() + "numDoc: " + usuario.getNumDocId() + ", estado: " + guardado.getIndEstado());
			return 3;
		}
				
		//VALIDA EN EL SERVICIO DE RENIEC
		try {
			String claveAcceso = generaClaveAcceso();
			usuario.setCodToken(claveAcceso);
		      HashPass hashPWD = new HashPass();
		      String hash = hashPWD.passWord(usuario.getNomClave(), hashPWD.getSaltString());
		      usuario.setNomClave(hash);
		      usuario.setNomEmail(usuario.getNomEmail().toUpperCase());
		      usuario.setApePaterno(usuario.getApePaterno().toUpperCase());
		      usuario.setApeMaterno(usuario.getApeMaterno()!=null?usuario.getApeMaterno().toUpperCase():StringUtils.EMPTY);
		      usuario.setNomPostulante(usuario.getNomPostulante().toUpperCase());
			usuarioDAO.insertSelective(usuario);
		    String nombreCompleto;
			if(StringUtils.isBlank(usuario.getApeMaterno())){
				nombreCompleto = usuario.getApePaterno() + " " + usuario.getNomPostulante();
			}else{
				nombreCompleto =   usuario.getApePaterno() + " " + usuario.getApeMaterno() + " " + usuario.getNomPostulante();
			}
			
			sendCorreoCrearCuenta(claveAcceso, usuario.getNomEmail().toUpperCase(),  nombreCompleto);	
		}catch(Exception e) {
			log.info("Ocurri� una excepcion al crear la cuenta",e);
		}
		
		return 1;
	}
	
	/**
	 *  return:
	 * 1: correcto
	 * 2: claves distintas 
	 * 3: correo (usuario) no existe 
	 * 
	 */
	public int registrarNuevaClave(String nuevaClave, String confirmarClave, String nomEmail){
		
		
		
		if(!nuevaClave.equals(confirmarClave)){
			return 2;
		}
		
		Map<String, Object> user = usuarioDAO.selectByEmail(nomEmail.toUpperCase());
		
		if(user==null){
			log.debug("Usuario no existe: " + nomEmail.toUpperCase());
			return 3;
		}
		
		try {
			HashPass hashPWD = new HashPass();
		    String hash = hashPWD.passWord(nuevaClave, hashPWD.getSaltString());
			
			Usuario param = new Usuario();
			param.setNumPostulante((Integer)user.get("num_postulante"));
			param.setNomClave(hash);
			param.setIndEstado("D");
			param.setCodUsumodif(String.valueOf(user.get("num_postulante")));
			param.setFecModif(new Date());
			param.setNomClave(hash);
			
					
			usuarioDAO.updateByPrimaryKeySelective(param);	
		}catch(Exception e) {
			log.info("Ocurri� una excepcion al registrar la nueva clave",e);
		}
		return 1;
	}
	
    
	public void sendCorreoCrearCuenta(String claveAcceso, String correo, String nombres) {
        /* Se envia correo  */
        
		try {
            if(correo!=null){

    			final String msg = "Hola " +  nombres + "<BR>&nbsp;<BR>"

    			+ "Acabas de crear tu cuenta en el Sistema de Postulaci&oacute;n de SUNAT, la cual permitir&aacute; realizar tu postulaci&oacute;n electr&oacute;nica. <BR>&nbsp;<BR>"
    			+ "Para iniciar sesi&oacute;n en el sistema deber&aacute;s ingresar el correo electr&oacute;nico y la contrase�a que creaste al momento del registro, recuerda que estas credenciales son de uso estrictamente personal.<BR>&nbsp;<BR>"
    			+ "Adicionalmente, te env&iacute;amos un c&oacute;digo para validar tu registro.<BR>&nbsp;<BR>"

    			+ "Usuario: " + correo.toLowerCase() + "<BR>&nbsp;<BR>"
    			+ "Contrase�a: La que creaste al momento del Registro.<BR>&nbsp;<BR>"
    			+ "C&oacute;digo para validar tu registro: " + claveAcceso + "<BR>&nbsp;<BR>"

    			+ "Recuerda que el C&oacute;digo para validar su registro tiene vigencia de 24 horas.<BR>&nbsp;<BR>"

    			+ "Atentamente.<BR>&nbsp;<BR>"

    			+ "Divisi�n de Dotaci&oacute;n<BR>&nbsp;<BR>"
    			+ "Intendencia Nacional de Recursos Humanos";
            	
    			Properties properties = new Properties();
    			properties.load(AccesoPostulacionServiceImpl.class.getResourceAsStream("/correo.properties"));
    			String servidor = properties.getProperty("servidor");
    			String correoRemitentePorDefecto = properties.getProperty("correoRemitentePorDefecto");
    			String asuntoPorDefecto = properties.getProperty("asuntoPorDefecto");
    			
            	Properties props = new Properties();
        		props.setProperty("mail.smtp.host", servidor);
        		props.setProperty("mail.smtp.starttls.enable", "true");
        		props.setProperty("mail.smtp.port", "25");
        		props.setProperty("mail.smtp.auth", "false");
        		
        		Session session = Session.getDefaultInstance(props);
                session.setDebug(true);
                
                // Create a default MimeMessage object.
                Message message = new MimeMessage(session);

                // Set From: header field of the header.
                message.setFrom(new InternetAddress(correoRemitentePorDefecto));

                // Set To: header field of the header.
                message.setRecipients(Message.RecipientType.TO,
                   InternetAddress.parse(correo.toLowerCase().trim()));

                // Set Subject: header field
                message.setSubject(asuntoPorDefecto);

                message.setContent(msg, "text/html; charset=utf-8" );
                // Send message
                Transport.send(message);            
            	
    			log.debug("******* expAduana: se envia correo. correo=" + message +  " *************");					
            
            }
        	
        }catch(Exception e) {
        	log.info("Ocurrio un error al enviar correo.",e);
        }
		
	}
	
	public void sendCorreoOlvidoClave(String claveAcceso, String correo, String nombres,final String asuntoMsg) throws MessagingException,IOException{
        /* Se envia correo  */

        
        if(correo!=null){
        	
        	final String msg = "Estimado(a) Sr(a): " +   nombres + "<BR>&nbsp;<BR>" + 
				"Hemos recibido su solicitud de Recuperar Clave y se ha generado la siguiente contrase�a temporal: <BR>&nbsp;<BR>" + 
				claveAcceso + "<BR>&nbsp;<BR>" + 
				"Le recordamos ingresar a nuestro Portal de Postulaci&oacute;n Web y cambiar su contrase�a.<BR>&nbsp;<BR>" + 
				"Atte.";
        	
			Properties properties = new Properties();
			properties.load(AccesoPostulacionServiceImpl.class.getResourceAsStream("/correo.properties"));
			String servidor = properties.getProperty("servidor");
			String correoRemitentePorDefecto = properties.getProperty("correoRemitentePorDefecto");
			String asuntoPorDefecto = properties.getProperty("asuntoPorDefecto");
			
        	Properties props = new Properties();
    		props.setProperty("mail.smtp.host", servidor);
    		props.setProperty("mail.smtp.starttls.enable", "true");
    		props.setProperty("mail.smtp.port", "25");
    		props.setProperty("mail.smtp.auth", "false");
    		
    		Session session = Session.getDefaultInstance(props);
            session.setDebug(true);
            
         // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(correoRemitentePorDefecto));

            // Set To: header field of the header.
            message.setRecipients(Message.RecipientType.TO,
               InternetAddress.parse(correo.toLowerCase().trim()));

            // Set Subject: header field
            message.setSubject(asuntoPorDefecto);

            message.setContent(msg, "text/html; charset=utf-8" );
            // Send message
            Transport.send(message);            
        	
			log.debug("******* expAduana: se envia correo. correo=" + message +  " *************");					
        
        }
		
	}
	
  
	
	// Obtener datos de webservicereniec
	public Map<String, Object> obtenerDatosReniec(String numDoc, String tipDoc) {
		Map<String, Object> t733 = null;
		try {
			t733 = t733DAO.findByPK(numDoc, tipDoc);
			if(t733!=null && MapUtils.isNotEmpty(t733) && t733.get("fec_nac_pnat")!=null){
				
				
				Date fecNac = (Date)t733.get("fec_nac_pnat");
				
				SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
				
				String fecNacStr = df.format(fecNac);
				t733.put("fecNacStr", fecNacStr);
				t733.put("cod", "1");
			} else {
				t733 = new HashMap<>();
				t733.put("cod", "0");
			}
		}
		
		catch (Exception e) {
			log.info("error", e);
		}
		return t733;
	}
		

	
	public static void main(String... args){
		SecureRandom random = new SecureRandom();

	    System.out.println(new BigInteger(130, random).toString(32));
	    		
		
	}


	@Override
	public Usuario getUsuarioPorId(Integer numPostulante) {
		return usuarioDAO.selectByPrimaryKey(numPostulante);
		
	}
	
}
