package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;

public interface ParamContribuyenteDAO {

	List<Parametro> listarDepartamentos();
	List<Parametro> listarProvincias(String codDepartamento);
	List<Parametro> listarDistritos(String codProvincia);
	List<Parametro> listarParametros(String codParametro);
	
}
