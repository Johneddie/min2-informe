package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.CodigosRrhhDAO;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;

public class CodigosRrhhDAOImpl extends SqlMapDAOBase implements CodigosRrhhDAO{

	@Override
	public List<Parametro> listarParametros(String codParametro, String codEstado) {
		Parametro param = new Parametro();
		param.setCodParametro(codParametro);
		param.setCodEstado(codEstado);
		return getSqlMapClientTemplate().queryForList("t99codigos.listarParametros",param);
	}
	
	@Override
	public List<Parametro> selectByParams(Map<String, Object> params){
		return (List<Parametro>)getSqlMapClientTemplate().queryForList("t99codigos.selectByParams", params);
	}

	@Override
	public Parametro selectByPrimaryKey(String codParametro, String codDataParametro) {
		Parametro paramSearch = new Parametro();
		paramSearch.setCodParametro(codParametro);
		paramSearch.setCodDataParametro(codDataParametro);
		return (Parametro)getSqlMapClientTemplate().queryForObject("t99codigos.selectByPrimaryKey", paramSearch);
	}

	@Override
	public List<Parametro> listarParametros(String codParametro,
			String codEstado, List<String> notIncluir) {
		Parametro param = new Parametro();
		param.setCodParametro(codParametro);
		param.setCodEstado(codEstado);
		param.setNotIncluir(notIncluir);
		return getSqlMapClientTemplate().queryForList("t99codigos.listarParametros",param);
	} 

	@Override
	public List<Parametro> listarNiveles(String codTipoEstudio) {
		Map<String,Object> param = new HashMap<>();
		param.put(Constantes.PROPERTIES_ITEM_TIPO_ESTUDIO, codTipoEstudio);
		return getSqlMapClientTemplate().queryForList("t99codigos.listarNiveles",param);
	}

	@Override
	public List<Parametro> listarCiclos(String codTipoEstudio, String codNivel) {
		Map<String,Object> param = new HashMap<>();
		param.put(Constantes.PROPERTIES_ITEM_TIPO_ESTUDIO, codTipoEstudio);
		param.put("codNivel", codNivel);
		return getSqlMapClientTemplate().queryForList("t99codigos.listarCiclos",param);
	}

	@Override
	public List<Parametro> listarCarreras(String codTipoEstudio) {
		Map<String,Object> param = new HashMap<>();
		param.put(Constantes.PROPERTIES_ITEM_TIPO_ESTUDIO, codTipoEstudio);
		return getSqlMapClientTemplate().queryForList("t99codigos.listarCarreras",param);
	}

	@Override
	public List<Parametro> listarCentrosEstudio() {
		return getSqlMapClientTemplate().queryForList("t99codigos.listarCentrosEstudio");
	}

	@Override
	public Parametro getMensajeInicio() {
		return (Parametro)getSqlMapClientTemplate().queryForObject("t99codigos.getMensajeInicio");
	}
}
