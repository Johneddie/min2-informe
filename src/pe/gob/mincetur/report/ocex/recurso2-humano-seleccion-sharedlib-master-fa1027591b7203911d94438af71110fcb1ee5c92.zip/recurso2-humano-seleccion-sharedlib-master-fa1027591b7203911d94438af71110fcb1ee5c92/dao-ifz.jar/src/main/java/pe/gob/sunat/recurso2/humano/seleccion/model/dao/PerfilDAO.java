package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Perfil;

public interface PerfilDAO {

	Perfil selectByPrimaryKey(Integer codProceso);
}
