package pe.gob.sunat.recurso2.humano.seleccion.service;

import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.USUARIO_POSTULACION;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DdjjPostulacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Ficha;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimientoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimientoHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimientoHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacionHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacionHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidadExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidadHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidadHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PostulacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Seguimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ArchivoPostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.DdjjPostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaConocimientoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaConocimientoHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEducacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEducacionHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEspecialidadDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEspecialidadHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaExperienciaDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaExperienciaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.SeguimientoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.UsuarioDAO;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;

@Service("registroPostulacionService")
public class RegistroPostulacionServiceImpl implements RegistroPostulacionService{
	
	public final Log log = LogFactory.getLog(getClass());
	
	
	@Autowired
	private FichaConocimientoDAO fichaConocimientoDAO;
	
	@Autowired
	private FichaDAO fichaDAO;
	
	@Autowired
	private FichaEducacionDAO fichaEducacionDAO;
	
	@Autowired
	private FichaEspecialidadDAO fichaEspecialidadDAO;
	
	@Autowired
	private FichaExperienciaDAO fichaExperienciaDAO;
	
	
	@Autowired
	private ArchivoPostulacionDAO archivoPostulacionDAO;
	
	@Autowired
	private DdjjPostulacionDAO ddjjPostulacionDAO;
	
	@Autowired
	private PostulacionDAO postulacionDAO;
	
	@Autowired
	private FichaHistoricoDAO fichaHistoricoDAO;
	
	@Autowired
	private FichaEducacionHistoricoDAO fichaEducacionHistoricoDAO;
	
	@Autowired
	private FichaEspecialidadHistoricoDAO fichaEspecialidadHistoricoDAO;
	
	@Autowired
	private FichaConocimientoHistoricoDAO fichaConocimientoHistoricoDAO;
	
	@Autowired
	private FichaExperienciaHistoricoDAO fichaExperienciaHistoricoDAO;
	
	@Autowired
	private UsuarioDAO usuarioDAO;
	
	@Autowired
	private SeguimientoDAO seguimientoDAO;
	

	@Override
	public boolean registrarActualizarFichaDatos(Ficha ficha) {
		log.info("Iniciando registro, actualizaci�n de datos a la ficha...");
		boolean transaccionOk = false;
		try{
			Ficha fichaBD = fichaDAO.selectByPrimaryKey(ficha.getNumPostulante());
			if(fichaBD==null){
				//registramos la ficha
				ficha.setFecRegis(new Date());
				ficha.setCodUsuregis(USUARIO_POSTULACION); 
				fichaDAO.insertSelective(ficha);
			}else{
				ficha.setFecModif(new Date());
				ficha.setCodUsumodif(USUARIO_POSTULACION);
				fichaDAO.updateByPrimaryKeySelective(ficha);
			}	
			transaccionOk = true;
		}catch(Exception e){
			log.info("Ocurri� un error al insertar/actualizar la ficha.",e);
		}
		
		return transaccionOk;
	}

	@Override
	public Ficha getFichaDatos(Integer numPostulante) {
		return fichaDAO.selectByPrimaryKey(numPostulante);
	}

	@Override
	public boolean registrarEducacion(FichaEducacion ficha) {
		boolean registrado = false;
		int numero;
		try{			
			
		    if(StringUtils.isBlank(ficha.getCodTipoEstudio()) && StringUtils.isBlank(ficha.getCodEspecialidad()) &&
	    		StringUtils.isBlank(ficha.getCodNivelEducativ()) && StringUtils.isBlank(ficha.getCodCentroEstudio()) &&
	    		StringUtils.isBlank(ficha.getIndPuestoUniv())) {
				ficha.setMensajeError("El tipo de Estudio no puede estar Vacio");
				
			} else {			
					if(ficha.getNumIdAcadem()!=null){
						//Actualizaci�n
						ficha.setFecModif(new Date());
						ficha.setCodUsumodif(USUARIO_POSTULACION);
						fichaEducacionDAO.updateByPrimaryKeySelective(ficha);	
						registrado = true;								
					}else{
						//Inserci�n
						numero = fichaEducacionDAO.countByFicha(ficha);						
						if (numero == 0) {
							ficha.setFecRegis(new Date());
							ficha.setCodUsuregis(USUARIO_POSTULACION);
							fichaEducacionDAO.insertSelective(ficha);
							registrado = true;		
						} else {
							ficha.setMensajeError("Ya existe una formaci�n acad�mica con estos datos, por favor verificar");
						}
					}
			}						
		}catch(Exception e){
			log.info("Ocurri� un error al registrar la formaci�n academica.",e);
		}
		return registrado;
	}

	
	
	
	@Override
	public boolean borrarDatosEducativos(Integer numIdAcadem) {
		boolean borrado = false;
		try{
			fichaEducacionDAO.deleteByPrimaryKey(numIdAcadem);
			borrado = true;
		}catch(Exception e){
			log.info("Ocurri� un error al borrar la formaci�n academica.",e);
		}
		return borrado;
	}
	

	@Override
	public List<FichaEducacion> listarDatosEducativos(Integer numPostulante) {
		FichaEducacion paramSearch = new FichaEducacion();
		paramSearch.setNumPostulante(numPostulante);
		
		List<FichaEducacion> estudios = fichaEducacionDAO.listarDatosEducativos(paramSearch);
		for(FichaEducacion e:estudios){
			if(e.getNumArcPostula()!=null){
				ArchivoPostulacion ap = archivoPostulacionDAO.selectByPrimaryKeyWithoutBLOBs(e.getNumArcPostula());
				e.setNomArchivo(ap.getNomArchivo());
			}
		}
		return estudios;
	}

	@Override
	public List<FichaConocimiento> listarConocimientosTecnicos(
			Integer numPostulante) {
		FichaConocimientoExample param = new FichaConocimientoExample() ;
		FichaConocimientoExample.Criteria criterio = param.createCriteria();
		criterio.andNumPostulanteEqualTo(numPostulante);
		criterio.andCodTipconoEqualTo("1");//tipo de conocimiento tecnico...
		param.setOrderByClause(" num_id_conocimient desc ");
		return fichaConocimientoDAO.selectByExample(param);
	}
	
	
	@Override
	public boolean registrarConocimientoTecnico(FichaConocimiento ficha) {
		boolean registrado = false;
		try{
			if(StringUtils.isBlank(ficha.getCodConocimiento()) && StringUtils.isBlank(ficha.getCodTipcono()) &&  StringUtils.isBlank(ficha.getCodNivel())) {
				registrado = false;		
			} else {
						
					if(ficha.getNumIdConocimient()!=null){
						//Actualizaci�n
						ficha.setFecModif(new Date());
						ficha.setCodUsumodif(USUARIO_POSTULACION);						
						fichaConocimientoDAO.updateByPrimaryKeySelective(ficha);	
					}else{
						//Inserci�n
						ficha.setFecRegis(new Date());
						ficha.setCodUsuregis(USUARIO_POSTULACION);
						fichaConocimientoDAO.insertSelective(ficha);
					}
				registrado = true;
			}
			
		}catch(Exception e){
			log.info("Ocurri� un error al registrar el conocimiento tecnico.",e);
		}
		return registrado;
	}

	@Override
	public boolean borrarConocimientoTecnico(Integer numIdConocimient) {
		boolean borrado = false;
		try{
			fichaConocimientoDAO.deleteByPrimaryKey(numIdConocimient);
			borrado = true;
		}catch(Exception e){
			log.info("Ocurri� un error al borrar el conocimiento tecnico.",e);
		}
		return borrado;
	}

	@Override
	public List<FichaConocimiento> listarConocimientosInformaticos(
			Integer numPostulante) {
		FichaConocimientoExample param = new FichaConocimientoExample() ;
		FichaConocimientoExample.Criteria criterio = param.createCriteria();
		criterio.andNumPostulanteEqualTo(numPostulante);
		List<String> listaValores = new ArrayList<>();
		listaValores.add("2");//Conocimientos informaticos
		listaValores.add("3");//Conocimientos de idiomas
		criterio.andCodTipconoIn(listaValores);
		param.setOrderByClause(" num_id_conocimient desc ");
		return fichaConocimientoDAO.selectByExample(param);
	}

	@Override
	public boolean registrarEstudioEspecializacion(FichaEspecialidad ficha) {
		boolean registrado = false;
		try{
			
			if(ficha.getNumIdIstAcadem()!=null){
				//Actualizaci�n
				ficha.setFecModif(new Date());
				ficha.setCodUsumodif(USUARIO_POSTULACION);
				fichaEspecialidadDAO.updateByPrimaryKeySelective(ficha);	
			}else{
				//Inserci�n
				ficha.setFecRegis(new Date());
				ficha.setCodUsuregis(USUARIO_POSTULACION);
				fichaEspecialidadDAO.insertSelective(ficha);
			}
			registrado = true;
			
		}catch(Exception e){
			log.info("Ocurri� un error al registrar el estudio de especializaci�n.",e);
		}
		return registrado;
	}

	@Override
	public boolean borrarEstudioEspecializacion(Integer numIdIstAcadem) {
		boolean borrado = false;
		try{
			fichaEspecialidadDAO.deleteByPrimaryKey(numIdIstAcadem);
			borrado = true;
		}catch(Exception e){
			log.info("Ocurri� un error al borrar el estudio de especializaci�n.",e);
		}
		return borrado;
	}

	@Override
	public List<FichaEspecialidad> listarEstudiosEspecializacion(
			Integer numPostulante, String indCertificacion) {
		FichaEspecialidad paramSearch = new FichaEspecialidad();
		paramSearch.setNumPostulante(numPostulante);
		paramSearch.setIndCertificacion(indCertificacion);
		List<FichaEspecialidad> estudios = fichaEspecialidadDAO.listarEstudiosEspecializacion(paramSearch); 
		for(FichaEspecialidad e:estudios){
			if(e.getNumArcPostula()!=null){
				ArchivoPostulacion ap = archivoPostulacionDAO.selectByPrimaryKeyWithoutBLOBs(e.getNumArcPostula());
				e.setNomArchivo(ap.getNomArchivo());
			}
		}
		return estudios;
		
	}

	@Override
	public boolean registrarExperienciaLaboral(FichaExperiencia ficha) {
		boolean registrado = false;
		try{
			
			if(StringUtils.isBlank(ficha.getCodTipocontrato()) && StringUtils.isBlank(ficha.getCodTipoentidad()) && 
			   StringUtils.isBlank(ficha.getCodTipoexpe()) && StringUtils.isBlank(ficha.getDesEntidad())) {
				
			}else {
			
				if(ficha.getNumIdExpe()!=null){
					//Actualizaci�n
					ficha.setFecModif(new Date());
					ficha.setCodUsumodif(USUARIO_POSTULACION);
					fichaExperienciaDAO.updateByPrimaryKeySelective(ficha);	
				}else{
					//Inserci�n
					ficha.setFecRegis(new Date());
					ficha.setCodUsuregis(USUARIO_POSTULACION);
					fichaExperienciaDAO.insertSelective(ficha);
				}
				registrado = true;
			}
			
		}catch(Exception e){
			log.info("Ocurri� un error al registrar la experiencia laboral.",e);
		}
		return registrado;
	}

	@Override
	public boolean borrarExperienciaLaboral(Integer numIdIstAcadem) {
		boolean borrado = false;
		try{
			fichaExperienciaDAO.deleteByPrimaryKey(numIdIstAcadem);
			borrado = true;
		}catch(Exception e){
			log.info("Ocurri� un error al borrar el conocimiento tecnico.",e);
		}
		return borrado;
	}

	@Override
	public List<FichaExperiencia> listarExperienciaLaboral(Integer numPostulante) {
		FichaExperienciaExample param = new FichaExperienciaExample() ;
		FichaExperienciaExample.Criteria criterio = param.createCriteria();
		criterio.andNumPostulanteEqualTo(numPostulante);
		param.setOrderByClause(" num_id_expe desc ");
		List<FichaExperiencia> lstExperiencia = fichaExperienciaDAO.selectByExample(param);
		for(FichaExperiencia e:lstExperiencia){
			if(e.getNumArcPostula()!=null){
				ArchivoPostulacion ap = archivoPostulacionDAO.selectByPrimaryKeyWithoutBLOBs(e.getNumArcPostula());
				e.setNomArchivo(ap.getNomArchivo());
			}
		}
		return lstExperiencia;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Integer registrarArchivo(String nomArchivo, Integer numPostulante, byte[] arcPostula) {
		Integer numArcPostula = null;
		try{
			ArchivoPostulacion ap = new ArchivoPostulacion();
			ap.setNomArchivo(nomArchivo);
			ap.setNumTamano(arcPostula.length);
			ap.setCodUsuregis(numPostulante.toString());
			ap.setFecRegis(new Date());
			numArcPostula = archivoPostulacionDAO.insertSelective(ap);
			
			HashMap params=new HashMap();
		    params.put("numArcPostula", numArcPostula);
		    params.put("arcPostula", arcPostula);
		    archivoPostulacionDAO.updateBlob(params);
			
		}catch(Exception e){
			log.info("Ha ocurrido un error en registrarArchivo: " + e.getMessage(), e);
		}
		return numArcPostula;
	}
	
	@Override
	public ArchivoPostulacion obtenerArchivoPostulacion(Integer numArcPostula) {
		return archivoPostulacionDAO.selectByPrimaryKey(numArcPostula);
	}
 
	@Override
	public List<FichaConocimiento> listarConocimiento(Integer numPostulante) {
		return fichaConocimientoDAO.listarConocimiento(numPostulante);
				
	}
	
	
	public void generarHistorico(Integer numPostulante, String codPuesto, Short codCat) {
		
		//borramos la postulaci�n hist�rica si es que la hubiera para el proceso.
		eliminarPostulacionHistorica(numPostulante,codPuesto,codCat);
		
		//1. Copiamos los datos de la ficha de postulacion
		Ficha ficha = fichaDAO.selectByPrimaryKey(numPostulante);
		
		Usuario usuario = usuarioDAO.selectByPrimaryKey(numPostulante);
		
		FichaHistorico fichaH = new FichaHistorico();//Insertamos la ficha hist�rica.
		fichaH.setCodCat(codCat);//1
		fichaH.setCodPuesto(codPuesto);//2
		fichaH.setNumPostulante(numPostulante);//3
		
		//datos del usuario
		fichaH.setCodTipoDoc(usuario.getCodTipoDoc());//4
		fichaH.setNumDocId(usuario.getNumDocId());//5
		fichaH.setNomEmail(usuario.getNomEmail());//6
		fichaH.setNomPostulante(usuario.getNomPostulante());//7
		
		fichaH.setApePaterno(usuario.getApePaterno());//8
		fichaH.setApeMaterno(usuario.getApeMaterno());//9
		fichaH.setFecNacimiento(usuario.getFecNacimiento());//10
		fichaH.setCodEstcivil(ficha.getCodEstcivil());//11
		fichaH.setCodUbigeonac(ficha.getCodUbigeonac());//12
		
		fichaH.setCodUbigeodom(ficha.getCodUbigeodom());//13
		fichaH.setCodTipzona(ficha.getCodTipzona());//14
		fichaH.setNomZona(ficha.getNomZona());//15
		fichaH.setCodTipvia(ficha.getCodTipvia());//16
		fichaH.setNomVia(ficha.getNomVia());//17
		
		fichaH.setNumDom(ficha.getNumDom());//18
		fichaH.setNumTelcasa(ficha.getNumTelcasa());//19
		fichaH.setNumTelcelular(ficha.getNumTelcelular());//20
		fichaH.setIndAnterior(ficha.getIndAnterior());//21
		fichaH.setNumLicencia(ficha.getNumLicencia());//22
		
		fichaH.setDirCarpetaarchivo(ficha.getDirCarpetaarchivo());//23
		fichaH.setMtoPretensionecon(ficha.getMtoPretensionecon());//24
		fichaH.setIndSunatId(ficha.getIndSunatId());//25
		fichaH.setDesFamilSunat(ficha.getDesFamilSunat());//26
		fichaH.setIndSunat(ficha.getIndSunat());//27
		
		fichaH.setIndDiscapacitado(ficha.getIndDiscapacitado());//28
		fichaH.setCodExamen(ficha.getCodExamen());//29
		fichaH.setCodEstado(ficha.getCodEstado());//30
		fichaH.setDesDiscapacidad(ficha.getDesDiscapacidad());//31
		fichaH.setIndLabor(ficha.getIndLabor());//32
		
		fichaH.setIndSexo(ficha.getIndSexo());//33
		fichaH.setIndSede1(ficha.getIndSede1());//34
		fichaH.setIndSede2(ficha.getIndSede2());//35
		fichaH.setNumRuc(ficha.getNumRuc());//36
		fichaH.setCodCatLicencia(ficha.getCodCatLicencia());//37
		
		fichaH.setNumColegiatura(ficha.getNumColegiatura());//38
		fichaH.setIndColegiatura(ficha.getIndColegiatura());//39
		fichaH.setCodUsuregis(ficha.getCodUsuregis());//40
		fichaH.setFecRegis(ficha.getFecRegis());//41
		fichaH.setCodUsumodif(ficha.getCodUsumodif());//42
		
		fichaH.setFecModif(ficha.getFecModif());//43
		fichaH.setCodUsuproc(Constantes.USUARIO_POSTULACION);//44
		fichaH.setFecProceso(new Date());//45
		
		fichaHistoricoDAO.insertSelective(fichaH);
		
		
		//2. Replicamos los datos de informaci�n acad�mica
		FichaEducacionExample paramSearchEducacion = new FichaEducacionExample();
		FichaEducacionExample.Criteria criteriaEducacion = paramSearchEducacion.createCriteria();
		criteriaEducacion.andNumPostulanteEqualTo(numPostulante);
		List<FichaEducacion> estudios = fichaEducacionDAO.selectByExample(paramSearchEducacion);
		short correlativo = 1;
		for(FichaEducacion e:estudios){
			FichaEducacionHistorico eh = new FichaEducacionHistorico();
			eh.setCodCat(codCat);//1
			eh.setCodPuesto(codPuesto);//2
			eh.setNumPostulante(numPostulante);//3
			eh.setNumCorrel(correlativo++);//4
			eh.setCodEspecialidad(e.getCodEspecialidad());//5
			
			eh.setCodNivelEducativ(e.getCodNivelEducativ());//6
			eh.setCodCentroEstudio(e.getCodCentroEstudio());//7
			eh.setNomCentroEstudio(e.getNomCentroEstudio());//8
			eh.setNomProfesion(e.getNomProfesion());//9
			eh.setIndPuestoUniv(e.getIndPuestoUniv());//10
			
			eh.setFecInicio(e.getFecInicio());//11
			eh.setFecFin(e.getFecFin());//12
			eh.setFecGrado(e.getFecGrado());//13
			eh.setFecEgreso(e.getFecEgreso());//14
			eh.setCodUsuregis(e.getCodUsuregis());//15
			
			eh.setFecRegis(e.getFecRegis());//16
			eh.setCodUsumodif(e.getCodUsumodif());//17
			eh.setFecModif(e.getFecModif());//18
			eh.setCodUsuproc(Constantes.USUARIO_POSTULACION);//19
			eh.setFecProceso(new Date());//20
			
			eh.setNumArcPostula(e.getNumArcPostula());//21
			eh.setCodTipoEstudio(e.getCodTipoEstudio());//22
			eh.setCodCiclo(e.getCodCiclo());//23
			
			fichaEducacionHistoricoDAO.insertSelective(eh);
		}
		
		//3. replicamos los datos de la especialidad
		correlativo = 1;
		FichaEspecialidadExample paramSearchEspecialidad = new FichaEspecialidadExample();
		FichaEspecialidadExample.Criteria criteriaEspecialidad = paramSearchEspecialidad.createCriteria();
		criteriaEspecialidad.andNumPostulanteEqualTo(numPostulante);
		List<FichaEspecialidad> especialidades = fichaEspecialidadDAO.selectByExample(paramSearchEspecialidad);
		for(FichaEspecialidad e:especialidades){
			FichaEspecialidadHistorico eh = new FichaEspecialidadHistorico();
			eh.setCodCat(codCat);//1
			eh.setCodPuesto(codPuesto);//2
			eh.setNumPostulante(numPostulante);//3
			eh.setNumCorrel(correlativo++);//4
			
			eh.setNomEspecialidad(e.getNomEspecialidad());//5
			eh.setCodCentroEstudio(e.getCodCentroEstudio());//6
			eh.setNomCentroEstudio(e.getNomCentroEstudio());//7
			eh.setFecInicio(e.getFecInicio());//8
			eh.setFecFin(e.getFecFin());//9
			
			eh.setCntHoraLectiva(e.getCntHoraLectiva());//10
			eh.setFecCertificado(e.getFecCertificado());//11
			eh.setCodUsuregis(e.getCodUsuregis());//12
			eh.setFecRegis(e.getFecRegis());//13
			eh.setCodUsumodif(e.getCodUsumodif());//14
			
			eh.setFecModif(e.getFecModif());//15
			eh.setCodUsuproc(Constantes.USUARIO_POSTULACION);//16
			eh.setFecProceso(new Date());//17
			eh.setNumArcPostula(e.getNumArcPostula());//18
			eh.setIndCertificacion(e.getIndCertificacion());//19
			
			fichaEspecialidadHistoricoDAO.insertSelective(eh);
		}
		
		//4. replicamos los datos de los conocimientos inform�ticos y de idiomas
		correlativo = 1;
		FichaConocimientoExample paramSearchConocimiento = new FichaConocimientoExample();
		FichaConocimientoExample.Criteria criteriaConocimiento = paramSearchConocimiento.createCriteria();
		criteriaConocimiento.andNumPostulanteEqualTo(numPostulante);
		List<FichaConocimiento> conocimientos = fichaConocimientoDAO.selectByExample(paramSearchConocimiento);
		for(FichaConocimiento e:conocimientos){
			FichaConocimientoHistorico eh = new FichaConocimientoHistorico();
			eh.setCodCat(codCat);//1
			eh.setCodPuesto(codPuesto);//2
			eh.setNumPostulante(numPostulante);//3
			eh.setNumCorrel(correlativo++);//4
			
			eh.setCodTipcono(e.getCodTipcono());//5
			eh.setCodConocimiento(e.getCodConocimiento());//6
			eh.setCodNivel(e.getCodNivel());//7
			eh.setNomConcomiento(e.getNomConcomiento());//8
			eh.setCodUsuregis(e.getCodUsuregis());//9
			
			eh.setFecRegis(e.getFecRegis());//10
			eh.setCodUsumodif(e.getCodUsumodif());//11
			eh.setFecModif(e.getFecModif());//12
			eh.setCodUsuproc(Constantes.USUARIO_POSTULACION);//13
			eh.setFecProceso(new Date());//14

			fichaConocimientoHistoricoDAO.insertSelective(eh);
		}
		
		//5. replicamos los datos de la experiencia laboral
		correlativo = 1;
		FichaExperienciaExample paramSearchExperiencia = new FichaExperienciaExample();
		FichaExperienciaExample.Criteria criteriaExperiencia = paramSearchExperiencia.createCriteria();
		criteriaExperiencia.andNumPostulanteEqualTo(numPostulante);
		List<FichaExperiencia> experiencias = fichaExperienciaDAO.selectByExample(paramSearchExperiencia);
		for(FichaExperiencia e:experiencias){
			FichaExperienciaHistorico eh = new FichaExperienciaHistorico();
			eh.setCodCat(codCat);//1
			eh.setCodPuesto(codPuesto);//2
			eh.setNumPostulante(numPostulante);//3
			eh.setNumCorrel(correlativo++);//4
			
			eh.setCodTipoexpe(e.getCodTipoexpe());//5
			eh.setCodTipoentidad(e.getCodTipoentidad());//6
			eh.setDesEntidad(e.getDesEntidad());//7
			eh.setDesArea(e.getDesArea());//8
			eh.setDesCargo(e.getDesCargo());//9
			
			eh.setCodTipocontrato(e.getCodTipocontrato());//10
			eh.setFecInicio(e.getFecInicio());//11
			
			
			if("005".equals(e.getCodMotivoCese())) {
				eh.setFecFin(new Date());//12
			}else {
				eh.setFecFin(e.getFecFin());//12	
			}
			
			eh.setCodMotivoCese(e.getCodMotivoCese());//13
			eh.setDesLabores(e.getDesLabores());//14
			
			eh.setMtoRemu(e.getMtoRemu());//15
			eh.setCodSeccion(e.getCodSeccion());//16
			eh.setNomContacto(e.getNomContacto());//17
			eh.setNumTelefono(e.getNumTelefono());//18
			eh.setNomCorreo(e.getNomCorreo());//19
			
			eh.setNomDireccion(e.getNomDireccion());//20
			eh.setDesCargoCont(e.getDesCargoCont());//21
			eh.setCodUsuregis(e.getCodUsuregis());//22
			eh.setFecRegis(e.getFecRegis());//23
			eh.setCodUsumodif(e.getCodUsumodif());//24
			
			eh.setFecModif(e.getFecModif());//25
			eh.setCodUsuproc(Constantes.USUARIO_POSTULACION);//26
			eh.setFecProceso(new Date());//27
			eh.setNumArcPostula(e.getNumArcPostula());//28

			fichaExperienciaHistoricoDAO.insertSelective(eh);
		}

	}
	
	private void eliminarPostulacionHistorica(Integer numPostulante, String codPuesto, Short codCat) {
		//borrado de la informaci�n acad�mica
		FichaEducacionHistoricoExample paramFichaEduHistDelete = new FichaEducacionHistoricoExample();
		FichaEducacionHistoricoExample.Criteria criteriaFichaEduHistDelete = paramFichaEduHistDelete.createCriteria();
		criteriaFichaEduHistDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaFichaEduHistDelete.andCodCatEqualTo(codCat);
		criteriaFichaEduHistDelete.andCodPuestoEqualTo(codPuesto);
		fichaEducacionHistoricoDAO.deleteByExample(paramFichaEduHistDelete);
		
		
		//borrado de la especialidad historica
		FichaEspecialidadHistoricoExample paramFichaEspHistDelete = new FichaEspecialidadHistoricoExample();
		FichaEspecialidadHistoricoExample.Criteria criteriaFichaEspHistDelete = paramFichaEspHistDelete.createCriteria();
		criteriaFichaEspHistDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaFichaEspHistDelete.andCodCatEqualTo(codCat);
		criteriaFichaEspHistDelete.andCodPuestoEqualTo(codPuesto);
		fichaEspecialidadHistoricoDAO.deleteByExample(paramFichaEspHistDelete);
		
		
		//borrado del conocimiento historico
		FichaConocimientoHistoricoExample paramFichaConHistDelete = new FichaConocimientoHistoricoExample();
		FichaConocimientoHistoricoExample.Criteria criteriaFichaConHistDelete = paramFichaConHistDelete.createCriteria();
		criteriaFichaConHistDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaFichaConHistDelete.andCodCatEqualTo(codCat);
		criteriaFichaConHistDelete.andCodPuestoEqualTo(codPuesto);
		fichaConocimientoHistoricoDAO.deleteByExample(paramFichaConHistDelete);
		
		
		//borrado de la experiencia historica
		FichaExperienciaHistoricoExample paramFichaExpHistDelete = new FichaExperienciaHistoricoExample();
		FichaExperienciaHistoricoExample.Criteria criteriaFichaExpHistDelete = paramFichaExpHistDelete.createCriteria();
		criteriaFichaExpHistDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaFichaExpHistDelete.andCodCatEqualTo(codCat);
		criteriaFichaExpHistDelete.andCodPuestoEqualTo(codPuesto);
		fichaExperienciaHistoricoDAO.deleteByExample(paramFichaExpHistDelete);
		
		//borrado de la ficha hist�rica...
		FichaHistoricoExample paramFichaHistDelete = new FichaHistoricoExample();
		FichaHistoricoExample.Criteria criteriaFichaHistDelete = paramFichaHistDelete.createCriteria();
		criteriaFichaHistDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaFichaHistDelete.andCodCatEqualTo(codCat);
		criteriaFichaHistDelete.andCodPuestoEqualTo(codPuesto);
		fichaHistoricoDAO.deleteByExample(paramFichaHistDelete);
	}

	@Override
	public void eliminarPostulacion(Integer numPostulante, String codPuesto, Short codCat) {
		//se borran las preguntas
		DdjjPostulacionExample paramDelete = new DdjjPostulacionExample();
		Seguimiento paramInsert = new Seguimiento();
		
		Usuario usuario = usuarioDAO.selectByPrimaryKey(numPostulante);
		
		DdjjPostulacionExample.Criteria criteriaDelete = paramDelete.createCriteria();
		criteriaDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaDelete.andCodCatEqualTo(codCat);
		criteriaDelete.andCodPuestoEqualTo(codPuesto);
		ddjjPostulacionDAO.deleteByExample(paramDelete);
		
		//se borra la postulaci�n
		PostulacionExample paramPostDelete = new PostulacionExample();
		PostulacionExample.Criteria criteriaPostDelete = paramPostDelete.createCriteria();
		criteriaPostDelete.andNumPostulanteEqualTo(numPostulante);
		criteriaPostDelete.andCodCatEqualTo(codCat);
		criteriaPostDelete.andCodPuestoEqualTo(codPuesto);
		postulacionDAO.deleteByExample(paramPostDelete);		
		eliminarPostulacionHistorica(numPostulante,codPuesto,codCat);
		
		paramInsert.setCodidentificador(codCat.toString());
		paramInsert.setIndidentificador("2");
		paramInsert.setIndaccion("03");
		paramInsert.setCodusuregis(numPostulante.toString() );		
		paramInsert.setFecregis(new Date());
		paramInsert.setDesaccion(usuario.getNumDocId());
		registrarSeguimiento(paramInsert);
		
	}

	@Override
	public boolean registrarSeguimiento(Seguimiento seguimiento) {
		
		log.info("Iniciando Registro Seguimiento...");
		
		boolean transaccionOk = false;
		
		try{
			seguimientoDAO.insert(seguimiento);			
			transaccionOk = true;
		}catch(Exception e){
			log.info("Ocurri� un error al insertar Seguimiento.",e);
		}
		
		return transaccionOk;
		
	}

	
}


