package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ArchivoPostulacionDAO;

public class ArchivoPostulacionDAOImpl extends SqlMapDAOBase implements ArchivoPostulacionDAO {

    public int countByExample(ArchivoPostulacionExample example) {
        return (Integer)  getSqlMapClientTemplate().queryForObject("t8380arcpostula.countByExample", example);
    }

    public int deleteByExample(ArchivoPostulacionExample example) {
        return getSqlMapClientTemplate().delete("t8380arcpostula.deleteByExample", example);
    }

    public int deleteByPrimaryKey(Integer numArcPostula) {
        ArchivoPostulacion key = new ArchivoPostulacion();
        key.setNumArcPostula(numArcPostula);
        return getSqlMapClientTemplate().delete("t8380arcpostula.deleteByPrimaryKey", key);
    }

    public void insert(ArchivoPostulacion record) {
        getSqlMapClientTemplate().insert("t8380arcpostula.insert", record);
    }

    public Integer insertSelective(ArchivoPostulacion record) {
    	return (Integer)getSqlMapClientTemplate().insert("t8380arcpostula.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoPostulacion> selectByExampleWithBLOBs(ArchivoPostulacionExample example) {
        return getSqlMapClientTemplate().queryForList("t8380arcpostula.selectByExampleWithBLOBs", example);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoPostulacion> selectByExampleWithoutBLOBs(ArchivoPostulacionExample example) {
        return getSqlMapClientTemplate().queryForList("t8380arcpostula.selectByExample", example);
    }

    public ArchivoPostulacion selectByPrimaryKey(Integer numArcPostula) {
        ArchivoPostulacion key = new ArchivoPostulacion();
        key.setNumArcPostula(numArcPostula);
        return (ArchivoPostulacion) getSqlMapClientTemplate().queryForObject("t8380arcpostula.selectByPrimaryKey", key);
    }
    
    public ArchivoPostulacion selectByPrimaryKeyWithoutBLOBs(Integer numArcPostula) {
        ArchivoPostulacion key = new ArchivoPostulacion();
        key.setNumArcPostula(numArcPostula);
        return (ArchivoPostulacion) getSqlMapClientTemplate().queryForObject("t8380arcpostula.selectByPrimaryKeyWithoutBLOBs", key);
    }

    public int updateByExampleSelective(ArchivoPostulacion record, ArchivoPostulacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByExampleSelective", parms);
    }

    public int updateByExampleWithBLOBs(ArchivoPostulacion record, ArchivoPostulacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByExampleWithBLOBs", parms);
    }

    public int updateByExampleWithoutBLOBs(ArchivoPostulacion record, ArchivoPostulacionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByExample", parms);
    }

    public int updateByPrimaryKeySelective(ArchivoPostulacion record) {
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByPrimaryKeySelective", record);
    }

    public int updateByPrimaryKeyWithBLOBs(ArchivoPostulacion record) {
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByPrimaryKeyWithBLOBs", record);
    }

    public int updateByPrimaryKeyWithoutBLOBs(ArchivoPostulacion record) {
        return getSqlMapClientTemplate().update("t8380arcpostula.updateByPrimaryKey", record);
    }

    private static class UpdateByExampleParms extends ArchivoPostulacionExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoPostulacionExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
    
	public int updateBlob(Map params){
		return this.getSqlMapClientTemplate().update("t8380arcpostula.updateBlob", params);
	}
}