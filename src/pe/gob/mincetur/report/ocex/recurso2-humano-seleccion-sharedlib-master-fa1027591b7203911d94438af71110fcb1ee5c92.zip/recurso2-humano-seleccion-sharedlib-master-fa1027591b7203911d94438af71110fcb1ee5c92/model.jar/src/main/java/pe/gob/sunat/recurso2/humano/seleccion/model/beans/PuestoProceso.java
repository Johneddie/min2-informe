package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class PuestoProceso implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer codCat;	//proceso
	private String desCat;
	private String desAbreviCat;
	private Date finiPostu;
	private Date ffinPostu;
	private String perProceso;
	private String tipoConv;
	private String tipoModa;
	private String relProc;
	private String indPostReg;
	private String indExpFic;//puesto
	private String codPuesto;
	private String desPuesto;
	private Integer numVacantes;
	private BigDecimal mtoRemu;
	private Integer cntEdadLimite;
	private Date fecPostulacion;//param
	private String estado;
	private String desProceso;//front
	private String desInscripcion;
	private String desEstado;
	
	private String indPerfil;
	private String indCurrent;
	
	private Integer numPostulante;
	
	public Integer getCodCat() {
		return codCat;
	}
	public void setCodCat(Integer codCat) {
		this.codCat = codCat;
	}
	public String getDesCat() {
		return desCat;
	}
	public void setDesCat(String desCat) {
		this.desCat = desCat;
	}
	public String getDesAbreviCat() {
		return desAbreviCat;
	}
	public void setDesAbreviCat(String desAbreviCat) {
		this.desAbreviCat = desAbreviCat;
	}
	public Date getFiniPostu() {
		return finiPostu;
	}
	public void setFiniPostu(Date finiPostu) {
		this.finiPostu = finiPostu;
	}
	public Date getFfinPostu() {
		return ffinPostu;
	}
	public void setFfinPostu(Date ffinPostu) {
		this.ffinPostu = ffinPostu;
	}
	public String getPerProceso() {
		return perProceso;
	}
	public void setPerProceso(String perProceso) {
		this.perProceso = perProceso;
	}
	public String getTipoConv() {
		return tipoConv;
	}
	public void setTipoConv(String tipoConv) {
		this.tipoConv = tipoConv;
	}
	public String getTipoModa() {
		return tipoModa;
	}
	public void setTipoModa(String tipoModa) {
		this.tipoModa = tipoModa;
	}
	public String getRelProc() {
		return relProc;
	}
	public void setRelProc(String relProc) {
		this.relProc = relProc;
	}
	public String getIndPostReg() {
		return indPostReg;
	}
	public void setIndPostReg(String indPostReg) {
		this.indPostReg = indPostReg;
	}
	public String getIndExpFic() {
		return indExpFic;
	}
	public void setIndExpFic(String indExpFic) {
		this.indExpFic = indExpFic;
	}
	public String getCodPuesto() {
		return codPuesto;
	}
	public void setCodPuesto(String codPuesto) {
		this.codPuesto = codPuesto;
	}
	public String getDesPuesto() {
		return desPuesto;
	}
	public void setDesPuesto(String desPuesto) {
		this.desPuesto = desPuesto;
	}
	public Integer getNumVacantes() {
		return numVacantes;
	}
	public void setNumVacantes(Integer numVacantes) {
		this.numVacantes = numVacantes;
	}
	public BigDecimal getMtoRemu() {
		return mtoRemu;
	}
	public void setMtoRemu(BigDecimal mtoRemu) {
		this.mtoRemu = mtoRemu;
	}
	public Integer getCntEdadLimite() {
		return cntEdadLimite;
	}
	public void setCntEdadLimite(Integer cntEdadLimite) {
		this.cntEdadLimite = cntEdadLimite;
	}
	public Date getFecPostulacion() {
		return fecPostulacion;
	}
	public void setFecPostulacion(Date fecPostulacion) {
		this.fecPostulacion = fecPostulacion;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDesProceso() {
		return desProceso;
	}
	public void setDesProceso(String desProceso) {
		this.desProceso = desProceso;
	}
	public String getDesInscripcion() {
		return desInscripcion;
	}
	public void setDesInscripcion(String desInscripcion) {
		this.desInscripcion = desInscripcion;
	}
	public Integer getNumPostulante() {
		return numPostulante;
	}
	public void setNumPostulante(Integer numPostulante) {
		this.numPostulante = numPostulante;
	}
	public String getDesEstado() {
		return desEstado;
	}
	public void setDesEstado(String desEstado) {
		this.desEstado = desEstado;
	}
	public String getIndPerfil() {
		return indPerfil;
	}
	public void setIndPerfil(String indPerfil) {
		this.indPerfil = indPerfil;
	}
	public String getIndCurrent() {
		return indCurrent;
	}
	public void setIndCurrent(String indCurrent) {
		this.indCurrent = indCurrent;
	}
	
}
