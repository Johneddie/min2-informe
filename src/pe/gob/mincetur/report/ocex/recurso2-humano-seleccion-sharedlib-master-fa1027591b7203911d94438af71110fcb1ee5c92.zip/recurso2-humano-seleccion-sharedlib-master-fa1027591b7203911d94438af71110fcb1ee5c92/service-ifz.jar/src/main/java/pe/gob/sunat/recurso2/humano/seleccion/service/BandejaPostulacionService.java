package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DdjjPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Perfil;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Postulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ProcesoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;

@SuppressWarnings("rawtypes")
public interface BandejaPostulacionService {
	public List<PuestoProceso> listarPuestosProcesoActivos(Integer numPostulante);
	public Map<String, Object> listarPreguntasDeclaracionJurada();
	public Map<String, Object> listarRespuestasDeclaracionJurada();
	public boolean registrarDeclaracion(List lstRespuestas, Short codCat, String codPuesto, Integer numPostulante,String nomFamiliar);
	public List<PuestoProceso> listarPostulaciones(Integer numPostulante);
	public Map<String, Object> validarDeclaracion(Integer numPostulante, Short codCat);
	public Map<String, Object> validarVencimientoPostulaci�n(Short codCat);
	public List<DdjjPostulacion> listarRespuestasPostulante(Integer numPostulante, Short codCat, String codPuesto);
	public ProcesoPostulacion obtenerProcesoPostulacion(Short codCat);
	public Map<String,Object> obtenerCabeceraFormato(Usuario usuario, Short codCat, String codPuesto, boolean indHistorico);
	public byte[] obtenerReporteFromPlantilla(int idPlantilla, Map<String, Object> cabecera, List detalle);
	public Map<String, Object> validarExistenciaFormato(Short codCat, String codPuesto, Integer numPostulante);
	public Perfil getPerfil(Integer codCat);
	public Postulacion getPostulacion(Short codCat, String codPuesto, Integer numPostulante);
}
