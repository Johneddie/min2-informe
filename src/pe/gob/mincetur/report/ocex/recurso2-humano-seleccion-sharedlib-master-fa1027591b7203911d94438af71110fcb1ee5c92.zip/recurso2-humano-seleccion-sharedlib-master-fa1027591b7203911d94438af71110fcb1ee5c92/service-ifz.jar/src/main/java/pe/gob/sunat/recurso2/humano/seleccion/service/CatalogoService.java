package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.List;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;

public interface CatalogoService {

	List<Parametro> listarDepartamentos();
	List<Parametro> listarProvincias(String codDepartamento);
	List<Parametro> listarDistritos(String codProvincia);
	
	List<Parametro> listarZonasDomiciliarias();
	List<Parametro> listarViasDomiciliarias();
	
	List<Parametro> listarGradosAcademicos();
	List<Parametro> listarProfesiones();
	List<Parametro> listarCentrosEstudio();
	
	List<Parametro> listarIndicadoresPuesto();
	
	List<Parametro> listarTiposExperiencia();
	List<Parametro> listarContratosPrivados();
	List<Parametro> listarContratosPublicos();
	List<Parametro> listarMotivosCese();
	
	List<Parametro> listarTiposBrevete();
	
	List<Parametro> listarTiposEstudio();
	List<Parametro> listarNivelEstudio(String codTipoEstudio);
	List<Parametro> listarCiclos(String codTipoEstudio, String codNivelEstudio);
	
	List<Parametro> listarCarreras(String codTipoEstudio);	
	List<Parametro> listaTipoConocimiento( String codTipoConocimiento);	
	
	Parametro getMensajeInicio();
	
	
}
