package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;
import javax.xml.rpc.ParameterMode;

import org.apache.axis.client.Call;
import org.apache.axis.encoding.XMLType;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.sojo.interchange.json.JsonSerializer;
import pe.gob.sunat.framework.spring.util.exception.ServiceException;
import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DdjjPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DdjjPostulacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Ficha;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacionHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidadHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistoricoKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Perfil;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Postulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PostulacionKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ProcesoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Puesto;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.CodigosRrhhDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.DdjjPostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaConocimientoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaConocimientoHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEducacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEducacionHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEspecialidadDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEspecialidadHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaExperienciaDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaExperienciaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParametroDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PerfilDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ProcesoPostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PuestoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.UsuarioDAO;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;
import pe.gob.sunat.recurso2.humano.seleccion.util.FechasUtil;
import pe.gob.sunat.recurso2.humano.seleccion.util.GeneradorQR;

@Service("bandejaPostulacionService")
public class BandejaPostulacionServiceImpl implements BandejaPostulacionService{
	
	public final Log log = LogFactory.getLog(getClass());
	Propiedades propiedades = new Propiedades(getClass(), "/correo.properties");
		
	@Autowired
	private PuestoDAO puestoDAO;//old
	
	@Autowired
	private ParametroDAO parametroDAO;
	
	@Autowired
	private CodigosRrhhDAO codigosDAO;
	
	@Autowired
	private DdjjPostulacionDAO ddjjPostulacionDAO;
	
	@Autowired
	private PostulacionDAO postulacionDAO;
	
		
	@Autowired
	private FichaDAO fichaDAO;
	
	@Autowired
	private UsuarioDAO usuarioDAO;
	
	
	@Autowired
	private FichaExperienciaDAO fichaExperienciaDAO;
	
	@Autowired
	private FichaConocimientoDAO fichaConocimientoDAO;
	
	@Autowired
	private FichaEducacionDAO fichaEducacionDAO;
	
	
	@Autowired
	private ProcesoPostulacionDAO procesoPostulacionDAO;
	
	@Autowired
	private CatalogoService catalogoService;
	
	@Autowired
	private FichaEspecialidadDAO fichaEspecialidadDAO;
	
		
	
	@Autowired
	private FichaHistoricoDAO fichaHistoricoDAO;
	@Autowired
	private FichaEducacionHistoricoDAO fichaEducacionHistoricoDAO;
	@Autowired
	private FichaEspecialidadHistoricoDAO fichaEspecialidadHistoricoDAO;
	@Autowired
	private FichaConocimientoHistoricoDAO fichaConocimientoHistoricoDAO;
	@Autowired
	private FichaExperienciaHistoricoDAO fichaExperienciaHistoricoDAO;
	
	@Autowired
	private PerfilDAO perfilDAO;
	
	
	@Autowired
	private RegistroPostulacionService registroPostulacionService;
	
	
	@Override
	public List<PuestoProceso> listarPuestosProcesoActivos(Integer numPostulante) {
		if(log.isDebugEnabled()) log.debug("method listarPuestosProcesoActivos");
		List<PuestoProceso> lstPuestosProcesoPermitidos = new ArrayList<PuestoProceso>();
		
		//procesos por postulante
		PuestoProceso puestoPostulante = new PuestoProceso();
		puestoPostulante.setEstado(Constantes.PROCESO_COD_ESTADO_ACTIVO);
		puestoPostulante.setNumPostulante(numPostulante);
		List<PuestoProceso> lstPuestosPostulante = postulacionDAO.listarPostulacionesByPostulante(puestoPostulante);
		
		//procesos activos
		PuestoProceso puestoProceso = new PuestoProceso(); 
		puestoProceso.setFecPostulacion(new Date());
		puestoProceso.setEstado(Constantes.PROCESO_COD_ESTADO_ACTIVO);
		List<PuestoProceso> lstPuestosProceso= puestoDAO.listarPuestosProcesoActivos(puestoProceso);
		
		for(PuestoProceso puesto:lstPuestosProceso){
			boolean exist = false;
			for(PuestoProceso puesto_:lstPuestosPostulante){
				if(puesto.getCodCat().equals(puesto_.getCodCat()) && puesto.getCodPuesto().equals(puesto_.getCodPuesto())){
					exist = true;
					break;
				}
			}
			if(!exist){
				String perProceso = puesto.getPerProceso();
				String anio = perProceso!=null&&perProceso.length()>4?perProceso.substring(0, 4):"";
				puesto.setDesProceso(puesto.getDesAbreviCat() + " - " + anio + " " + puesto.getDesPuesto());
				puesto.setDesInscripcion(FechasUtil.getFechaString(puesto.getFiniPostu()) + " al " + FechasUtil.getFechaString(puesto.getFfinPostu()));
				lstPuestosProcesoPermitidos.add(puesto);
			}
		}
		
		return lstPuestosProcesoPermitidos;
	}
	
	@Override
	public Map listarPreguntasDeclaracionJurada() {
		if(log.isDebugEnabled()) log.debug("method listarPreguntasDeclaracionJurada");
		
		Parametro parametro = new Parametro();
		parametro.setCodParametro(Constantes.PREG_DDJJ_CODIGO_PREGUNTAS);
		parametro.setDesParametroAbrev(Constantes.PREG_DDJJ_CODIGO_SECCION_AUSENCIA);
		List<Parametro> lstPreguntasDeclaracionAusencia= parametroDAO.listarPreguntasDeclaracionJurada(parametro);
		
		parametro.setCodParametro(Constantes.PREG_DDJJ_CODIGO_PREGUNTAS);
		parametro.setDesParametroAbrev(Constantes.PREG_DDJJ_CODIGO_SECCION_OTROS);
		List<Parametro> lstPreguntasDeclaracionOtros= parametroDAO.listarPreguntasDeclaracionJurada(parametro);
		
		Map<String, Object> hmPreguntas = new HashMap<>();
		hmPreguntas.put("lstPreguntasDeclaracionAusencia", lstPreguntasDeclaracionAusencia);
		hmPreguntas.put("lstPreguntasDeclaracionOtros", lstPreguntasDeclaracionOtros);
		
		return hmPreguntas;
	}
	
	@Override
	public Map listarRespuestasDeclaracionJurada() {
		if(log.isDebugEnabled()) log.debug("method listarRespuestasDeclaracionJurada");
		
		Map<String, Object> hmPreguntas = new HashMap<>();
		
		HashMap<String, Object> hmParams = new HashMap<>();
		hmParams.put("codTab", Constantes.PREG_DDJJ_CODIGO_RESPUESTAS);
		hmParams.put("estado", Constantes.PREG_DDJJ_CODIGO_ACTIVO);
		hmParams.put("tipo", Constantes.CODIGO_RESP_TIPO_NORMAL);
		List<Parametro> lstRespuestasDeclaracionNormal= codigosDAO.selectByParams(hmParams);
		hmPreguntas.put("lstRespuestasDeclaracionNormal", lstRespuestasDeclaracionNormal);
		
		hmParams.put("tipo", Constantes.CODIGO_RESP_TIPO_COND_COLEG);
		List<Parametro> lstRespuestasDeclaracionColegiatura= codigosDAO.selectByParams(hmParams);
		hmPreguntas.put("lstRespuestasDeclaracionColegiatura", lstRespuestasDeclaracionColegiatura);
		
		hmParams.put("tipo", Constantes.CODIGO_RESP_TIPO_TIP_DISCAP);
		List<Parametro> lstRespuestasDeclaracionDiscapacidad= codigosDAO.selectByParams(hmParams);
		hmPreguntas.put("lstRespuestasDeclaracionDiscapacidad", lstRespuestasDeclaracionDiscapacidad);
		
		hmParams.put("tipo", Constantes.CODIGO_RESP_TIPO_MOD_FORM);
		List<Parametro> lstRespuestasDeclaracionFormativa= codigosDAO.selectByParams(hmParams);
		hmPreguntas.put("lstRespuestasDeclaracionFormativa", lstRespuestasDeclaracionFormativa);
		
		return hmPreguntas;
	}
	
	
	public boolean registrarDeclaracion(List lstRespuestas, Short codCat, String codPuesto, Integer numPostulante, String nomFamiliar){
		if (log.isDebugEnabled()) log.debug("method registrarDeclaracion");
		boolean estado = false;
		Date today = new Date();
		
		try{
			//postulacion
			Postulacion postulacion = new Postulacion();
			postulacion.setCodCat(codCat);
			postulacion.setCodPuesto(codPuesto);
			postulacion.setNumPostulante(numPostulante);
			postulacion.setIndEstado(Constantes.ESTADO_ACTIVO);
			postulacion.setFecRegis(today);
			postulacion.setCodUsuregis(Constantes.USUARIO_POSTULACION); //PENDIENTE
			postulacionDAO.insert(postulacion);
			
			//respuestas ddjj
			for(Object objRespuesta:lstRespuestas){
				DdjjPostulacion respuestaDdjj = (DdjjPostulacion)objRespuesta;
				if(Constantes.CODIGO_PREG_FAMI.equals(respuestaDdjj.getCodPregunta())) {
					respuestaDdjj.setNomFamiliar(nomFamiliar);
				}
				respuestaDdjj.setCodCat(codCat);
				respuestaDdjj.setCodPuesto(codPuesto);
				respuestaDdjj.setNumPostulante(numPostulante);
				respuestaDdjj.setIndEstado(Constantes.ESTADO_ACTIVO);
				respuestaDdjj.setFecDdjj(today);
				respuestaDdjj.setFecRegis(today);
				respuestaDdjj.setCodUsuregis(Constantes.USUARIO_POSTULACION); //PENDIENTE
				ddjjPostulacionDAO.insert(respuestaDdjj);
			}
			
			Usuario usuario = usuarioDAO.selectByPrimaryKey(numPostulante);
			//replicarDatosPostulacion(lstRespuestas, codCat, codPuesto, usuario);
			
			//detalle
			ArrayList<HashMap<String,Object>> lstDetalle = new ArrayList<HashMap<String,Object>>();
			lstDetalle.add(new HashMap<String,Object>());
			String nombreArchivo = Constantes.ARCHIVO_PDF_FORMATO_POSTULACION + codCat +"_"+ numPostulante;
			Map<String, Object> cabecera = obtenerCabeceraFormato(usuario, codCat, codPuesto, false);//se genera el c�digo qr
			//byte[] bytFormato = obtenerReporteFromPlantilla(Constantes.TEMPLATE_FORMATO_POSTULACION, cabecera, lstDetalle);
			byte[] bytFormato = generarFormatoPostulacionPDF(cabecera,lstDetalle);//se genera el archivo pdf
			

			Integer numArcPostula = registroPostulacionService.registrarArchivo(nombreArchivo+".pdf", numPostulante, bytFormato);
			//TODO: Actualizar la tabla de postulaciones con el c�digo del archivo binario
			Postulacion postulacionUpdate = new Postulacion();
			postulacionUpdate.setNumArcFup(numArcPostula);
			postulacionUpdate.setCodCat(codCat);
			postulacionUpdate.setCodPuesto(codPuesto);
			postulacionUpdate.setNumPostulante(numPostulante);
			postulacionDAO.actualizarFileFup(postulacionUpdate);
			
			File filFormato = generarFilefromByte(bytFormato, nombreArchivo);
			log.debug("archivo generado con codigo qr:"+filFormato.getAbsolutePath());
			enviarCorreoPostulacion(codCat, codPuesto, usuario, today, filFormato);	
			
			estado = true;
					
		}catch(DataAccessException ex){
			log.error("DataAccessException en registrarPostulaciones: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex.getMessage());
		}catch(ServiceException ex){
			log.error("ServiceException en registrarPostulaciones: " + ex.getMessage());
			throw new ServiceException(this, ex.getMessage());
		}catch(Exception ex){
			log.error("Exception en registrarPostulaciones: " + ex.getMessage(), ex);
			throw new ServiceException(this, ex.getMessage());
		}finally{
			if (log.isDebugEnabled()) log.debug("Fin - registrarDeclaracion");
		}
		return estado;
	}
	
	
	private byte[] generarFormatoPostulacionPDF(Map<String, Object> parametros, List<HashMap<String,Object>> lstDetalle) throws Exception{
		
		String jasperFile = "/data0/generador/jasper/plantillas/PLANTILLA007725.jasper";
		byte[] pdfBytes = null;
		
		try {
			JasperPrint print = JasperFillManager.fillReport(jasperFile, parametros, new JRBeanCollectionDataSource(lstDetalle));
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			JRPdfExporter exporter = new JRPdfExporter(); 
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
		    exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
			exporter.exportReport();
			pdfBytes = outputStream.toByteArray();
		} catch (JRException e) {
			log.info("Ocurrio un error al generar el pdf(generarConstanciaRectificacionPDF)",e);
			throw new Exception("ocurrio un error al crear el pdf",e);
		}
		
		return pdfBytes;
	}

	
	@Override
	public Map<String, Object> validarVencimientoPostulaci�n(Short codCat) {
		if(log.isDebugEnabled()) log.debug("method validarVencimientoPostulaci�n");
		Date today = new Date();
		Map<String, Object> hmValidacion = new HashMap<String, Object>();
		hmValidacion.put("error", false);
		
		ProcesoPostulacion proceso = procesoPostulacionDAO.selectByPrimaryKey(codCat);
		if(today.after(proceso.getFfinPostu())){
			hmValidacion.put("error", true);
			hmValidacion.put("mensaje", "El plazo de postulaci�n ha vencido.");
		}
		
		return hmValidacion;
	}
	
	public Map<String, Object> validarDeclaracion(Integer numPostulante, Short codCat){
		if (log.isDebugEnabled()) log.debug("method validarDeclaracion");
		
		Map<String, Object> hmValidacion = new HashMap<String, Object>();
		hmValidacion.put("error", false);
		
		Ficha fichaDatos = fichaDAO.selectByPrimaryKey(numPostulante);
		FichaEducacion paramSearch = new FichaEducacion();
		paramSearch.setNumPostulante(numPostulante);
		List<FichaEducacion> lstFichaEducacion = fichaEducacionDAO.listarDatosEducativos(paramSearch);
		
		List<String> lstErrores = new ArrayList<String>();
		if(fichaDatos == null || fichaDatos.getCodUbigeodom()==null || "".equals(fichaDatos.getCodUbigeodom())){
			hmValidacion.put("codError", "001");
			hmValidacion.put("errorValida", true);
			lstErrores.add("Domicilio");
		}
		if(fichaDatos == null  || ((fichaDatos.getNumTelcasa()==null || "".equals(fichaDatos.getNumTelcasa())) && (fichaDatos.getNumTelcelular()==null || "".equals(fichaDatos.getNumTelcelular())))){
			hmValidacion.put("codError", "002");
			hmValidacion.put("errorValida", true);
			lstErrores.add("Tel�fono Celular o Tel�fono de Casa");
		}
		if(fichaDatos == null  || lstFichaEducacion.size()==0){
			hmValidacion.put("codError", "003");
			hmValidacion.put("errorValida", true);
			lstErrores.add("Formaci�n acad�mica");
		}
		
		//Validamos que el postulante no se inscriba en m�s de una
		
		ProcesoPostulacion procesoBD = procesoPostulacionDAO.selectByPrimaryKey(codCat);
		String indPerfilBD = procesoBD.getIndPerfil();
		if(Constantes.COD_PROCESO_CONVENIO.equals(indPerfilBD) ||
				Constantes.COD_PROCESO_PRACTICAS.equals(indPerfilBD)) {
			//Si est� tratando de postular a un convenio o practica, verificar que no haya
			int postulaciones = this.postulacionDAO.countPostulacionesConvenioPracticas(numPostulante, codCat.intValue());
			if(postulaciones>0) {
				String nombreProceso = "-";
				PuestoProceso puestoPostulanteSearch = new PuestoProceso();
				puestoPostulanteSearch.setEstado(Constantes.PROCESO_COD_ESTADO_ACTIVO);
				puestoPostulanteSearch.setNumPostulante(numPostulante);
				puestoPostulanteSearch.setIndPerfil("3");//filtra los perfil 3,4
				puestoPostulanteSearch.setIndCurrent("1");//filtra los procesos activos
				List<PuestoProceso> lstPuestosPostulante = postulacionDAO.listarPostulacionesByPostulante(puestoPostulanteSearch);
				if(!CollectionUtils.isEmpty(lstPuestosPostulante)) {
					PuestoProceso puesto = lstPuestosPostulante.get(0);
					nombreProceso = puesto.getDesAbreviCat()+"-"+puesto.getDesPuesto();
				}
				hmValidacion.put("codError", "004");
				hmValidacion.put("errorValida", true);
				lstErrores.add("Usted ya est� inscrito en el proceso:"+nombreProceso);	
			}
		}
		
		
		hmValidacion.put("lstErrores", lstErrores);
		
		if(CollectionUtils.isEmpty(lstErrores)) {
			Perfil perfil = perfilDAO.selectByPrimaryKey(codCat.intValue());
			if(perfil!=null) {
				hmValidacion.put("conocimientoExigido", perfil.getDesConocimientos());	
			}
		}
		
		return hmValidacion;
	}
	

	private File generarFilefromByte(byte[] bytes, String nomFile) {
	    FileOutputStream fo = null;
	    try { 
	    	fo = new FileOutputStream(Constantes.DIRECTORIO_TEMPORAL + "/" + nomFile + ".pdf"); 
	        fo.write(bytes);
	    } catch (Exception e) {
	        log.error("Error al generar pdf: " + e.getMessage(), e);
	    } finally {
	        try {
	        	if(fo!=null)fo.close();
			} catch (Exception e) {
				log.error("Error al cerrar FileOutputStream: " + e.getMessage(), e);
			}
	    }
	    
	    return new File(Constantes.DIRECTORIO_TEMPORAL + "/" + nomFile + ".pdf");
	}
    
	
	@Override
	public List<PuestoProceso> listarPostulaciones(Integer numPostulante) {
		if(log.isDebugEnabled()) log.debug("method listarPostulaciones");
		Date today = new Date();
		String desEstado = "";
		
		//procesos por postulante
		PuestoProceso puestoPostulante = new PuestoProceso();
		puestoPostulante.setEstado(Constantes.PROCESO_COD_ESTADO_ACTIVO);
		puestoPostulante.setNumPostulante(numPostulante);
		List<PuestoProceso> lstPuestosPostulante = postulacionDAO.listarPostulacionesByPostulante(puestoPostulante);
		
		for(PuestoProceso puesto:lstPuestosPostulante){
			String perProceso = puesto.getPerProceso();
			String anio = perProceso!=null&&perProceso.length()>4?perProceso.substring(0, 4):"";
			puesto.setDesProceso(puesto.getDesAbreviCat() + " - " + anio + " " + puesto.getDesPuesto());
			puesto.setDesInscripcion(FechasUtil.getStringLargeFromDate(puesto.getFecPostulacion()));
			if(!today.after(puesto.getFfinPostu()) && !today.before(puesto.getFiniPostu()))
				desEstado = "Nuevo";
			else
				desEstado = "Proceso o Cerrado";
			puesto.setDesEstado(desEstado);
		}
		
		return lstPuestosPostulante;
	}
	
	private void enviarCorreoPostulacion(Short codCat, String codPuesto, Usuario usuario, Date date, File file){
		if(log.isDebugEnabled()) log.debug("enviarCorreoPostulacion");
		
		PuestoKey puestoKey = new PuestoKey();
		puestoKey.setCodCat(codCat);
		puestoKey.setCodPuesto(codPuesto);
		Puesto puesto = puestoDAO.selectByPrimaryKey(puestoKey);
		ProcesoPostulacion proceso = procesoPostulacionDAO.selectByPrimaryKey(codCat);
		
		String mensaje = Constantes.MENSAJE_CONFIRMACION_POSTULACION;
		
		Ficha fichaBD = fichaDAO.selectByPrimaryKey(usuario.getNumPostulante());
		mensaje = mensaje.replace("{desSexo}", "M".equals(fichaBD.getIndSexo())?"o":"a");
		mensaje = mensaje.replace("{desNombres}", usuario.getNomPostulante());
		mensaje = mensaje.replace("{desProceso}", proceso.getDesAbreviCat() + " - " + proceso.getPerProceso() + " " + puesto.getDesPuesto());
		mensaje = mensaje.replace("{desFecPostulacion}", FechasUtil.getStringLargeFromDate(date));
		if(log.isDebugEnabled()) log.debug("mensaje: " + mensaje);
		enviarEmail(usuario.getNomEmail(), Constantes.ASUNTO_CONFIRMACION_POSTULACION, mensaje, file);
	}
	
	public int enviarEmail(String destinatario, String asunto, String mensaje, File file) {
		if(log.isDebugEnabled()) log.debug("enviarEmail: " + destinatario);
		
		JavaMailSenderImpl sender = new JavaMailSenderImpl();
		sender.setHost(propiedades.leePropiedad("servidor"));
		sender.setUsername(propiedades.leePropiedad("correoRemitentePorDefecto"));
		MimeMessage message = sender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
			helper.setFrom(propiedades.leePropiedad("correoRemitentePorDefecto"), propiedades.leePropiedad("nombreRemitentePorDefecto"));
			helper.setTo(destinatario);
			helper.setSubject(asunto);
			helper.setText(mensaje, true);
			if (file != null){
				helper.addAttachment(file.getName(), file);
			}
			sender.send(message);
		} catch (Exception e) {			
			log.error("ERROR: no se pudo enviar el correo electronico a " + destinatario + "\n" + e.getMessage(), e);
			return 0;
		}
		return 1;		
	}
	
	@Override
	public List<DdjjPostulacion> listarRespuestasPostulante(Integer numPostulante, Short codCat, String codPuesto) {
		DdjjPostulacionExample param = new DdjjPostulacionExample() ;
		DdjjPostulacionExample.Criteria criterio = param.createCriteria();
		criterio.andNumPostulanteEqualTo(numPostulante);
		criterio.andCodCatEqualTo(codCat);
		criterio.andCodPuestoEqualTo(codPuesto);
		param.setOrderByClause(" cod_pregunta asc ");
		return ddjjPostulacionDAO.selectByExample(param);
	}
	
	public ProcesoPostulacion obtenerProcesoPostulacion(Short codCat){
		return procesoPostulacionDAO.selectByPrimaryKey(codCat);
	}
	
	private Puesto obtenerPuestoPostulacion(Short codCat, String codPuesto){
		PuestoKey puestoKey =  new PuestoKey();
		puestoKey.setCodCat(codCat);
		puestoKey.setCodPuesto(codPuesto);
		Puesto puesto = puestoDAO.selectByPrimaryKey(puestoKey);
		return puesto;
	}
	
	@Override
	public Map<String, Object> validarExistenciaFormato(Short codCat, String codPuesto, Integer numPostulante) {
		if(log.isDebugEnabled()) log.debug("method validarExistenciaFormatoHistorico");
		Date today = new Date();
		Map<String, Object> hmValidacion = new HashMap<String, Object>();
		hmValidacion.put("error", false);
		
		ProcesoPostulacion proceso = obtenerProcesoPostulacion(codCat);
		boolean isHistorico = today.after(proceso.getFfinPostu());
		FichaHistorico fichaHistoricoBD = null;
		Ficha fichaBD = null;
		if(isHistorico){
			FichaHistoricoKey hk = new FichaHistoricoKey();
			hk.setCodCat(codCat);
			hk.setCodPuesto(codPuesto);
			hk.setNumPostulante(numPostulante);
			fichaHistoricoBD = fichaHistoricoDAO.selectByPrimaryKey(hk);
		}else{
			fichaBD = fichaDAO.selectByPrimaryKey(numPostulante);
		}
			
		if((isHistorico && fichaHistoricoBD==null) || (!isHistorico && fichaBD == null)){
			hmValidacion.put("error", true);
			hmValidacion.put("mensaje", "El archivo no existe.");
		}
		
		return hmValidacion;
	}
	
	//Formato de postulaci�n
	public Map<String,Object> obtenerCabeceraFormato(Usuario usuario, Short codCat, String codPuesto, boolean indHistorico){
		if(log.isDebugEnabled()) log.debug("method obtenerCabeceraFormato"); 
		
		Map<String,Object> parametros = new HashMap<String,Object>();
		Date nowDate = new Date();
		Integer numPostulante = usuario.getNumPostulante();
		ProcesoPostulacion proceso = obtenerProcesoPostulacion(codCat);
				
		//1. datos principales
		Ficha fichaBD;
		if(!indHistorico){
			fichaBD = fichaDAO.selectByPrimaryKey(numPostulante);
		}else{
			FichaHistoricoKey hk = new FichaHistoricoKey();
			hk.setCodCat(codCat);
			hk.setCodPuesto(codPuesto);
			hk.setNumPostulante(numPostulante);
			fichaBD = fichaHistoricoDAO.selectByPrimaryKeyHistorico(hk);
		}
		
		//par�metros
		Map<String, String> mapEstadosCivil = generaMap("C","CASADO", "D","DIVORCIADO", "E","CONVIVIENTE", "S","SOLTERO", "V","VIUDO");
		Map<String, String> mapPuestoUniv = generaMapFromList(catalogoService.listarIndicadoresPuesto());
		Map<String, String> mapTipCono = generaMap("2","INFORM�TICO","3","IDIOMAS");
		Map<String, String> mapConInformatico = generaMap("0001","PROCESADOR DE TEXTOS","0002","EXCEL","0003","POWER POINT");
		Map<String, String> mapConIdiomas = generaMap("0001","INGL�S","0002","FRANC�S");
		Map<String, String> mapNiveles = generaMap("A","AVANZADO","B","B�SICO","I","INTERMEDIO");
		Map<String, String> mapDepartamentos = generaMapFromList(catalogoService.listarDepartamentos());
		Map<String, String> mapCentrosEstudio = generaMapFromList(catalogoService.listarCentrosEstudio());
		Map<String, String> mapContratPublic = generaMapFromList(catalogoService.listarContratosPublicos());
		Map<String, String> mapContratPrivad = generaMapFromList(catalogoService.listarContratosPrivados());
		Map<String, String> mapMotivCese = generaMapFromList(catalogoService.listarMotivosCese());
		String codUbigeodom = fichaBD.getCodUbigeodom();
		Map<String, String> mapProvincias = generaMapFromList(catalogoService.listarProvincias(codUbigeodom.substring(0, 2)));
		Map<String, String> mapDistritos = generaMapFromList(catalogoService.listarDistritos(codUbigeodom.substring(0, 4)));
		Map<String, String> mapVias = generaMapFromList(catalogoService.listarViasDomiciliarias());
		Map<String, String> mapTiposBrevete = generaMapFromList(catalogoService.listarTiposBrevete());
		
		parametros.put("apePaterno", usuario.getApePaterno());	
		parametros.put("apeMaterno", usuario.getApeMaterno());		
		parametros.put("nomPostulante", usuario.getNomPostulante());
		parametros.put("desUbigeonac", mapDepartamentos.get(fichaBD.getCodUbigeonac().substring(0, 2)));
		parametros.put("desEstcivil", mapEstadosCivil.get(fichaBD.getCodEstcivil()));
		parametros.put("desFecNacimiento", FechasUtil.getStringFromDateReporte(usuario.getFecNacimiento()));
		
		 int diffYear = nowDate.getYear() - usuario.getFecNacimiento().getYear();
		 int diffMonth = nowDate.getMonth()  - usuario.getFecNacimiento().getMonth();
		 int diffDay = nowDate.getDay() -   usuario.getFecNacimiento().getDay()  ;
		 
		 if (diffMonth < 0 || (diffMonth == 0 && diffDay < 0)) {
		        diffYear = diffYear - 1;
		    }
		
		parametros.put("numEdad", diffYear + "");
		parametros.put("desVia", mapVias.get(fichaBD.getCodTipvia()) + " " + fichaBD.getNomVia());		
		parametros.put("numDom", fichaBD.getNumDom());
		parametros.put("desUbigeodomDep", mapDepartamentos.get(codUbigeodom.substring(0, 2)));
		parametros.put("desUbigeodomPro", mapProvincias.get(codUbigeodom.substring(0, 4)));
		parametros.put("desUbigeodomDis", mapDistritos.get(codUbigeodom.substring(0, 6)));	
		parametros.put("codTipoDocDni", "01".equals(usuario.getCodTipoDoc())?"X":"");
		parametros.put("codTipoDocCar", "04".equals(usuario.getCodTipoDoc())?"X":"");
		parametros.put("numDocId", usuario.getNumDocId());
		parametros.put("numRuc", fichaBD.getNumRuc());	
		parametros.put("numLicencia", fichaBD.getNumLicencia());
		parametros.put("desCatLicencia", mapTiposBrevete.get(fichaBD.getCodCatLicencia()));
		parametros.put("numTelcasa", fichaBD.getNumTelcasa());
		parametros.put("numTelcelular", fichaBD.getNumTelcelular());
		parametros.put("nomEmail", usuario.getNomEmail());
		
		//2. formaci�n educativa
		List<FichaEducacion> lstDatosEducativosBD;
		if(!indHistorico){
			FichaEducacion paramSearch = new FichaEducacion();
			paramSearch.setNumPostulante(numPostulante);
			lstDatosEducativosBD = fichaEducacionDAO.listarDatosEducativos(paramSearch);
		}else{
			FichaEducacionHistorico paramSearch = new FichaEducacionHistorico();
			paramSearch.setNumPostulante(numPostulante);
			paramSearch.setCodCat(codCat);
			paramSearch.setCodPuesto(codPuesto);
			lstDatosEducativosBD = fichaEducacionHistoricoDAO.listarDatosEducativos(paramSearch);
		}
		
		List<Map<String,Object>> lstDatosEducativos = new ArrayList<Map<String,Object>>();
		for(FichaEducacion e:lstDatosEducativosBD){
			Map<String, Object> mhEducacion = new HashMap<String, Object>();
			mhEducacion.put("desTipoEstudio", e.getDesTipoEstudio());
			mhEducacion.put("desNivel", e.getDesNivel());
			mhEducacion.put("desEspecialidad", e.getDesEspecialidad());
			mhEducacion.put("desCentroEstudio", StringUtils.isNotBlank(e.getCodCentroEstudio())?
					"OTROS".equals(mapCentrosEstudio.get(e.getCodCentroEstudio()))?e.getDesCentroEstudio():mapCentrosEstudio.get(e.getCodCentroEstudio()):"-");
			mhEducacion.put("desFecEgreso", FechasUtil.getStringFromDateReporte(e.getFecEgreso()));
			mhEducacion.put("desFecGrado", FechasUtil.getStringFromDateReporte(e.getFecGrado()));
			mhEducacion.put("indPuestoUniv", mapPuestoUniv.get(e.getIndPuestoUniv()));
			lstDatosEducativos.add(mhEducacion);
		}
		if(lstDatosEducativos.size()==0) lstDatosEducativos.add(new HashMap<String,Object>());
		parametros.put("lstDatosEducativos", lstDatosEducativos);
		
		//3. estudios especializacion
		List<FichaEspecialidad> lstEstudiosEspecializacionBD;
		if(!indHistorico){
			FichaEspecialidad paramSearchE = new FichaEspecialidad();
			paramSearchE.setNumPostulante(numPostulante);
			paramSearchE.setIndCertificacion("0");
			lstEstudiosEspecializacionBD = fichaEspecialidadDAO.listarEstudiosEspecializacion(paramSearchE);
		}else{
			FichaEspecialidadHistorico paramSearchE = new FichaEspecialidadHistorico();
			paramSearchE.setNumPostulante(numPostulante);
			paramSearchE.setCodCat(codCat);
			paramSearchE.setCodPuesto(codPuesto);
			paramSearchE.setIndCertificacion("0");
			lstEstudiosEspecializacionBD = fichaEspecialidadHistoricoDAO.listarEstudiosEspecializacion(paramSearchE);
		}
		
		List<Map<String,Object>> lstEstudiosEspecializacion = new ArrayList<Map<String,Object>>();
		for(FichaEspecialidad e:lstEstudiosEspecializacionBD){
			Map<String, Object> mhEspecializa = new HashMap<String, Object>();
			mhEspecializa.put("nomEspecialidad", e.getNomEspecialidad());
			mhEspecializa.put("nomCentroEstudio", "99999".equals(e.getCodCentroEstudio())?e.getNomCentroEstudio():mapCentrosEstudio.get(e.getCodCentroEstudio()));
			mhEspecializa.put("desFecInicio", FechasUtil.getStringFromDateReporte(e.getFecInicio()));
			mhEspecializa.put("desFecFin", FechasUtil.getStringFromDateReporte(e.getFecFin()));
			mhEspecializa.put("desFecCertificado", FechasUtil.getStringFromDateReporte(e.getFecCertificado()));
			mhEspecializa.put("cntHoraLectiva", "" + e.getCntHoraLectiva());
			lstEstudiosEspecializacion.add(mhEspecializa);
		}
		if(lstEstudiosEspecializacion.size()==0) lstEstudiosEspecializacion.add(new HashMap<String,Object>());
		parametros.put("lstEstudiosEspecializacion", lstEstudiosEspecializacion);
		
		//3.2. certificaciones
		List<FichaEspecialidad> lstCertificacionesBD;
		if(!indHistorico){
			FichaEspecialidad paramSearchE = new FichaEspecialidad();
			paramSearchE.setNumPostulante(numPostulante);
			paramSearchE.setIndCertificacion("1");
			lstCertificacionesBD = fichaEspecialidadDAO.listarEstudiosEspecializacion(paramSearchE);
		}else{
			FichaEspecialidadHistorico paramSearchE = new FichaEspecialidadHistorico();
			paramSearchE.setNumPostulante(numPostulante);
			paramSearchE.setCodCat(codCat);
			paramSearchE.setCodPuesto(codPuesto);
			paramSearchE.setIndCertificacion("1");
			lstCertificacionesBD = fichaEspecialidadHistoricoDAO.listarEstudiosEspecializacion(paramSearchE);
		}
		
		List<Map<String,Object>> lstCertificaciones = new ArrayList<Map<String,Object>>();
		for(FichaEspecialidad e:lstCertificacionesBD){
			Map<String, Object> mhEspecializa = new HashMap<String, Object>();
			mhEspecializa.put("nomEspecialidad", e.getNomEspecialidad());
			mhEspecializa.put("nomCentroEstudio", "99999".equals(e.getCodCentroEstudio())?e.getNomCentroEstudio():mapCentrosEstudio.get(e.getCodCentroEstudio()));
			mhEspecializa.put("desFecInicio", FechasUtil.getStringFromDateReporte(e.getFecInicio()));
			mhEspecializa.put("desFecFin", FechasUtil.getStringFromDateReporte(e.getFecFin()));
			mhEspecializa.put("desFecCertificado", FechasUtil.getStringFromDateReporte(e.getFecCertificado()));
			mhEspecializa.put("cntHoraLectiva", "" + e.getCntHoraLectiva());
			lstCertificaciones.add(mhEspecializa);
		}
		if(lstCertificaciones.size()==0) lstCertificaciones.add(new HashMap<String,Object>());
		parametros.put("lstCertificaciones", lstCertificaciones);
		
		//4. estudios t�cnicos
		List<Perfil> lstConocimientosTecnicos = new ArrayList<Perfil>();
		Perfil perfil = perfilDAO.selectByPrimaryKey(codCat.intValue());
		if(perfil!=null) 
			lstConocimientosTecnicos.add(perfil);
		else
			lstConocimientosTecnicos.add(new Perfil());
		parametros.put("lstConocimientosTecnicos", lstConocimientosTecnicos);
		
		//5. estudios inform�ticos
		List<FichaConocimiento> lstConocimientosInformaticoBD;
		if(!indHistorico){
			lstConocimientosInformaticoBD = fichaConocimientoDAO.listarConocimiento(numPostulante);
		}else{
			lstConocimientosInformaticoBD = fichaConocimientoHistoricoDAO.listarConocimiento(numPostulante,codCat,codPuesto);
		}
		List<Map<String,Object>> lstConocimientosInformatico = new ArrayList<Map<String,Object>>();
		for(FichaConocimiento e:lstConocimientosInformaticoBD){
			Map<String, Object> mhTecnico = new HashMap<String, Object>();
			mhTecnico.put("desTipcono", e.getDesTipo());
			mhTecnico.put("desCodConocimiento", e.getNomConcomiento());
			mhTecnico.put("desNivel", e.getDesNivel());
			lstConocimientosInformatico.add(mhTecnico);
		}
		if(lstConocimientosInformatico.size()==0) lstConocimientosInformatico.add(new HashMap<String,Object>());
		parametros.put("lstConocimientosInformatico", lstConocimientosInformatico);
		
		//6. experiencia
		List<FichaExperiencia> lstExperienciaBD;
		if(!indHistorico){
			FichaExperienciaExample paramE = new FichaExperienciaExample() ;
			FichaExperienciaExample.Criteria criterioE = paramE.createCriteria();
			criterioE.andNumPostulanteEqualTo(numPostulante);
			paramE.setOrderByClause(" fec_inicio desc ");
			lstExperienciaBD = fichaExperienciaDAO.selectByExample(paramE);
		}else{
			FichaExperienciaHistoricoExample paramE = new FichaExperienciaHistoricoExample() ;
			FichaExperienciaHistoricoExample.Criteria criterioE = paramE.createCriteria();
			criterioE.andNumPostulanteEqualTo(numPostulante);
			criterioE.andCodCatEqualTo(codCat);
			criterioE.andCodPuestoEqualTo(codPuesto);
			paramE.setOrderByClause(" fec_inicio desc ");
			lstExperienciaBD = fichaExperienciaHistoricoDAO.selectByExampleHistorico(paramE);
		}
		
		List<Map<String,Object>> lstExperiencia = new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> lstExperienciaPublica = new ArrayList<Map<String,Object>>();
		for(FichaExperiencia e:lstExperienciaBD){
			
			//Siempre se coloca la fecha de fin de proceso?
			if(!indHistorico){
				//Unicamente ejecutado cuando se postula actualmente
				if(Constantes.MOTCESE_AUNLAB.equals(e.getCodMotivoCese()))
					e.setFecFin(new Date());
			}else {
				//Ejecutado para procesos antiguos.
				if(Constantes.MOTCESE_AUNLAB.equals(e.getCodMotivoCese()))
					e.setFecFin(proceso.getFfinPostu());	
			}
			
			
			Map<String, Object> mhTecnico = new HashMap<String, Object>();
			mhTecnico.put("desEntidad", e.getDesEntidad());
			mhTecnico.put("desArea", e.getDesArea());
			mhTecnico.put("desCargo", e.getDesCargo());
			mhTecnico.put("desLabores", e.getDesLabores());
			mhTecnico.put("desFecInicio", FechasUtil.getStringFromDateReporte(e.getFecInicio()));
			mhTecnico.put("desFecFin", FechasUtil.getStringFromDateReporte(e.getFecFin()));
			mhTecnico.put("desTiempoServ", FechasUtil.getDateDifferenceInDDMMYYYY(e.getFecInicio(),e.getFecFin()));
			mhTecnico.put("mtoRemu", ""+e.getMtoRemu());
			String desTipocontrato = "";
		    if("1".equals(e.getCodTipoentidad()))
		    	desTipocontrato = mapContratPublic.get(e.getCodTipocontrato());
		    else
		    	desTipocontrato = mapContratPrivad.get(e.getCodTipocontrato());
			mhTecnico.put("desTipocontrato", desTipocontrato);
			mhTecnico.put("desMotivoCese", mapMotivCese.get(e.getCodMotivoCese()));
			lstExperiencia.add(mhTecnico);
			
			//publica
			mhTecnico.put("desNomDireccion", e.getNomDireccion());
			if("1".equals(e.getCodTipoentidad()))
				lstExperienciaPublica.add(mhTecnico);
			
			//referencias
			mhTecnico.put("desCargoCont", e.getDesCargoCont());
			mhTecnico.put("nomContacto", e.getNomContacto());
			mhTecnico.put("numTelefono", e.getNumTelefono());
			mhTecnico.put("nomCorreo", e.getNomCorreo());
		}
		if(lstExperiencia.size()==0) lstExperiencia.add(new HashMap<String,Object>());
		parametros.put("lstExperiencia", lstExperiencia);
		
		//7. experiencia publica
		parametros.put("indAdminPublica", lstExperienciaPublica.size()==0?"X":"");
		if(lstExperienciaPublica.size()==0) lstExperienciaPublica.add(new HashMap<String,Object>());
		parametros.put("lstExperienciaPublica", lstExperienciaPublica);
		
		
		//datos proceso
		Puesto puesto = obtenerPuestoPostulacion(codCat, codPuesto);
		String strAnio = proceso.getPerProceso().length()>=4?proceso.getPerProceso().substring(0, 4):"";
		String desProceso = proceso.getDesAbreviCat() + " - " + strAnio + " " + puesto.getDesPuesto();
		String tipProceso = proceso.getDesAbreviCat().length()>3?proceso.getDesAbreviCat().substring(0, 3):"";
		parametros.put("ind1057", "CAS".equals(tipProceso)?"X":"");
		parametros.put("ind728", "728".equals(tipProceso)?"X":"");
		parametros.put("desProceso", desProceso);
		
		//DDJJ
		List<Map<String,Object>> lstDeclaracionOtros = new ArrayList<>();
		List<Map<String,Object>> lstDeclaracionAusencia = new ArrayList<>();
		Map<String, Object> mapDeclaracionOtros = new HashMap<>();
		Map<String, Object> mapDeclaracionAusencia = new HashMap<>();
		
		Map<String,Object> lstPreguntasDeclaracionJurada = listarPreguntasDeclaracionJurada();
		List<Parametro> lstPregDdjjAusencia = (List<Parametro>)lstPreguntasDeclaracionJurada.get("lstPreguntasDeclaracionAusencia");
		List<Parametro> lstPregDdjjOtros = (List<Parametro>)lstPreguntasDeclaracionJurada.get("lstPreguntasDeclaracionOtros");
		String[] vecPreguntasAusencia = obtenerDesPreguntasDdjj(lstPregDdjjAusencia);
		String[] vecPreguntasOtros = obtenerDesPreguntasDdjj(lstPregDdjjOtros);
		mapDeclaracionAusencia.put("desPregDDJJ01", vecPreguntasAusencia[0]);
		mapDeclaracionAusencia.put("desPregDDJJ02", vecPreguntasAusencia[1]);
		mapDeclaracionAusencia.put("desPregDDJJ03", vecPreguntasAusencia[2]);
		mapDeclaracionAusencia.put("desPregDDJJ04", vecPreguntasAusencia[3]);
		mapDeclaracionAusencia.put("desPregDDJJ05", vecPreguntasAusencia[4]);
		mapDeclaracionAusencia.put("desPregDDJJ06", vecPreguntasAusencia[5]);
		mapDeclaracionAusencia.put("desPregDDJJ07", vecPreguntasAusencia[6]);
		mapDeclaracionAusencia.put("desPregDDJJ08", vecPreguntasAusencia[7]);
		mapDeclaracionOtros.put("desPregDDJJ09", vecPreguntasOtros[8]);
		mapDeclaracionOtros.put("desPregDDJJ10", vecPreguntasOtros[9]);
		mapDeclaracionOtros.put("desPregDDJJ11", vecPreguntasOtros[10]);
		mapDeclaracionOtros.put("desPregDDJJ12", vecPreguntasOtros[11]);
		mapDeclaracionOtros.put("desPregDDJJ13", vecPreguntasOtros[12]);
		mapDeclaracionOtros.put("desPregDDJJ14", vecPreguntasOtros[13]);
		mapDeclaracionOtros.put("desPregDDJJ15", vecPreguntasOtros[14]);
		mapDeclaracionOtros.put("desPregDDJJ16", vecPreguntasOtros[15]);
		mapDeclaracionOtros.put("desPregDDJJ17", vecPreguntasOtros[16]);
		mapDeclaracionOtros.put("desPregDDJJ18", vecPreguntasOtros[17]);
		mapDeclaracionOtros.put("desPregDDJJ19", vecPreguntasOtros[18]);
		mapDeclaracionOtros.put("desPregDDJJ20", vecPreguntasOtros[19]);
		mapDeclaracionOtros.put("desPregDDJJ21", vecPreguntasOtros[20]); //PAS005
		mapDeclaracionOtros.put("desPregDDJJ22", vecPreguntasOtros[21]);
		mapDeclaracionOtros.put("desPregDDJJ23", vecPreguntasOtros[22]);
		mapDeclaracionOtros.put("desPregDDJJ24", vecPreguntasOtros[23]);
		
		List<DdjjPostulacion> lstRespuestasPostulante = listarRespuestasPostulante(usuario.getNumPostulante(), codCat, codPuesto);
		String[] vecRespuestasPostulante = obtenerDesRespuestasDdjj(lstRespuestasPostulante);
		mapDeclaracionAusencia.put("desRespDDJJ01", vecRespuestasPostulante[0]);
		mapDeclaracionAusencia.put("desRespDDJJ02", vecRespuestasPostulante[1]);
		mapDeclaracionAusencia.put("desRespDDJJ03", vecRespuestasPostulante[2]);
		mapDeclaracionAusencia.put("desRespDDJJ04", vecRespuestasPostulante[3]);
		mapDeclaracionAusencia.put("desRespDDJJ05", vecRespuestasPostulante[4]);
		mapDeclaracionAusencia.put("desRespDDJJ06", vecRespuestasPostulante[5]);
		mapDeclaracionAusencia.put("desRespDDJJ07", vecRespuestasPostulante[6]);
		mapDeclaracionAusencia.put("desRespDDJJ08", vecRespuestasPostulante[7]);
		mapDeclaracionOtros.put("desRespDDJJ09", vecRespuestasPostulante[8]);
		mapDeclaracionOtros.put("desRespDDJJ10", vecRespuestasPostulante[9]);
		mapDeclaracionOtros.put("desRespDDJJ11", vecRespuestasPostulante[10]);
		mapDeclaracionOtros.put("desRespDDJJ12", vecRespuestasPostulante[11]);
		mapDeclaracionOtros.put("desRespDDJJ13", vecRespuestasPostulante[12]);
		mapDeclaracionOtros.put("desRespDDJJ14", vecRespuestasPostulante[13]);
		mapDeclaracionOtros.put("desRespDDJJ15", vecRespuestasPostulante[14]);
		mapDeclaracionOtros.put("desRespDDJJ16", vecRespuestasPostulante[15]);
		mapDeclaracionOtros.put("desRespDDJJ17", vecRespuestasPostulante[16]);
		mapDeclaracionOtros.put("desRespDDJJ18", vecRespuestasPostulante[17]);
		mapDeclaracionOtros.put("desRespDDJJ19", vecRespuestasPostulante[18]);
		mapDeclaracionOtros.put("desRespDDJJ20", vecRespuestasPostulante[19]);
		mapDeclaracionOtros.put("desRespDDJJ21", vecRespuestasPostulante[20]);//PAS005
		mapDeclaracionOtros.put("desRespDDJJ22", vecRespuestasPostulante[21]);
		mapDeclaracionOtros.put("desRespDDJJ23", vecRespuestasPostulante[22]);
		mapDeclaracionOtros.put("desRespDDJJ24", vecRespuestasPostulante[23]);
		
		mapDeclaracionOtros.put("numColegiatura", fichaBD.getNumColegiatura());
		lstDeclaracionOtros.add(mapDeclaracionOtros);
		lstDeclaracionAusencia.add(mapDeclaracionAusencia);
		parametros.put("lstDeclaracionOtros", lstDeclaracionOtros);
		parametros.put("lstDeclaracionAusencia", lstDeclaracionAusencia);
		
		//indicador cumple conocimientos t�cnicos
		parametros.put("indConocimientoTec", vecRespuestasPostulante[19]);
		
		//pdf
		String urlCodificada = getUrlCodificada(codCat,codPuesto,numPostulante);
		log.debug("URL CODIFICADA:"+urlCodificada);
		String filePathQR = GeneradorQR.generarCodigoQR(urlCodificada);
		parametros.put("codigoQR", filePathQR);
		parametros.put("sunat", Constantes.RUTA_LOGO_SUNAT);
		parametros.put("SUBREPORT_URI", Constantes.RUTA_SUBREPORT);
		parametros.put("codCat", codCat);
		parametros.put("numPostulante", usuario.getNumPostulante());
		
		return parametros;
	}
	
	
	private String getUrlCodificada(Short codCat, String codPuesto, Integer numPostulante){
		String scodCat = StringUtils.leftPad(codCat.toString(), 10, '0');
		String scodPuesto = StringUtils.leftPad(codPuesto, 10, '0');
		String snumPostulante = StringUtils.leftPad(numPostulante.toString(), 10, '0');
		String codigoURL = scodCat+"_"+scodPuesto+"_"+snumPostulante;
		String hash = DigestUtils.sha256Hex(Constantes.URL_HASH);
		byte[] data = new String(codigoURL.concat(hash)).getBytes();
		String dataCodificada = Base64.encodeBase64String(data);
		return Constantes.URL_QRCODE+dataCodificada;
	}
	
	
	public byte[] obtenerReporteFromPlantilla(int idPlantilla, Map<String, Object> cabecera, List detalle) {
		if (log.isDebugEnabled()) log.debug("method obtenerReporteFromPlantilla");
		Integer firma = 0;

		try {
			Map<String, Object> datos = new HashMap<String, Object>();
			datos.put("detalle", detalle);
			datos.put("cabecera", cabecera);

			org.apache.axis.client.Service service = new org.apache.axis.client.Service();
			Call callGenPDF = (Call) service.createCall();
			callGenPDF.setTargetEndpointAddress(new java.net.URL(Constantes.RUTA_GENERADOR_SERVICE));
			callGenPDF.setOperationName("generar");
			callGenPDF.addParameter("iddoc", XMLType.XSD_INT, ParameterMode.IN);
			callGenPDF.addParameter("datos", XMLType.XSD_STRING,ParameterMode.IN);
			callGenPDF.addParameter("tipo", XMLType.XSD_STRING,ParameterMode.IN);
			callGenPDF.addParameter("modelo", XMLType.XSD_INT, ParameterMode.IN);
			callGenPDF.addParameter("firma", XMLType.XSD_INT, ParameterMode.IN);
			callGenPDF.setReturnClass(byte[].class);

			JsonSerializer serializer = new JsonSerializer();
			String json = (String) serializer.serialize(datos, new String[] {"~unique-id~", "class" });
			log.debug("Cadena json = " + json); // 23/02

			int modelo = 1000;

			byte[] numPDF = (byte[]) (callGenPDF.invoke(new Object[] {idPlantilla, json, "pdf", modelo, firma }));

			log.debug("numPDF en byte= " + numPDF); // 23/02
			return numPDF;
		} catch (Exception e) {
			log.error(this, e);
		}
		return new byte[] {};
	}
	   
	private <K, V> Map<K, V> generaMap(Object... keyValues) {
		Map<K, V> map = new HashMap<>();
		K key = null;
		for (int index = 0; index < keyValues.length; index++) {
			if (index % 2 == 0) {
				key = (K) keyValues[index];
			} else {
				map.put(key, (V) keyValues[index]);
			}
		}
		return map;
	}
	   
	private Map<String, String> generaMapFromList(List<Parametro> lista) {
		Map<String, String> map = new HashMap<>();
		for (Parametro p : lista) {
			map.put(p.getCodParametro(), p.getDesParametro());
		}
		return map;
	}
	   
	private String[] obtenerDesPreguntasDdjj(List<Parametro> lstPreguntas) {
		String[] vecPreguntas = new String[30];
		for (Parametro p : lstPreguntas) {
			vecPreguntas[Integer.parseInt(p.getCodDataParametro()) - 1] = p
					.getDesGlosa();
		}
		return vecPreguntas;
	}
	
	   
   private String[] obtenerDesRespuestasDdjj(List<DdjjPostulacion> lstRespuestas){
	   String[] vecRespuestas = new String[30];
	   String strRespuesta = "";
	   String [] pregEspeciales = new String [] {"10", "15", "19"};
	   List<String> lstPregEspeciales = new ArrayList<String>(Arrays.asList(pregEspeciales));
	   List<DdjjPostulacion> lstRespuestas15 = new ArrayList<>();
	   List<DdjjPostulacion> lstRespuestas19 = new ArrayList<>();
	   Map<String, String> mapRespuestas15 = generaMap("01","F�SICA","02","AUDITIVA","03","VISUAL","04","MENTAL");
	   Map<String, String> mapRespuestas19 = generaMap("01","Programa pr�cticas pre-profesionales","02","Programa pr�cticas profesionales","03","Programa de capacitaci�n laboral");
	   
	   for(DdjjPostulacion p:lstRespuestas){
		   if(!lstPregEspeciales.contains(p.getCodPregunta())){
			   if("01".equals(p.getCodRespuesta()))		strRespuesta = "SI";
			   else if("02".equals(p.getCodRespuesta()))strRespuesta = "NO";
			   vecRespuestas[Integer.parseInt(p.getCodPregunta())-1] = strRespuesta;
		   }else if("10".equals(p.getCodPregunta())){
			   if("00".equals(p.getCodRespuesta()))		strRespuesta = "NO APLICA";
			   else if("01".equals(p.getCodRespuesta()))strRespuesta = "HABILITADO";
			   else if("02".equals(p.getCodRespuesta()))strRespuesta = "DESHABILITADO";
			   vecRespuestas[Integer.parseInt(p.getCodPregunta())-1] = strRespuesta;
		   }else if("15".equals(p.getCodPregunta())){
			   lstRespuestas15.add(p);
		   }else if("19".equals(p.getCodPregunta())){
			   lstRespuestas19.add(p);
		   }
	   }
	   
	   String strRespuestaTmp = "";
	   for(DdjjPostulacion p:lstRespuestas15){
		   strRespuestaTmp += mapRespuestas15.get(p.getCodRespuesta()) +", ";
	   }
	   if(strRespuestaTmp.length() > 2)
		   strRespuestaTmp = strRespuestaTmp.substring(0, strRespuestaTmp.length()-2);
	   vecRespuestas[14] = strRespuestaTmp;//rpt15
	   
	   strRespuestaTmp = "";
	   for(DdjjPostulacion p:lstRespuestas19){
		   strRespuestaTmp += mapRespuestas19.get(p.getCodRespuesta()).toUpperCase() +", ";
	   }
	   if(strRespuestaTmp.length() > 2)
		   strRespuestaTmp = strRespuestaTmp.substring(0, strRespuestaTmp.length()-2);
	   vecRespuestas[18] = strRespuestaTmp;//rpt19
	   
	   return vecRespuestas;
   }

   @Override
   public Perfil getPerfil(Integer codCat) { 
	   return perfilDAO.selectByPrimaryKey(codCat);
   }

   @Override
   public Postulacion getPostulacion(Short codCat, String codPuesto, Integer numPostulante) {
	   PostulacionKey pk = new PostulacionKey();
	   pk.setCodCat(codCat);
	   pk.setCodPuesto(codPuesto);
	   pk.setNumPostulante(numPostulante);
	   return postulacionDAO.selectByPrimaryKey(pk);
   }
   
}
