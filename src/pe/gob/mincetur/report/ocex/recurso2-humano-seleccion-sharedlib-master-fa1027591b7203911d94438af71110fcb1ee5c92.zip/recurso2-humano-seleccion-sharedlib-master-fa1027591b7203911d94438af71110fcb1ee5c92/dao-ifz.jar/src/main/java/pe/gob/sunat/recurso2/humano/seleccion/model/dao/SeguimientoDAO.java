package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Seguimiento;


public interface SeguimientoDAO {

	 void insert(Seguimiento record);
	
	
}
