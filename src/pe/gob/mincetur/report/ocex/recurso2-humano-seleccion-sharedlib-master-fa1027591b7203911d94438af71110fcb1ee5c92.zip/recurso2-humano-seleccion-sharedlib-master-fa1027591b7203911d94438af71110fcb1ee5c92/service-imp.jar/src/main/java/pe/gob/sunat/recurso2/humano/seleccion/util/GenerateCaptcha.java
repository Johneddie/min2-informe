package pe.gob.sunat.recurso2.humano.seleccion.util;

import java.awt.image.BufferedImage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.octo.captcha.CaptchaException;
import com.octo.captcha.service.captchastore.FastHashMapCaptchaStore;
import com.octo.captcha.service.image.DefaultManageableImageCaptchaService;
import com.octo.captcha.service.image.ImageCaptchaService;

public class GenerateCaptcha {
	
	private static final Log log = LogFactory.getLog("pe.gob.sunat.recurso2.humano.seleccion.util.GenerateCaptcha");
	
	private GenerateCaptcha() {
	}
	
	// a singleton class
	private static ImageCaptchaService instance = new DefaultManageableImageCaptchaService(new FastHashMapCaptchaStore(),
            new SunatImageCaptchaEngine(),
            100,
            100000,
            75000);
	
	public static ImageCaptchaService getInstance(){
	    return instance;
	}

	public static BufferedImage generateCaptcha(String id){
	    BufferedImage image = null;
	    try{
	      image = instance.getImageChallengeForID(id);
	    }
	    catch (Exception e) {
	      throw new CaptchaException(e);
	    }

	    return image;
	}
	
	public static boolean isValid(String id, String texto){
		boolean salida = false;
		try{
			salida = instance.validateResponseForID(id, texto); 
		}catch(Exception e){
			log.debug("error",e);
		}
		return salida;
	}
	
}
