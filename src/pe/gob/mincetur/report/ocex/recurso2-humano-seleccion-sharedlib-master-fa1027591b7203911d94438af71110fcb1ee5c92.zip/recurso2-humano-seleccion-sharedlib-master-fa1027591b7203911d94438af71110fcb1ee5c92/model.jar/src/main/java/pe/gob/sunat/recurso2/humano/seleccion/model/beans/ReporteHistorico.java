package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

public class ReporteHistorico {
	
	private String desProceso;
	private String nomPersona;
	private String resultado;
	private String fechaResultado;
	
	public String getDesProceso() {
		return desProceso;
	}
	public void setDesProceso(String desProceso) {
		this.desProceso = desProceso;
	}
	public String getNomPersona() {
		return nomPersona;
	}
	public void setNomPersona(String nomPersona) {
		this.nomPersona = nomPersona;
	}
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	public String getFechaResultado() {
		return fechaResultado;
	}
	public void setFechaResultado(String fechaResultado) {
		this.fechaResultado = fechaResultado;
	}
	
}
