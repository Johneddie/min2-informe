package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.Map;


import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;

public interface AccesoPostulacionService {
	
	/**
	 * Por ahora solo validar� si el usuario y contrase�a es v�lido
	 * */
	public int procesarLogin(String nomEmail, String desClave);

	public Map<String, Object> olvidoClave(String nomEmail);
		
	
	public String generaClaveAcceso();
	
	public int crearCuenta(Usuario usuario);
	
	public int validaClaveAccesoInicial(String uid, String claveAcceso);
	
	public int registrarNuevaClave(String nuevaClave, String confirmarClave, String nomEmail);
	
	public Usuario getUsuario(String nomEmail);

	public Map<String, Object> obtenerDatosReniec(String numDoc, String tipDoc) ;
	
	public int validarMail(String nomEmail);
	
	public int validarDocumento(String codtipdoc, String numdoc);
	
	public Usuario getUsuarioPorId(Integer numPostulante);
}
