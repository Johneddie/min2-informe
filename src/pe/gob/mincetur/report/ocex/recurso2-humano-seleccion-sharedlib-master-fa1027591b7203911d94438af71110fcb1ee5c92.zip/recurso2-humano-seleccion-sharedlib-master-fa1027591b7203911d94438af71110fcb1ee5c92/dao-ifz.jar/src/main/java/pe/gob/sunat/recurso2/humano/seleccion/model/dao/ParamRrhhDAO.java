package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;

public interface ParamRrhhDAO {

	List<Parametro> listarParametros(String codParametro);
}
