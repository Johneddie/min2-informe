package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

import java.util.Date;

public class ArchivoPostulacion {
    private Integer numArcPostula;

    private String nomArchivo;

    private Integer numTamano;

    private String indEstado;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    private byte[] arcPostula;

    public Integer getNumArcPostula() {
        return numArcPostula;
    }

    public void setNumArcPostula(Integer numArcPostula) {
        this.numArcPostula = numArcPostula;
    }

    public String getNomArchivo() {
        return nomArchivo;
    }

    public void setNomArchivo(String nomArchivo) {
        this.nomArchivo = nomArchivo == null ? null : nomArchivo.trim();
    }

    public Integer getNumTamano() {
        return numTamano;
    }

    public void setNumTamano(Integer numTamano) {
        this.numTamano = numTamano;
    }

    public String getIndEstado() {
        return indEstado;
    }

    public void setIndEstado(String indEstado) {
        this.indEstado = indEstado == null ? null : indEstado.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public byte[] getArcPostula() {
        return arcPostula;
    }

    public void setArcPostula(byte[] arcPostula) {
        this.arcPostula = arcPostula;
    }
}