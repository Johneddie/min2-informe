package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacionExample;

public interface ArchivoPostulacionDAO {
    int countByExample(ArchivoPostulacionExample example);

    int deleteByExample(ArchivoPostulacionExample example);

    int deleteByPrimaryKey(Integer numArcPostula);

    void insert(ArchivoPostulacion record);

    public Integer insertSelective(ArchivoPostulacion record);

    List<ArchivoPostulacion> selectByExampleWithBLOBs(ArchivoPostulacionExample example);

    List<ArchivoPostulacion> selectByExampleWithoutBLOBs(ArchivoPostulacionExample example);

    ArchivoPostulacion selectByPrimaryKey(Integer numArcPostula);
    
    ArchivoPostulacion selectByPrimaryKeyWithoutBLOBs(Integer numArcPostula);

    int updateByExampleSelective(ArchivoPostulacion record, ArchivoPostulacionExample example);

    int updateByExampleWithBLOBs(ArchivoPostulacion record, ArchivoPostulacionExample example);

    int updateByExampleWithoutBLOBs(ArchivoPostulacion record, ArchivoPostulacionExample example);

    int updateByPrimaryKeySelective(ArchivoPostulacion record);

    int updateByPrimaryKeyWithBLOBs(ArchivoPostulacion record);

    int updateByPrimaryKeyWithoutBLOBs(ArchivoPostulacion record);
    
    public int updateBlob(Map params);
}