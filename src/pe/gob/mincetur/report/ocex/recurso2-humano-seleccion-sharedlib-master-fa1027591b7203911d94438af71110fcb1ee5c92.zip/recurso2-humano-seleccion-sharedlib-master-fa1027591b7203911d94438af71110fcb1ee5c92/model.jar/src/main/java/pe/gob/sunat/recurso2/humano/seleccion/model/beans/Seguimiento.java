package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

import java.util.Date;

public class Seguimiento {
	
	private String codidentificador;
	
	private String indidentificador;
	
	private String codusuregis;
	
	private Date fecregis;
	
	private String indaccion;
	
	private String desaccion;
	
	
	public String getCodidentificador() {
		return codidentificador;
	}
	public void setCodidentificador(String codidentificador) {
		this.codidentificador = codidentificador;
	}
	public String getIndidentificador() {
		return indidentificador;
	}
	public void setIndidentificador(String indidentificador) {
		this.indidentificador = indidentificador;
	}
	public String getCodusuregis() {
		return codusuregis;
	}
	public void setCodusuregis(String codusuregis) {
		this.codusuregis = codusuregis;
	}
	public Date getFecregis() {
		return fecregis;
	}
	public void setFecregis(Date fecregis) {
		this.fecregis = fecregis;
	}
	public String getIndaccion() {
		return indaccion;
	}
	public void setIndaccion(String indaccion) {
		this.indaccion = indaccion;
	}
	public String getDesaccion() {
		return desaccion;
	}
	public void setDesaccion(String desaccion) {
		this.desaccion = desaccion;
	}
	
	

}
