package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParametroDAO;

@SuppressWarnings({ "deprecation", "unchecked" })
public class ParametroDAOImpl extends SqlMapDAOBase implements ParametroDAO{

	@Override
	public Parametro selectByPrimaryKey(
			String codParametro, String codDataParametro) {
		Parametro paramSearch = new Parametro();
		paramSearch.setCodParametro(codParametro);
		paramSearch.setCodDataParametro(codDataParametro);
		return (Parametro)getSqlMapClientTemplate().queryForObject("T5864parametro.selectByPrimaryKey", paramSearch);
	}

	
	@Override
	public List<Parametro> listarPreguntasDeclaracionJurada(Parametro params) {
		return (List<Parametro>)getSqlMapClientTemplate().queryForList("T5864parametro.listPreguntasDeclaracionJurada", params);
	}

}
