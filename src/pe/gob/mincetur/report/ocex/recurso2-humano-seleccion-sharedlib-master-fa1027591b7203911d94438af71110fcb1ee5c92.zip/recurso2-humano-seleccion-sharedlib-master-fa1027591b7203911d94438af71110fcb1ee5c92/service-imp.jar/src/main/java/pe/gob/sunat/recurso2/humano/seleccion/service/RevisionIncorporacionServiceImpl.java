package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Derivacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DerivacionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DerivacionKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DetalleFase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DetalleFaseExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DetalleFaseKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Empleado;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Fase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacionHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidadHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperienciaHistoricoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ProcesoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ReporteHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Revision;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.RevisionDocumento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.RevisionDocumentoExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.RevisionExample;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.SeccionEvaluacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.SeccionEvaluacionKey;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.UnidadOrganica;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.DerivacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.DetalleFaseDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.EmpleadoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FaseDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaConocimientoHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEducacionHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaEspecialidadHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaExperienciaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.FichaHistoricoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ProcesoPostulacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.PuestoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.RevisionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.RevisionDocumentoDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.SeccionEvaluacionDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.UnidadOrganicaDAO;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;
//Fin Codigo practicante Jean Pierre


@Service("revisionIncorporacionService")
public class RevisionIncorporacionServiceImpl implements RevisionIncorporacionService{

	
	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private PuestoDAO puestoDAO;//old
		
	@Autowired
	private FichaHistoricoDAO fichaHistoricoDAO;
 
	
	@Autowired 
	private FichaEducacionHistoricoDAO fichaEducacionHistoricoDAO; 
	
	@Autowired
	private FichaEspecialidadHistoricoDAO fichaEspecialidadHistoricoDAO;
	
	@Autowired
	private FichaConocimientoHistoricoDAO fichaConocimientoHistoricoDAO; 
	
	@Autowired
	private FichaExperienciaHistoricoDAO fichaExperienciaHistoricoDAO;
	
	@Autowired
	private SeccionEvaluacionDAO seccionEvaluacionDAO;
	
	@Autowired
	private EmpleadoDAO empleadoDAO;
	
	@Autowired
	private RevisionDAO revisionDAO;
	
	@Autowired
	private RevisionDocumentoDAO revisionDocumentoDAO;
	
	@Autowired
	private DerivacionDAO derivacionDAO;
	
	@Autowired
	private UnidadOrganicaDAO unidadOrganicaDAO;
	
	@Autowired
	private FaseDAO faseDAO;
	
	@Autowired
	private DetalleFaseDAO detalleFaseDAO;
	
	
	@Autowired
	private ProcesoPostulacionDAO procesoPostulacionDAO;
	

	@Override
	public List<PuestoProceso> listarProcesosPorUnidad(String codUuoo, String codPersona) {
		return puestoDAO.listarPuestosProcesoRevision(codUuoo,codPersona);
	}

	@Override
	public List<FichaHistorico> listarPostulantesPorProceso(Short codCat, String codPuesto) {
		// TODO Auto-generated method stub
		String codFase = fichaHistoricoDAO.getCodigoUltimaFase(codCat);
		return fichaHistoricoDAO.listarPostulantesPorProceso(codCat, codPuesto,codFase);
	}
	
	
	//Para Data Educacion
	@Override
	public List<FichaEducacion> listarDatosEducativos(Short codCat,
			String codPuesto, Integer numPostulante) {
		
		FichaEducacionHistorico ficha = new FichaEducacionHistorico();				
		ficha.setCodCat(codCat);
		ficha.setCodPuesto(codPuesto);
		ficha.setNumPostulante(numPostulante);
		List<FichaEducacion> estudios = fichaEducacionHistoricoDAO.listarDatosEducativos(ficha);			
		return estudios;
	}
	
	//Para data Especializacion - Certificacion
	@Override
	public List<FichaEspecialidad> listarEstudiosEspecializacion(
			Short codCat, String codPuesto, Integer numPostulante,String indCertificacion) {
		
		FichaEspecialidadHistorico paramSearchE = new FichaEspecialidadHistorico();		
		paramSearchE.setCodCat(codCat);
		paramSearchE.setCodPuesto(codPuesto);
		paramSearchE.setNumPostulante(numPostulante);
		paramSearchE.setIndCertificacion(indCertificacion);		
		
		List<FichaEspecialidad> lstEstudiosEspecializacionBD = fichaEspecialidadHistoricoDAO.listarEstudiosEspecializacion(paramSearchE);
		
		return lstEstudiosEspecializacionBD;
				
	}
	
	//para conocimiento informatico
	
	@Override
	public List<FichaConocimiento> listarConocimiento(Integer numPostulante,
			Short codCat, String codPuesto) {
		return fichaConocimientoHistoricoDAO.listarConocimiento(numPostulante, codCat, codPuesto);
	}

	//para experiencia laboral
	
	@Override
	public List<FichaExperiencia> listarExperienciaLaboral(Short codCat,
			String codPuesto, Integer numPostulante) {
		
		FichaExperienciaHistoricoExample paramE = new FichaExperienciaHistoricoExample() ;
		FichaExperienciaHistoricoExample.Criteria criterioE = paramE.createCriteria();
		criterioE.andCodCatEqualTo(codCat);
		criterioE.andCodPuestoEqualTo(codPuesto);
		criterioE.andNumPostulanteEqualTo(numPostulante);		
		paramE.setOrderByClause(" fec_inicio desc ");
		List<FichaExperiencia> lstExperienciaBD = fichaExperienciaHistoricoDAO.selectByExampleHistorico(paramE);		
		return lstExperienciaBD;
		
	}

	@Override
	public String getCodigoUltimaFase(Short codCat) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SeccionEvaluacion getSeccionEvaluacion(Short codCat, String codSeccion) {
		// TODO Auto-generated method stub
		SeccionEvaluacionKey key = new SeccionEvaluacionKey();
		key.setCodCat(codCat);
		key.setCodSeccion(codSeccion);
		SeccionEvaluacion seccionEvaluacion = seccionEvaluacionDAO.selectByPrimaryKey(key);
		if(seccionEvaluacion==null) {
			seccionEvaluacion = new SeccionEvaluacion();
			seccionEvaluacion.setIndSeleccion("0");
		}
		return seccionEvaluacion;//prevenci�n de nulls
	}
	//para reporte historico
	@Override
	public List<ReporteHistorico> listarReporteHistorico(Integer numArcPostula) {
		// TODO Auto-generated method stub
		//return ReporteHistorico.listarReporteHistorico(numArcPostula);
		return puestoDAO.listarReporteHistorico(numArcPostula);
	}


	@Override
	public List<Derivacion> listarDerivaciones(Derivacion derivacion) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Empleado buscarEmpleado(String codEmpleado) {
		return empleadoDAO.selectByPrimaryKey(codEmpleado);
	}

	
	@Override
	public boolean esRevisorDeProceso(String codUnidad, String codEmpleado) {
		// TODO Auto-generated method stub
		UnidadOrganica unidad = unidadOrganicaDAO.selectByPrimaryKey(codUnidad);
		if(unidad!=null) {
			String codJefeBD = (!StringUtils.isEmpty(unidad.getT12codEncar()))?unidad.getT12codEncar():unidad.getT12codJefat();
			if(codEmpleado.equals(codJefeBD)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<Empleado> buscarEmpleados(String codRegistro, String apePaterno, String apeMaterno, String nombres,
			Short codCat) {
		// TODO Auto-generated method stub
		return empleadoDAO.buscarEmpleados(codRegistro, apePaterno, apeMaterno, nombres, codCat);
	}

	@Override
	public List<Empleado> buscarEmpleadosAsignados(String codRegistro, String apePaterno, String apeMaterno,
			String nombres, Short codCat) {
		return empleadoDAO.buscarEmpleadosAsignados(codRegistro, apePaterno, apeMaterno, nombres, codCat);
	}

	@Override
	public void registrarActualizarDerivacion(Derivacion derivacion, String indTipo) {
		
		DerivacionExample derivacionParam = new DerivacionExample();
		
		DerivacionExample.Criteria criterios = derivacionParam.createCriteria();
		criterios.andCodCatEqualTo(derivacion.getCodCat());
		criterios.andCodPuestoEqualTo(derivacion.getCodPuesto());
		criterios.andCodRegrecepEqualTo(derivacion.getCodRegrecep());
		
		List<Derivacion> derivacionesBD = derivacionDAO.selectByExample(derivacionParam);//solo debe de retornar un registro
		
		if(!CollectionUtils.isEmpty(derivacionesBD)) {
			//Si ya existe una asignaci�n para este proceso
			if("1".equals(indTipo)) {
				derivacion.setFecRegis(null);
				derivacion.setCodUsuregis(null);
				derivacion.setIndDel("0");
				derivacionDAO.updateByExampleSelective(derivacion, derivacionParam);
				
			}else {
				//Se quita la derivacion
				derivacion.setFecRegis(null);
				derivacion.setCodUsuregis(null);
				derivacion.setIndDel("1");
				derivacionDAO.updateByExampleSelective(derivacion, derivacionParam);
			}
			
		}else {
			
			derivacionDAO.insertSelective(derivacion);
			
		}
		
	}

	@Override
	public Revision registrarActualizarRevision(Revision revision) {
		log.info("Iniciando grabaci�n de la revision para la secci�n:"+revision.getCodSeccion());
		List<RevisionDocumento> documentos = revision.getRevisionesDocs();
		//1. sacamos el primer n�mero de revisi�n para este proceso y este postulante
		
		Short numRevision = revisionDAO.siguienteNumeroRevision(revision);
		revision.setNumRevision(numRevision);
		revision.setFecRegis(new Date());
		revision.setIndDel("0");
		revisionDAO.insertSelective(revision);
		
		for(RevisionDocumento documento:documentos) {
			documento.setNumRevision(numRevision);
			documento.setIndDel("0");
			documento.setFecRegis(new Date());
			documento.setCodUsuregis(revision.getCodUsuregis());
			if(documento.getNumArcPostula()==0)documento.setNumArcPostula(null);
			revisionDocumentoDAO.insertSelective(documento);
		}
		
		return revision;//la revision con su clave primaria.
	}

	@Override
	public List<String> registrarActualizarRevisionPostulante(DetalleFase revisionPostulante) {
		
		Revision revisionBD = new Revision();
		revisionBD.setCodCat(revisionPostulante.getCodCat());
		revisionBD.setCodPuesto("001");//puesto='001'
		revisionBD.setNumPostulante(revisionPostulante.getNumPostulante());
		
		revisionPostulante.setCodFase(Constantes.CODIGO_FASE_REVISION_DOCUMENTO);//constante
		revisionPostulante.setNumVersion(Constantes.NUM_VERSION_REVISION);//constante
		
		
		//Aqui antes de grabar la postulaci�n debemos de verificar que se haya revisado todas las secciones.
		SeccionEvaluacion formacion = getSeccionEvaluacion(revisionPostulante.getCodCat(), Constantes.CODIGO_SECCION_FORMACION);
		SeccionEvaluacion estudios = getSeccionEvaluacion(revisionPostulante.getCodCat(), Constantes.CODIGO_SECCION_ESTUDIOS_ESPECIALIZACION);
		SeccionEvaluacion certificaciones = getSeccionEvaluacion(revisionPostulante.getCodCat(), Constantes.CODIGO_SECCION_CERTIFICACIONES);
		SeccionEvaluacion conocimientos = getSeccionEvaluacion(revisionPostulante.getCodCat(), Constantes.CODIGO_SECCION_CONOCIMIENTOS);
		SeccionEvaluacion experiencia = getSeccionEvaluacion(revisionPostulante.getCodCat(), Constantes.CODIGO_SECCION_EXPERIENCIA);
		//Verificamos si se
		List<String> errores = new ArrayList<String>();
		if("1".equals(formacion.getIndSeleccion())) {
			revisionBD.setCodSeccion(Constantes.CODIGO_SECCION_FORMACION);
			if(!seccionRevisada(revisionBD))errores.add("No ha evaluado la Formaci&oacute;n Acad&eacute;mica.");
		}
		
		if("1".equals(estudios.getIndSeleccion())) {
			revisionBD.setCodSeccion(Constantes.CODIGO_SECCION_ESTUDIOS_ESPECIALIZACION);
			if(!seccionRevisada(revisionBD))errores.add("No ha evaluado los Estudios de Especializaci&oacute;n.");
		}
		
		if("1".equals(certificaciones.getIndSeleccion())) {
			revisionBD.setCodSeccion(Constantes.CODIGO_SECCION_CERTIFICACIONES);
			if(!seccionRevisada(revisionBD))errores.add("No ha evaluado las Certificaciones.");
		}
		
		if("1".equals(conocimientos.getIndSeleccion())) {
			revisionBD.setCodSeccion(Constantes.CODIGO_SECCION_CONOCIMIENTOS);
			if(!seccionRevisada(revisionBD))errores.add("No ha evaluado los Conocimientos de Ofim&aacute;tica e Idiomas.");
		}
		
		if("1".equals(experiencia.getIndSeleccion())) {
			revisionBD.setCodSeccion(Constantes.CODIGO_SECCION_EXPERIENCIA);
			if(!seccionRevisada(revisionBD))errores.add("No ha evaluado la Experiencia Laboral.");
		}
		
		if(CollectionUtils.isEmpty(errores)) {
			DetalleFaseKey key = new DetalleFaseKey();
			key.setCodCat(revisionPostulante.getCodCat());//enviado desde js
			key.setCodFase(revisionPostulante.getCodFase());
			key.setNumPostulante(revisionPostulante.getNumPostulante());//enviado desde js
			key.setNumVersion(revisionPostulante.getNumVersion());
			DetalleFase detalleBD = detalleFaseDAO.selectByPrimaryKey(key);
			if(detalleBD==null) {
				//Insertamos
				//revisionPostulante.setCodUsumodif(null);
				revisionPostulante.setFecRegis(new Date());
				revisionPostulante.setFecModif(new Date());
				revisionPostulante.setIndDel("0");
				detalleFaseDAO.insertSelective(revisionPostulante);
			}else {
				//Actualizamos
				revisionPostulante.setCodUsuregis(null);
				revisionPostulante.setFecModif(new Date());
				detalleFaseDAO.updateByPrimaryKeySelective(revisionPostulante);
			}	
		}
		
		return errores;
	}

	@Override
	public void finalizarProcesoPostulacion(Fase fase) {
		//Cerramos la fase
		fase.setIndBloqueo("1");
		fase.setCodFase(Constantes.CODIGO_FASE_REVISION_DOCUMENTO);
		fase.setFecCierre(new Date());
		fase.setCodUsucierre(fase.getCodUsumodif());
		fase.setNumVersion(new Short("0"));
		faseDAO.updateByPrimaryKeySelective(fase);
		
		//Ahora actualizamos el proceso
		ProcesoPostulacion procesoUpdate = new ProcesoPostulacion();
		procesoUpdate.setCodCat(fase.getCodCat());
		procesoUpdate.setCodEstado(Constantes.CODIGO_PROCESO_REVISADO);
		procesoUpdate.setFecModif(new Date());
		procesoUpdate.setCuserModifica(fase.getCodUsumodif());
		procesoPostulacionDAO.updateByPrimaryKeySelective(procesoUpdate);
	}

	@Override
	public void devolverProcesoPostulacion(Fase fase) {
		//Ahora actualizamos el proceso
		ProcesoPostulacion procesoUpdate = new ProcesoPostulacion();
		procesoUpdate.setCodCat(fase.getCodCat());
		procesoUpdate.setCodEstado(Constantes.CODIGO_PROCESO_INICIO);
		procesoUpdate.setFecModif(new Date());
		procesoUpdate.setCuserModifica(fase.getCodUsumodif());
		procesoPostulacionDAO.updateByPrimaryKeySelective(procesoUpdate);
	}

	@Override
	public boolean validarProcesoPostulacion(Fase fase) {
		
		String codFase = fichaHistoricoDAO.getCodigoUltimaFase(fase.getCodCat());//Sacamos el c�digo de la fases
		
		//postulantes a evaluar(la lista)
		DetalleFaseExample detalleParamExample1 = new DetalleFaseExample();
		DetalleFaseExample.Criteria criterios1 = detalleParamExample1.createCriteria();
		criterios1.andCodCatEqualTo(fase.getCodCat());
		criterios1.andCodFaseEqualTo(codFase);
		criterios1.andNumVersionEqualTo(new Short("0"));
		criterios1.andCodResultadoEqualTo("01");//aprobados de la fase previa;
		criterios1.andIndDelEqualTo("0");
		int postulantesAEvaluar = detalleFaseDAO.countByExample(detalleParamExample1);
		
		//postulantes evaluados
		DetalleFaseExample detalleParamExample2 = new DetalleFaseExample();
		DetalleFaseExample.Criteria criterios2 = detalleParamExample2.createCriteria();
		criterios2.andCodCatEqualTo(fase.getCodCat());
		criterios2.andCodFaseEqualTo("05");//REVISADOS
		criterios2.andNumVersionEqualTo(new Short("0"));
		
		
		List<String> resultados = new ArrayList<String>();
		resultados.add("00");//no apto
		resultados.add("01");//no apto
		criterios2.andCodResultadoIn(resultados);//Se validan los aptos y no aptos, osea los revisados
		criterios2.andIndDelEqualTo("0");
		int postulantesEvaluados = detalleFaseDAO.countByExample(detalleParamExample2);
		
		return postulantesAEvaluar==postulantesEvaluados;
	}

	@Override
	public boolean seccionRevisada(Revision revision) {
		RevisionExample revisionParam = new RevisionExample();
		RevisionExample.Criteria criterio = revisionParam.createCriteria();
		criterio.andCodCatEqualTo(revision.getCodCat());
		criterio.andCodPuestoEqualTo(revision.getCodPuesto());
		criterio.andNumPostulanteEqualTo(revision.getNumPostulante());
		criterio.andCodSeccionEqualTo(revision.getCodSeccion());
		criterio.andIndDelEqualTo("0");
		int registros = revisionDAO.countByExample(revisionParam);
		return registros>0;
	}

	
	@Override
	public Map<String, Object> getUltimaRevisionPostulante(Revision revisionParam) {
		Map<String,Object> revisionesMap = new HashMap<>();
		
		Short maxRevision;
		
		//revision de los estudios de la formaci�n
		revisionParam.setCodSeccion(Constantes.CODIGO_SECCION_FORMACION);//para sacar el m�ximo
		maxRevision = revisionDAO.maxNumeroRevision(revisionParam);
		if(maxRevision>0) {
			revisionParam.setNumRevision(maxRevision);
			Revision revFormacion = getUltimaRevisionSeccion(revisionParam);
			revisionesMap.put("revFormacion", revFormacion);	
		}
		
		//revision de los estudios de especializaci�n
		revisionParam.setCodSeccion(Constantes.CODIGO_SECCION_ESTUDIOS_ESPECIALIZACION);
		maxRevision = revisionDAO.maxNumeroRevision(revisionParam);
		if(maxRevision>0) {
			revisionParam.setNumRevision(maxRevision);
			Revision revEstudios = getUltimaRevisionSeccion(revisionParam);
			revisionesMap.put("revEstudios", revEstudios);	
		}
		
		//revision de las certificaciones
		revisionParam.setCodSeccion(Constantes.CODIGO_SECCION_CERTIFICACIONES);
		maxRevision = revisionDAO.maxNumeroRevision(revisionParam);
		if(maxRevision>0) {
			revisionParam.setNumRevision(maxRevision);
			Revision revCertificaciones = getUltimaRevisionSeccion(revisionParam);
			revisionesMap.put("revCertificaciones", revCertificaciones);	
		}
		
		//revision de los conocimientos
		revisionParam.setCodSeccion(Constantes.CODIGO_SECCION_CONOCIMIENTOS);
		maxRevision = revisionDAO.maxNumeroRevision(revisionParam);
		if(maxRevision>0) {
			revisionParam.setNumRevision(maxRevision);
			Revision revConocimientos = getUltimaRevisionSeccion(revisionParam);
			revisionesMap.put("revConocimientos", revConocimientos);	
		}
		
		//revision de la experiencia
		revisionParam.setCodSeccion(Constantes.CODIGO_SECCION_EXPERIENCIA);
		maxRevision = revisionDAO.maxNumeroRevision(revisionParam);
		if(maxRevision>0) {
			revisionParam.setNumRevision(maxRevision);
			Revision revExperiencia = getUltimaRevisionSeccion(revisionParam);
			revisionesMap.put("revExperiencia", revExperiencia);	
		}
		
		//postulantes evaluados
		
		DetalleFaseKey key = new DetalleFaseKey();
		key.setCodCat(revisionParam.getCodCat());
		key.setCodFase("05");//REVISADOS
		key.setNumVersion(new Short("0"));
		key.setNumPostulante(revisionParam.getNumPostulante());
		
		DetalleFase evaluacion = detalleFaseDAO.selectByPrimaryKey(key);
		revisionesMap.put("evaluacion", evaluacion);	
		
		return revisionesMap;
		
	}

	@Override
	public Revision getUltimaRevisionSeccion(Revision revisionParam) {
		Revision revisionBD = revisionDAO.selectByPrimaryKey(revisionParam);
		if(revisionBD!=null) {
			RevisionDocumentoExample revDocExample = new RevisionDocumentoExample(); 
			RevisionDocumentoExample.Criteria criterios = revDocExample.createCriteria();
			criterios.andCodCatEqualTo(revisionParam.getCodCat());
			criterios.andCodPuestoEqualTo(revisionParam.getCodPuesto());
			criterios.andNumPostulanteEqualTo(revisionParam.getNumPostulante());
			criterios.andCodSeccionEqualTo(revisionParam.getCodSeccion());
			criterios.andNumRevisionEqualTo(revisionParam.getNumRevision());
			List<RevisionDocumento> documentos = revisionDocumentoDAO.selectByExample(revDocExample);
			revisionBD.setRevisionesDocs(documentos);	
		}
		return revisionBD;
		
	}

}










