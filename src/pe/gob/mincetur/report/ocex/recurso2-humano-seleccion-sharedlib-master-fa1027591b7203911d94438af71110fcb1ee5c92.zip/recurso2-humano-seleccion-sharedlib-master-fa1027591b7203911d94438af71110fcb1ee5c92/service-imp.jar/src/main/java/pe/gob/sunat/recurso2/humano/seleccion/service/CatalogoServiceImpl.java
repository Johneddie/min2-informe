package pe.gob.sunat.recurso2.humano.seleccion.service;

import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_CENTROS_ESTUDIO;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_CONTRATOS_PRIVADOS;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_CONTRATOS_PUBLICOS;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_GRADOS_ACADEMICOS;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_INDICADORES_PUESTO;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_MOTIVOS_CESE;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_PROFESIONES;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_TIPOS_EXPERIENCIA;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_VIAS_DOMICILIO;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_ZONAS_DOMICILIO;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_TIPOS_BREVETE;
import static pe.gob.sunat.recurso2.humano.seleccion.util.Constantes.CODIGO_TABLA_TIPOS_ESTUDIO;

import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.CodigosRrhhDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParamContribuyenteDAO;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParamRrhhDAO;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;


@Service("catalogoService")
public class CatalogoServiceImpl implements CatalogoService{

	public final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private ParamContribuyenteDAO paramContribuyenteDAO;
	
	@Autowired
	private ParamRrhhDAO paramRrhhDAO;
	
	@Autowired
	private CodigosRrhhDAO codigosRrhhDAO;
	
	@Override
	public List<Parametro> listarDepartamentos() {
		return paramContribuyenteDAO.listarDepartamentos();
	}

	@Override
	public List<Parametro> listarProvincias(String codDepartamento) {
		log.info("[Catalogo]. Listando provincias con c�digo de departamento:"+codDepartamento);
		return paramContribuyenteDAO.listarProvincias(codDepartamento);
	}

	@Override
	public List<Parametro> listarDistritos(String codProvincia) {
		log.info("[Catalogo]. Listando distritos con c�digo de provincia:"+codProvincia);
		return paramContribuyenteDAO.listarDistritos(codProvincia);
	}

	@Override
	public List<Parametro> listarZonasDomiciliarias() {
		log.info("[Catalogo]. Listando zonas de la tabla:"+CODIGO_TABLA_ZONAS_DOMICILIO);
		return paramRrhhDAO.listarParametros(CODIGO_TABLA_ZONAS_DOMICILIO);
	}

	@Override
	public List<Parametro> listarViasDomiciliarias() {
		log.info("[Catalogo]. Listando vias de la tabla:"+CODIGO_TABLA_VIAS_DOMICILIO);
		return paramRrhhDAO.listarParametros(CODIGO_TABLA_VIAS_DOMICILIO);
	}

	@Override
	public List<Parametro> listarGradosAcademicos() {
		log.info("[Catalogo]. Listando centros de estudio de la tabla:"+CODIGO_TABLA_CENTROS_ESTUDIO);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_GRADOS_ACADEMICOS,"1");
	}

	@Override
	public List<Parametro> listarProfesiones() {
		log.info("[Catalogo]. Listando centros de estudio de la tabla:"+CODIGO_TABLA_PROFESIONES);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_PROFESIONES,"0");
	}

	@Override
	public List<Parametro> listarCentrosEstudio() {
		return codigosRrhhDAO.listarCentrosEstudio();
	}

	@Override
	public List<Parametro> listarIndicadoresPuesto() {
		log.info("[Catalogo]. Listando centros de estudio de la tabla:"+CODIGO_TABLA_INDICADORES_PUESTO);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_INDICADORES_PUESTO,"1");
	}

	@Override
	public List<Parametro> listarContratosPrivados() {
		log.info("[Catalogo]. Listando contratos privados:"+CODIGO_TABLA_CONTRATOS_PRIVADOS);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_CONTRATOS_PRIVADOS,"1");
	}

	@Override
	public List<Parametro> listarContratosPublicos() {
		log.info("[Catalogo]. Listando contratos publicos:"+CODIGO_TABLA_CONTRATOS_PUBLICOS);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_CONTRATOS_PUBLICOS,"1");
	}

	@Override
	public List<Parametro> listarMotivosCese() {
		log.info("[Catalogo]. Listando motivos de cese:"+CODIGO_TABLA_MOTIVOS_CESE);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_MOTIVOS_CESE,"1");
	}

	@Override
	public List<Parametro> listarTiposExperiencia() {
		log.info("[Catalogo]. Listando tipos de experiencia:"+CODIGO_TABLA_TIPOS_EXPERIENCIA);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_TIPOS_EXPERIENCIA,"1");
	}

	@Override
	public List<Parametro> listarTiposBrevete() {
		log.info("[Catalogo]. Listando tipos de brevete:"+CODIGO_TABLA_TIPOS_BREVETE);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_TIPOS_BREVETE,"1");
	}

	@Override
	public List<Parametro> listarTiposEstudio() {
		log.info("[Catalogo]. Listando tipos de estudio:"+CODIGO_TABLA_TIPOS_ESTUDIO);
		return codigosRrhhDAO.listarParametros(CODIGO_TABLA_TIPOS_ESTUDIO,"1");
	}

	@Override
	public List<Parametro> listarNivelEstudio(String codTipoEstudio) {
		return codigosRrhhDAO.listarNiveles(codTipoEstudio);
	}

	@Override
	public List<Parametro> listarCiclos(String codTipoEstudio, String codNivelEstudio) {
		return codigosRrhhDAO.listarCiclos(codTipoEstudio,codNivelEstudio);
	}

	@Override
	public List<Parametro> listarCarreras(String codTipoEstudio) {
		return codigosRrhhDAO.listarCarreras(codTipoEstudio);
	}

	@Override
	public Parametro getMensajeInicio() {
		return codigosRrhhDAO.getMensajeInicio();
	}

		
	@Override
	public List<Parametro> listaTipoConocimiento(String codTipoConocimiento) {
		
		log.info("[Catalogo]. Listando Tipos Conocimiento");
		
		log.info("codTipoConocimiento------>" +codTipoConocimiento);
		
		HashMap<String, Object> hmParam = new HashMap<>();
				
		hmParam.put("codTab", Constantes.CODIGO_TABLA_CONOCIMIENTO);
		hmParam.put("estado", Constantes.ESTADO_ACTIVO);	
				
		if ("2".equals(codTipoConocimiento)){
			hmParam.put("abreviatura", Constantes.CODIGO_ABREVIATURA_CONOCIMIENTO_INFORMATICO);
		
		}else{
			hmParam.put("abreviatura", Constantes.CODIGO_ABREVIATURA_CONOCIMIENTO_IDIOMA);
			
		}
				
		log.info("Parametros------>" +hmParam);
				
										
		return codigosRrhhDAO.selectByParams(hmParam);
	}

}
