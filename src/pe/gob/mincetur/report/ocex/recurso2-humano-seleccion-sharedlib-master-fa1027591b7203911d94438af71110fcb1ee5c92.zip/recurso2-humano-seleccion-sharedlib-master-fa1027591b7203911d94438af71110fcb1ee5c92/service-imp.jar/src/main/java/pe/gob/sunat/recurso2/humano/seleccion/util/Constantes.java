package pe.gob.sunat.recurso2.humano.seleccion.util;

public class Constantes {

	public static final String CODIGO_TABLA_VIAS_DOMICILIO = "058";
	public static final String CODIGO_TABLA_ZONAS_DOMICILIO = "059";
	
	public static final String CODIGO_TABLA_PROFESIONES = "615";
	public static final String CODIGO_TABLA_CENTROS_ESTUDIO = "617";
	public static final String CODIGO_TABLA_GRADOS_ACADEMICOS = "081";
	public static final String CODIGO_TABLA_INDICADORES_PUESTO = "580";
	public static final String CODIGO_TABLA_TIPOS_EXPERIENCIA = "581";
	
	public static final String CODIGO_TABLA_CONTRATOS_PRIVADOS = "082";
	public static final String CODIGO_TABLA_CONTRATOS_PUBLICOS = "083";
	public static final String CODIGO_TABLA_MOTIVOS_CESE = "084";
	public static final String CODIGO_TABLA_TIPOS_BREVETE = "086";
	
	public static final String CODIGO_TABLA_TIPOS_ESTUDIO = "632";
	
	public static final String CODIGO_TABLA_CONOCIMIENTO = "612";
	
	public static final String USUARIO_POSTULACION = "USUARIO_WEB";
	
	
	public static final String PROCESO_COD_ESTADO_ACTIVO = "1";
	public static final String COD_PROCESO_CONVENIO = "3";
	public static final String COD_PROCESO_PRACTICAS = "4";
	public static final String PREG_DDJJ_CODIGO_PREGUNTAS = "011";
	public static final String PREG_DDJJ_CODIGO_RESPUESTAS = "080";
	public static final String PREG_DDJJ_CODIGO_ACTIVO = "1";
	public static final String CODIGO_RESP_TIPO_NORMAL = "01";
	public static final String CODIGO_RESP_TIPO_COND_COLEG = "02";
	public static final String CODIGO_RESP_TIPO_TIP_DISCAP = "03";
	public static final String CODIGO_RESP_TIPO_MOD_FORM = "04";
	public static final String CODIGO_RESP_TIPO_SI = "01";
	public static final String CODIGO_RESP_TIPO_NO = "02";
	public static final String CODIGO_PREG_TIPO_COND_COLEG = "10";
	public static final String CODIGO_PREG_DISCAP = "14";
	public static final String CODIGO_PREG_TIPO_TIP_DISCAP = "15";
	public static final String CODIGO_PREG_MOD_FORM = "18";
	public static final String CODIGO_PREG_TIPO_MOD_FORM = "19";
	public static final String CODIGO_PREG_FAMI = "01";
	public static final String CODIGO_PREG_SUNAT = "17";
	public static final String CODIGO_PREG_CUMPLE_CONOCIMIENTOS = "20";
	
	public static final String CODIGO_ABREVIATURA_CONOCIMIENTO_INFORMATICO = "2";
	public static final String CODIGO_ABREVIATURA_CONOCIMIENTO_IDIOMA = "3";
	
	public static final String PREG_DDJJ_CODIGO_SECCION_AUSENCIA = "01";
	public static final String PREG_DDJJ_CODIGO_SECCION_OTROS = "02";
	
	public static final String ESTADO_ACTIVO = "1";
	
	public static final String MENSAJE_CONFIRMACION_POSTULACION = "Estimad{desSexo}: {desNombres}<br><br>"+
			"Mediante el presente confirmamos su inscripci&oacute;n en el proceso de selecci&oacute;n {desProceso} de la SUNAT.<br><br>"+
			"Fecha y hora de Postulaci&oacute;n: {desFecPostulacion}<br><br>"+
			"Se le recuerda que conforme a lo se&ntilde;alado en la \"Gu&iacute;a de Postulaci&oacute;n\", <u>la informaci&oacute;n brindada tiene car&aacute;cter de Declaraci&oacute;n Jurada y <b>NO</b> podr&aacute; ser modificada.</u><br><br>"+
			"De realizar alguna actualizaci&oacute;n en su hoja de vida, esta tendr&aacute; efecto para su pr&oacute;xima postulaci&oacute;n.<br><br>"+
			"Atentamente.<br><br>Divisi&oacute;n de Incorporaci&oacute;n y Administraci&oacute;n de Personal<br>Intendencia Nacional de Recursos Humanos";
	
	public static final String ASUNTO_CONFIRMACION_POSTULACION = "Confirmaci�n de Postulaci�n";
	
	public static final Integer TEMPLATE_FORMATO_POSTULACION = 7725;
	public static final String ARCHIVO_PDF_FORMATO_POSTULACION= "FUP_";
	
	//Ruta Logo SUNAT
	public static final String RUTA_LOGO_SUNAT   = "/data0/generador/jasper/plantillas/imagenes/SUNAT-LogoNuevaVersion.jpg";
	
	
	public static final String RUTA_SUBREPORT = "/data0/generador/jasper/plantillas/";
	
	//Ruta Service generador
	public static final String RUTA_GENERADOR_SERVICE   = "http://wssunat:8080/cl-ti-iagenerador-service/GeneradorReportService";
	
	public static final String DIRECTORIO_TEMPORAL = "/data0/tempo";
	
	public static final double MAX_SIZE_FILE_UPLOAD_MEGAS = 1;
	public static final int LONGITUD_MAXIMA_ARCHIVOCARGA = 100;
	protected static final String[] ARRAY_EXTENSION_PERMITIDA = {"pdf"};
	
	public static final String MOTCESE_AUNLAB = "005";
	
	public static final String URL_QRCODE = "https://www.sunat.gob.pe/ol-at-itseleccion/registro/descargar?c=";
	public static final String URL_HASH = "456678SKALLKA784521AALOlp987";
	
	
	public static final String CODIGO_SECCION_FORMACION = "03";
	public static final String CODIGO_SECCION_ESTUDIOS_ESPECIALIZACION = "04";
	public static final String CODIGO_SECCION_CERTIFICACIONES = "05";
	public static final String CODIGO_SECCION_CONOCIMIENTOS = "06";
	public static final String CODIGO_SECCION_EXPERIENCIA = "07";
	
	
	public static final String CODIGO_FASE_REVISION_DOCUMENTO = "05";
	public static final Short NUM_VERSION_REVISION = 0;
	
	
	public static final String CODIGO_PROCESO_INICIO = "00";
	public static final String CODIGO_PROCESO_POR_REVISAR = "01";
	public static final String CODIGO_PROCESO_REVISADO = "02";
	
	public static final String PROPERTIES_ITEM_TIPO_ESTUDIO = "codTipoEstudio";
	public static final String PROPERTIES_ITEM_USUARIO_MODIF = "codUsumodif";
	
	private Constantes() {
	}
}
