package pe.gob.sunat.recurso2.humano.seleccion.service;

import java.util.List;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Ficha;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Seguimiento;

public interface RegistroPostulacionService {

	public boolean registrarActualizarFichaDatos(Ficha ficha);
	public Ficha getFichaDatos(Integer numPostulante);
	
	public boolean registrarEducacion(FichaEducacion ficha);
	public boolean borrarDatosEducativos(Integer numIdAcadem);
	public List<FichaEducacion> listarDatosEducativos(Integer numPostulante);
	public boolean registrarConocimientoTecnico(FichaConocimiento ficha);
	public boolean borrarConocimientoTecnico(Integer numIdConocimient);
	public List<FichaConocimiento> listarConocimientosTecnicos(Integer numPostulante);
	public List<FichaConocimiento> listarConocimientosInformaticos(Integer numPostulante);
	public List<FichaConocimiento> listarConocimiento(Integer numPostulante);
	
	public boolean registrarEstudioEspecializacion(FichaEspecialidad ficha);
	public boolean borrarEstudioEspecializacion(Integer numIdIstAcadem);
	public List<FichaEspecialidad> listarEstudiosEspecializacion(Integer numPostulante,String indCertificacion);
	
	public boolean registrarExperienciaLaboral(FichaExperiencia ficha);
	public boolean borrarExperienciaLaboral(Integer numIdIstAcadem);
	public List<FichaExperiencia> listarExperienciaLaboral(Integer numPostulante);
	//archivo
	public Integer registrarArchivo(String nomArchivo, Integer numPostulante, byte[] arcPostula);
	public ArchivoPostulacion obtenerArchivoPostulacion(Integer numArcPostula);
	
	public void eliminarPostulacion(Integer numPostulante, String codPuesto, Short codCat);
	
	public void generarHistorico(Integer numPostulante, String codPuesto, Short codCat);
	
	public boolean registrarSeguimiento(Seguimiento seguimiento);
	
	
}
