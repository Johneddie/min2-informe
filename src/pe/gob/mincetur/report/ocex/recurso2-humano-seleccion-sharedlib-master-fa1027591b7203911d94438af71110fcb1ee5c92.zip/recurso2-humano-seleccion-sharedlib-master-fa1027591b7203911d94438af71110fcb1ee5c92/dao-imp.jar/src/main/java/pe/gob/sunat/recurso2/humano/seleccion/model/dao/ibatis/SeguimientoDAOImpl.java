package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Seguimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.SeguimientoDAO;

public class SeguimientoDAOImpl extends SqlMapDAOBase implements SeguimientoDAO{
	
	public SeguimientoDAOImpl() {
		super();
	}

	@Override
	public void insert(Seguimiento record) {	
		 getSqlMapClientTemplate().insert("t8460seguimiento.insert_seguimiento", record);		
	}

}
