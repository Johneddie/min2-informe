package pe.gob.sunat.recurso2.humano.seleccion.model.dao.ibatis;

import java.util.List;

import pe.gob.sunat.framework.spring.util.dao.SqlMapDAOBase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.dao.ParamRrhhDAO;

public class ParamRrhhDAOImpl extends SqlMapDAOBase implements ParamRrhhDAO{

	@Override
	public List<Parametro> listarParametros(String codParametro) {
		Parametro param = new Parametro();
		param.setCodParametro(codParametro);
		return getSqlMapClientTemplate().queryForList("t01paramsp.listarParametros",param);
	}

}
