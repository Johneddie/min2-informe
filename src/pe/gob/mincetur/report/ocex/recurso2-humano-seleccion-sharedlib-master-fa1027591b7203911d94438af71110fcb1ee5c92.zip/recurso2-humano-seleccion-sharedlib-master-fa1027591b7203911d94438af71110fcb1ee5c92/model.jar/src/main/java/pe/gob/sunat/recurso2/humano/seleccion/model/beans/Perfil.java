package pe.gob.sunat.recurso2.humano.seleccion.model.beans;

public class Perfil {
	
	private Integer codCat;
	private String desPerfil;
	private String desConocimientos;
	
	public Integer getCodCat() {
		return codCat;
	}
	public void setCodCat(Integer codCat) {
		this.codCat = codCat;
	}
	public String getDesPerfil() {
		return desPerfil;
	}
	public void setDesPerfil(String desPerfil) {
		this.desPerfil = desPerfil;
	}
	public String getDesConocimientos() {
		return desConocimientos;
	}
	public void setDesConocimientos(String desConocimientos) {
		this.desConocimientos = desConocimientos;
	}

}
