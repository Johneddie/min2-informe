package pe.gob.sunat.recurso2.humano.seleccion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;

public interface CodigosRrhhDAO {

	List<Parametro> listarParametros(String codParametro, String codEstado);
	List<Parametro> listarParametros(String codParametro, String codEstado, List<String> notIncluir);
	List<Parametro> selectByParams(Map<String, Object> params);
	Parametro selectByPrimaryKey(String codParametro, String codDataParametro);
	List<Parametro> listarNiveles(String codTipoEstudio);
	List<Parametro> listarCiclos(String codTipoEstudio, String codCiclo);
	List<Parametro> listarCarreras(String codTipoEstudio);
	List<Parametro> listarCentrosEstudio();
	Parametro getMensajeInicio();
}
