package pe.gob.sunat.recurso2.humano.seleccion.web.view;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;

public class PostulantesExcel extends AbstractExcelView{
	private HSSFCellStyle estiloTit = null;
	private HSSFCellStyle estiloTitI = null;
	private HSSFFont fuenteTit = null;
	private HSSFCellStyle estiloDat = null;
	private HSSFFont fuenteDat = null;
	private HSSFCellStyle estiloCab = null;
	private HSSFCellStyle estiloDatCent = null;
	private HSSFFont fuenteCab = null;
	
	
	private final Log log = LogFactory.getLog(getClass());
	
	
	public void iniciarlizaEstilos(HSSFWorkbook libroXLS){
		estiloTit = libroXLS.createCellStyle();
        estiloTitI = libroXLS.createCellStyle();
        estiloDat = libroXLS.createCellStyle();
        estiloCab = libroXLS.createCellStyle();
        estiloDatCent = libroXLS.createCellStyle();
        fuenteCab = libroXLS.createFont();
        fuenteCab.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); //En negrita
        fuenteCab.setFontHeight((short) 220);
        fuenteCab.setFontName("Arial");
        fuenteTit = libroXLS.createFont();
        fuenteDat = libroXLS.createFont();
        fuenteTit.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); //En negrita
        fuenteTit.setFontHeight((short) 160);
        fuenteTit.setFontName("Arial");
        fuenteDat.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL); //Sin negrita
        fuenteDat.setFontHeight((short) 160);
        fuenteDat.setFontName("Arial");
        estiloTit.setFont(fuenteTit);
        estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        estiloTit.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        estiloTit.setBorderRight(HSSFCellStyle.BORDER_THIN);
        estiloTit.setBorderTop(HSSFCellStyle.BORDER_THIN);
        estiloTit.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        estiloTit.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        estiloTitI.setFont(fuenteTit);
        estiloTitI.setAlignment(HSSFCellStyle.ALIGN_LEFT);
        estiloCab.setFont(fuenteCab);
        estiloCab.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        estiloDatCent.setFont(fuenteDat);
        estiloDatCent.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        estiloDatCent.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        estiloDatCent.setBorderRight(HSSFCellStyle.BORDER_THIN);
        estiloDatCent.setBorderTop(HSSFCellStyle.BORDER_THIN);
        estiloDatCent.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected void buildExcelDocument(Map model, HSSFWorkbook libroXLS,
		HttpServletRequest request, HttpServletResponse response)
		throws Exception {
		
		try{
			iniciarlizaEstilos(libroXLS);
			
			//1. Data a ser pintada en el excel:
			List<FichaHistorico> reporteList = (List<FichaHistorico>) model.get("reporteList");
			
			FechaBean fechaHoy = new FechaBean();
			String nombreArchivo = "Postulantes_"+fechaHoy.getFormatDate("ddMMyyyyHHmmss")+".xls";
	        response.setHeader("Content-Disposition","attachment; filename=\"" + nombreArchivo +"\"");
	        response.setContentType("application/vnd.ms-excel");
			HSSFSheet hojaXLS = libroXLS.createSheet("Reporte");
			HSSFRow filaXLS;
	        HSSFCell celdaXLS;
	        
	        int z = 0;
	        filaXLS = hojaXLS.createRow(0);
	        
	        String[] columnas = new String[] {"Tipo de Documento","Documento","Apellidos y Nombres","Estado","Evaluador"};	
	        
	        
	        for(String columna:columnas){
	        	celdaXLS = filaXLS.createCell(++z);
	            celdaXLS.setCellStyle(estiloTit);
	            celdaXLS.setCellValue(columna);
	            hojaXLS.setColumnWidth(z, (columna.length() * 512));
	        }
	        
	        if(!CollectionUtils.isEmpty(reporteList)){
	        	//Mostramos la data:
		        int i = 0;
		        for(FichaHistorico s:reporteList){
		        	filaXLS = hojaXLS.createRow(++i);
		            z = 0;
		            //tipo de documnto
		            celdaXLS = filaXLS.createCell(++z);
		            celdaXLS.setCellStyle(estiloDatCent);
		            celdaXLS.setCellValue(s.getDescTipoDoc());
		            
		            //n�mero de documento
		            celdaXLS = filaXLS.createCell(++z);
		            celdaXLS.setCellStyle(estiloDatCent);
		            celdaXLS.setCellValue(s.getNumDocId());
		            
		            //nombre del postulante
		            celdaXLS = filaXLS.createCell(++z);
		            celdaXLS.setCellStyle(estiloDatCent);
		            celdaXLS.setCellValue(s.getNomPostulante());
		            
		            //estado
		            celdaXLS = filaXLS.createCell(++z);
		            celdaXLS.setCellStyle(estiloDatCent);
		            celdaXLS.setCellValue(s.getDesResultado());
		            
		            //evaluador
		            celdaXLS = filaXLS.createCell(++z);
		            celdaXLS.setCellStyle(estiloDatCent);
		            celdaXLS.setCellValue(s.getDesRevisor());
		        }	
	        }
	        
	        	
		}catch(Exception e){
			log.info("Ocurri una excepcin al descargar a excel,",e);
		}
		
		
	}

}
