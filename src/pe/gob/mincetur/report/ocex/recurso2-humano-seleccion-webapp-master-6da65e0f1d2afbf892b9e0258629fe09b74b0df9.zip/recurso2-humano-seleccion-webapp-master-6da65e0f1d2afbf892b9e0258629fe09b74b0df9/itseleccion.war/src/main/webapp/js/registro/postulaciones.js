function renderizarTablaPostulaciones(){
    	
		$.ajax({
            url: "/ol-at-itseleccion/bandeja/cargarListaPostulaciones",
            type: "GET",
           // label:'',
            async : false,
			cache : false,
            dataType: "json",
            data : {
            	numPostulante : $('#numPostulante').val() 
            }
        }).done(function(paramJson) {
        	/*if(paramJson.length==0){
        		mostrarAlerta("danger", "No existe informaci&oacute;n de procesos de Notificaci&oacute;n de acuerdo al criterio seleccionado");
        	}*/
        	try {
        		$('#tblListaPostulaciones').DataTable().destroy();
        	}catch(err) {
        	}
        	
        	$('#tblListaPostulaciones').DataTable({
        			"ordering": false,
        			"searching":false,
            		destroy: true,
            		data: paramJson,
            	    columns: [
            	        { data: 'desProceso'    	, render : function(data, type, row){return '<td>'+row.desProceso+'</td>'; }},
            	        { data: 'desInscripcion'	, "class":'text-center', render : function(data, type, row){return '<td>'+row.desInscripcion+'</td>'; }},
            	        { data: 'desEstado'	, "class":'text-center', render : function(data, type, row){return '<td>'+row.desEstado+'</td>'; }},            	       
            	        { data: 'codCat'	, "class":'text-center', render : function(data, type, row){return '<a href="javascript:obtenerFormatoPdf(' + row.codCat + ',\'' + row.codPuesto + '\')" ><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>'; }},
            	        { data: 'codCat'	, "class":'text-center', render : function(data, type, row){
            	        	if(row.desEstado=='Nuevo'){
            	        		return '<a href="javascript:eliminarPostulacion(' + row.codCat + ',\'' + row.codPuesto + '\')" ><i class="fa fa-times" aria-hidden="true"></i></a>';	
            	        	}else{
            	        		return '';
            	        	}
            	        	 
            	        }}
            	    ],
            	    
            	    language: {
	            	    lengthMenu: '',
	            	    loadingRecords: "Por favor espere, cargando lista de convocatorias <img heigh='11' width='50' src='resources/images/loading-dots.gif'/>",
	            	    url: '/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json'
            	    },
            	    searching: false,
            	    //scrollX: true, //not work ie8
            	    lengthChange: false
            	});
        	
			}).fail(function( jqXHR, textStatus, errorThrown ) {
				//console.log('entro error, '+errorThrown);
				alert( "error"+errorThrown +", "+jqXHR+","+textStatus);
			});
    	
}


function obtenerFormatoPdf(codCat, codPuesto){
	ping();//reload session	
	var params = "&codCat="+codCat+"&codPuesto="+codPuesto;	
	$.ajax({
        url: "/ol-at-itseleccion/bandeja/validarExistenciaFormato",
        type: "GET",
        async : false,
		cache : false,
        dataType: "json",
        data : {
        	codCat: codCat, 
        	codPuesto: codPuesto,
        	numPostulante:$("#numPostulante").val()
        	}
	}).done(function(respuesta){
		if(respuesta.error) {		
			if(respuesta.mensaje == 'ERROR_SESION') {
                terminarSesion();
			}else{
                mostrarMensaje(respuesta.mensaje);
			}
		} else{
			$("#idCodCat").val(codCat);
			$('#idCodPuesto').val(codPuesto);
			$("#frmHiddenReportes").submit();
		}
		
	});
}


function eliminarPostulacion(codCat, codPuesto){
	ping();//reload session	
	
	bootbox.confirm({
	    title: "Confirmaci&oacute;n",
	    message: "\u00BFEst&aacute; seguro de eliminar la postulaci&oacute;n\u003F",
	    buttons: {
	        cancel: {label: '<i class="fa fa-times"></i> NO'},
	        confirm: {label: '<i class="fa fa-check"></i> S&Iacute;'}
	    },
	    callback: function (result) {
	        if(result){
	        	var params = "&codCat="+codCat+"&codPuesto="+codPuesto;	
	        	$.blockUI({ message: "<h1>Eliminando postulaci&oacute;n...</h1>" }); 
	        	$.ajax({
	                url: "/ol-at-itseleccion/bandeja/eliminarPostulacion",
	                type: "GET",
	                async : false,
	        		cache : false,
	                dataType: "json",
	                data : {
	                	codCat: codCat, 
	                	codPuesto: codPuesto,
	                	numPostulante:$("#numPostulante").val()
	                	}
	        	}).done(function(respuesta){
	        		$.unblockUI();
	        		if(respuesta.error) {		
	        			if(respuesta.mensaje == 'ERROR_SESION') {
	                        terminarSesion();
	        			}else{
	                        mostrarMensaje(respuesta.mensaje);
	        			}
	        		} else{
	        			//Actualizar bandeja de postulaciones
	        			renderizarTablaPostulaciones();
	        			renderizarTablaConvocatorias();
	        		}
	        		
	        	}).fail(function(jqXHR, textStatus, errorThrown){
	        		$.unblockUI();
	        		mostrarMensaje("Ocurrió un error al eliminar la postulaci&oacute;n,"+textStatus);
	        	});
	        }
	    }
	});
	
	
	
}



