/**
 * Aquí la funciones javascript de autenticacion y acceso
 * 
 */

var validacionesFormularios = function () {


	  $('#frmIniciarSesion').bootstrapValidator({
		  	feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        locale: 'es_PE',
	        fields: {
	        	txtDesCorreo4: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {

	                        	if($.trim(value).length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el correo electr\u00F3nico'
                               		};
	                        	}
								var inValid2 = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
								var k2 = inValid2.test(value);
	                        	if(!k2){
										return {
	                    	               	valid: false,
	                                    	message: 'Debe ingresar un correo correcto'
	                        	       	};
	                        	}
	                           	return true;
	                        }
	                    }
	                }
	            },
	            txtDesClave4: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar la contraseña'
                               		};
	                        	}
	                        	if(value.length<5){
									return {
                    	               	valid: false,
                                    	message: 'Debe tener m\u00EDnimo 5 caracteres y m\u00E1ximo 15'
                               		};
	                        	}
	                           	return true;
	                        }
	                    }
					}
	            },
	            txtCaptcha: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length!=4){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el c\u00F3digo captcha'
                               		};
	                        	}
	                        	/*if(!validarTextoCaptcha(value)){
	                            	goRefresh();
									return {
                    	               	valid: false,
                                    	message: 'C\u00F3digo capcha no es correcto'
                               		};
	                    		}*/
	                        	return true;
	                        }
	                    }
	                }
	            }
	        },
	        message: 'This value is not valid'
	    }).on('status.field.bv', function(e, data) {
	           data.bv.disableSubmitButtons(false);
	    }).on('error.field.bv', function(e, data) {
			  data.bv.disableSubmitButtons(false);
		}).on('success.form.bv', function(e) {
            // Prevent submit form
            
			var value = txtCaptcha.val();
        	if(!validarTextoCaptcha(value)){
                	bootbox.alert('C\u00F3digo captcha no es correcto');
                	goRefresh();
                	$('#frmIniciarSesion').bootstrapValidator('revalidateField', 'txtCaptcha');   
                    return false;
    		}
        	e.preventDefault();
    		var formulario = $("#frmIniciarSesion");
    		var formArray = formToObject(formulario.serializeArray())
    		var data = $.toJSON(formArray);
    		var url = CONTEXT_APP+"/acceso/procesarLogin";
    		document.getElementById("btnIniciarSesion").disabled=true;
    	    $.ajax({
    	           type: "POST",
    	           url: url,
    	           dataType: 'json',	
    	           data: data, 
    	           contentType: "application/json; charset=utf-8",
    	           timeout: 60000,
    	           success: function(respuesta){
    					
    					if (respuesta.cod == "0") {
    						$("#numPostulanteInicio").val(respuesta.msg);//seteamos el login del postulante
    						$("#frmIniciarRegistro").submit();//enviamos el formulario con el numpostulante como request.
    						//window.location = CONTEXT_APP + "/registro/inicio";//LOGIN OK
    					} else {
    						document.getElementById("btnIniciarSesion").disabled=false;
    						if (respuesta.cod == "1") {
    							goRefresh();
    							bootbox.alert("Usuario y/o Contraseña incorrectos");
    						 	$('.password').addClass('has-error has-feedback');
    						    $('.password').find('i.form-control-feedback').hide();
    						} else if (respuesta.cod == "3") {
    							goRefresh();
    							bootbox.alert("Correo Electr\u00F3nico no existe.");
    						 	$('.correo').addClass('has-error has-feedback');
    						    $('.correo').find('i.form-control-feedback').hide();
    						} else if (respuesta.cod == "4") {
    							goRefresh();
    							bootbox.alert("Clave vacia.");
    						} else if (respuesta.cod == "5") {
    							txtDesClave2.val("");
    				    		document.getElementById("hdnDesCorreo2").value=document.getElementById("txtDesCorreo4").value;
    				    		//goRefresh4();
    							$("#div_claveacceso").modal('show');
    							// validar clave acceso 
    						} else if (respuesta.cod == "10") { // clave acceso correcta se muestra la ventana de nueva contraseña
    							//goRefresh();
    							txtDesClave4.val("");
    							document.getElementById("hdnDesCorreo3").value=document.getElementById("txtDesCorreo4").value;
    							txtDesClave3.val("");
    							txtDesConfirmarClave3.val("");
    							$("#div_nuevaclave").modal('show');
    						} else if (respuesta.cod == "6") { // contraseña temporal incorrecto estado temporal de la cuenta
    							goRefresh();
    							bootbox.alert("Contraseña Temporal incorrecta.");
    						 	$('.password').addClass('has-error has-feedback');
    						    $('.password').find('i.form-control-feedback').hide();
    						} else if (respuesta.cod == "11") {
    							goRefresh();
    							bootbox.alert("Contraseña Temporal incorrecta.");
    						 	$('.password').addClass('has-error has-feedback');
    						    $('.password').find('i.form-control-feedback').hide();
    						} else if (respuesta.cod == "14") {
    							goRefresh();
    							bootbox.alert("Clave token vac\u00EDa.");
    						} else if (respuesta.cod == "15") {
    							goRefresh();
    							txtDesClave4.val("");
    							bootbox.alert("La contraseña temporal se encuentra vencida, se enviar&aacute; un correo electr&oacute;nico con su nuevo c&oacute;digo.");
    						 	$('.password').addClass('has-error has-feedback');
    						    $('.password').find('i.form-control-feedback').hide();
    						}
    						
    						$('#frmIniciarSesion').bootstrapValidator('revalidateField', 'txtCaptcha');    
    					}
    					
    	           },
    				error : function (xhr, ajaxOptions, thrownError) {
    					alert('Error de IniciarSesion.'+thrownError);
    					document.getElementById("btnIniciarSesion").disabled=false;
    				}
    	   });

	    });
	  
	  
	  $('#frmClaveAcceso').bootstrapValidator({
	        framework: 'bootstrap',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        locale: 'es_PE',
	        fields: {
	            txtDesClave2: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length!=5){
									return {
                    	               	valid: false,
                                    	message: 'C\u00F3digo de Validaci\u00F3n no v\u00E1lido'
                               		};
	                        	}
	                        	return true;
	                        }
	                    }
	                }
	            }/*,
	            txtCaptcha4: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length!=4){
									return {
                    	               	valid: false,
                                    	message: 'Ingresar 4 caracteres'
                               		};
	                        	}
	                        	if(!validarTextoCaptcha(value)){
	                            	goRefresh4();
									return {
                    	               	valid: false,
                                    	message: 'Ingrese el c\u00F3digo que se muestra en la imagen'
                               		};
	                    		}
	                        	return true;
	                        }
	                    }
	                }
	            }*/
	        }
	    }).on('status.field.bv', function(e, data) {
	           data.bv.disableSubmitButtons(false);
	    }).on('success.form.bv', function(e) {
            // Prevent submit form
            e.preventDefault();
            
            //get the action-url of the form
    		var formulario = $("#frmClaveAcceso");
    		var formArray = formToObject(formulario.serializeArray())
    		var data = $.toJSON(formArray);
    		var url = CONTEXT_APP+"/acceso/validaClaveAccesoInicial";
    		document.getElementById("btnClaveAcceso").disabled=true;
    	    $.ajax({
    	           type: "POST",
    	           url: url,
    	           dataType: 'json',	
    	           data: data, 
    	           contentType: "application/json; charset=utf-8",
    	           timeout: 60000,
    	           success: function(respuesta){
    					
    					if (respuesta.cod == "0") {
    						$("#numPostulanteInicio").val(respuesta.msg);//seteamos el login del postulante
    						$("#frmIniciarRegistro").submit();//enviamos el formulario con el numpostulante como request.
    						//window.location = CONTEXT_APP + "/registro/inicio";
    					} else {
    						document.getElementById("btnClaveAcceso").disabled=false;
    						if (respuesta.cod == "1") {
    							//goRefresh4();
    							bootbox.alert("El c&oacute;digo de validaci&oacute;n no es correcto.");
    						} else 	if (respuesta.cod == "2") {
    							txtDesClave2.val("");
    							bootbox.alert("Usuario no se encuentra en estado Temporal.");
    							//goRefresh();
    							$("#div_claveacceso").modal('hide');
    							//window.location = "registro/inicio";
    						} else 	if (respuesta.cod == "5") {
    							txtDesClave2.val("");
    							//goRefresh();
    							bootbox.alert("La contraseña temporal se encuentra vencida, se enviar\u00E1 un correo electr\u00F3nico con su nuevo c\u00F3digo.");
    							$("#div_claveacceso").modal('hide');
    							//window.location = "registro/inicio";
    						} 
     
    					}
    					
    	           },
   				error : function (xhr, ajaxOptions, thrownError) {
					alert('Error de ClaveAccesoInicial.'+thrownError);
					document.getElementById("btnClaveAcceso").disabled=false;
				}
    	   });
	    });
	  
	  $('#frmNuevaClave').bootstrapValidator({
	        framework: 'bootstrap',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        locale: 'es_PE',
	        fields: {
	        	txtDesClave3: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar su contraseña'
                               		};
	                        	}
								var inValid2 = /^(?=.*\d)(?=.*[A-Z]).{8,15}$/;
								var k2 = inValid2.test(value);
								if(!k2){
										return {
											valid: false,
											message: 'Debe tener m\u00EDnimo 8 caracteres y m\u00E1ximo 15. Debe contener m\u00EDnimo  una letra may\u00FAscula y un n\u00FAmero.'
										};
								}
								$('#frmCrearCuenta').bootstrapValidator('revalidateField', $('#txtDesConfirmarClave'));
	                           	return true;
	                        }
	                    }
	                }
	            },
	            txtDesConfirmarClave3: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar la confirmaci\u00F3n de la contraseña'
                               		};
	                        	}
	                        	if(value!=txtDesClave3.val()){
									return {
	                                   	valid: false,
                                    	message: 'La confirmaci\u00F3n de contraseña est\u00E1 errada'
                        	       	};
	                        	}
	                        	return true;
	                        }
	                    }
	                }
	            }	            
	        }
	    }).on('success.form.bv', function(e) {
            // Prevent submit form
            e.preventDefault();
            
            //get the action-url of the form
    		var formulario = $("#frmNuevaClave");
    		var formArray = formToObject(formulario.serializeArray())
    		var data = $.toJSON(formArray);
    		var url = CONTEXT_APP+"/acceso/nuevaClave";
    		document.getElementById("btnCambiarClave").disabled=true;
    	    $.ajax({
    	           type: "POST",
    	           url: url,
    	           dataType: 'json',	
    	           data: data, 
    	           contentType: "application/json; charset=utf-8",
    	           timeout: 60000,
    	           success: function(respuesta){
    					
    					if (respuesta.cod == "1") {
    						bootbox.alert("Se actualiz&oacute; exitosamente la clave");
    						$("#numPostulanteInicio").val(respuesta.msg);//seteamos el login del postulante
    						$("#frmIniciarRegistro").submit();//enviamos el formulario con el numpostulante como request.
    						//window.location = CONTEXT_APP + "/registro/inicio"; // LOGIN OK
    					} else if (respuesta.cod == "2") {
    						bootbox.alert("La confirmaci\u00F3n de clave est\u00E1 errada");
    						document.getElementById("btnCambiarClave").disabled=false;
    					} else {
    						bootbox.alert("Error en la actualizaci\u00F3n de la clave");
							document.getElementById("btnCambiarClave").disabled=false;
    					}
    					
    	           },
      				error : function (xhr, ajaxOptions, thrownError) {
    					alert('Error de CambiarClave.'+thrownError);
    					document.getElementById("btnCambiarClave").disabled=false;
    				}
    	    	});	    
    	    });

	  $('#frmRecuperarClave').bootstrapValidator({
	        framework: 'bootstrap',
	        icon: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        locale: 'es_PE',
	        fields: {
	        	txtDesCorreo2: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el correo electr\u00F3nico'
                               		};
	                        	}
								var inValid2 = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
								var k2 = inValid2.test(value);
								if(!k2){
										return {
											valid: false,
											message: 'Debe ingresar un correo correcto'
										};
								}
	                           	return true;
	                        }
	                    }
	                }
	            },
	            txtCaptcha3: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length!=4){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el c\u00F3digo captcha'
                               		};
	                        	}
	                        	/*if(!validarTextoCaptcha(value)){
	                            	goRefresh3();
									return {
                    	               	valid: false,
                                    	message: 'C\u00F3digo captcha no es correcto'
                               		};
	                    		}*/
	                        	return true;
	                        }
	                    }
	                }
	            }
	        }
	    }).on('status.field.bv', function(e, data) {
	           data.bv.disableSubmitButtons(false);
	    }).on('success.form.bv', function(e) {
            // Prevent submit form
			var value = txtCaptcha3.val();
        	if(!validarTextoCaptcha(value)){
                	bootbox.alert('C\u00F3digo captcha no es correcto');
                	goRefresh3();
                	$('#frmRecuperarClave').bootstrapValidator('revalidateField', 'txtCaptcha3'); 
                    return false;
    		}
            e.preventDefault();
            
            //get the action-url of the form
    		var formulario = $("#frmRecuperarClave");
    		var formArray = formToObject(formulario.serializeArray())
    		var data = $.toJSON(formArray);
    		var url = CONTEXT_APP+"/acceso/recuperaClave";
    		document.getElementById("btnEnviarCorreo").disabled=true;
    	    $.ajax({
    	           type: "POST",
    	           url: url,
    	           dataType: 'json',	
    	           data: data, 
    	           contentType: "application/json; charset=utf-8",
    	           timeout: 60000,
    	           success: function(respuesta){
    					
    					if (respuesta.cod == "1") {
    						bootbox.alert("Se envi&oacute; un correo electr&oacute;nico con los datos de acceso");
    						//goRefresh();
    						$("#div_olvidoclave").modal('hide');
    					} else {
    						goRefresh3();
    						bootbox.alert("La cuenta de correo no se encuentra registrada");
						 	$('.correo2').addClass('has-error has-feedback');
						    $('.correo2').find('i.form-control-feedback').hide();
    						document.getElementById("btnEnviarCorreo").disabled=false;
    						$('#frmRecuperarClave').bootstrapValidator('revalidateField', 'txtCaptcha3'); 
    					}
    					
    	           },
      				error : function (xhr, ajaxOptions, thrownError) {
    					alert('Error de RecuperarClave.'+thrownError);
    					document.getElementById("btnEnviarCorreo").disabled=false;
    				}
    	   });
	    });
	  
	  $('#frmCrearCuenta').bootstrapValidator({
		  feedbackIcons: {
	            valid: 'glyphicon glyphicon-ok',
	            invalid: 'glyphicon glyphicon-remove',
	            validating: 'glyphicon glyphicon-refresh'
	        },
	        locale: 'es_PE',
	        fields: {
	        	/*txtDesCorreo: {
	                validators: {
	                    notEmpty: {
	                    },
	                    emailAddress: {
	                    }
	                }
	            },*/
	        	txtDesCorreo: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {

	                        	if($.trim(value).length==0){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el correo electr\u00F3nico'
                               		};
	                        	}
								var inValid2 = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
								var k2 = inValid2.test(value);
	                        	if(!k2){
										return {
	                    	               	valid: false,
	                                    	message: 'Debe ingresar un correo correcto'
	                        	       	};
	                        	}
	                        	var flag = validaMail(value);
	                        	if(!flag){
									return {
                    	               	valid: false,
                                    	message: 'Correo electr\u00F3nico se encuentra registrado'
                               		};
	                        	}
								$('#frmCrearCuenta').bootstrapValidator('revalidateField', $('#txtDesConfirmarCorreo'));
	                           	return true;
	                        }
	                    }
	                }
	            },
	        	txtDesConfirmarCorreo: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value.toUpperCase())!=$.trim(txtDesCorreo.val().toUpperCase())){
									return {
	                                   	valid: false,
                                    	message: 'El correo electr\u00F3nico y su confirmaci\u00F3n no coinciden'
                        	       	};
	                        	}
	                        	return true;
	                        }
	                    }
	                }
	            },
	            txtDesClave: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Ingrese su contraseña'
                               		};
	                        	}
								var inValid2 = /^(?=.*\d)(?=.*[A-Z]).{8,15}$/;
								var k2 = inValid2.test(value);
								if(!k2){
										return {
											valid: false,
											message: 'Debe tener m\u00EDnimo 8 caracteres y m\u00E1ximo 15. Debe contener m\u00EDnimo  una letra may\u00FAscula y un n\u00FAmero.'
										};
								}
								$('#frmCrearCuenta').bootstrapValidator('revalidateField', $('#txtDesConfirmarClave'));
	                           	return true;
	                        }
	                    }
	                }
	            },
	            txtDesConfirmarClave: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Ingrese la confirmaci\u00F3n de contraseña'
                               		};
	                        	}
	                        	if(value!=txtDesClave.val()){
									return {
	                                   	valid: false,
                                    	message: 'La confirmaci\u00F3n de contraseña est\u00E1 errada'
                        	       	};
	                        	}
	                        	return true;
	                        }
	                    }
	                }
	            },
	            cmbTipoDocumento: {
	                validators: {
	                    notEmpty: {
	                    	message: 'Ingrese su Tipo de Documento'
	                    }
	                }
	            },
	            txtNumDocumento: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {

	                        	if($.trim(value).length==0){
									return {
                    	               	valid: false,
                                    	message: 'Ingresar n\u00FAmero de documento'
                               		};
	                        	}
								var inValid2 = /^[0-9]+$/;
								var k2 = inValid2.test(value);
	                        	if(!k2){
										return {
	                    	               	valid: false,
	                                    	message: 'Solo ingresar n\u00FAmeros'
	                        	       	};
	                        	} 
	                        	var tipDoc = cmbTipoDocumento.val();
		                        if(tipDoc=='01'){
		                        	if($.trim(value).length!=8){
										return {
	                    	               	valid: false,
	                                    	message: 'DNI debe ser de 8 caracteres'
	                               		};
		                        	}
		                        	var flag = validaDocumento(tipDoc,value);
		                        	if(!flag){
										return {
	                    	               	valid: false,
	                                    	message: 'Tipo de documento y n\u00FAmero de documento se encuentran registrados'
	                               		};
		                        	}
		                        	buscarPersona("01",value);
		                        } else {
		                        	if($.trim(value).length!=9){
										return {
	                    	               	valid: false,
	                                    	message: 'Carnet de Extranjer\u00EDa debe ser de 9 caracteres'
	                               		};
		                        	}
		                        	var flag = validaDocumento(tipDoc,value);
		                        	if(!flag){
										return {
	                    	               	valid: false,
	                                    	message: 'Tipo de documento y n\u00FAmero de documento se encuentran registrados'
	                               		};
		                        	}
		                        }
	                           	return true;
	                        }
	                    }
	                }
	            },
	            txtApePaterno: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Ingrese su Apellido Paterno'
                               		};
	                        	}
								if (value.indexOf("''") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s ap\u00F3strofes continuos'
	                        	       	};
	                        	}
								/*if (value.indexOf("  ") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s espacios en blanco continuos'
	                        	       	};
	                        	}*/
	                        	return true;
	                        }
	                    }
	                }
	            },
	            txtApeMaterno: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
								if (value.indexOf("''") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s ap\u00F3strofes continuos'
	                        	       	};
	                        	}
								/*if (value.indexOf("  ") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s espacios en blanco continuos'
	                        	       	};
	                        	}*/
	                        	return true;
	                        }
	                    }
	                }
	            },
	            txtNombre: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if(value.length==0){
									return {
                    	               	valid: false,
                                    	message: 'Ingrese sus Nombres'
                               		};
	                        	}
								if (value.indexOf("''") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s ap\u00F3strofes continuos'
	                        	       	};
	                        	}
								/*if (value.indexOf("  ") >= 0){
										return {
	                    	               	valid: false,
	                                    	message: 'Ingres\u00F3 2 o m\u00E1s espacios en blanco continuos'
	                        	       	};
	                        	}*/
	                        	return true;
	                        }
	                    }
	                }
	            },
	            txtFecNacimiento: {
	                validators: {
	                    notEmpty: {
	                    	message: 'Ingrese su Fecha de Nacimiento'
	                    },
	                    date: {
	                        format: 'DD/MM/YYYY'
	                    }
	                }
	            },
	            txtCaptcha2: {
	                validators: {
	                    callback: {
	                    	message: '',
	                        callback: function(value, validator, $field) {
	                        	if($.trim(value).length!=4){
									return {
                    	               	valid: false,
                                    	message: 'Debe ingresar el c\u00F3digo capcha'
                               		};
	                        	}
	                        	/*if(!validarTextoCaptcha(value)){
	                            	goRefresh2();
									return {
                    	               	valid: false,
                                    	message: 'C\u00F3digo capcha no es correcto'
                               		};
	                    		}*/
	                        	return true;
	                        }
	                    }
	                }
	            }
	        },
			highlight: function (e) {
				if($(e).is("input[id^='fec']")) {
					$(e).closest('.custom-form-group').removeClass('has-sucess').addClass('has-error');
					$(e).removeClass('has-success').addClass('has-error');		
				}else{
					$(e).parent().removeClass('has-success').addClass('has-error');	
				}
				
			},
			onSuccess: function (e) {
				$(e).parent().removeClass('has-error').addClass('has-success');
				$(e).closest('.input-group').removeClass('has-error');
				$(e).remove();
			},
			onError: function (error) {
			}
	   }).on('status.field.bv', function(e, data) {
           data.bv.disableSubmitButtons(false);
       }).on('error.field.bv', function(e, data) {
		   data.bv.disableSubmitButtons(false);
	   }).on('success.form.bv', function(e) {
		   //alert("holaaaaaaaaa");
		   
			
			var value = txtCaptcha2.val();
        	if(!validarTextoCaptcha(value)){
                	bootbox.alert('C\u00F3digo captcha no es correcto');
                	goRefresh2();
                	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtCaptcha2'); 
                    return false;
    		}
		   
			
			e.preventDefault();
		    //get the action-url of the form
			var formulario = $("#frmCrearCuenta");
			var formArray = formToObject(formulario.serializeArray())
			var data = $.toJSON(formArray);
			var url = CONTEXT_APP+"/acceso/crearCuenta";
			
			bootbox.confirm("El correo " +  document.getElementById("txtDesCorreo").value + " ser&aacute; con el que usted ingresar&aacute; al sistema, favor de confirmar.", function(confirmed) {
			//if(confirm("El correo " +  document.getElementById("txtDesCorreo").value + " será con el que usted ingresará al sistema, favor de confirmar.")){
				if(confirmed){
					document.getElementById("btnCrearCuenta").disabled=true;
				    $.ajax({
				           type: "POST",
				           url: url,
				           dataType: 'json',	
				           data: data, 
				           contentType: "application/json; charset=utf-8",
				           timeout: 60000,
				           success: function(respuesta){
								
								if (respuesta.cod == "1") {
									var mensaje = "Su cuenta ha sido creada, revise su correo electr&oacute;nico donde encontrar&aacute; un c&oacute;digo de acceso para activar su cuenta.";
									bootbox.dialog({title:"Creaci&oacute;n de cuenta",message: mensaje,
									        			   buttons: {danger: {label: "Aceptar",className: "btn-primary"}}});
									resetFormCuenta();
									resetCamposPostulante();
									$("#div_crearcuenta").modal('hide');
									//goRefresh();
								} else {
									if (respuesta.cod == "4") {
										bootbox.alert("Numero de documento no se encuentra en reniec.");
										document.getElementById("btnCrearCuenta").disabled=false;
									} else if (respuesta.cod == "2") {
										bootbox.alert("La cuenta de correo existe en la base de datos.");
										document.getElementById("btnCrearCuenta").disabled=false;
									} else if (respuesta.cod == "3") {
										bootbox.alert("El tipo y numero de documento se encuentran registrados.");
										document.getElementById("btnCrearCuenta").disabled=false;
									} else {
										bootbox.alert("Usuario no se encuentra.");
										document.getElementById("btnCrearCuenta").disabled=false;
									}
									goRefresh2();
									$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtCaptcha2');
									return false;
								}
								
				           },
		      				error : function (xhr, ajaxOptions, thrownError) {
		    					alert('Error de CrearCuenta.'+thrownError);
		    					document.getElementById("btnCrearCuenta").disabled=false;
		    				}
				    
				    });
				} else {
					//resetCamposPostulante();
					document.getElementById("btnCrearCuenta").disabled=false;
					goRefresh2();
					$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtCaptcha2');   
				}
			});
	   });
}

var validarTextoCaptcha = function(txtCaptchaInput){
	var txtCaptcha = txtCaptchaInput.toString();
	var captchaValido = false;
	if(txtCaptcha.length==4){
		
		//2. Verifico el captcha.
		var url = CONTEXT_APP + "/acceso/validarTextoCaptcha?txtCaptcha="+txtCaptcha+"&ms="+(new Date()).getTime();
		//console.log(url);
		$.ajax({
			type: "POST",
			url: url,
			dataType: "json",
			async: false,
			timeout : 60000,
			contentType: "application/x-www-form-urlencoded",
			success: function(response) {
				var isValid = response.cod;
				if(isValid==1){
					captchaValido = true;
				}else{
					//goRefresh();
				}
			},
			error : function (xhr, ajaxOptions, thrownError) {
				alert('Error de Captcha. '+thrownError);
			}
		});
	}
	return captchaValido;
};

var  validaDocumento = function(tipdoc, numdoc){
	
	var URL_VALIDADOCUMENTO = CONTEXT_APP+"/acceso/validaDocumento?codTipDocIdentidad="+tipdoc + "&numDocumento=" + numdoc;
	var flag = false;
	$.ajax({
        url: URL_VALIDADOCUMENTO,
        type: "GET",
       // label:'',
        async : false,
		cache : false,
        dataType: "json", 
		timeout : 60000,
        success: function(response) {
			var cod = response.cod;
			if(cod=="0"){
				flag = true;
			} else {
				flag = false;
			}
        },
		error : function (xhr, ajaxOptions, thrownError) {
			alert('Error de validaDocumento. '+thrownError);
		}
        
	});
	return flag;
};

function validaMail(nomemail){
	
	var URL_VALIDAEMAIL = CONTEXT_APP+"/acceso/validaEmail?nomEmail="+nomemail;
	var flag = false;
	$.ajax({
        url: URL_VALIDAEMAIL,
        type: "GET",
       // label:'',
        async : false,
		cache : false,
        dataType: "json", 
        timeout : 60000,
        success: function(response) {
			var cod = response.cod;
			if(cod=="0"){
				flag = true;
			} else {
				flag = false;
			}
        },
		error : function (xhr, ajaxOptions, thrownError) {
			alert('Error de validaMail. '+thrownError);
		}
       
	});
	 return flag;
};


function inputSoloNumeros(){
	$("#txtNumDocumento").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });	

	$('#txtNumDocumento').keypress(function (e) {
	    var regex = new RegExp("^[0-9]+$");
		if(e.keyCode==8 || e.keyCode==37 || e.keyCode==39 || e.keyCode==9){
			return true;
		}
	    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
	    if (regex.test(str)) {
	        return true;
	    }

	    e.preventDefault();
	    return false;
	});	
}


