package pe.gob.sunat.recurso2.humano.seleccion.web.controller;

import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Derivacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DetalleFase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Empleado;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Fase;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Postulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ReporteHistorico;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Revision;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.SeccionEvaluacion;
import pe.gob.sunat.recurso2.humano.seleccion.service.AccesoPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.BandejaPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.seleccion.service.RegistroPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.RevisionIncorporacionService;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;
import pe.gob.sunat.recurso2.humano.seleccion.util.Intranet;
import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;

@Intranet   
@Controller
@RequestMapping(value="/revision")
public class RevisionIncorporacionController {
	
	public final Log log = LogFactory.getLog(getClass());

	@Autowired
	@Qualifier("registroPostulacionService")
	private RegistroPostulacionService registroPostulacionService;
	
	@Autowired
	@Qualifier("catalogoService")
	private CatalogoService catalogoService;
	
	@Autowired
	@Qualifier("bandejaPostulacionService")
	private BandejaPostulacionService bandejaPostulacionService;
	
	@Autowired
	@Qualifier("accesoPostulacionService")
	private AccesoPostulacionService accesoPostulacionService;
	
	@Autowired
	@Qualifier("revisionIncorporacionService")
	private RevisionIncorporacionService revisionIncorporacionService;
	
	@RequestMapping("/inicio")
	public ModelAndView iniciarRegistro(HttpServletRequest request,
			HttpServletResponse response) {
		log.info("Ingresando a la p�gina de inicio de revisi�n de documentos.");
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		Map<String,Object> parametros = new HashMap<>();
		
		Empleado empleado = revisionIncorporacionService.buscarEmpleado(usuarioBean.getNroRegistro()); 
		
		
		parametros.put("esCAS", "8".equals(empleado.getT02codRegl())?"1":"0");
		
		//TODO: Revisar tambi�n que si es CAS entonces acceder a la lista de derivaciones.
		/*if(!revisionIncorporacionService.esRevisorDeProceso(usuarioBean.getCodUO(), usuarioBean.getNroRegistro())) {
			parametros.put("mensajeError", "Usted no tiene acceso a revisi�n de documentos.");
			return new ModelAndView("revision/errorForm",parametros);	
		}*/
		
		List<PuestoProceso> procesos = revisionIncorporacionService.listarProcesosPorUnidad(usuarioBean.getCodUO(),usuarioBean.getNroRegistro());
		if(CollectionUtils.isEmpty(procesos)) {
			parametros.put("mensajeError", "No tiene procesos de selecci�n por revisar.");
			return new ModelAndView("revision/errorForm",parametros);	
		}
		parametros.put("listaProcesos", procesos);
		
		return new ModelAndView("revision/revisionForm",parametros);
	}
	
	
	@RequestMapping(value = "/postulantes", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> listarNiveles(@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto") String codPuesto)  {
		log.info("Listando postulantes....");
		Map<String,Object> resultadoProceso = new HashMap<String,Object>();
		List<FichaHistorico> postulantes = revisionIncorporacionService.listarPostulantesPorProceso(codCat, codPuesto);
		
		SeccionEvaluacion formacion = revisionIncorporacionService.getSeccionEvaluacion(codCat, Constantes.CODIGO_SECCION_FORMACION);
		SeccionEvaluacion estudios = revisionIncorporacionService.getSeccionEvaluacion(codCat, Constantes.CODIGO_SECCION_ESTUDIOS_ESPECIALIZACION);
		SeccionEvaluacion certificaciones = revisionIncorporacionService.getSeccionEvaluacion(codCat, Constantes.CODIGO_SECCION_CERTIFICACIONES);
		SeccionEvaluacion conocimientos = revisionIncorporacionService.getSeccionEvaluacion(codCat, Constantes.CODIGO_SECCION_CONOCIMIENTOS);
		SeccionEvaluacion experiencia = revisionIncorporacionService.getSeccionEvaluacion(codCat, Constantes.CODIGO_SECCION_EXPERIENCIA);
		
		resultadoProceso.put("postulantes", postulantes);
		resultadoProceso.put("indVisualizaFormacion", formacion.getIndSeleccion());
		resultadoProceso.put("indVisualizaEstudios", estudios.getIndSeleccion());
		resultadoProceso.put("indVisualizaCertificaciones", certificaciones.getIndSeleccion());
		resultadoProceso.put("indVisualizaConocimientos", conocimientos.getIndSeleccion());
		resultadoProceso.put("indVisualizaExperiencia", experiencia.getIndSeleccion());
		
		return resultadoProceso;
	}
	
	
	//Descarga a excel del listado de postulantes.
	@RequestMapping(value = "/descargar/excel", method=RequestMethod.POST,produces={MediaType.APPLICATION_OCTET_STREAM_VALUE})
	public ModelAndView descargarExcel(HttpServletRequest request)  {
		log.info("Iniciando descarga en excel de los datos... ");

		
		Short codCat = Short.parseShort(request.getParameter("codCat"));
		String codPuesto = request.getParameter("codPuesto");
		List<FichaHistorico> reporteList = revisionIncorporacionService.listarPostulantesPorProceso(codCat, codPuesto);
		
		
		Map<String,Object> modelo = new HashMap<String,Object>();
		modelo.put("reporteList", reporteList);
		return new ModelAndView("excelPostulantesView",modelo);
	}
	
	
	@RequestMapping(value = "/listarDatosEducativos", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaEducacion> listarDatosEducativos(
			@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto") String codPuesto,
			@RequestParam("numPostulante") Integer numPostulante)  {
		
		log.info("Listando 	Datos Academicos....");		
					
		return revisionIncorporacionService.listarDatosEducativos(codCat,codPuesto,numPostulante);				
	}
	
	//Para especializacion y para certificacion
	
	@RequestMapping(value = "/listarEstudiosEspecializacion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaEspecialidad> listarEstudiosEspecializacion(
			@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto") String codPuesto,
			@RequestParam("numPostulante") Integer numPostulante,
			@RequestParam("indCertificacion") String indCertificacion) {
				
		log.info("Listando 	Especializaciones....");		
					
		return revisionIncorporacionService.listarEstudiosEspecializacion(codCat,codPuesto,numPostulante,indCertificacion);				
	}
		
	//para conocimiento informatico
	
	@RequestMapping(value = "/listarConocimiento", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaConocimiento> listarConocimiento(
			@RequestParam("numPostulante") Integer numPostulante,
			@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto")String codPuesto) {
				
		log.info("Listando 	Certificaciones....");		
					
		return revisionIncorporacionService.listarConocimiento(numPostulante, codCat, codPuesto);				
	}
	
	
	//para experiencia laboral
	
	@RequestMapping(value = "/listarExperienciaLaboral", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaExperiencia> listarExperienciaLaboral(
			@RequestParam("numPostulante") Integer numPostulante,
			@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto")String codPuesto) {
				
		log.info("Listando 	Experiencia Laboral....");		
					
		return revisionIncorporacionService.listarExperienciaLaboral(codCat,codPuesto,numPostulante);				
	}
	
	//Descarga de PDF
	
	@RequestMapping(value = "/descargarDocumentoSustentoPdf", method=RequestMethod.POST,produces={MediaType.APPLICATION_OCTET_STREAM_VALUE})
	public ModelAndView exportarFormatoPdf(HttpServletRequest request,	HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method generarFormatoPdf");

		try {
			Integer numArcPostula= Integer.parseInt(request.getParameter("numArcPostulaDownload"));
			
			ArchivoPostulacion ap = registroPostulacionService.obtenerArchivoPostulacion(numArcPostula);
			response.setHeader("Content-Disposition", "attachment; filename=\"" + ap.getNomArchivo() + "\"");
			response.setContentType("application/pdf");
			if(ap.getArcPostula() != null)
				response.setContentLength(ap.getArcPostula().length);

			OutputStream out = response.getOutputStream();
			out.write(ap.getArcPostula());
			out.close();
			out.flush();	
		}catch(Exception e) {
			log.debug("Ocurrio una excepcion al exportar a pdf",e);
		}
		
		return new ModelAndView("registro/postulanteForm",null);
	}
	
	
	//ver Reporte Historico
	
	@RequestMapping(value = "/listarReporteHistorico", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<ReporteHistorico> listarReporteHistorico(
			@RequestParam("numArcPostula") Integer numArcPostula) {
				
		log.info("Listando Reporte Historico ....");		
		return revisionIncorporacionService.listarReporteHistorico(numArcPostula);
				
	}
	
	
	
	@RequestMapping(value = "/listarEmpleados", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Empleado> listarEmpleados(
			@RequestParam("codRegistro") String codRegistro,
			@RequestParam("apePaterno") String apePaterno,
			@RequestParam("apeMaterno") String apeMaterno,
			@RequestParam("nombres") String nombres,
			@RequestParam("codCat") Short codCat,
			@RequestParam("indAsignado") String indAsignado) {
		
		if("1".equals(indAsignado)) {
			return revisionIncorporacionService.buscarEmpleadosAsignados(codRegistro, apePaterno, apeMaterno, nombres, codCat);
		}else {
			return revisionIncorporacionService.buscarEmpleados(codRegistro, apePaterno, apeMaterno, nombres, codCat);
		}
				
	}
	
	
	@RequestMapping(value = "/registrarDerivacion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> registrarDerivacion(
			@RequestParam("codRegistro") String codRegistro,
			@RequestParam("codCat") Short codCat,
			@RequestParam("codPuesto") String codPuesto,
			@RequestParam("indTipo") String indTipo,
			HttpServletRequest request,	HttpServletResponse response) {
		Map<String,Object> resultadoProceso = new HashMap<String,Object>();		
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		resultadoProceso.put("derivacionRealizada", "0");
		
		Derivacion derivacion = new Derivacion();
		derivacion.setCodCat(codCat);
		derivacion.setCodPuesto(codPuesto);
		derivacion.setCodRegderiva(usuarioBean.getNroRegistro());
		derivacion.setCodRegrecep(codRegistro);
		derivacion.setFecRegis(new Date());
		derivacion.setCodUsuregis(usuarioBean.getNroRegistro());
		derivacion.setFecModif(new Date());
		derivacion.setCodUsumodif(usuarioBean.getNroRegistro());
		revisionIncorporacionService.registrarActualizarDerivacion(derivacion, indTipo);
		
		resultadoProceso.put("derivacionRealizada", "1");
		return resultadoProceso;
	}
	
	
	@RequestMapping(value = "/descargar/fup", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public void descargarFUP(HttpServletRequest request, HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method descargar fup para revisi�n");
		try {
			Short codCat = Short.parseShort(request.getParameter("codCat"));
			String codPuesto = request.getParameter("codPuesto");
			Integer numPostulante = Integer.parseInt(request.getParameter("numPostulante"));
			
			Postulacion p = bandejaPostulacionService.getPostulacion(codCat, codPuesto, numPostulante);//codCat,codPuesto,numPostulacion
			ArchivoPostulacion ap = registroPostulacionService.obtenerArchivoPostulacion(p.getNumArcFup());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + ap.getNomArchivo() + "\"");
			response.setContentType("application/pdf");
			if(ap.getArcPostula() != null)
				response.setContentLength(ap.getArcPostula().length);
			OutputStream out = response.getOutputStream();
			out.write(ap.getArcPostula());
			out.close();
			out.flush();	
		}catch(Exception e) {
			log.debug("Ocurrio una excepcion al exportar a pdf",e);
		}
	}
	
	
	
	@RequestMapping(value = "/grabarSeccion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> grabarSeccion(@RequestBody Revision revision,HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.info("Registrando/actualizando ficha con los datos acad�micos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("seccionRevisada", 0);
		revision.setCodUsuregis(usuarioBean.getNroRegistro());
		revisionIncorporacionService.registrarActualizarRevision(revision);
		respuesta.put("seccionRevisada", 1);
		return respuesta;
	}
	
	
	@RequestMapping(value = "/grabarRevisionPostulante", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> grabarRevisionPostulante(@RequestBody DetalleFase detalle,HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.info("Registrando/actualizando el detalle del postulante....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("postulanteRevisado", 0);
		detalle.setCodUsuregis(usuarioBean.getNroRegistro());
		detalle.setCodUsumodif(usuarioBean.getNroRegistro());
		List<String> errores = revisionIncorporacionService.registrarActualizarRevisionPostulante(detalle);
		respuesta.put("postulanteRevisado", 1);
		respuesta.put("errores", errores);
		return respuesta;
	}
	
	
	@RequestMapping(value = "/finalizarProcesoPostulacion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> finalizarProcesoPostulacion(@RequestBody Fase fase,HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.info("Registrando/actualizando el detalle del postulante....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("procesoFinalizado", 0);
		respuesta.put("error", 0);
		fase.setCodUsumodif(usuarioBean.getNroRegistro());
		
		//Validamos que todos los postulantes est�n evaluados.
		if(revisionIncorporacionService.validarProcesoPostulacion(fase)) {
			revisionIncorporacionService.finalizarProcesoPostulacion(fase);
			respuesta.put("procesoFinalizado", 1);
		}else {
			respuesta.put("error", 1);
		}
		
		return respuesta;
	}

	
	@RequestMapping(value = "/devolverProcesoPostulacion", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> devolverProcesoPostulacion(@RequestBody Fase fase,HttpServletRequest request)  {
		UsuarioBean usuarioBean = (UsuarioBean) WebUtils.getSessionAttribute(request, "usuarioBean");
		log.info("Registrando/actualizando el detalle del postulante....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("procesoDevuelto", 0);
		fase.setCodUsuregis(usuarioBean.getNroRegistro());
		fase.setCodUsumodif(usuarioBean.getNroRegistro());
		revisionIncorporacionService.devolverProcesoPostulacion(fase);
		respuesta.put("procesoDevuelto", 1);
		return respuesta;
	}
	
	
	@RequestMapping(value = "/getUltimaRevision", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> getUltimaRevision(@RequestBody Revision revision,HttpServletRequest request)  {
		log.info("Obteniendo la �ltima revisi�n del postulante....");
		return revisionIncorporacionService.getUltimaRevisionPostulante(revision);
	}
	
}



