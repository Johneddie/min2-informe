package pe.gob.sunat.recurso2.humano.seleccion.web.interceptor;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;
import org.springframework.web.util.WebUtils;

import pe.gob.sunat.framework.spring.util.bean.MensajeBean;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;

public class UsuarioInterceptor implements HandlerInterceptor {
	
	private static String ajaxRequest = "XMLHttpRequest";

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		
		
		boolean isAjaxRequest = ajaxRequest.equals(request.getHeader("X-Requested-With"));
		Usuario usuario = (Usuario)WebUtils.getSessionAttribute(request, "usuario");
		
		if(usuario==null){
			ModelAndView msgView = new ModelAndView("/acceso/logout");
			if (!isAjaxRequest) {
	            throw new ModelAndViewDefiningException(msgView);
	        }else{
	        	MensajeBean mensajeBean = new MensajeBean();
	        	mensajeBean.setError(true);
	            mensajeBean.setMensajeerror("Su sesi�n ha terminado.");
	            mensajeBean.setMensajesol("Vuelva a ingresar a la aplicaci�n.");
	        	throw new ModelAndViewDefiningException(new ModelAndView("jsonView", "errorSesion", mensajeBean));
	        }
		}
		HttpSession session = request.getSession(false);
		session.setAttribute("ULTIMO_ACCESO", new Date().getTime());//Todas las consultas de sesion pasan por aqu�.
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		//Nothing
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		//Nothing
	}

}
