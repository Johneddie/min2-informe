/**
 * Aquí la funciones javascript de autenticacion y acceso
 * 
 */
var txtDesCorreo4;
var txtDesClave4;
var txtDesClave2;
var btnIniciarSesion;
var btnClaveAcceso;
var txtDesCorreo2;
var txtDesClave3;
var txtDesConfirmarClave3;

var txtDesCorreo;
var txtDesClave;
var txtDesConfirmarClave;
var cmbTipoDocumento;
var txtNumDocumento;
var txtApePaterno;
var txtApeMaterno;
var txtNombre;
var txtFecNacimiento;
var btnCrearCuenta;
var txtCaptcha;
var txtCaptcha2;
var txtCaptcha3;
var txtDesConfirmarCorreo;
var hdnFecNacimiento;
function iniciaVariables(){
	txtDesClave4=$('#txtDesClave4');
	txtDesClave2=$('#txtDesClave2');
	txtDesCorreo4=$('#txtDesCorreo4');
	btnIniciarSesion=$('#btnIniciarSesion');
	btnClaveAcceso=$('#btnClaveAcceso');
	txtDesCorreo2=$('#txtDesCorreo2');
	txtDesClave3=$('#txtDesClave3');
	txtDesConfirmarClave3=$('#txtDesConfirmarClave3');
	txtCaptcha=$('#txtCaptcha');
	txtCaptcha2=$('#txtCaptcha2');
	txtCaptcha3=$('#txtCaptcha3');
	
	txtDesCorreo=$('#txtDesCorreo');
	txtDesClave=$('#txtDesClave');
	txtDesConfirmarClave=$('#txtDesConfirmarClave');
	cmbTipoDocumento=$('#cmbTipoDocumento');
	txtNumDocumento=$('#txtNumDocumento');
	txtApePaterno=$('#txtApePaterno');
	txtApeMaterno=$('#txtApeMaterno');
	txtNombre=$('#txtNombre');
	txtFecNacimiento=$('#txtFecNacimiento');
	txtDesConfirmarCorreo=$('#txtDesConfirmarCorreo');
	hdnFecNacimiento=$('#hdnFecNacimiento');
	document.getElementById("btnIniciarSesion").disabled=true;
	
	inputSoloNumeros();

	/*$('#datetimePicker4').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date(),
    	minDate:"01/01/1900"
    }).on('changeDate show', function (e) {
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });

	$('#txtFecNacimiento').on('changeDate show', function (e) {
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });
	
	$('#txtFecNacimiento').on('change', function (e) {
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });*/
	
	$('#txtFecNacimiento').datepicker({
	    format: "dd/mm/yyyy",
	    autoclose: true,
	    language: "es",
	    multidate: false, 
	    startDate: "01/01/1900",
	    endDate: fecact
	   })
	   .on('changeDate show', function (e) {
		   hdnFecNacimiento.val(txtFecNacimiento.val());
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });
		
	
	$('#txtDesConfirmarCorreo').bind('copy paste cut',function(e) {
			    e.preventDefault();
			});
	
	$('#txtDesClave3').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#txtDesClave4').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#txtDesClave2').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#txtDesClave').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#txtDesConfirmarClave3').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#txtDesConfirmarClave').bind('copy paste cut',function(e) {
	    e.preventDefault();
	});
	
	$('#div_crearcuenta').on('hidden.bs.modal', function () {
	    // do something…
	    	resetFormCuenta();
	    	goRefresh();
	})

	$('#div_claveacceso').on('hidden.bs.modal', function () {
	    // do something…
	    	goRefresh();
	})
	
	$('#div_nuevaclave').on('hidden.bs.modal', function () {
	    // do something…
	    	goRefresh();
	})
	
	$('#div_olvidoclave').on('hidden.bs.modal', function () {
	    // do something…
	    	goRefresh();
	})

	$(".nombrespostulante").on("keydown", function(event){
		  // Allow controls such as backspace, tab etc.

		  var arr = [8,9,16,17,20,32,35,36,37,38,39,40,45,46,186,192,219];

		  // Allow letters
		  for(var i = 65; i <= 90; i++){
			arr.push(i);
		  }
		  // Prevent default if not in array
		  if(jQuery.inArray(event.which, arr) === -1 && event.key == "ñ" && event.key == "Ñ"){
			event.preventDefault();
		  }
	});
	
	$(".nombrespostulante").on("input", function(){
		var regexp = /[^\u00C0-\u00FCa-zA-Z ']/g;
		  if($(this).val().match(regexp)){
			$(this).val( $(this).val().replace(regexp,'') );
		  }
	});
}


var formToObject = function(formArray) {
	var returnArray = {};
	for (var i = 0; i < formArray.length; i++){
		returnArray[formArray[i]['name']] = formArray[i]['value'];
	}
	return returnArray;
};

var changeTipoDocumento = function(val) {

	txtNumDocumento.prop('maxlength','12');
	if(val.value=="01"){
		txtNumDocumento.val("");
		txtNumDocumento.prop('maxlength','8');
		txtNumDocumento.focus();
	} else 	if(val.value=="04"){
		txtNumDocumento.val("");
		txtNumDocumento.prop('maxlength','9');
		txtNumDocumento.focus();
	} else {
		txtNumDocumento.val("");
	}
	resetCamposPostulante();
}

var resetFormCuenta = function(){
	txtDesCorreo.val("");
	txtDesConfirmarCorreo.val("");
	txtDesClave.val("");
	txtDesConfirmarClave.val("");
	cmbTipoDocumento.val("");
	txtNumDocumento.val("");
	txtApePaterno.val("");
	txtApeMaterno.val("");
	txtNombre.val("");
	txtFecNacimiento.val("");
	txtCaptcha2.val("");

	txtApePaterno.prop("readonly",false);
	txtApeMaterno.prop("readonly",false);
	txtNombre.prop("readonly",false);
	
	txtFecNacimiento.prop("disabled",false);
	$('#txtFecNacimiento').datepicker({
	    format: "dd/mm/yyyy",
	    todayBtn: "linked",
	    autoclose: true,
	    todayHighlight: true,
	    orientation: "top",
	    language: "es",
	    multidate: false, 
	    startDate: "01/01/1900",
	    endDate: fecact
	   })
	   .on('changeDate show', function (e) {
		   hdnFecNacimiento.val(txtFecNacimiento.val());
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });	

	
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'cmbTipoDocumento');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtNumDocumento');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApePaterno');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApeMaterno');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtNombre');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtDesCorreo');
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtDesClave');    
	
}


var buscarPersona = function(tipdoc, numdoc){
	
	var URL_TIPOS_CONTRATO = CONTEXT_APP+"/acceso/buscarPersona?codTipDocIdentidad="+tipdoc + "&numDocumento=" + numdoc;
	$.getJSON(URL_TIPOS_CONTRATO, function( response ) {
		var cod = response.cod;
		if(cod=="1"){
			txtApePaterno.val(response.des_apepat_pnat);
			txtApeMaterno.val(response.des_apemat_pnat);
			txtNombre.val(response.des_nombre_pnat);
			txtFecNacimiento.val(response.fecNacStr);
			hdnFecNacimiento.val(response.fecNacStr);
			txtApePaterno.prop("readonly",true);
			txtApeMaterno.prop("readonly",true);
			txtNombre.prop("readonly",true);
			
			$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
			txtFecNacimiento.prop("disabled",true);
			$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApePaterno');    
			$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApeMaterno');    
			$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtNombre');    
		} else {
			resetCamposPostulante();
		}
	});		
}

var resetCamposPostulante = function(){
	txtApePaterno.val("");
	txtApeMaterno.val("");
	txtNombre.val("");
	txtFecNacimiento.val("");
	txtApePaterno.prop("readonly",false);
	txtApeMaterno.prop("readonly",false);
	txtNombre.prop("readonly",false);
	
	txtFecNacimiento.prop("disabled",false);
	$('#txtFecNacimiento').datepicker({
	    format: "dd/mm/yyyy",
	    todayBtn: "linked",
	    autoclose: true,
	    todayHighlight: true,
	    orientation: "top",
	    language: "es",
	    multidate: false, 
	    startDate: "01/01/1900",
	    endDate: fecact
	   })
	   .on('changeDate show', function (e) {
		   hdnFecNacimiento.val(txtFecNacimiento.val());
		   $('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	   });	

	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtFecNacimiento');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApePaterno');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtApeMaterno');    
	$('#frmCrearCuenta').bootstrapValidator('revalidateField', 'txtNombre');    
	
}




