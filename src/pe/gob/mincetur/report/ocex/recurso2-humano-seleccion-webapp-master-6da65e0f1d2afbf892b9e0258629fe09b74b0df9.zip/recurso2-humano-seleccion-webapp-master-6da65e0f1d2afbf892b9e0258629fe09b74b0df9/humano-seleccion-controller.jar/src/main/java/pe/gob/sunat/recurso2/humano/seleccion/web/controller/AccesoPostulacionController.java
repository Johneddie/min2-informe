package pe.gob.sunat.recurso2.humano.seleccion.web.controller;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.framework.spring.util.ws.rest.MensajeRespuesta;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;
import pe.gob.sunat.recurso2.humano.seleccion.service.AccesoPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.util.FechasUtil;
import pe.gob.sunat.recurso2.humano.seleccion.util.GenerateCaptcha;
import pe.gob.sunat.recurso2.humano.seleccion.util.Internet;

@Internet   
@Controller
@RequestMapping(value="/acceso")
public class AccesoPostulacionController {
	
	public final Log log = LogFactory.getLog(getClass());

	@Autowired
	@Qualifier("accesoPostulacionService")
	private AccesoPostulacionService accesoPostulacionService;
	
	@Value("${aplicacion.version}")
	private String version;
	
	@Value("${aplicacion.buildTime}")
	private String buildTime;
	
	
	@RequestMapping(value = "/checkSesion", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> checkSesion(HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> respuesta = new HashMap<>();
		respuesta.put("esSesionValida", 1);//por default es una sesion valida.
		try{
			
			String fechaToken = request.getParameter("TOKPOSTULACION");
			Date dateToken = FechasUtil.getDateToken(fechaToken);
			
			long ultimoAcceso = dateToken.getTime();
			long ahora = new Date().getTime();
			
			if((ahora-ultimoAcceso)>=1000*60*30){//30 MINUTOS
				respuesta.put("esSesionValida", 0);
			}
			
		}catch(Exception e){
			log.info("Error al verificar la sesion",e);
			respuesta.put("esSesionValida", 0);
		}
		
		return respuesta;
	}
	
	
	/**
	 * Carga la p�gina inicial de bienvenida al usuario
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping("/inicioBienvenida")
	public ModelAndView iniciarBienvenida() {
		log.info("Ingresando a la p�gina de bienvenida al postulante.");
		return new ModelAndView("acceso/bienvenida");
	}
	
	
	/**
	 * Carga la p�gina inicial de autenticacion con el usuario
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping("/inicioLogin")
	public ModelAndView iniciarLogin() {
		log.info("Ingresando a la p�gina de inicio de autenticacion al postulante.");
		Map<String, Object> respuesta = new HashMap<>();
		respuesta.put("hoy", new Date());
		respuesta.put("version", version);
		respuesta.put("buildTime", buildTime);
		return new ModelAndView("acceso/loginForm",respuesta);
	}
	
	
	
	/**
	 * Procesa la verificaci�n de los datos de autenticaci�n del usuario(correo y clave)
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value = "/procesarLogin", method=RequestMethod.POST,headers = {"Content-type=application/json"},consumes={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody MensajeRespuesta  procesarLogin(@RequestBody  Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		
		
		log.info("Autenticando postulante.... ");
		String nomEmail = map.get("txtDesCorreo4");//c�digo de la cuenta a procesar
		String desClave = map.get("txtDesClave4");//la clave debe viajar codificada en el cliente.
		MensajeRespuesta mensaje = new MensajeRespuesta();//parte del framework, reutilizar.
		int res = accesoPostulacionService.procesarLogin(nomEmail,desClave);
		if(res == 0){
			Usuario user = accesoPostulacionService.getUsuario(nomEmail);
			request.getSession().setAttribute("usuario", user);
			log.info("procesarLogin - Se inicio la sesion del usuario: " + nomEmail);
			mensaje.setCod("0");//c�digo de mensaje si el login es correcto
			mensaje.setMsg(user.getNumPostulante().toString());//mensaje
		}else{
			mensaje.setCod(String.valueOf(res));
			mensaje.setMsg("LoginFake");//mensaje
		}
		
		return mensaje;
	}
	
	
	/**
	 * Procesa la verificaci�n de la clave de acceso inicial
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value = "/validaClaveAccesoInicial", method=RequestMethod.POST,headers = {"Content-type=application/json"},consumes={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody MensajeRespuesta  validaClaveAccesoInicial(@RequestBody  Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		
		
		log.info("validaClaveAccesoInicial postulante.... ");
		String nomEmail = map.get("hdnDesCorreo2");//c�digo de la cuenta a procesar
		String desClave = map.get("txtDesClave2");//la clave debe viajar codificada en el cliente.
		MensajeRespuesta mensaje = new MensajeRespuesta();//parte del framework, reutilizar.
		int res = accesoPostulacionService.validaClaveAccesoInicial(nomEmail,desClave);
		if(res == 0){
			Usuario user = accesoPostulacionService.getUsuario(nomEmail);
			request.getSession().setAttribute("usuario", user);
			log.info("validaClaveAccesoInicial Se inicio la sesion del usuario: " + nomEmail);			
			mensaje.setCod("0");//c�digo de mensaje si el login es correcto
			//mensaje.setMsg("registro/inicio");//mensaje
			mensaje.setMsg(user.getNumPostulante().toString());//mensaje
			//Aqu� se crea el usuario de sessi�n y desde la p�gina JSP se debe de redirigir hacia:
			//https://www.sunat.gob.pe/ol-at-itseleccion/registro/inicio
			//La anterior p�gina es el punto de inicio del registro de postulante, antes de ingresar a cualquier p�gina
			//de esas /registro/* se deber� pasar por un interceptor que valide la existencia del usuario creado en este m�todo.
			
		}else{
			mensaje.setCod(String.valueOf(res));
			mensaje.setMsg("LoginFake");//mensaje
		}
		
		return mensaje;
	}
	
		
	/**
	 * Procesa la recuperacion de clave
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value = "/recuperaClave", method=RequestMethod.POST,headers = {"Content-type=application/json"},consumes={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody MensajeRespuesta  recuperaClave(@RequestBody  Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		
		
		log.info("recuperaClave postulante.... ");
		String nomEmail = map.get("txtDesCorreo2");//c�digo de la cuenta a procesar
		MensajeRespuesta mensaje = new MensajeRespuesta();//parte del framework, reutilizar.
		 Map<String, Object>  res = accesoPostulacionService.olvidoClave(nomEmail);
		if(res!=null && res.get("codigo")!=null && "1".equals(res.get("codigo").toString())){
			mensaje.setCod(res.get("codigo").toString());//c�digo de mensaje si el login es correcto
			mensaje.setMsg("registro/inicio");//mensaje
			
		}else{
			mensaje.setCod("0");
			mensaje.setMsg("LoginFake");//mensaje
		}
		
		return mensaje;
	}
	
	/**
	 * Procesa la nueva  clave
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value = "/nuevaClave", method=RequestMethod.POST,headers = {"Content-type=application/json"},consumes={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody MensajeRespuesta  nuevaClave(@RequestBody  Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		
		log.info("nuevaClave postulante.... ");
		String nomEmail = map.get("hdnDesCorreo3");//c�digo de la cuenta a procesar
		String txtDesClave3 = map.get("txtDesClave3");//c�digo de la cuenta a procesar
		String txtDesConfirmarClave3 = map.get("txtDesConfirmarClave3");//c�digo de la cuenta a procesar
		MensajeRespuesta mensaje = new MensajeRespuesta();//parte del framework, reutilizar.
		
		try {
			
			int  res = accesoPostulacionService.registrarNuevaClave(txtDesClave3, txtDesConfirmarClave3, nomEmail);
			if(res == 1){
				mensaje.setCod("1");//c�digo de mensaje si el login es correcto
				//mensaje.setMsg("registro/inicio");//mensaje
				Usuario user = accesoPostulacionService.getUsuario(nomEmail);
				mensaje.setMsg(user.getNumPostulante().toString());//mensaje
				request.getSession().setAttribute("usuario", user);
				log.info("nuevaClave Se inicio la sesion del usuario: " + nomEmail);			
				
				//Aqu� se crea el usuario de sessi�n y desde la p�gina JSP se debe de redirigir hacia:
				//https://www.sunat.gob.pe/ol-at-itseleccion/registro/inicio
				//La anterior p�gina es el punto de inicio del registro de postulante, antes de ingresar a cualquier p�gina
				//de esas /registro/* se deber� pasar por un interceptor que valide la existencia del usuario creado en este m�todo.
				
			}else{
				mensaje.setCod(String.valueOf(res));
				mensaje.setMsg("LoginFake");//mensaje
			}	
		}catch(Exception e) {
			log.info("Error al crear nueva clave.",e);
		}
		
		return mensaje;
	}
	
	/**
	 * Procesa la nueva  clave
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value = "/crearCuenta", method=RequestMethod.POST,headers = {"Content-type=application/json"},consumes={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody MensajeRespuesta  crearCuenta(@RequestBody  Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		
		log.info("crearCuenta postulante.... ");
		String nomEmail = map.get("txtDesCorreo");//c�digo de la cuenta a procesar
		String txtDesClave = map.get("txtDesClave");//c�digo de la cuenta a procesar
		String cmbTipoDocumento = map.get("cmbTipoDocumento");//c�digo de la cuenta a procesar
		String txtNumDocumento = map.get("txtNumDocumento");//c�digo de la cuenta a procesar
		String txtApePaterno = map.get("txtApePaterno");//c�digo de la cuenta a procesar
		String txtApeMaterno = map.get("txtApeMaterno");//c�digo de la cuenta a procesar
		String txtNombre = map.get("txtNombre");//c�digo de la cuenta a procesar
		String txtFecNacimiento = map.get("hdnFecNacimiento");//c�digo de la cuenta a procesar
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		MensajeRespuesta mensaje = new MensajeRespuesta();//parte del framework, reutilizar.
		
		try {
			Date fecNac = df.parse(txtFecNacimiento);
	    	Usuario usuario = new Usuario();
	    	usuario.setCodTipoDoc(cmbTipoDocumento);
	    	usuario.setNomPostulante(txtNombre);
	    	usuario.setApeMaterno(txtApeMaterno);
	    	usuario.setApePaterno(txtApePaterno);
	    	usuario.setNumDocId(txtNumDocumento);
	    	usuario.setNomEmail(nomEmail);
	    	usuario.setFecRegis(new Date());
	    	usuario.setCodUsuregis("USUARIO-EXTERNO");
	    	usuario.setFecModif(new Date());
	    	usuario.setFecNacimiento(fecNac);
	        usuario.setNomClave(txtDesClave);
	    	usuario.setFecModif(new Date());
	    	usuario.setCodUsumodif("USUARIO-EXTERNO");
	    	usuario.setIndEstado("T");
			
			int  res = accesoPostulacionService.crearCuenta(usuario);
			if(res == 0){
				mensaje.setCod("0");//c�digo de mensaje si el login es correcto
				mensaje.setMsg("registro/inicio");//mensaje
				
				//Aqu� se crea el usuario de sessi�n y desde la p�gina JSP se debe de redirigir hacia:
				//https://www.sunat.gob.pe/ol-at-itseleccion/registro/inicio
				//La anterior p�gina es el punto de inicio del registro de postulante, antes de ingresar a cualquier p�gina
				//de esas /registro/* se deber� pasar por un interceptor que valide la existencia del usuario creado en este m�todo.
				
			}else{
				mensaje.setCod(String.valueOf(res));
				mensaje.setMsg("LoginFake");//mensaje
			}	
		}catch(Exception e) {
			log.info("Error al crear cuenta.",e);
		}
		
		return mensaje;
	}
	
	
	/**
	 * Generar captcha
	 * 
	 * @param request
	 *            the request
	 * @return the model and view
	 */
	@RequestMapping({"/generaCaptcha"})
	public void generaCaptcha(HttpServletRequest request, HttpServletResponse response){
		try {
		    ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
		    ImageIO.write(GenerateCaptcha.generateCaptcha(request.getSession().getId()), "jpg", jpegOutputStream);

		    if (this.log.isDebugEnabled()) this.log.debug("generando imagen...........");
		    byte[] captchaChallengeAsJpeg = jpegOutputStream.toByteArray();
		    response.setHeader("Cache-Control", "no-store");
		    response.setHeader("Pragma", "no-cache");
		    response.setDateHeader("Expires", 0L);
		    response.setContentType("image/jpeg");
		    ServletOutputStream responseOutputStream = response.getOutputStream();
		    responseOutputStream.write(captchaChallengeAsJpeg);
		    responseOutputStream.flush();
		    responseOutputStream.close();	
		}catch(Exception e) {
			log.info("Error al generar captcha.",e);
		}
		
	  }	
	
	
	
	  @RequestMapping(value={"/validarTextoCaptcha"}, method={org.springframework.web.bind.annotation.RequestMethod.POST}, produces={"application/json"})
	  public @ResponseBody MensajeRespuesta validarTextoCaptcha(HttpServletRequest request, HttpServletResponse response){
	    this.log.debug("Llega a validarTextoCaptcha");
	    MensajeRespuesta resultado = new MensajeRespuesta();
	    try {
	      int valido = 1;
	      String txtCaptcha = request.getParameter("txtCaptcha").toUpperCase();
	      this.log.debug("Validando captcha : " + txtCaptcha.trim() + ", para id de session:" + request.getSession().getId());
	      if (!GenerateCaptcha.isValid(request.getSession().getId(), txtCaptcha.trim())) {
	        valido = 0;
	      }
	      resultado.setCod(String.valueOf(valido));
	      this.log.debug("validarTextoCaptcha captcha : " + txtCaptcha.trim() + ", result: " + valido + ", para id de session:" + request.getSession().getId());
	    } catch (Exception e) {
	      this.log.error("************ ERROR EN validarTextoCaptcha *********** ", e);
	    }
	    return resultado;
	  }
	
		/**
		 * Procesa la buscarPersona en reniec
		 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
		 * */
		@RequestMapping(value = "/buscarPersona", method=RequestMethod.GET)
		public Map<String, Object>  buscarPersona(@PathParam("codTipDocIdentidad") String codTipDocIdentidad,
				@PathParam("numDocumento") String numDocumento, HttpServletRequest request, HttpServletResponse response) {
			
			log.info("buscarPersona postulante.... codTipDocIdentidad: " + codTipDocIdentidad + ", numDocumento: " + numDocumento);
			String tipdoc = codTipDocIdentidad;//c�digo de la cuenta a procesar
			String numdoc = numDocumento;//la clave debe viajar codificada en el cliente.
			return accesoPostulacionService.obtenerDatosReniec(numdoc, tipdoc);
		}

		

		/**
		 * Procesa la validaDocumento en la BD Postulante
		 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
		 * */
		@RequestMapping(value = "/validaDocumento", method=RequestMethod.GET)
		public @ResponseBody MensajeRespuesta  validaDocumento(@PathParam("codTipDocIdentidad") String codTipDocIdentidad,
				@PathParam("numDocumento") String numDocumento, HttpServletRequest request, HttpServletResponse response) {
			MensajeRespuesta resultado = new MensajeRespuesta();
			log.info("validaDocumento postulante.... codTipDocIdentidad: " + codTipDocIdentidad + ", numDocumento: " + numDocumento);
			String tipdoc = codTipDocIdentidad;//c�digo de la cuenta a procesar
			String numdoc = numDocumento;//la clave debe viajar codificada en el cliente.
			int res = accesoPostulacionService.validarDocumento(tipdoc, numdoc);
			resultado.setCod(String.valueOf(res));
			return resultado;
		}
		
		/**
		 * Procesa la validaEmail en la BD Postulante
		 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
		 * */
		@RequestMapping(value = "/validaEmail", method=RequestMethod.GET)
		public @ResponseBody MensajeRespuesta  validaEmail(@PathParam("nomEmail") String nomEmail, HttpServletRequest request, HttpServletResponse response) {
			MensajeRespuesta resultado = new MensajeRespuesta();
			log.info("validaEmail postulante.... codTipDocIdentidad: " + nomEmail );
			int res = accesoPostulacionService.validarMail(nomEmail);
			resultado.setCod(String.valueOf(res));
			return resultado;
		}
		
		@RequestMapping("/login")
		public ModelAndView iniciarLoginWithoutCaptcha() {
			return new ModelAndView("acceso/login");
		}
		
		
}





