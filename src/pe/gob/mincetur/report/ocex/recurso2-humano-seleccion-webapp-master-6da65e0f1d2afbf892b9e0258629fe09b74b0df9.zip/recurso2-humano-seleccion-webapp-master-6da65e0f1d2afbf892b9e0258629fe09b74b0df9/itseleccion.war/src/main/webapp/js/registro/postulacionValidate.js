/**
 * Aquí las funciones javascript de postulacion
 * 
 */

var validadorFormacionAcademica = null;
var validadorEstudiosEspecializacion = null;
var validadorConocimientosInformaticos = null;
var validadorExperienciaLaboral = null;

var validarDatosRegistro = function(){
	
	// just for the demos, avoids form submit
	$.validator.setDefaults({
	  debug: false,
	  success: "valid"
	});
	
	//Validaciones genericas:
	setValidacionesGenericas();
	
	validarInformacionPersonal();
	validarDomicilio();
	validarFormacionAcademica();	
	validarEstudiosEspecializacion();
	validarCertificacion();
	validarConocimientosInformaticos();
	validarExperienciaLaboral();
};

var validarAlfanumerico = function(e){
	var patron = /^[a-zA-Z0-9]+$/;
	if(patron.test(e.value))return true;
	else return false;
};

var setValidacionesGenericas = function(){
	$.validator.addMethod("maxFecha", function(value, element) {
		var fecha = $(element).datepicker("getDate");
		return this.optional(element) || fecha.getTime()<=fechaMaxima.getTime();
	}, "Fecha fuera de rango.");  
	
	$(".form-control").validate({onkeyup: false});
	
	$.validator.addMethod("minFecha", function(value, element) {
		var ianio = 0;
		if(value!=null && value.length==10){
			ianio = parseInt(value.substring(6));
		}
		if(ianio<=1899)return false;
		var fecha = getDateFromFormat($(element).val(),'dd/MM/yyyy');
		var fechaMinimaTime = getDateFromFormat('01/01/1900','dd/MM/yyyy');
		return this.optional(element) || fecha>fechaMinimaTime;
	}, "La fecha debe ser mayor a 01/01/1900.");
	
	$.validator.addMethod("valMinFechaGrado", function(value, element) {
		var fechaEgreso = getDateFromFormat($("#fecEgreso").val(),'dd/MM/yyyy');
		var fechaGrado = getDateFromFormat($("#fecGrado").val(),'dd/MM/yyyy');
		return this.optional(element) || fechaEgreso<=fechaGrado;
	}, "La fecha debe ser mayor o igual a la fecha de egreso.");
	
	
	$.validator.addMethod("valMinFechaFin", function(value, element) {
		var fechaInicio = getDateFromFormat($("#fecInicio").val(),'dd/MM/yyyy');
		var fechaFin = getDateFromFormat($("#fecFin").val(),'dd/MM/yyyy');
		return this.optional(element) || fechaInicio<=fechaFin;
	}, "La fecha debe ser mayor o igual a la fecha de inicio.");
	
	
	$.validator.addMethod("valMinFechaCertificado", function(value, element) {
		var fechaFin = getDateFromFormat($("#fecFin").val(),'dd/MM/yyyy');
		var fechaCertificado = getDateFromFormat($("#fecCertificado").val(),'dd/MM/yyyy');
		return this.optional(element) || fechaFin<=fechaCertificado;
	}, "La fecha debe ser mayor o igual a la fecha de fin.");
	
	$.validator.addMethod("valMinFechaCertificadoCert", function(value, element) {
		var fechaFin = getDateFromFormat($("#fecFinCert").val(),'dd/MM/yyyy');
		var fechaCertificado = getDateFromFormat($("#fecCertificadoCert").val(),'dd/MM/yyyy');
		return this.optional(element) || fechaFin<=fechaCertificado;
	}, "La fecha debe ser mayor o igual a la fecha de fin.");
	
	
	$.validator.addMethod("valMinFechaExperiencia", function(value, element) {
		var fechaInicio = getDateFromFormat($("#fecInicioExp").val(),'dd/MM/yyyy');
		var fechaFin = getDateFromFormat($("#fecFinExp").val(),'dd/MM/yyyy');
		return this.optional(element) || fechaInicio<=fechaFin;
	}, "La fecha debe ser mayor o igual a la fecha de inicio.");
	
	$.validator.addMethod("valDocumentoSustento", function(value, element) {
		var numArcPostulaELBD = $("#numArcPostulaELBD").val();
		var docFisicoEL = $("#docFisicoEL").val();
		
		return docFisicoEL!='' || numArcPostulaELBD!='';
	}, "Adjunte un documento de sustento.");
	
	$.validator.addMethod("valDocumentoSustentoCertificado", function(value, element) {
		var numArcPostulaCertBD = $("#numArcPostulaCertBD").val();
		var docFisicoCert = $("#docFisicoCert").val();
		return docFisicoCert!='' || numArcPostulaCertBD!='';
	}, "Adjunte un documento de sustento.");
	
	$.validator.addMethod("valDocumentoSustentoEstudioEspecializacion", function(value, element) {
		var numArcPostulaEEBD = $("#numArcPostulaEEBD").val();
		var docFisicoEE = $("#docFisicoEE").val();
		return docFisicoEE!='' || numArcPostulaEEBD!='';
	}, "Adjunte un documento de sustento.");
	
	
	$.validator.addMethod("regex",function(value, element, regexp){        
		        return this.optional(element) || regexp.test(value);
	}, "Ingrese nombre de entidad.");
	
	$.validator.addMethod("valNumeroBrevete", function(value, element){		
		var categoria = $("#txtCategoriaBrevete option:selected").text()	
		var campo = $(element).val().trim();
		var n = campo.length; 
		if (categoria != '[--Seleccione--]' && n == 0 ) {
			return false;
		}else {
			return true;				
		} 
	}, "Ingrese Numero de Brevete");
	
	
	$.validator.addMethod("valCategoriaBrevete", function(value, element){
		var categoria = $("#txtCategoriaBrevete option:selected").text()	
		var campo = $('#txtNumBrevete').val().trim();
        var n = campo.length;
        if ( categoria == '[--Seleccione--]' && n > 0 ) {
			return false;
		} else {
			return true;
		}
	}, "Seleccione Categoría del Brevete");
	
	
	$.validator.addMethod("valDuplicidadConoInformatico", function(value, element){
		var tipoConocimiento = $("#selTipoConoInformatico").val();
		var codConocimiento = $("#selDetalleTipoConoInformatico").val();
		
		//Buscamos en la lista
		var tbl = $('#tblDataConoInformatico').DataTable();
		
		var data = tbl.rows().data();
		var noHayError = true;
		data.each(function (value, index) {
			var codTipo = value[5];
			var codCono = value[6];
			if(codTipo==tipoConocimiento && 
					codCono==codConocimiento){
				noHayError = false;
			}
	    });
		return noHayError;
		
	}, "Ya existe este conocimiento de este tipo, debe editarlo.");
	
	
	
};




var validarInformacionPersonal = function(){

	
	//validación del formulario con jquery
	$("#formInformacionPersonal").validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		codEstcivil: {
	      		required: true
	    	},
	    	indSexo: {
	      		required: true
	    	},
	    	numTelcasa: {
  				required: false,
  				digits: true,
  				min:100000
			},
			numTelcelular: {
				required: true,
				digits: true,
  				min:100000
			},
			codUbiDepLugarNac: {
  				required: true
			},
			codUbiProvLugarNac: {
  				required: true
			},
			codUbigeonac: {
  				required: true
			},	
			
			numLicencia:{			
				valNumeroBrevete: true
			},
			
			codCatLicencia :{
				valCategoriaBrevete: true
			},		
								
			numRuc: {
  				required: false,
  				number: true,
  				min: 10000000000,
  				max: 99999999999,
  				decimales: false 
			}
	   },
	   messages: {
		    codEstcivil: {
	      		required: 'Seleccione Estado Civil.'
	    	},
	    	indSexo: {
	      		required: 'Seleccione Sexo.'
	    	},
	    	numTelcasa: {
 				required: 'Ingrese teléfono de casa.',
 				digits: 'Ingrese solo números.',
 				min: 'Ingrese un número de teléfono válido.'
			},
			numTelcelular: {
				required: 'Ingrese teléfono celular.',
				digits: 'Ingrese solo números.',
				min: 'Ingrese un número de teléfono válido.'
			},
			codUbiDepLugarNac: {
 				required: 'Seleccione Departamento.'
			},
			codUbiProvLugarNac: {
 				required: 'Seleccione Provincia.'
			},
			codUbigeonac: {
 				required: 'Seleccione Distrito.'
			},
			numRuc: {
  				number: 'Número de RUC inválido.',
  				min: 'Número de RUC inválido.',
  				max: 'Número de RUC inválido.',
  				decimales: 'Número de RUC inválido.'
			}
		},
		highlight: function (e) {
			$(e).parent().removeClass('has-success').addClass('has-error');
		},
		success: function (e) {
			$(e).parent().removeClass('has-error').addClass('has-success');
		},
		errorPlacement: function (error, element) {
			error.insertAfter(element);
		},

		submitHandler: function (form) {
			var formulario = $("#formInformacionPersonal");
			var data = $.toJSON(formToObject(formulario.serializeArray()));
			var url = CONTEXT_APP+"/registro/ficha";
		    $.ajax({
		           type: "POST",
		           url: url,
		           dataType: 'json',	
		           data: data, 
		           contentType: "application/json; charset=utf-8",
		           success: function(resultado){
		        	   if(validaSesion(resultado)){
		        		   if(resultado.fichaActualizada==1){
			        		   bootbox.alert("Ficha Actualizada.");
			        	   }else{
			        		   alert("Se encontraron errores...");
			        	   }   
		        	   }
		           }
		   });	
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
	
	$('#txtNumBrevete').keypress(function (e) {
	    var regex = new RegExp("^[a-zA-Z0-9]+$");
	    var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
	    if (regex.test(str)) {
	        return true;
	    }

	    e.preventDefault();
	    return false;
	});
	
};

var validaSesion = function(resultado){
	var sesionValida = true;
	if(resultado.errorSesion!=null){
		sesionValida = false;
		terminarSesion();
	}
	return sesionValida;
};

var terminarSesion = function(){
	bootbox.dialog({title:"Sesión expirada",message: "Su sesión ha terminado por inactividad.",closeButton: false,
		   buttons: {danger: {label: "Aceptar",className: "btn-danger",callback:function(){
			   location.href=CONTEXT_APP+"/acceso/inicioLogin";		   
		   }}}});
};


function alerta(mensaje){
	bootbox.dialog({title:"Error",message: mensaje,closeButton: false,
        			   buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
}


var formToObject = function(formArray) {
	var returnArray = {};
	for (var i = 0; i < formArray.length; i++){
		var cadena = formArray[i]['value'];
		if(cadena!=null)returnArray[formArray[i]['name']] = cadena.toUpperCase();
		else  returnArray[formArray[i]['name']] = formArray[i]['value'];
	}
	return returnArray;
};


var validarDomicilio = function(){
	
	//validación del formulario con jquery
	$( "#formInformacionDomicilio" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		codTipvia: {
	      		required: true
	    	},
	    	nomVia: {
	      		required: true
	    	},
	    	numDom: {
	      		required: true
	    	},
	    	codTipzona: {
  				required: true
			},
			nomZona: {
				required: true
			},
			codUbiDepLugarDom: {
  				required: true
			},
			codUbiProvLugarDom: {
  				required: true
			},
			codUbigeodom: {
  				required: true
			}
	   },
	   messages: {
		    codTipvia: {
			   required: 'Seleccione tipo de vía.'
	    	},
	    	nomVia: {
	  			required: 'Ingrese dirección.'
	    	},
	    	numDom: {
	    		required: 'Ingrese número de domicilio.'
	    	},
	    	codTipzona: {
	    		required: 'Seleccione tipo de zona.'
			},
			nomZona: {
				required: 'Ingrese nombre de zona.'
			},
			codUbiDepLugarDom: {
				required: 'Seleccione Departamento.'
			},
			codUbiProvLugarDom: {
				required: 'Seleccione Provincia.'
			},
			codUbigeodom: {
 				required: 'Seleccione Distrito.'
			}
		},
		highlight: function (e) {
			$(e).parent().removeClass('has-success').addClass('has-error');
		},
		success: function (e) {
			$(e).parent().removeClass('has-error').addClass('has-success');
		},
		errorPlacement: function (error, element) {
			error.insertAfter(element);
		},

		submitHandler: function (form) {
			var formulario = $("#formInformacionDomicilio");
			var data = $.toJSON(formToObject(formulario.serializeArray()));
			var url = CONTEXT_APP+"/registro/ficha";
		    $.ajax({
		           type: "POST",
		           url: url,
		           dataType: 'json',	
		           data: data, 
		           contentType: "application/json; charset=utf-8",
		           success: function(resultado){
		        	   if(validaSesion(resultado)){
		        		   if(resultado.fichaActualizada==1){
			        		   bootbox.alert("Ficha Actualizada.");
			        	   }else{
			        		   alert("Se encontraron errores...");
			        	   }   
		        	   }
		        	   
		           }
		   });	
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
	
};

var validarFormacionAcademica = function(){

	//validación del formulario con jquery
	validadorFormacionAcademica = $( "#formDatosAcademicos" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		codTipoEstudio: {
	      		required: true
	    	},
	  		codNivelEducativ: {
	      		required: {
  					depends:function(element){
  						var selTipoEstudio = $("#selTipoEstudio").val();
  						return selTipoEstudio!='1';//para 1=secndaria completa es opcional
  					}
  				}
	      		
	    	},
	    	codCentroEstudio: {
	    		required: {
  					depends:function(element){
  						var selTipoEstudio = $("#selTipoEstudio").val();
  						return selTipoEstudio!='1';//para 1=secndaria completa es opcional
  					}
  				}
	    	},
	    	codEspecialidad: {
	    		required: {
  					depends:function(element){
  						var selTipoEstudio = $("#selTipoEstudio").val();
  						return selTipoEstudio!='1';//para 1=secndaria completa es opcional
  					}
  				}
	    	},
	    	nomCentroEstudio: {
	    		required: {
  					depends:function(element){
  						var codCentroEstudio = $("#codCentroEstudio").val();
  						if(codCentroEstudio=='99996' || codCentroEstudio=='99997' ||
  				    			codCentroEstudio=='99998' || codCentroEstudio=='99999'){
  							return true;
  						}else{
  							return false;
  						}
  					}
  				}
			},
			nomProfesion: {
  				required: {
  					depends:function(element){
  						var codEspecialidad = $("#selCarrera").val();
  						if(codEspecialidad=='9995' || codEspecialidad=='9996' || codEspecialidad=='9997' || 
  								codEspecialidad=='9998' || codEspecialidad=='9999'){
  							return true;
  						}else{
  							return false;
  						}
  					}
  				}
			},
	    	codCiclo: {
  				required: {
  					depends:function(element){
  						var valueNivel = $("#selNivelEducativo").val();
  						//Si el nivel educativo es estudiante..
  						return valueNivel=='1';
  					}
  				}
			},
			fecEgreso: {
				minFecha: true,
				required: {
  					depends:function(element){
  						var selNivelEducativo = $("#selNivelEducativo").val();//ESTUDIANTE
  						return selNivelEducativo!='1';//Si es estudiante entonces se oculta y es opcional
  					}
  				}
			},
			fecGrado: {
				minFecha: true,
				required: {
  					depends:function(element){
  						var selTipoEstudio = $("#selTipoEstudio").val();//ESCOLAR
  						return selTipoEstudio!='1'
  					}
  				},
  				valMinFechaGrado: {
  					depends:function(element){
  						var valueFechaGrado = $("#fecEgreso").val();
  						return valueFechaGrado!='';
  					}
  				}
			},
			indPuestoUniv: {
				required: {
  					depends:function(element){
  						var selTipoEstudio = $("#selTipoEstudio").val();
  						return selTipoEstudio!='1';//para 1=secndaria completa es opcional
  					}
  				}
			}/*,
			docFisicoFA: {
  				required: true
			}*/
	   },
	   messages: {
		    codTipoEstudio: {
	      		required: 'Especifique tipo de estudios.'
	    	},
		    codNivelEducativ: {
	      		required: 'Especifique nivel de estudios.'
	    	},
	    	codCiclo: {
 				required: 'Especifique ciclo.'
			},
	    	codCentroEstudio: {
	      		required: 'Especifique centro de estudios.'
	    	},
	    	codEspecialidad: {
	      		required: 'Especifique carrera.'
	    	},
	    	nomCentroEstudio: {
 				required: 'Especifique centro de estudios.'
			},
			nomProfesion: {
 				required: 'Especifique carrera.'
			},
	    	
			fecEgreso: {
				required: 'Ingrese fecha de egreso.',
				maxFecha: 'La fecha no puede ser mayor a la actual.'
			},
			fecGrado: {
 				required: 'Ingrese fecha del grado.'
			},
			indPuestoUniv: {
 				required: 'Ingrese mérito obtenido.'
			}/*,
			docFisicoFA: {
 				required: 'Adjunte un documento de sustento.'
			}*/
		},
		highlight: function (e) {
			if($(e).is("input[id^='fec']")) {
				//$(e).closest('.custom-form-group').removeClass('has-success').addClass('has-error');
				//$(e).removeClass('has-success').addClass('has-error');
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');
			}else{
				//$(e).parent().removeClass('has-success').addClass('has-error');	
				$(e).parent().addClass('has-error');
			}
			
		},
		success: function (e) {
			//$(e).parent().removeClass('has-error').addClass('has-success');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[id^='fec']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			registrarArchivoUpload("FA");

		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
};


var validarEstudiosEspecializacion = function(){
	
	//validación del formulario con jquery
	validadorEstudiosEspecializacion = $( "#formDatosEstudiosEspecializacion" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		nomEspecialidad: {
	      		required: true
	    	},
	    	codCentroEstudio: {
	      		required: true
	    	},
	    	nomCentroEstudio: {
	      		required: true
	    	},
	    	fecInicio: {
	    		minFecha: true,
  				required: true
			},
			fecFin: {
				minFecha: true,
  				required: true,
  				valMinFechaFin: {
  					depends:function(element){
  						var valueFechaInicio = $("#fecInicio").val();
  						return valueFechaInicio!='';
  					}
  				}
			},
			fecCertificado: {
				minFecha: true,
  				required: true,
  				valMinFechaCertificado: {
  					depends:function(element){
  						var valueFechaFin = $("#fecFin").val();
  						return valueFechaFin!='';
  					}
  				}
			},
			cntHoraLectiva: {
  				required: true,
  				number: true,
  				min: 0,
  				max: 99999,
  				decimales: false
			},
			docFisicoEE: {
				valDocumentoSustentoEstudioEspecializacion: true
			}
	   },
	   messages: {
		    nomEspecialidad: {
	      		required: 'Ingrese especialidad.'
	    	},
	    	codCentroEstudio: {
	      		required: 'Seleccione centro de estudios.'
	    	},
	    	nomCentroEstudio: {
	      		required: 'Ingrese centro de estudios.'
	    	},
	    	fecInicio: {
  				required: 'Ingrese fecha de inicio.'
			},
			fecFin: {
  				required: 'Ingrese fecha de fin.'
			},
			fecCertificado: {
  				required: 'Ingrese fecha de certificado.'
			},
			cntHoraLectiva: {
  				required: 'Ingrese horas lectivas.',
  				number: 'Ingrese horas lectivas.',
  				min: 'Ingrese horas lectivas.',
  				max: 'Ingrese horas lectivas.',
  				decimales: 'Ingrese horas lectivas.'
			}
		},
		highlight: function (e) {
			if($(e).is("input[id^='fec']")) {
				//$(e).closest('.custom-form-group').removeClass('has-sucess').addClass('has-error');
				//$(e).removeClass('has-success').addClass('has-error');
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');
			}else{
				//$(e).parent().removeClass('has-success').addClass('has-error');	
				$(e).parent().addClass('has-error');
			}
			
		},
		success: function (e) {
			//$(e).parent().removeClass('has-error').addClass('has-success');
			$(e).parent().removeClass('has-error');
			$(e).closest('.custom-form-group').removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[id^='fec']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			registrarArchivoUpload("EE");
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
	
};

var validarCertificacion = function(){
	//validación del formulario con jquery
	$( "#formDatosCertificacion" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		nomEspecialidad: {
	      		required: true
	    	},
	    	codCentroEstudio: {
	      		required: true
	    	},
	    	nomCentroEstudio: {
	      		required: true
	    	},
	    	fecInicio: {
	    		minFecha: true,
  				required: true
			},
			fecFin: {
				minFecha: true,
  				required: true,
  				valMinFechaFin: {
  					depends:function(element){
  						var valueFechaInicio = $("#fecInicioCert").val();
  						return valueFechaInicio!='';
  					}
  				}
			},
			fecCertificado: {
				minFecha: true,
  				required: true,
  				valMinFechaCertificadoCert: {
  					depends:function(element){
  						/*var valueFechaFin = $("#fecFinCert").val();
  						return valueFechaFin!='';*/
  						return false;
  					}
  				}
			},
			docFisicoCert: {
				valDocumentoSustentoCertificado: true
			}
	   },
	   messages: {
		    nomEspecialidad: {
	      		required: 'Ingrese especialidad.'
	    	},
	    	codCentroEstudio: {
	      		required: 'Seleccione centro de estudios.'
	    	},
	    	nomCentroEstudio: {
	      		required: 'Ingrese centro de estudios.'
	    	},
	    	fecInicio: {
  				required: 'Ingrese fecha de inicio.'
			},
			fecFin: {
  				required: 'Ingrese fecha de fin.'
			},
			fecCertificado: {
  				required: 'Ingrese fecha de certificado.'
			}
		},
		highlight: function (e) {
			if($(e).is("input[id^='fec']")) {
				//$(e).closest('.custom-form-group').removeClass('has-sucess').addClass('has-error');
				//$(e).removeClass('has-success').addClass('has-error');
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');
			}else{
				//$(e).parent().removeClass('has-success').addClass('has-error');	
				$(e).parent().addClass('has-error');
			}
			
		},
		success: function (e) {
			//$(e).parent().removeClass('has-error').addClass('has-success');
			$(e).parent().removeClass('has-error');
			$(e).closest('.custom-form-group').removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[id^='fec']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			registrarArchivoUpload("Cert");
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
	
};


var validarConocimientosInformaticos = function(){
	
	//validación del formulario con jquery
	validadorConocimientosInformaticos = $( "#formDatosConocimientosInformaticos" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		codTipcono: {
	      		required: true
	    	},
	    	codConocimiento: {
	      		required: true,
	      		valDuplicidadConoInformatico:{
  					depends:function(element){
  						var valueConocimiento = $("#codTipcono").val();
  						var valueId = $("#numIdConocimient").val();
  						return valueConocimiento!='' && valueId=='';
  					}
  				}
	    	},
	    	nomConcomiento: {
	      		required: true
	    	},
	    	codNivel: {
  				required: true
			}
	   },
	   messages: {
	  		codTipcono: {
	      		required: 'Seleccione tipo de conocimiento.'
	    	},
	    	codConocimiento: {
	      		required: 'Seleccione conocimiento.'
	    	},
	    	nomConcomiento: {
	      		required: 'Ingrese conocimiento.'
	    	},
	    	codNivel: {
  				required: 'Ingrese nivel.'
			}
		},
		highlight: function (e) {
			if($(e).is("input[id^='fec']")) {
				//$(e).closest('.custom-form-group').removeClass('has-sucess').addClass('has-error');
				//$(e).removeClass('has-success').addClass('has-error');
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				//$(e).parent().removeClass('has-success').addClass('has-error');	
				$(e).parent().addClass('has-error');
			}
			
		},
		success: function (e) {
			//$(e).parent().removeClass('has-error').addClass('has-success');
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[id^='fec']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			//Registramos y actualizamos la grilla
			var formulario = $("#formDatosConocimientosInformaticos");
			var formArray = formToObject(formulario.serializeArray())
			var data = $.toJSON(formArray);
			var url = CONTEXT_APP+"/registro/contecnico/registrar";
		    $.ajax({
		           type: "POST",
		           url: url,
		           dataType: 'json',	
		           data: data, 
		           contentType: "application/json; charset=utf-8",
		           success: function(resultado){
		        	   if(validaSesion(resultado)){
		        		   if(resultado.fichaActualizada==1){
			        		   bootbox.alert("Ficha Actualizada.");
			        		   $("#divDatosConoInformaticoPopup").modal('hide');
			        		   $('#formDatosConocimientosInformaticos').trigger("reset");
			        		   recargarGrillaConocimientosInformaticos();
			        	   }else{
			        		   alert("Se encontraron errores...");
			        	   }   
		        	   }
		           }
		   });
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});
	
};


var validarExperienciaLaboral = function(){
	//validación del formulario con jquery
	validadorExperienciaLaboral = $( "#formDatosExperiencia" ).validate({
		errorElement: 'span',
		errorClass: 'help-block',
		ignore: ":hidden:not(select)",
	  	rules: {
	  		codTipoexpe: {
	      		required: true
	    	},
	    	codTipoentidad: {
	      		required: true
	    	},
	    	desEntidad  : {
	      		required: true, 
	      		normalizer: function( value ) {return $.trim( value );},
	      		regex: /([-a-zA-Z0-9]|\0)/
			},
			nomDireccion: {
  				required: true,
  				normalizer: function( value ) {return $.trim( value );}
			},
			desArea: {
				required: true,
				normalizer: function( value ) {return $.trim( value );}
			},
			desCargo: {
				required: true,
				normalizer: function( value ) {return $.trim( value );}
			},
			desLabores: {
				required: true,
				normalizer: function( value ) {return $.trim( value );}
			},
			fecInicio: {
				minFecha: true,
  				required: true
			},
			fecFin: {
				minFecha: true,
  				required: true,
  				valMinFechaExperiencia: {
  					depends:function(element){
  						var valueFechaInicio = $("#fecInicioExp").val();
  						return valueFechaInicio!='';
  					}
  				}
			},
			mtoRemu: {
  				required: true,
  				number: true,
  				min: 0,
  				max: 9999999,
  				decimales: false
			},
			codTipocontrato: {
  				required: true
			},
			codMotivoCese: {
  				required: true
			},
			desCargoCont: {
  				required: false
			},
			nomContacto: {
  				required: false
			},
			numTelefono: {
  				required: false
			},
			nomCorreo:{
				email: true
			},
			docFisicoEL: {
				valDocumentoSustento: {
  					depends:function(element){
  						//var valueDocumentoSustento = $("#numArcPostulaELBD").val();
  						//return valueDocumentoSustento!='';
  						return true;
  					}
  				}
			}
	   },
	   messages: {
		    codTipoexpe: {
	      		required: 'Seleccione tipo de experiencia.'
	    	},
	    	codTipoentidad: {
	      		required: 'Seleccione tipo de entidad.'
	    	},
	    	desEntidad: {
	      		required: 'Ingrese nombre de entidad.'
	    	},
	    	nomDireccion: {
 				required: 'Ingrese Dirección.'
			},
			desArea: {
				required: 'Ingrese área.'
			},
			desCargo: {
				required: 'Ingrese cargo.'
			},
			desLabores: {
 				required: 'Ingrese funciones principales.'
			},
			fecInicio: {
 				required: 'Ingrese fecha de inicio.'
			},
			fecFin: {
 				required: 'Ingrese fecha de fin.'
			},
			mtoRemu: {
 				required: 'Ingrese pago.',
 				number: 'Ingrese un monto.',
 				min: 'Ingrese un monto.',
 				max: 'Ingrese un monto.',
 				decimales: 'Ingrese monto sin decimales.',
			},
			codTipocontrato: {
  				required: 'Seleccione tipo de contrato.'
			},
			codMotivoCese: {
  				required: 'Seleccione motivo de cese.'
			},
			desCargoCont: {
  				required: 'Ingrese el cargo del contacto.'
			},
			nomContacto: {
  				required: 'Ingrese nombres y apellidos del contacto.'
			},
			numTelefono: {
  				required: 'Ingrese teléfono del contacto'
			},
			nomCorreo: {
  				email: 'Por favor ingrese un email válido.'
			}
		},
		highlight: function (e) {
			if($(e).is("input[id^='fec']")) {
				//$(e).closest('.custom-form-group').removeClass('has-sucess').addClass('has-error');
				//$(e).removeClass('has-success').addClass('has-error');		
				$(e).closest('.custom-form-group').addClass('has-error');
				$(e).addClass('has-error');		
			}else{
				//$(e).parent().removeClass('has-success').addClass('has-error');	
				$(e).parent().addClass('has-error');
			}
			
		},
		success: function (e) {
			//$(e).parent().removeClass('has-error').addClass('has-success');
			$(e).parent().removeClass('has-error');
			$(e).closest('.input-group').removeClass('has-error');
			$(e).remove();
		},
		errorPlacement: function (error, element) {
			if(element.is("input[id^='fec']")) {
				error.insertAfter(element.parent());
			}else{
				error.insertAfter(element);	
			}
		},

		submitHandler: function (form) {
			registrarArchivoUpload("EL");
		    
		},
		invalidHandler: function (form) {
			ping();//reload session
		}
	});	
	
	
	
};

var resetFormExperiencia = function(){
	$('#numIdExpe').val("");
	$('#formDatosExperiencia').trigger("reset");
	
	$('#numArcPostulaEL').val("");
	$('#numArcPostulaELBD').val("");
};


