/**
 * Aquí las funciones javascript de postulacion
 * 
 */
var inicializarRevision = function(){
	
	//$("#tabPostulacion").tabs();//
	
	//Configuracion de la tabla de experiencia laboral
    var tblDataPostulaciones = $('#tblDataPostulaciones').DataTable( {
    	"columnDefs": [{"targets": [0], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    //Codigo practicante Jean Pierre
    
    // configuracion de la tabla de educacion
    var tblDataAcademica = $('#tblDataAcademica').DataTable( {
    	"columnDefs": [{"targets": [0,1,10,11], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    // configuracion de la tabla de especializacion  
    var tblDataEstudiosEspecializacion = $('#tblDataEstudiosEspecializacion').DataTable( {
    	"columnDefs": [{"targets": [0,1,11,12],"visible": false,"searchable": false}], 
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    // Configuracion de tabla de certificacion
    var tblDataCertificacion = $('#tblDataCertificacion').DataTable( {
    	"columnDefs": [{"targets": [0,1,11,12], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
        
  // Configuracion de tabla de ofimatica e Idiomas
    var tblDataConoInformatico = $('#tblDataConoInformatico').DataTable( {
    	"columnDefs": [{"targets": [0,1,5,6],"visible": false,"searchable": false}],  //"visible": false
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    
    // Configuracion de tabla de Experiencia Laborarl "visible": false
    
    var tblDataExperienciaLaboral = $('#tblDataExperienciaLaboral').DataTable( {
    	"columnDefs": [{"targets": [0,1,11,12],"visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    //listar reporte historico  "visible": false,
    var tblDatosReporteHistorico = $('#tblDatosReporteHistorico').DataTable( {
    	"columnDefs": [{"targets": [0],"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    
    var tblDataSearchPersonal = $('#tblDataSearchPersonal').DataTable( {
		columnDefs: [ {
            orderable: false,
            className: 'select-checkbox',
            targets:   0
        } ],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":false,
        "bLengthChange": false,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "select": {
            style:    'single',
            selector: 'td:first-child'
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    //Al seleccionar una fila
    tblDataSearchPersonal.on( 'select', function ( e, dt, type, indexes ) {
		  verificarSeleccion();
	});
    
    //Al deseleccionar una fila
    tblDataSearchPersonal.on( 'deselect', function ( e, dt, type, indexes ) {
		  verificarSeleccion();
	});
    
    $("#divDatosBuscarPersonal" ).on('shown.bs.modal', function(){
    	$('#numRegistroSearchPersonal').val("");
    	$('#apePaternoSearchPersonal').val("");
    	$('#apeMaternoSearchPersonal').val("");
    	$('#nombresSearchPersonal').val("");
    	var tbl = $('#tblDataSearchPersonal').DataTable();
		tbl.clear().draw();			
		$("#apePaternoSearchPersonal").focus();
	});
    
    
    $("#btnBuscarPersonal").click(function(){
		buscarPersonalEnVentanaEmergente();	
	});
    
    
	$('#numRegistroSearchPersonal').keypress(alPulsarEnterBusquedaPersonal);
	$('#apePaternoSearchPersonal').keypress(alPulsarEnterBusquedaPersonal);
	$('#apeMaternoSearchPersonal').keypress(alPulsarEnterBusquedaPersonal);
	$('#nombresSearchPersonal').keypress(alPulsarEnterBusquedaPersonal);
	

	$("#btnCerrarSeleccionPersonal").click(function(){
		$("#divDatosBuscarPersonal").modal('hide');
	});
	
	
	$("#btnSeleccionPersonal").click(function(){
		//aqui hay q verificar que se haya seleccionado un registro y sino quitar la seleccion...
		if(seleccionarPersona()){
			if(postProcessBuscarPersonalFunction!=null){
				postProcessBuscarPersonalFunction();
			}
			$("#divDatosBuscarPersonal").modal('hide');	
		}
	});
        
    
    $("#btnConsultar").click(function(){
    	//al consultar.
    	
    	var codProceso = $("#selProceso").val();
    	if(codProceso!="-"){
    		//1. Limpiamos la tabla
    		var tbl = $('#tblDataPostulaciones').DataTable();
			tbl.clear().draw();
			
			//2. Preparamos la data con la que vamos a consultar 
    		var codProcesoArray = codProceso.split("-");
    		var codCat = codProcesoArray[0] ;
    		var codPuesto = codProcesoArray[1] ;
    		var URL = CONTEXT_APP+"/revision/postulantes?codCat="+codCat+"&codPuesto="+codPuesto;
    		
    		//3. Realizamos la consulta
    		$.blockUI({ message: "<h1>Procesando...</h1>" });
        	setTimeout(function(){
        		$.ajax(
        				{
        					async: false, 
        					type: "POST",
        					url: URL,
        					dataType: 'json', 
        					contentType: "application/json; charset=utf-8"})
    			.done(function(resultado){
    				//1. Informacion de revision
    				
    				$("#indVisualizaFormacion").val(resultado.indVisualizaFormacion);
    				$("#indVisualizaEstudios").val(resultado.indVisualizaEstudios);
    				$("#indVisualizaCertificaciones").val(resultado.indVisualizaCertificaciones);	
    				$("#indVisualizaConocimientos").val(resultado.indVisualizaConocimientos);
    				$("#indVisualizaExperiencia").val(resultado.indVisualizaExperiencia);
    				
    				//Limpiamos las secciones de evaluacion
    				if("1"==resultado.indVisualizaFormacion)$("#divGrabacionFormacion").show();	
    				else $("#divGrabacionFormacion").hide();
    				
    				if("1"==resultado.indVisualizaEstudios)$("#divGrabacionEstudios").show();	
    				else $("#divGrabacionEstudios").hide();
    				
    				if("1"==resultado.indVisualizaCertificaciones)$("#divGrabacionCertificacion").show();	
    				else $("#divGrabacionCertificacion").hide();
    				
    				if("1"==resultado.indVisualizaConocimientos)$("#divGrabacionConocimientos").show();	
    				else $("#divGrabacionConocimientos").hide();
    				
    				if("1"==resultado.indVisualizaExperiencia)$("#divGrabacionExperiencia").show();	
    				else $("#divGrabacionExperiencia").hide();
    				
    				
    				//2. INformacion de postulantes
    				var postulantes = resultado.postulantes;
    				if(postulantes.length>0){ // if
    					for(var i=0;i<postulantes.length;i++){
    		        		var p = postulantes[i];
    		        		var linkFUP = "<a href='javascript:visualizarFUP(\""+p.numPostulante+"\",\""+codCat+"\",\""+codPuesto+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;FUP</a>";
    		        		var linkVer = "<a href='javascript:visualizarPostulante(\""+p.numPostulante+"\",\""+codCat+"\",\""+codPuesto+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;REVISAR</a>";
    						tbl.row.add( 
    								[p.numPostulante,
    								 p.descTipoDoc,
    								 p.numDocId,
    								 p.nomPostulante,
    								 linkFUP,
    								 linkVer,
    								 $.trim(p.desResultado),
    								 $.trim(p.desRevisor)]).draw( true );
    		        	}// f for
    					//Mostramos el listado de postulantes.
    					//$("#accordion").accordion("option","active","accordionResultadoProceso");
    					$('#divResultadoProcesos').collapse('show');
    					
    					$.unblockUI();
    					
    					//$("#tabPostulacion").tabs("option", "active", 1);
    					//$("#tabPostulacion").tabs({ active: 1 });
    					
    				}else{ // f if i else
    					$.unblockUI();
    					alertar("Sin postulantes.");		
    				}
    			}).fail(function(jqXHR, textStatus, errorThrown){
    				alertar("Sin postulantes.");
    			});		
        		//$("#tabPostulacion").tabs("option", "active", 1);
        	},250);
        	
    	}else{
    		alertar("Debe seleccionar un proceso.",function(){
    			$("#selProceso").focus();
    		});
    	}
    });
    
    $("#btnDescargar").click(function(){
    	var codProceso = $("#selProceso").val();
    	if(codProceso!="-"){
    		var codProcesoArray = codProceso.split("-");
    		var codCat = codProcesoArray[0] ;
    		var codPuesto = codProcesoArray[1];
    		$("#codCatExcel").val(codCat);
    		$("#codPuestoExcel").val(codPuesto);
    		$("#formDescargarExcel").submit();	
    	}else{
    		alertar("Debe seleccionar un proceso.",function(){
    			$("#selProceso").focus();
    		});
    	}
    	
    });
    
    
    $("#btnAsignar").click(function(){
    	
    	var codProceso = $("#selProceso").val();
    	if(codProceso!="-"){
    		reiniciarBusqueda();
        	var tblDataSearchPersonal = $('#tblDataSearchPersonal').DataTable();
        	tblDataSearchPersonal.clear().draw();
        	$("#divDatosBuscarPersonal").modal('show');	
    	}else{
    		alertar("Debe seleccionar un proceso.",function(){
    			$("#selProceso").focus();
    		});
    	}
    	
    });
    
    
    $("#btnCerrarHistorico").click(function(){
		$("#divDatosReporteHistorico").modal('hide');
    });
    
    $("#btnDerivarPersonal").click(function(){
    	
    	var codProceso = $("#selProceso").val();
    	var codProcesoArray = codProceso.split("-");
    	var codCat = codProcesoArray[0] ;
    	var codPuesto = codProcesoArray[1] ;
    	
    	//1. Verificar que haya seleccionado un dato
    	var tbl = $('#tblDataSearchPersonal').DataTable();
    	var empleadoSeleccionado = tbl.rows( { selected: true } ).data().toArray()[0];//solo se puede escoger un bien a la vez,
		if("NO"==empleadoSeleccionado[3]){
			//asignamos
			asignarDesasignarRevision(empleadoSeleccionado[1],codCat,codPuesto,"1");
		}else{
			//desasignamos
			asignarDesasignarRevision(empleadoSeleccionado[1],codCat,codPuesto,"0");
		}
    });
    
    
    $("#btnCerrarBusquedaPersonal").click(function(){
		$("#divDatosBuscarPersonal").modal('hide');
    });
    
    
    $("#btnGrabarRevisionFormacion").click(function(){
    	grabarRevisionSeccion("tblDataAcademica","selRevForm","03","selRevFormacionSeccion");
    });
    
    $("#btnGrabarRevisionEstudios").click(function(){
    	grabarRevisionSeccion("tblDataEstudiosEspecializacion","selRevEstudios","04","selRevEstudiosSeccion");
    });
    
    $("#btnGrabarRevisionCertificacion").click(function(){
    	grabarRevisionSeccion("tblDataCertificacion","selRevCertifica","05","selRevCertificacionesSeccion");
    });
    
    $("#btnGrabarRevisionConocimientos").click(function(){
    	grabarRevisionSeccion("tblDataConoInformatico","-","06","selRevConocimientosSeccion");
    });

    $("#btnGrabarRevisionExperiencia").click(function(){
    	grabarRevisionSeccion("tblDataExperienciaLaboral","selRevExperiencia","07","selRevExperienciaSeccion");
    });
    
    $("#btnGrabarRevisionPostulante").click(function(){
    	grabarRevisionPostulante();
    });
    
    $("#selRevPostulanteApto").change(function(){
    	var codResultado = $(this).val();
    	if("01"==codResultado){
    		$("#selRevPostulantePuntaje").prop("disabled",false);		
    	}else{
    		$("#selRevPostulantePuntaje").val("0");
    		$("#selRevPostulantePuntaje").prop("disabled",true);
    	}
    });
    
    $("#btnFinalizar").click(function(){
    	finalizarProcesoPostulacion();
    });
    
    $("#btnDevolver").click(function(){
    	devolverProcesoPostulacion();
    });

    
};

var limpiarFormularioRevision = function(){
	$("#selRevFormacionSeccion").val("");
	$("#selRevEstudiosSeccion").val("");
	$("#selRevCertificacionesSeccion").val("");
	$("#selRevConocimientosSeccion").val("");
	$("#selRevExperienciaSeccion").val("");
	$("#selRevPostulantePuntaje").val("0");
	$("#selRevPostulanteApto").val("");
	$("#selRevPostulantePuntaje").prop("disabled",true);
};


var confirmarProceso = function(mensaje,callbackFunction){
	bootbox.confirm({
		title: "Confirmaci&oacute;n",
		message: mensaje,
		buttons: {
			confirm: {label: '<i class="fa fa-check"></i> S&Iacute;'},
    		cancel: {label: '<i class="fa fa-times"></i> NO'}
		},
		callback: function (result) {
    		if(result){
    			callbackFunction();
    		}
		}
	});
};

var recargarPagina = function(){
	var url = CONTEXT_APP+"/revision/inicio";
	location.href = url;
};

var getUltimaRevision = function(numPostulante,codCat,codPuesto){
	
	var revision = {};
	revision["codCat"] = codCat;
	revision["numPostulante"] = numPostulante;
	revision["codPuesto"] = codPuesto;
	
	var revisionPostulante = null;
	var data = $.toJSON(revision);
	var url = CONTEXT_APP+"/revision/getUltimaRevision";
    $.ajax({
    	   async: false,
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){
        	   revisionPostulante = resultado;
           }
   });
   return revisionPostulante;
};


var devolverProcesoPostulacion = function(){
	
	var codProceso = $("#selProceso").val();
	if(codProceso!="-"){
		var mensaje = "\u00BFEsta seguro de DEVOLVER el proceso de selecci&oacute;n\u003F";
		confirmarProceso(mensaje,function(){
			
			var codProcesoArray = codProceso.split("-");
			var codCat = codProcesoArray[0] ;
			var codPuesto = codProcesoArray[1] ;
			var revision = {};
			revision["codCat"] = codCat;
			
			var data = $.toJSON(revision);
			var url = CONTEXT_APP+"/revision/devolverProcesoPostulacion";
		    $.ajax({
		           type: "POST",
		           url: url,
		           dataType: 'json',	
		           data: data, 
		           contentType: "application/json; charset=utf-8",
		           success: function(resultado){
		        	   if(resultado.procesoDevuelto==1){
		        		   mensajeInformativo("Proceso Devuelto.");
		        		   setTimeout(recargarPagina,1000);
		        	   }else{
		        		   alertar("Se encontraron errores...");
		        	   }
		           }
		   });
			
			
		});
	}else{
		alertar("Debe seleccionar un proceso.");
	}
};


var finalizarProcesoPostulacion = function(){
	
	var codProceso = $("#selProceso").val();
	if(codProceso!="-"){
		var mensaje = "\u00BFEsta seguro de FINALIZAR el proceso de selecci&oacute;n\u003F";
		confirmarProceso(mensaje,function(){
			
			var codProcesoArray = codProceso.split("-");
			var codCat = codProcesoArray[0] ;
			var codPuesto = codProcesoArray[1] ;
			var revision = {};
			revision["codCat"] = codCat;
			
			var data = $.toJSON(revision);
			var url = CONTEXT_APP+"/revision/finalizarProcesoPostulacion";
		    $.ajax({
		           type: "POST",
		           url: url,
		           dataType: 'json',	
		           data: data, 
		           contentType: "application/json; charset=utf-8",
		           success: function(resultado){
		        	   if(resultado.procesoFinalizado==1){
		        		   mensajeInformativo("Proceso Finalizado.");
		        		   setTimeout(recargarPagina,1000);
		        	   }else if(resultado.error==1){
		        		   alertar("Debe completar la revisi&oacute;n de todos los postulantes.");
		        	   }else{
		        		   alertar("Se encontraron errores...");
		        	   }
		           }
		   });	
		});
		
		
	}else{
		alertar("Debe seleccionar un proceso.");
	}
};



var grabarRevisionPostulante = function(){
	//Se cierra la revisión del postulante
	
	var codResultado = $("#selRevPostulanteApto").val();
	var valResultado = $("#selRevPostulantePuntaje").val();
	if(""==codResultado){
		alertar("Debe calificar al postulante.");
		return;
	}
	
	
	var esRevisableFormacion = $("#indVisualizaFormacion").val()=='1';
	var esRevisableEstudios = $("#indVisualizaEstudios").val()=='1';
	var esRevisableCertificaciones = $("#indVisualizaCertificaciones").val()=='1';	
	var esRevisableConocimientos = $("#indVisualizaConocimientos").val()=='1';
	var esRevisableExperiencia = $("#indVisualizaExperiencia").val()=='1';
	
	var resFormacion = $("#selRevFormacionSeccion").val();
	var resEstudios = $("#selRevEstudiosSeccion").val();
	var resCertifica = $("#selRevCertificacionesSeccion").val();
	var resConocimiento = $("#selRevConocimientosSeccion").val();
	var resExperiencia = $("#selRevExperienciaSeccion").val();
	
	if( (resFormacion=='' && esRevisableFormacion) || 
		(resEstudios=='' && esRevisableEstudios) || 
		(resCertifica=='' && esRevisableCertificaciones) || 
		(resConocimiento=='' && esRevisableConocimientos) || 
		(resExperiencia=='' && esRevisableExperiencia)){
		alertar("Verifique la calificación de las secciones, todas deben ser calificadas.");
		return;
	}
	
	//Si se calificó como apto
	if("01"==codResultado){
		//Se debe de validar q todas las secciones sean aptos.
		if(valResultado=='0'){
			alertar("Debe asignar un puntaje a la calificaci&oacute;n.");
			return;
		}
		
		if( (resFormacion!='01' && esRevisableFormacion) || 
			(resEstudios!='01' && esRevisableEstudios) || 
			(resCertifica!='01' && esRevisableCertificaciones) || 
			(resConocimiento!='01' && esRevisableConocimientos) || 
			(resExperiencia!='01' && esRevisableExperiencia)){
			alertar("Verifique la calificación de las secciones, todas deben ser calificadas como 'Apta'.");
			return;
		}
		
	}
	
	
	//Si se calificó como no apto
	if("00"==codResultado){
		//Se valida q al menos una sección sea no apto
		var marcoComoNoApto = false;
		if((resFormacion=='00' && esRevisableFormacion) ||
		   (resEstudios=='00' && esRevisableEstudios) || 
		   (resCertifica=='00' && esRevisableCertificaciones) || 
		   (resConocimiento=='00' && esRevisableConocimientos) || 
		   (resExperiencia=='00' && esRevisableExperiencia)){
			marcoComoNoApto = true;
		}
		
		if(!marcoComoNoApto){
			alertar("Verifique la calificación de las secciones, al menos una debe ser calificada como 'No Apta'.");
			return;
		}
	}
	
	var codCat = $("#codCatRevision").val();
	var numPostulante = $("#numPostulanteRevision").val();
	
	
	var revision = {};
	revision["codCat"] = codCat;
	revision["numPostulante"] = numPostulante;
	revision["codResultado"] = codResultado;
	revision["valResultado"] = valResultado;
	
	var data = $.toJSON(revision);
	var url = CONTEXT_APP+"/revision/grabarRevisionPostulante";
    $.ajax({
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){
        	   var errores = resultado.errores;
        	   if(resultado.postulanteRevisado==1 && errores.length==0){
        		   mensajeInformativo("Postulante Revisado.");
        		   
        		   $("#tabPostulacion").tabs("option", "active", 0);
        		   setTimeout(function(){
        			   $("#btnConsultar").click();   
        		   },150);
        		   
        	   }else if(errores.length>0){
        		   //alert("Se encontraron errores...");
        		   var mensajeError = "";
        		   for(var i=0;i<errores.length;i++){
        			   mensajeError = mensajeError + errores[i]+ "<br/>";
        		   }
        		   alertar(mensajeError);
        		   
        	   }else{
        		   alert("Se encontraron errores...");
        	   }
           }
   });
};

var grabarRevisionSeccion = function(idTabla,idSelectorItem,codSeccion,idSelectorSeccion){
	var codCat = $("#codCatRevision").val();
	var codPuesto = $("#codPuestoRevision").val();
	var numPostulante = $("#numPostulanteRevision").val();
	//iteramos sobre la data de formacion y obtenemos el valor seleccionado por el usuario
	
	var arrayRevisionDoc = [];
	var tbl = $('#'+idTabla).DataTable();
	var data = tbl.rows().data().toArray();
	
	var revisionValida = true;
	
	
	if(data.length>0 && idSelectorItem!="-"){
		
		for(var i=0;i<data.length;i++){
			var codSel = codCat+"_"+codPuesto+"_"+numPostulante+"_"+data[i][0];
			var codItem = "#"+idSelectorItem+"_"+codSel;
			var seleccionado = $(codItem).val();
			var revisionDoc = {};
			revisionDoc["codCat"] = codCat;
			revisionDoc["codPuesto"] = codPuesto;
			revisionDoc["codSeccion"] = codSeccion;
			revisionDoc["numCorrel"] = data[i][0];
			revisionDoc["numPostulante"] = numPostulante;
			revisionDoc["numRevision"] = "1";//la misma que la del padre
			revisionDoc["numArcPostula"] = data[i][1];
			revisionDoc["valResultado"] = tbl.$(codItem).val();
			
			if (!tbl.$(codItem).length){
				continue;
			}
			
			if(tbl.$(codItem).val()=='0'){
				alertar("Debe calificar todos los documentos.");
				$(codItem).focus();
				revisionValida = false;
				break;
			}
			
			arrayRevisionDoc.push(revisionDoc);	
		}
	}
	
	if(!revisionValida){
		return;
	}
	
	
	if($("#"+idSelectorSeccion).val()==''){
		alertar("Debe calificar la secci&oacute;n.");
		return;
	}
	$.blockUI({ message: "<h1>Grabando...</h1>" });
	setTimeout(function(){
		var revision = {};
		revision["codCat"] = codCat;
		revision["codPuesto"] = codPuesto;
		revision["codSeccion"] = codSeccion;
		revision["numPostulante"] = numPostulante;
		revision["codResultado"] = $("#"+idSelectorSeccion).val();
		revision["valResultado"] = "0";
		revision["revisionesDocs"] = arrayRevisionDoc;
		
		var data = $.toJSON(revision);
		var url = CONTEXT_APP+"/revision/grabarSeccion";
	    $.ajax({
	           type: "POST",
	           url: url,
	           dataType: 'json',	
	           data: data, 
	           contentType: "application/json; charset=utf-8",
	           success: function(resultado){
	        	   if(resultado.seccionRevisada==1){
	        		   mensajeInformativo("Sección Revisada.");
	        	   }else{
	        		   alert("Se encontraron errores...");
	        	   }   
	        	   $.unblockUI();
	           }
	   });	
	},500);
	
};


var asignarDesasignarRevision = function(codRegistro,codCat,codPuesto,indTipo){
	var queryString = "codRegistro="+codRegistro+"&codCat="+codCat+"&codPuesto="+codPuesto+"&indTipo="+indTipo;
	var URL = CONTEXT_APP+"/revision/registrarDerivacion?"+queryString;
	
	$.ajax({async: false, type: "POST",url: URL, dataType: 'json', contentType: "application/json; charset=utf-8"})
		.done(function(resultado){
			if(indTipo=="1"){
				mensajeInformativo("Derivaci&oacute;n realizada correctamente.");
			}else{
				mensajeInformativo("Se quit&oacute; la derivaci&oacute;n al usuario seleccionado.");	
			}
			$("#divDatosBuscarPersonal").modal('hide');	
			
	}).fail(function(jqXHR, textStatus, errorThrown){
		alertar("No hay registros para los criterios de búsqueda.");
	});
};




var verificarSeleccion = function(){
	var tbl = $('#tblDataSearchPersonal').DataTable();
	var size = tbl.rows().count();
	var sizeSeleccion = tbl.rows( { selected: true } ).count();
	if(sizeSeleccion>0){
		//Si hay registros seleccionados
		
		//<button type="button" class="btn btn-sm btn-primary" id="btnDerivarPersonal"><span class="glyphicon glyphicon-check"></span>&nbsp;Asignar</button>
		$("#btnDerivarPersonal").prop("disabled",false);//habilitamos el boton
		
		var empleadoSeleccionado = tbl.rows( { selected: true } ).data().toArray()[0];//solo se puede escoger un bien a la vez,
		if("NO"==empleadoSeleccionado[3]){
			//no está asignado
			$("#btnDerivarPersonal").removeClass("btn-danger");
			$("#btnDerivarPersonal").addClass("btn-primary");
			$("#btnDerivarPersonal").html("<span class='glyphicon glyphicon-check'></span>&nbsp;Asignar");
		}else{
			//Ya está asignado, lo desasignamos
			$("#btnDerivarPersonal").removeClass("btn-primary");
			$("#btnDerivarPersonal").addClass("btn-danger");
			$("#btnDerivarPersonal").html("<span class='glyphicon glyphicon-check'></span>&nbsp;Desasignar");
		}
		
	}else{
		$("#btnDerivarPersonal").prop("disabled",true);
	}
};


var alPulsarEnterBusquedaPersonal = function(e){
	var keyCode = window.event ? event.keyCode : event.which;
	if (keyCode == 13) {
		buscarPersonalEnVentanaEmergente();
		return false;
	}
	else {
		return true;
	}
};

var reiniciarBusqueda = function(){
	$("#btnDerivarPersonal").prop("disabled",true);
	$("#btnDerivarPersonal").removeClass("btn-danger");
	$("#btnDerivarPersonal").addClass("btn-primary");
	$("#btnDerivarPersonal").html("<span class='glyphicon glyphicon-check'></span>&nbsp;Asignar");
};


var buscarPersonalEnVentanaEmergente = function(){
	//limpiar el formulario de la pantalla emergente..
	var registro = $("#numRegistroSearchPersonal").val();
	var paterno = $("#apePaternoSearchPersonal").val();
	var materno = $("#apeMaternoSearchPersonal").val();
	var nombres = $("#nombresSearchPersonal").val();
	
	var codProceso = $("#selProceso").val();
	var codProcesoArray = codProceso.split("-");
	var codCat = codProcesoArray[0] ;
	var indAsignado = $('#indMostrarDerivados').is(':checked')?"1":"0";
	reiniciarBusqueda();
	buscarPersonal(registro,paterno,materno,nombres,codCat,indAsignado);
};


var buscarPersonal = function(numeroRegistro,paterno,materno,nombres,codCat,indAsignado){
	var queryString = ""
	var URL = '';
	if($.trim(numeroRegistro)=='' && "0"==indAsignado){
		//validar que se ingresó al menos un campo
		if($.trim(paterno)=='' && $.trim(materno)=='' && $.trim(nombres)==''){
			alertar("Debe ingresar un valor para la búsqueda.");
			return;
		}
	}
	
	queryString = "codRegistro="+numeroRegistro+"&apePaterno="+paterno.toUpperCase()+"&apeMaterno="+materno.toUpperCase()+"&nombres="+nombres.toUpperCase()+"&codCat="+codCat+"&indAsignado="+indAsignado;
	URL = CONTEXT_APP+"/revision/listarEmpleados?"+queryString;
	
	$.ajax({async: false, type: "POST",url: URL, dataType: 'json', contentType: "application/json; charset=utf-8"})
		.done(function(resultado){
			
			var tbl = $('#tblDataSearchPersonal').DataTable();
			tbl.clear().draw();
			if(resultado.length>0){
				for(var i=0;i<resultado.length;i++){
		    		var r = resultado[i];
					tbl.row.add(['',r.t02codPers,r.nombreCompleto,(r.indAsignado=='S'?"S&Iacute;":"NO")]).draw( true );
		    	}
			}else{
				alertar("No hay registros para los criterios de búsqueda.");
			}
			
	}).fail(function(jqXHR, textStatus, errorThrown){
		alertar("No hay registros para los criterios de búsqueda.");
	});
	
};

var visualizarFUP = function(numPostulante,codCat,codPuesto){
	$("#codCatFUP").val(codCat);
	$("#codPuestoFUP").val(codPuesto);
	$("#numPostulanteFUP").val(numPostulante);
	$("#formDescargarFUP").submit();
};
    
//Codigo practicante Jean Pierre
var visualizarPostulante = function(numPostulante,codCat,codPuesto){
   
	//Variables para la revisión...
	$("#codCatRevision").val(codCat);
	$("#codPuestoRevision").val(codPuesto);
	$("#numPostulanteRevision").val(numPostulante);
	
	limpiarFormularioRevision();
	var revisionBD = getUltimaRevision(numPostulante,codCat,codPuesto);	
	if(revisionBD!=null && revisionBD.evaluacion!=null){
		$("#selRevPostulanteApto").val(revisionBD.evaluacion.codResultado);
		$("#selRevPostulanteApto").change();
		$("#selRevPostulantePuntaje").val(revisionBD.evaluacion.valResultado);
	}
	
	visualizarDatosEducativos(numPostulante,codCat,codPuesto,revisionBD);
	visualizarDatosEspecializacion(numPostulante,codCat,codPuesto,revisionBD);
	visualizarDatosCertificacion(numPostulante,codCat,codPuesto,revisionBD);
	visualizarDatosConocimientosInformaticos(numPostulante,codCat,codPuesto,revisionBD);
	visualizarDatosExperienciaLaboral(numPostulante,codCat,codPuesto,revisionBD);
	
	$('#divDataAcademica').collapse('show');
	$('#divDataEstudiosEspecializacion').collapse('hide');
	$('#divDataConocimientoTecnico').collapse('hide');
	$('#divDataIdiomas').collapse('hide');
	$('#divDataExperienciaLaboral').collapse('hide');//toggle
	
	//habilitar la pestaña
	$("#tabPostulacion").tabs("option", "active", 1);

};


var getRevisionDocumento = function(revisionBD,selector,numCorrel){
	var resultado = [];
	resultado[0]='selected';
	resultado[1]='';
	resultado[2]='';
	if(revisionBD!=null && revisionBD[selector]!=null){
		var documentos = revisionBD[selector].revisionesDocs;
		for(var i=0;i<documentos.length;i++){
			if(documentos[i].numCorrel==numCorrel){
				if(documentos[i].valResultado=='1'){
					resultado[0]='';
					resultado[1]='selected';
				}else if(documentos[i].valResultado=='2'){
					resultado[0]='';
					resultado[2]='selected';
				}
				break;
			}
		}
	}
	return resultado;
};

	var visualizarDatosEducativos=function(numPostulante,codCat,codPuesto,revisionBD){
	
    	// 1. Limpiamos la tabla
    	var tbl = $('#tblDataAcademica').DataTable();
    	tbl.clear().draw();
    	
    	setRevisionSeccion(revisionBD,"revFormacion","selRevFormacionSeccion");
    	
    	var codPostulante = codCat+"_"+codPuesto+"_"+numPostulante;
        var URL = CONTEXT_APP+"/revision/listarDatosEducativos?codCat="+codCat+"&codPuesto="+codPuesto + "&numPostulante="+ numPostulante;                   
    		$.ajax(
    				{
    					async: false, 
    					type: "POST",
    					url: URL,
    					dataType: 'json', 
    					contentType: "application/json; charset=utf-8"})
    		.done(function(resultado){
    			
    			if(resultado.length>0){
    				for(var i=0;i<resultado.length;i++){
    	        		var p = resultado[i];	        		
		        		var	linkDocumento = '&nbsp;';
		            	var linkVerHis = "&nbsp;";
		       
		            	if(p.numArcPostula!=null){
		            		linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + p.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
			            	linkVerHis = "<a href='javascript:visualizarHistorico(\""+p.numArcPostula+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;Ver Historico</a>";	
		            	}
    	            	
    	            	var validadoPorSunedu = false;
    	            	//si el tipo de estudio es universitario y el nivel es bachiller o titulado
    	            	if(p.codTipoEstudio=='3' && (p.codNivelEducativ=='3' || p.codNivelEducativ=='4')){
    	            		validadoPorSunedu = true;
    	            	}
    	            	
    	            	var linkApt = "&nbsp;";
    	            	var codSel = codPostulante + "_" + p.numCorrel;//selRevForm_9967_001_5_1000;
    	            	
    	            	var resRevision = getRevisionDocumento(revisionBD,"revFormacion",p.numCorrel);
    	            	
    	            	if("1"==$("#indVisualizaFormacion").val() && !validadoPorSunedu){
    	            		linkApt = "<select id='selRevForm_"+codSel+"'><option value='0' "+resRevision[0]+">[--Seleccione--]</option><option value='1' "+resRevision[1]+">VALIDO</option><option  value='2' "+resRevision[2]+">NO VALIDO</option></select>";	
    	            	}
    	            	
    	        		tbl.row.add(
    							[								
    								(p.numCorrel),//0
    								(p.numArcPostula==null?0:p.numArcPostula),//1
    								p.desTipoEstudio, //2
    								(p.desNivel==null?'':p.desNivel),//3								
    								(p.codNivelEducativ==null?'':p.codNivelEducativ),//4
    								(p.desEspecialidad==null?'':p.desEspecialidad),//5
    								(p.desCentroEstudio==null?'':p.desCentroEstudio),//6
    								linkDocumento,//7
    								linkApt,//8
    								linkVerHis,//9
    								(p.codCat==null?'':p.codCat),//10
									(p.codPuesto==null?'':p.codPuesto)//11
    							 ]).draw(true);
    	        	}				
    									    				
    			}else{		    				
    				//alertar("Sin Datos Academicos");		
    			}		
    		}).fail(function(jqXHR, textStatus, errorThrown){
    			alertar("Sin postulantes.");
    		});
    		
    		

	};

	var visualizarDatosEspecializacion=function(numPostulante,codCat,codPuesto,revisionBD){		
    
		var tbl = $('#tblDataEstudiosEspecializacion').DataTable();
		tbl.clear().draw();			
		setRevisionSeccion(revisionBD,"revEstudios","selRevEstudiosSeccion");
		
		var codPostulante = codCat+"_"+codPuesto+"_"+numPostulante;
	    var URL = CONTEXT_APP+"/revision/listarEstudiosEspecializacion?codCat="+codCat+"&codPuesto="+codPuesto + "&numPostulante="+ numPostulante + "&indCertificacion=0";              	   
		$.ajax({async: false, 
				type: "POST",
				url: URL,
				dataType: 'json', 
				contentType: "application/json; charset=utf-8"})
			.done(function(resultado){
				
				
				
				if(resultado.length>0){
					for(var i=0;i<resultado.length;i++){
		        		var p = resultado[i];	     
		        		
		        		var	linkDocumento = '&nbsp;';
		            	var linkVerHis = "&nbsp;";
		       
		            	if(p.numArcPostula!=null){
		            		linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + p.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
			            	linkVerHis = "<a href='javascript:visualizarHistorico(\""+p.numArcPostula+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;Ver Historico</a>";	
		            	}
		            	
		            	var resRevision = getRevisionDocumento(revisionBD,"revEstudios",p.numCorrel);
		            	
		            	var linkApt = "&nbsp;";
    	            	var codSel = codPostulante + "_" + p.numCorrel;//selRevForm_9967_001_5_1000;
    	            	if("1"==$("#indVisualizaEstudios").val()){
    	            		linkApt = "<select id='selRevEstudios_"+codSel+"'><option value='0' "+resRevision[0]+">[--Seleccione--]</option><option value='1' "+resRevision[1]+">VALIDO</option><option  value='2' "+resRevision[2]+">NO VALIDO</option></select>";
    	            	}
		            	
		        		tbl.row.add(
								    [	
								     p.numCorrel,//0
								     (p.numArcPostula==null?0:p.numArcPostula),//1
									 (p.nomEspecialidad==null?'':p.nomEspecialidad), //2
									 (p.desCentroEstudio==null?'':p.desCentroEstudio),//3
									 (p.fecInicio==null?'':p.fecInicio),//4
									 (p.fecFin==null?'':p.fecFin),//5
									 (p.fecCertificado==null?'':p.fecCertificado),//6
									 (p.cntHoraLectiva==null?'':p.cntHoraLectiva),//7									 
									 linkDocumento,//8
									 linkApt,//9
									 linkVerHis,	//10
									 (p.codCat==null?'':p.codCat),//11
									 (p.codPuesto==null?'':p.codPuesto)//12
								 ]).draw(true);		        		
		        	}				
    
				}else{							
				}		
			}).fail(function(jqXHR, textStatus, errorThrown){
			});
	};
	
	var setRevisionSeccion = function(revisionBD,idSelector,idComponente){
		if(revisionBD!=null && revisionBD[idSelector]!=null){
			var codResultado = revisionBD[idSelector].codResultado;
			$("#"+idComponente).val(codResultado);
		}
	};

	var visualizarDatosCertificacion=function(numPostulante,codCat,codPuesto,revisionBD){		
		
		var tbl = $('#tblDataCertificacion').DataTable();
		tbl.clear().draw();
		setRevisionSeccion(revisionBD,"revCertificaciones","selRevCertificacionesSeccion");
		
		var codPostulante = codCat+"_"+codPuesto+"_"+numPostulante;
	    var URL = CONTEXT_APP+"/revision/listarEstudiosEspecializacion?codCat="+codCat+"&codPuesto="+codPuesto + "&numPostulante="+ numPostulante+ "&indCertificacion=1";              

		$.ajax({
				async: false, 
				type: "POST",
				url: URL,
				dataType: 'json', 
				contentType: "application/json; charset=utf-8"})
			.done(function(resultado){
				
				if(resultado.length>0){
					for(var i=0;i<resultado.length;i++){
		        		var p = resultado[i];	        		
		        		
		        		var	linkDocumento = '&nbsp;';
		            	var linkVerHis = "&nbsp;";
		       
		            	if(p.numArcPostula!=null){
		            		linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + p.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
			            	linkVerHis = "<a href='javascript:visualizarHistorico(\""+p.numArcPostula+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;Ver Historico</a>";	
		            	}		            	
		            	
		            	var resRevision = getRevisionDocumento(revisionBD,"revCertificaciones",p.numCorrel);
		            	
		            	var linkApt = "&nbsp;";
    	            	var codSel = codPostulante + "_" + p.numCorrel;//selRevForm_9967_001_5_1000;
    	            	if("1"==$("#indVisualizaCertificaciones").val()){
    	            		linkApt = "<select id='selRevCertifica_"+codSel+"'><option value='0' "+resRevision[0]+">[--Seleccione--]</option><option value='1' "+resRevision[1]+">VALIDO</option><option  value='2' "+resRevision[2]+">NO VALIDO</option></select>";
    	            	}
		            	
		        		tbl.row.add(
								[	
									p.numCorrel,//0
									(p.numArcPostula==null?0:p.numArcPostula),//1
									(p.nomEspecialidad==null?'':p.nomEspecialidad),//2
									(p.desCentroEstudio==null?'':p.desCentroEstudio),//3
									(p.fecInicio==null?'':p.fecInicio),//4
									(p.fecFin==null?'':p.fecFin),//5
									(p.fecCertificado==null?'':p.fecCertificado),//6
									(p.cntHoraLectiva==null?'':p.cntHoraLectiva),//7
									linkDocumento,//8
									linkApt,		//9							
									linkVerHis,//10
									(p.codCat==null?'':p.codCat),//11
									(p.codPuesto==null?'':p.codPuesto)//12
								 ]).draw(true);		        				        				        		
		        	}				
					// $.unblockUI();
				}else{		
					// $.unblockUI();
					//alertar("Sin Datos Certificacion");		
				}		
			}).fail(function(jqXHR, textStatus, errorThrown){
				//alertar("Sin Datos Certificacion.");
			});
	
    	
		
	};

	
	var visualizarDatosConocimientosInformaticos=function(numPostulante,codCat,codPuesto,revisionBD){	
		// 1. Limpiamos la tabla
		var tbl = $('#tblDataConoInformatico').DataTable();
        tbl.clear().draw();
        
        setRevisionSeccion(revisionBD,"revConocimientos","selRevConocimientosSeccion");
        	
	    var URL = CONTEXT_APP+"/revision/listarConocimiento?codCat="+codCat+"&codPuesto="+codPuesto + "&numPostulante="+ numPostulante;	   
			$.ajax(
					{
						async: false, 
						type: "POST",
						url: URL,
						dataType: 'json', 
						contentType: "application/json; charset=utf-8"})
			.done(function(resultado){
				if(resultado.length>0){
					for(var i=0;i<resultado.length;i++){
		        		var p = resultado[i];	        				        		        		
		        		var tipoConocimiento = '-';        		
		        		var desNivel = '-';
        		
		        		if(p.codTipcono=='2') tipoConocimiento = "INFORMATICO";
		        		if(p.codTipcono=='3') tipoConocimiento = "IDIOMAS";        		
            		
		        		if(p.codNivel=='A') desNivel = "AVANZADO";
		        		else if(p.codNivel=='B') desNivel = "BÁSICO";
		        		else if(p.codNivel=='I') desNivel = "INTERMEDIO";
		        		
		        		tbl.row.add( 
		        				[				        				 	  		        				 	  
		        					  p.numCorrel,//0
		        					  0,//1
		        		              tipoConocimiento,//2		        		              
		        		              (p.nomConcomiento==null?'':p.nomConcomiento),//3
		        		              desNivel,//4
		        		              (p.codCat==null?'':p.codCat),//5
									  (p.codPuesto==null?'':p.codPuesto)//6
		        		              ]).draw( true );				        			        	
					}
            	
				}else{							
					//alertar("Sin Datos de Conocimientos");		
        }
			}).fail(function(jqXHR, textStatus, errorThrown){
				//alertar("Sin Datos de Conocimientos.");
			});				
	};

	var visualizarDatosExperienciaLaboral=function(numPostulante,codCat,codPuesto,revisionBD){
	
		// 1. Limpiamos la tabla
		var tbl = $('#tblDataExperienciaLaboral').DataTable();
		tbl.clear().draw();
		setRevisionSeccion(revisionBD,"revExperiencia","selRevExperienciaSeccion");
		
		var codPostulante = codCat+"_"+codPuesto+"_"+numPostulante;

	    var URL = CONTEXT_APP+"/revision/listarExperienciaLaboral?codCat="+codCat+"&codPuesto="+codPuesto + "&numPostulante="+ numPostulante;              
	
			$.ajax(
					{
						async: false, 
						type: "POST",
						url: URL,
						dataType: 'json', 
						contentType: "application/json; charset=utf-8"})
			.done(function(resultado){
				if(resultado.length>0){
					for(var i=0;i<resultado.length;i++){
		        		var p = resultado[i];	        		
		        		// var linkDocumento = '';
		            	// if(p.numArcPostula!=null)
		            	var	linkDocumento = '&nbsp;';
		            	var linkVerHis = "&nbsp;";
		       
		            	if(p.numArcPostula!=null){
		            		linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + p.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
			            	linkVerHis = "<a href='javascript:visualizarHistorico(\""+p.numArcPostula+"\");' aria-label='escogerOpcion' data-toggle='tooltip' title='Ver'>&nbsp;<i class='ace-icon fa fa-edit align-middle'></i>&nbsp;Ver Historico</a>";	
		            	}
		            	
		            	var resRevision = getRevisionDocumento(revisionBD,"revExperiencia",p.numCorrel);
		            	
		            	var linkApt = "&nbsp;";
    	            	var codSel = codPostulante + "_" + p.numCorrel;//selRevForm_9967_001_5_1000;
    	            	if("1"==$("#indVisualizaExperiencia").val()){
    	            		linkApt = "<select id='selRevExperiencia_"+codSel+"'><option value='0' "+resRevision[0]+">[--Seleccione--]</option><option value='1' "+resRevision[1]+">VALIDO</option><option  value='2' "+resRevision[2]+">NO VALIDO</option></select>";
    	            	}
		            	
		            	var desTipoEntidad = '';
		        		if(p.codTipoentidad=='1') desTipoEntidad='PUBLICO';
		        		else if(p.codTipoentidad=='2') desTipoEntidad='PRIVADO';
		        		
		        		var fechaFin = "";
		        		if(p.fecFin!='01/01/0001')	
		        			fechaFin = p.fecFin;
		            	
		        		tbl.row.add(
								[	
									(p.numCorrel),//0
									(p.numArcPostula==null?0:p.numArcPostula),//1
									desTipoEntidad,//2
									p.desEntidad,//3
									p.desArea,//4
									p.desCargo,	//5							
									p.fecInicio,//6
									fechaFin,//7
									linkDocumento,//8
									linkApt,//9
									linkVerHis,//10
									(p.codCat==null?'':p.codCat),//11
									(p.codPuesto==null?'':p.codPuesto)//12
								 ]).draw(true);
		        	}				
				}else{							
					//alertar("Sin Datos De Experiencia");		
				}		
			}).fail(function(jqXHR, textStatus, errorThrown){
				//alertar("Sin Datos De Experiencia.");
			});			
};



var visualizarHistorico = function(numArcPostula){
	
	var tbl = $('#tblDatosReporteHistorico').DataTable();
	tbl.clear().draw();	
	
	var URL = CONTEXT_APP+"/revision/listarReporteHistorico?numArcPostula="+numArcPostula;	   
	$.ajax(
			{
				async: false, 
				type: "POST",
				url: URL,
				dataType: 'json', 
				contentType: "application/json; charset=utf-8"})
	.done(function(resultado){
		if(resultado.length>0){
			for(var i=0;i<resultado.length;i++){    
				var p = resultado[i];	
        		tbl.row.add([(p.desProceso==null?'':p.desProceso),
							 (p.nomPersona==null?'':p.nomPersona),
							 (p.resultado==null?'':p.resultado),
							 (p.fechaResultado==null?'':p.fechaResultado)]).draw( true );				        			        	
			}
			$("#divDatosReporteHistorico").modal('show');
		}else{							
			//alertar("Sin Datos de Conocimientos");	
			mensajeInformativo("El documento a&uacute;n no ha sido revisado.");
		}
	}).fail(function(jqXHR, textStatus, errorThrown){
		//alertar("Sin Datos de Conocimientos.");
	});		

	//fin prac-jean pierre
};

//Codigo practicante Jean Pierre
/*------------------------------ DESCARGAR ----------------------------*/
function onClickDescargarDocumentoSustento(numArcPostula){
	if(numArcPostula==null){
		mostrarMensaje("No se adjuntó ningún archivo.");
	}else{
		$("#numArcPostulaDownload").val(numArcPostula);
		$("#frmArchivoDownload").submit();
	}

}
//fin prac-jean pierre

var replaceAll = function(str, find, replace) {
    return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
};

var escapeRegExp = function(str) {
    return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
};

var formToObject = function(formArray) {
	var returnArray = {};
	for (var i = 0; i < formArray.length; i++){
		var cadena = formArray[i]['value'];
		if(cadena!=null)returnArray[formArray[i]['name']] = cadena.toUpperCase();
		else  returnArray[formArray[i]['name']] = formArray[i]['value'];
	}
	return returnArray;
};


var alertar = function(mensaje,callbackFunction){
	bootbox.dialog({title:"Error",message: mensaje,
		buttons: {danger: {label: "Aceptar",className: "btn-danger",callback:callbackFunction}}});
};


var mensajeInformativo = function(mensaje,callbackFunction){
	bootbox.dialog({title:"Mensaje del Sistema",message: mensaje,
		buttons: {danger: {label: "Aceptar",className: "btn-success",callback:callbackFunction}}});
};



