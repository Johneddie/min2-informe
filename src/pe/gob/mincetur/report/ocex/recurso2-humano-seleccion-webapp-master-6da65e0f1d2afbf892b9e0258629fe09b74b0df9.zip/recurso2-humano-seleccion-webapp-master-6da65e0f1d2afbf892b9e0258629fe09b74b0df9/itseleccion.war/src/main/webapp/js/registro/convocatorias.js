   /*Declarar variables*/
    //en js no  se deben de utilizar variables globales
	//var tblListaConvocatorias=null;
	//var btnAceptar=null;
	
	/*jQuery.browser = {};
	(function () {
	    jQuery.browser.msie = false;
	    jQuery.browser.version = 0;
	    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
	        jQuery.browser.msie = true;
	        jQuery.browser.version = RegExp.$1;
	    }
	})();*/
	
    /*function iniVariables(){
     	tblListaConvocatorias = $('#tblListaConvocatorias');
     	btnAceptar = $('#btnAceptar');
    }*/
    
    
    function iniComponentes(){
    	
    	$('#btnAceptar').bind('click', function(event){
	    	if(validarPreguntas()){
	    		aceptarDeclaracion();
	    	}
	    });
    	
    	//sobre discapacidad
    	$("input[name='pregunta15']").each(function() {
    		$(this).attr("disabled", true);
         });
    	
	    $("input[name='pregunta14']").change(function(){
	    	if($("input[name='pregunta14']:checked").val() == '01'){
	        	$("input[name='pregunta15']").each(function() {
	        		//$(this).prop( "checked", false);
	        		$(this).removeAttr("disabled");
	        		
	             });
	    	}else{
	        	$("input[name='pregunta15']").each(function() {
	        		$(this).prop( "checked", false);
	        		$(this).attr("disabled", true);
	             });
	    	}
	    });
	    
	    //sobre modalidades formativas
    	$("input[name='pregunta19']").each(function() {
    		$(this).attr("disabled", true);
         });
	    
	    $("input[name='pregunta18']").change(function(){
	    	if($("input[name='pregunta18']:checked").val() == '01'){
	        	$("input[name='pregunta19']").each(function() {
	        		//$(this).prop( "checked", false);
	        		$(this).removeAttr("disabled");
	             });
	    	}else{
	        	$("input[name='pregunta19']").each(function() {
	        		$(this).prop( "checked", false);
	        		$(this).attr("disabled", true);
	             });
	    	}
	    });
    	
    }
    
    function renderizarTablaConvocatorias(){
    	
		$.ajax({
            url: "/ol-at-itseleccion/bandeja/cargarListaConvocatorias",
            type: "GET",
           // label:'',
            async : false,
			cache : false,
            dataType: "json",
            data : {numPostulante:$("#numPostulante").val()}
        }).done(function(paramJson) {
        	/*if(paramJson.length==0){
        		mostrarAlerta("danger", "No existe informaci&oacute;n de procesos de Notificaci&oacute;n de acuerdo al criterio seleccionado");
        	}*/
        	try {
        		$('#tblListaConvocatorias').DataTable().destroy();
        	}catch(err) {
        	}
        	
        	$('#tblListaConvocatorias').DataTable({
            		destroy: true,
            		data: paramJson,
            	    columns: [
            	        { data: 'desProceso'    	, render : function(data, type, row){return '<td>'+row.desProceso+'</td>'; }},
            	        { data: 'desInscripcion'	, "class":'text-center', render : function(data, type, row){return '<td>'+row.desInscripcion+'</td>'; }},
           	        	{ data: 'codCat',  "class":'text-center',
			              render : function(data, type, row){
			             	return '<a href="javascript:validarFichaPostular(' + row.codCat + ',\'' + row.codPuesto + '\',\'' + row.desProceso + '\')" ><i class="fa fa-pencil-square-o fa-2" aria-hidden="true"></i>' + '' + '</a>';
    	                  }
			            }
            	    ],
            	    
            	    language: {
	            	    lengthMenu: '',
	            	    loadingRecords: "Por favor espere, cargando lista de convocatorias <img heigh='11' width='50' src='resources/images/loading-dots.gif'/>",
	            	    url: '/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json'
            	    },
            	    searching: false,
            	    //scrollX: true, //not work ie8
            	    lengthChange: false 
            	});
        	
			}).fail(function( jqXHR, textStatus, errorThrown ) {
				console.log('entro error, '+errorThrown);
			alert( "error"+errorThrown +", "+jqXHR+","+textStatus);
			});
    	
    }
    
    
    function validarFichaPostular(codCat, codPuesto, desProceso){
    	$.ajax({
            url: "/ol-at-itseleccion/bandeja/validarFichaPostular?ts="+(new Date().getTime()),
            type: "GET",
            async : false,
    		cache : false,
            dataType: "json",
            data : {codCat: codCat,numPostulante:$("#numPostulante").val()}
    	}).done(function(respuesta){
				error = respuesta.error;
				if(!error){
					errorValida = respuesta.errorValida;
					if(!errorValida){
						mostrarDeclaracionJurada(codCat, codPuesto, desProceso, respuesta.conocimientoExigido);
					}else{
						var lstErrores = respuesta.lstErrores;
						var codError = respuesta.codError;
						if(codError=='004'){
							mostrarMensaje(lstErrores[lstErrores.length-1]);
						}else{
							
							var strErrores = "<ul>";
							for (var i = 0; i < lstErrores.length; i++){
								strErrores += "<li>" + lstErrores[i] + "</li>";
							}
							strErrores += "</ul>";
							mostrarMensaje("Debe registrar: <br>" + strErrores);	
						}
						
					}
				}else{//error
					mostrarMensaje(respuesta.mensaje);
				}
		});
    }
    
    
    function mostrarDeclaracionJurada(codCat, codPuesto, desProceso,conocimientoExigido){
    	$("#idCodCat").val(codCat);
    	$("#idCodPuesto").val(codPuesto);
    	$("#modalTitleDeclaracion").text("Declaración Jurada - " + desProceso);
    	limpiarDeclaracion();
    	$("#btnAceptar").prop("disabled",false);
    	$("input[name='pregunta15']").each(function() {
    		$(this).attr("disabled", true);
         });
    	$("input[name='pregunta19']").each(function() {
    		$(this).attr("disabled", true);
         });
    	
    	if(conocimientoExigido!=null && $.trim(conocimientoExigido)!=''){
    		$("#divPregunta20").show();
    		$("#etiqueta20").html($("#desGlosaPreguntaConocimiento").val()+'<br/>'+conocimientoExigido);
    	}else{
    		$("#divPregunta20").hide();
    	}
    	
    	$("#modalDeclaracionJurada").modal('show');	
    }
    
    
    function limpiarDeclaracion(){
    	$("#divFamiliar").hide();
    	$("#nomFamiliar").val("");
    	$("input[name^='pregunta']").each(function() {
    		$(this).prop( "checked", false );
        });
        $("select[name^='pregunta']").each(function() {
         	 $(this).val("00"); //no aplica
     	});
    }
    
	
	
	
	
	function mostrarMensaje(mensaje){
		bootbox.dialog({
			title: "Mensaje",
			message: mensaje,
			buttons: {danger: {label: "Aceptar",className: "btn-danger"}}});
	}
	
	function mostrarMensajeExito(mensaje){
		bootbox.dialog({
			title: "Mensaje",
			message: mensaje,
			buttons: {danger: {label: "Aceptar",className: "btn-primary"}}});
	}
	
    function aceptarDeclaracion(){

    	//Validamos si ha seleccionado al familiar.
    	if($("#divFamiliar").is(":visible") && $.trim($("#nomFamiliar").val())==''){
    		$("#nomFamiliar").focus();
    		setTimeout(function(){
    			bootbox.alert("Debe ingresar nombres y apellidos del familiar.");
    		}, 100);
    		return;
    	}

    	//nos bajamos la pantalla de la postulación.
    	$("#modalDeclaracionJurada").modal('hide');
    	$.blockUI({ message: "<h1>Inscribiendo su postulaci&oacute;n...</h1>" });
    	setTimeout(function(){
    		
    		var seleccionados="";
        	var codCat = $("#idCodCat").val();
        	var codPuesto = $("#idCodPuesto").val();
        	
        	//obtener respuestas
            $("input[name^='pregunta']").each(function() {
               if ($(this).is(":checked")) {
            	   seleccionados+=($(this).attr("codigo") + '-' + $(this).val())+",";
               }
            });
            
            $("select[name^='pregunta']").each(function() {
            	seleccionados+=($(this).attr("codigo") + '-' + $(this).val())+",";
        	});
            seleccionados = seleccionados.substr(0,seleccionados.length - 1);
            
            
            
            //registrar datos
            $("#btnAceptar").prop("disabled",true);
             
        	$.ajax({
                url: "/ol-at-itseleccion/bandeja/registrarDeclaracion",
                type: "GET",
                async : false,
        		cache : false,
                dataType: "json",
                data : {
                	respuestas : seleccionados,
                	codCat : codCat,
                	codPuesto : codPuesto,
                	nomFamiliar : $("#divFamiliar:visible")?$("#nomFamiliar").val():'',
                	numPostulante:$("#numPostulante").val()
                }
        	}).done(function(respuesta){
    				//console.log(respuesta);
        		    $.unblockUI();
    				error = respuesta.error;
    				if(!error){
    					$("#modalDeclaracionJurada").modal('hide');	
    					mostrarMensajeExito("Su inscripción al proceso de selección se ha registrado correctamente.");
    					renderizarTablaConvocatorias();//actualizar grilla
    					renderizarTablaPostulaciones();//actualizar grilla de postulaciones
    				}else{//error
    					mostrarMensaje(respuesta.mensaje);
    					$("#btnAceptar").prop("disabled",false);
    				}
    		}).fail(function(jqXHR, textStatus, errorThrown){
            		$.unblockUI();
            		mostrarMensaje("Ocurrió un error al inscribir su postulación,"+textStatus);
            });
    		
    		
		}, 250);
    	
	}
    
    function visualizarFamiliar(comp){
    	if($(comp).val()=='01') {
    		$("#divFamiliar").show();
    		$("#nomFamiliar").focus();
    	}else{
    		$("#divFamiliar").hide();
    	}	
    };
	
