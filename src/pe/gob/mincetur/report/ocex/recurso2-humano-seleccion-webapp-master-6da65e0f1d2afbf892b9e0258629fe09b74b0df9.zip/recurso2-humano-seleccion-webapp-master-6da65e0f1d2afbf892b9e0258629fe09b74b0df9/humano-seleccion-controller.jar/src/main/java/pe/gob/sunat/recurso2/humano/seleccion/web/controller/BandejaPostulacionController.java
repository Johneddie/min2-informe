package pe.gob.sunat.recurso2.humano.seleccion.web.controller;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.DdjjPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Postulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ProcesoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.PuestoProceso;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Usuario;
import pe.gob.sunat.recurso2.humano.seleccion.service.BandejaPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.RegistroPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;
import pe.gob.sunat.recurso2.humano.seleccion.util.Internet;

@Internet
@Controller
@RequestMapping(value="/bandeja")
public class BandejaPostulacionController {
	
	public final Log log = LogFactory.getLog(getClass());

	@Autowired
	private BandejaPostulacionService bandejaPostulacionService;
	
	@Autowired
	private RegistroPostulacionService registroPostulacionService;
	
	@RequestMapping("/inicioBandejaConvocatorias")
	public ModelAndView inicioBandejaConvocatorias() {
		if(log.isDebugEnabled()) log.debug("method inicioBandejaConvocatorias");

		Map<String,Object> hmBandejaConvocatorias = new HashMap<>();
		
		hmBandejaConvocatorias.putAll(bandejaPostulacionService.listarPreguntasDeclaracionJurada()); //
		hmBandejaConvocatorias.putAll(bandejaPostulacionService.listarRespuestasDeclaracionJurada()); //
		hmBandejaConvocatorias.put("CODIGO_PREG_TIPO_COND_COLEG",Constantes.CODIGO_PREG_TIPO_COND_COLEG);
		hmBandejaConvocatorias.put("CODIGO_PREG_TIPO_TIP_DISCAP",Constantes.CODIGO_PREG_TIPO_TIP_DISCAP);
		hmBandejaConvocatorias.put("CODIGO_PREG_TIPO_MOD_FORM",Constantes.CODIGO_PREG_TIPO_MOD_FORM);
		hmBandejaConvocatorias.put("CODIGO_PREG_DISCAP",Constantes.CODIGO_PREG_DISCAP);
		hmBandejaConvocatorias.put("CODIGO_PREG_MOD_FORM",Constantes.CODIGO_PREG_MOD_FORM);
		return new ModelAndView("bandeja/bandejaConvocatoriasForm", hmBandejaConvocatorias);
	}
	
	
	@RequestMapping(value = "/cargarListaConvocatorias", method = { RequestMethod.GET }, produces = "application/json")
	public @ResponseBody List<PuestoProceso> cargarListaConvocatorias(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method cargarListaConvocatorias");
		
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		ArrayList<PuestoProceso> lstProcesos = new ArrayList<>();
		try{
			lstProcesos = (ArrayList<PuestoProceso>)bandejaPostulacionService.listarPuestosProcesoActivos(numPostulante);
			
		}catch(Exception exception){
			log.info("Excepci�n",exception);
		}
		return lstProcesos;
	}
	
	
	@RequestMapping(value="/registrarDeclaracion", method = {RequestMethod.GET}, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, Object> registrarDeclaracion(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method grabarDeclaracion");
		
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		
		Map<String, Object> resultado = new HashMap<>();
		try{
			List<DdjjPostulacion> lstRespuestas = new ArrayList<>();
			String[] arrRespuestas = request.getParameter("respuestas").split(",");
			Short codCat = Short.parseShort(request.getParameter("codCat"));
			String codPuesto = request.getParameter("codPuesto");
			String nomFamiliar = request.getParameter("nomFamiliar");
			
			resultado = bandejaPostulacionService.validarVencimientoPostulaci�n(codCat);
			if(!(Boolean)resultado.get("error")){
			
				for(String strRespuesta:arrRespuestas){
					DdjjPostulacion rptDeclaracacion = new DdjjPostulacion();
					rptDeclaracacion.setCodCat(codCat);
					rptDeclaracacion.setCodPuesto(codPuesto);
					rptDeclaracacion.setNumPostulante(numPostulante);
					String[] lstRespuesta = strRespuesta.split("-");
					rptDeclaracacion.setCodPregunta(lstRespuesta[0]);
					rptDeclaracacion.setCodRespuesta(lstRespuesta[1]);
					lstRespuestas.add(rptDeclaracacion);
				}
				
				bandejaPostulacionService.registrarDeclaracion(lstRespuestas, codCat, codPuesto, numPostulante,nomFamiliar);
				registroPostulacionService.generarHistorico(numPostulante, codPuesto, codCat);
			}
			
		}catch(Exception e){
			log.error("Ocurri� un error en registrarPostulaciones: " + e.getMessage(), e);
			resultado.put("error", true);
			resultado.put("mensaje", "Ocurri� un error al registrar la declaraci�n jurada.");
		}
		
		return resultado;
	}
	
	@RequestMapping(value="/validarFichaPostular", method = {RequestMethod.GET}, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, Object> validarFichaPostular(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method validarFichaPostular");

		Short codCat = Short.parseShort(request.getParameter("codCat"));
		
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		
		Map<String, Object> resultado = new HashMap<>();
		try{
			resultado = bandejaPostulacionService.validarVencimientoPostulaci�n(codCat);
			if(!(Boolean)resultado.get("error")){
				resultado = bandejaPostulacionService.validarDeclaracion(numPostulante,codCat);
			}
			
		}catch(Exception e){
			log.error("Ocurri� un error en validarFichaPostular: " + e.getMessage(), e);
			resultado.put("error", true);
			resultado.put("mensaje", "Ocurri� un error al validar la ficha de postulaci�n.");
		}
		
		return resultado;
	}
	
	@RequestMapping(value="/validarExistenciaFormato", method = {RequestMethod.GET}, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Map<String, Object> validarExistenciaFormato(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method validarExistenciaFormato");
		Usuario usuario = (Usuario)request.getSession().getAttribute("usuario");		
		Short codCat = Short.parseShort(request.getParameter("codCat"));
		String codPuesto = request.getParameter("codPuesto");	
		
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		
		Map<String, Object> resultado = new HashMap<>();
		try{			
            
			if(usuario == null){
                resultado.put("error", true);
                resultado.put("mensaje", "ERROR_SESION");
            }else{			
				resultado = bandejaPostulacionService.validarExistenciaFormato(codCat, codPuesto, numPostulante);
            }
            
		}catch(Exception e){
			log.error("Ocurri� un error en validarFichaPostular: " + e.getMessage(), e);
			resultado.put("error", true);
			resultado.put("mensaje", "Ocurri� un error al validar la ficha de postulaci�n.");
		}
		
		return resultado;
	}
	
	
	@RequestMapping("/inicioBandejaPostulaciones")
	public ModelAndView inicioBandejaPostulaciones() {
		if(log.isDebugEnabled()) log.debug("method inicioBandejaPostulaciones");
		Map<String,Object> hmBandejaConvocatorias = new HashMap<>();
		return new ModelAndView("bandeja/bandejaPostulacionesForm", hmBandejaConvocatorias);
	}
	
	@RequestMapping(value = "/cargarListaPostulaciones", method = { RequestMethod.GET }, produces = "application/json")
	public @ResponseBody List<PuestoProceso> cargarListaPostulaciones(HttpServletRequest request, HttpServletResponse response){
		if(log.isDebugEnabled()) log.debug("method cargarListaPostulaciones");
		Integer numPostulante = Integer.parseInt(request.getParameter("numPostulante"));
		ArrayList<PuestoProceso> lstProcesos = new ArrayList<>();
		try{
			lstProcesos = (ArrayList<PuestoProceso>)bandejaPostulacionService.listarPostulaciones(numPostulante);
			
		}catch(Exception exception){
			log.info("Excepci�n",exception);
		}
		return lstProcesos;
	}
	
	/**
	 * Visualiza la p�gina de registro del postulante
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping(value="/exportarFormatoPdf", method = {RequestMethod.POST})
	public void exportarFormatoPdf(HttpServletRequest request,	HttpServletResponse response) throws Exception {
		if(log.isDebugEnabled()) log.debug("method generarFormatoPdf");
		Usuario usuario = (Usuario)request.getSession().getAttribute("usuario");
		Short codCat = Short.parseShort(request.getParameter("codCat"));
		String codPuesto= request.getParameter("codPuesto");
		Date nowDate = new Date();
		
		
		Postulacion postulacion = bandejaPostulacionService.getPostulacion(codCat, codPuesto, usuario.getNumPostulante());
		if(postulacion.getNumArcFup()!=null) {
			//Sacamos el PDF directamente desde la BD
			ArchivoPostulacion ap = registroPostulacionService.obtenerArchivoPostulacion(postulacion.getNumArcFup());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + ap.getNomArchivo() + "\"");
			response.setContentType("application/pdf");
			if(ap.getArcPostula() != null)
				response.setContentLength(ap.getArcPostula().length);

			OutputStream out = response.getOutputStream();
			out.write(ap.getArcPostula());
			out.close();
			out.flush();
			
		}else {
			//Generamos el pdf mediante el tecnologia-generador, m�todo anterior(DEPRECADO)
			//cabecera
			Map<String,Object> parametros;
			ProcesoPostulacion proceso = bandejaPostulacionService.obtenerProcesoPostulacion(codCat);
			boolean isHistorico = nowDate.after(proceso.getFfinPostu());
			parametros = bandejaPostulacionService.obtenerCabeceraFormato(usuario, codCat, codPuesto, isHistorico);
			
			//detalle
			ArrayList<HashMap<String,Object>> lstDetalle = new ArrayList<>();
			lstDetalle.add(new HashMap<String,Object>());
			
			generarPDF(Constantes.ARCHIVO_PDF_FORMATO_POSTULACION, parametros, lstDetalle, Constantes.TEMPLATE_FORMATO_POSTULACION, request, response);
		}
		
		
	}
	
	private boolean generarPDF(String fileName, Map<String, Object> cabecera, List<?> documentosComprasList, Integer plantilla, 
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		if(log.isDebugEnabled()) log.debug("method generarPDF");
		boolean resultado = false;
		try {
			byte[] pdfBytes = bandejaPostulacionService.obtenerReporteFromPlantilla(plantilla, cabecera, documentosComprasList);
			
			String nombreArchivo = fileName + cabecera.get("codCat") +"_"+ cabecera.get("numPostulante") + ".pdf";
			response.setHeader("Content-Disposition", "attachment; filename=\"" + nombreArchivo + "\"");
			response.setContentType("application/pdf");

			OutputStream out = response.getOutputStream();
			out.write(pdfBytes);
			out.close();
			out.flush();
			resultado = true;
		} catch (Exception e) {
			log.error("Error en generarPDFProveedor: " + e.getMessage(), e);
			throw new Exception (e);
		}
		return resultado;
	}
	
	
	@RequestMapping("/eliminarPostulacion")
	public @ResponseBody Map<String, Object> eliminarPostulacion(HttpServletRequest request, HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method inicioEliminarPostulacion");
		Short codCat = Short.parseShort(request.getParameter("codCat"));
		String codPuesto = request.getParameter("codPuesto");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		
		Map<String, Object> resultado = new HashMap<>();
		try{
			registroPostulacionService.eliminarPostulacion(numPostulante, codPuesto, codCat);			
			
		}catch(Exception e){
			log.error("Ocurri� un error al eliminar la postulaci�n: " + e.getMessage(), e);
			resultado.put("error", true);
			resultado.put("mensaje", "Ocurri� un error al eliminar la postulaci�n.");
		}
		
		return resultado;
	}
	

}


