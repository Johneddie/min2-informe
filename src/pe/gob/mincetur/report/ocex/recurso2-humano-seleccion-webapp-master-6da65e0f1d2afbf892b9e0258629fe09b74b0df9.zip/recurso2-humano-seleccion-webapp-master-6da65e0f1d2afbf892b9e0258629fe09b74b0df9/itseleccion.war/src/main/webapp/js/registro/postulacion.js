/**
 * Aquí las funciones javascript de postulacion
 * 
 */
var inicializarDatosRegistro = function(){
	
	inicializarInformacionPersonal();
	inicializarDomicilio();
	inicializarFormacionAcademica();	
	inicializarEstudiosEspecializacion();
	inicializarCertificacion();
	inicializarConocimientosInformaticos();
	inicializarExperienciaLaboral();
	
	//Inicio de la validacion
	validarDatosRegistro();
	
	//temporizador de sesion:
	var t = setInterval(function(){
		//Verificamos la sesion cada minutos
		var URL_CHECK_SESSION = CONTEXT_APP+"/acceso/checkSesion?TOKPOSTULACION="+$("#TOKPOSTULACION").val();
		$.getJSON(URL_CHECK_SESSION,function( response ) {
			if(response.esSesionValida==0){
				clearInterval(t);
				terminarSesion();
			}
		});
		
	}, 5*1000);
};

var ping = function(){
	var URL_PING = CONTEXT_APP+"/registro/ping";
	$.getJSON(URL_PING, function( response ) {
		$("#TOKPOSTULACION").val(response.TOKPOSTULACION);
	});
};

var logout = function(){
	location.href=CONTEXT_APP+"/registro/logout";
};


//===============================================================================================
//DATOS DE INFORMACION PERSONAL
//===============================================================================================
var inicializarInformacionPersonal = function(){
	
	//validación del formulario con jquery
	$("#selUbiDepLugarNac").change(function(){
		var codDep = $(this).val();
		alCambiarDepartamentoNac(codDep);
	});
	
	$("#selUbiProvLugarNac").change(function(){
		var codProv = $(this).val();
		alCambiarProvinciaNac(codProv);
	});
	
	
	$("#btnMensajeInicialAbre").click(function(){
		$("#divDatosMensajeInicialPopup").modal("show");
	});
	
	$("#btnMensajeInicialCierra").click(function(){
		$("#divDatosMensajeInicialPopup").modal("hide");
	});
	
	//Aquí seteamos el código del departamento si ya existe la ficha en bd
	if(codUbigeonac!=""){
		var codDep = codUbigeonac.substring(0,2);
		var codProv = codUbigeonac.substring(0,4);
		var codDist = codUbigeonac;
		$('#selUbiDepLugarNac').val(codDep);
		alCambiarDepartamentoNac(codDep,codProv,codDist);
	}
};

var alCambiarDepartamentoNac = function(codDep,codProvSel,codDistSel){
	//Cargamos las provincias
	var URL_PROVINCIAS = CONTEXT_APP+"/registro/departamentos/"+codDep+"/provincias";
	$.getJSON(URL_PROVINCIAS, function( response ) {
		if(validaSesion(response)){
			$('#selUbiProvLugarNac').html("");
			$('#selUbiProvLugarNac').append('<option value="">[--Seleccione--]</option>');
			$('#selUbiDistLugarNac').html("");
			$('#selUbiDistLugarNac').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){
				$('#selUbiProvLugarNac').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));
			});
			if(codProvSel!=null){
				$('#selUbiProvLugarNac').val(codProvSel);
				alCambiarProvinciaNac(codProvSel,codDistSel);
			}	
		}
	});
};

var alCambiarProvinciaNac = function(codProv,codDistSel){
	//Cargamos los distritos
	var URL_PROVINCIAS = CONTEXT_APP+"/registro/provincias/"+codProv+"/distritos";
	$.getJSON(URL_PROVINCIAS, function( response ) {
		if(validaSesion(response)){
			$('#selUbiDistLugarNac').html("");
			$('#selUbiDistLugarNac').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){
				$('#selUbiDistLugarNac').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));
			});
			if(codDistSel!=null){
				$('#selUbiDistLugarNac').val(codDistSel);
			}	
		}
		
	});
};


//===============================================================================================
// DATOS DE DOMICILIO
//===============================================================================================
var inicializarDomicilio = function(){
	//validación del formulario con jquery
	$("#selUbiDepLugarDom").change(function(){
		//Cargamos las provincias
		var codDep = $(this).val();
		alCambiarDepartamentoDom(codDep);
	});
	
	$("#selUbiProvLugarDom").change(function(){
		//Cargamos los distritos
		var codProv = $(this).val();
		alCambiarProvinciaDom(codProv);
	});
	
	//Aquí seteamos el código del departamento si ya existe la ficha en bd
	if(codUbigeodom!=""){
		var codDep = codUbigeodom.substring(0,2);
		var codProv = codUbigeodom.substring(0,4);
		var codDist = codUbigeodom;
		$('#selUbiDepLugarDom').val(codDep);
		alCambiarDepartamentoDom(codDep,codProv,codDist);
	}
	
};

var alCambiarDepartamentoDom = function(codDep,codProvSel,codDistSel){
	var URL_PROVINCIAS = CONTEXT_APP+"/registro/departamentos/"+codDep+"/provincias";
	$.getJSON(URL_PROVINCIAS, function( response ) {
		if(validaSesion(response)){
			$('#selUbiProvLugarDom').html("");
			$('#selUbiProvLugarDom').append('<option value="">[--Seleccione--]</option>');
			$('#selUbiDistLugarDom').html("");
			$('#selUbiDistLugarDom').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){
				$('#selUbiProvLugarDom').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));
			});
			if(codProvSel!=null){
				$('#selUbiProvLugarDom').val(codProvSel);
				alCambiarProvinciaDom(codProvSel,codDistSel);
			}	
		}
	});
};

var alCambiarProvinciaDom = function(codProv,codDistSel){
	var URL_PROVINCIAS = CONTEXT_APP+"/registro/provincias/"+codProv+"/distritos";
	$.getJSON(URL_PROVINCIAS, function( response ) {
		if(validaSesion(response)){
			$('#selUbiDistLugarDom').html("");
			$('#selUbiDistLugarDom').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){
				$('#selUbiDistLugarDom').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));
			});
			if(codDistSel!=null){
				$('#selUbiDistLugarDom').val(codDistSel);
			}	
		}
	});
};


//===============================================================================================
//DATOS DE FORMACIÓN ACADÉMICA
//===============================================================================================
var inicializarFormacionAcademica = function(){
	//Funciones relativas a los datos academicos.
	$("#selGradoAcademico").change(function(){
		ping();//reload session
		var codGrado = $(this).val();
		if(codGrado=='002' || codGrado=='003' || codGrado=='004' || codGrado=='031' || codGrado=='032' || 
			codGrado=='037' || codGrado=='038' || codGrado=='039' || codGrado==''){
			$("#divFechaExpedicionGrado").show();
		}else{
			$("#fecGrado").val("");
			$("#divFechaExpedicionGrado").hide();
		}
	});
	
	
	
	$("#selTipoEstudio").change(function(){
		var codTipoEstudio = $(this).val();
		
		if("1"==codTipoEstudio){
			mostrarOcultarTipoSecundaria(false);//ocultamos
		}else{
			mostrarOcultarTipoSecundaria(true);//mostramos
			alCambiarTipoEstudio(codTipoEstudio,null,null,null);//el nivel,la carrera y ciclo no se seleccionan
		}
		
	});
	
	
	$("#selNivelEducativo").change(function(){
		var codNivel = $(this).val();
		if("1"==codNivel){
			//Si es estudiante
			$("#divFechaEgreso").hide();
			$("#lblFechaGrado").html("Fecha del Certificado/Constancia:");
		}else{
			$("#divFechaEgreso").show();
			$("#lblFechaGrado").html("Fecha de Expedici&oacute;n del Grado/T&iacute;tulo:");
		}
		alCambiarNivelEstudio(codNivel,null);//null:ciclo
	});
	
	
	$("#selCentroEstudios").change(function(){
		ping();//reload session
		var codCentroEstudio = $(this).val();
		if(codCentroEstudio=='99996' || codCentroEstudio=='99997' ||
    			codCentroEstudio=='99998' || codCentroEstudio=='99999'){
			$("#divOtroCentroEstudio").show();
		}else{
			$("#divOtroCentroEstudio").hide();
		}
		
	});
	
	$("#selCarrera").change(function(){
		ping();//reload session
		var codEspecialidad = $(this).val();
		if(codEspecialidad=='9995' || codEspecialidad=='9996' || codEspecialidad=='9997' || 
				codEspecialidad=='9998' || codEspecialidad=='9999'){
			$("#divOtraCarrera").show();
		}else{
			$("#divOtraCarrera").hide();
		}
	});
	
	$("#btnAgregarDatosAcademicos").click(function(){
		ping();//reload session
		limpiarFormulario("#formDatosAcademicos");
		$('#formDatosAcademicos').trigger("reset");
		
		$("#selCarrera").val('');
		$("#selCarrera").trigger('change');
		$("#selCentroEstudios").val('');
		$("#selCentroEstudios").trigger('change');
		
		$("#selTipoEstudio").change();
		$("#selEspecialidad").change();
		$("#selNivelEducativo").change();
		$("#numArcPostulaFA").val('');
		$("#numArcPostulaFABD").val('');
		$("#numIdAcadem").val("");
		$("#nomArchivoFA").html('');
		$("#divDatosAcademicosPopup").modal('show');
	});
	
	$("#divDatosAcademicosPopup" ).on('shown.bs.modal', function(){
		$("#selGradoAcademico").focus();
	});
	
	
	$("#btnCerrarPopupDatosAcademicos").click(function(){
		confirmarCancelacion("divDatosAcademicosPopup","formDatosAcademicos");
	});
	
	//Configuracion de la tabla de datos academicos...
    $('#tblDataAcademica').DataTable( {
    	"columnDefs": [{"targets": [8,9,10,11,12,13,14,15,16,17,18], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
	$('#fecEgresoDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        return true;
    });
	
	$('#fecGradoDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        return true;
    });
	
	
	$("#divDatosAcademicosPopup" ).on('shown.bs.modal', function(){
		
	});
	
	recargarGrillaDatosAcademicos();
	recargarCentrosEstudio();
	
};



var mostrarOcultarTipoSecundaria = function(mostrar){
	if(mostrar){
		$("#divNivelEducativo").show();
		$("#divCiclo").show();
		$("#divCarrera").show();
		//$("#divOtraCarrera").show();
		$("#divCentroEstudios").show();
		//$("#divOtroCentroEstudio").show();
		$("#divMeritoObtenido").show();
		$("#divFechaExpedicionGrado").show();	
	}else{
		$("#divNivelEducativo").hide();
		$("#divCiclo").hide();
		$("#divCarrera").hide();
		//$("#divOtraCarrera").hide();
		$("#divCentroEstudios").hide();
		//$("#divOtroCentroEstudio").hide();
		$("#divMeritoObtenido").hide();
		$("#divFechaExpedicionGrado").hide();
	}
	
};


var alCambiarNivelEstudio = function(codNivel,codCicloSel){
	ping();//reload session
	var codTipoEstudio = $("#selTipoEstudio").val();
	$('#selCiclo').html("");
	$('#selCiclo').append('<option value="">[--Seleccione--]</option>');
	$("#divCiclo").hide();
	if(codNivel=='1'){
		$("#divCiclo").show();
		var URL_CICLOS = CONTEXT_APP+"/registro/formacion/ciclos?codTipoEstudio="+codTipoEstudio+"&codNivel="+codNivel;
		$.getJSON(URL_CICLOS, function( response ) {
			$.each(response, function(idx, rec){
				if(codCicloSel!=null){
					var seleccionado = '';
					if(codCicloSel==rec.codParametro){
						seleccionado = "selected='selected'";
					}
					var html = "<option value = '"+rec.codParametro+"' "+seleccionado+" >"+rec.desParametro+"</option>";
					$('#selCiclo').append(html);
				}else{
					$('#selCiclo').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));	
				}
			});
		});			
	}	
};

var alCambiarTipoEstudio = function(codTipoEstudio,codNivelSel, codCarreraSel, codCicloSel){
	ping();//reload session
	$("#divCiclo").hide();
	$('#selNivelEducativo').html("");
	$('#selNivelEducativo').append('<option value="">[--Seleccione--]</option>');
	if(codTipoEstudio!=''){
		recargarNiveles(codTipoEstudio,codNivelSel,codCicloSel);
		recargarCarreras(codTipoEstudio,codCarreraSel);
	}
};


var recargarNiveles = function(codTipoEstudio,codNivelSel,codCicloSel){
	var URL_NIVELES = CONTEXT_APP+"/registro/formacion/niveles?codTipoEstudio="+codTipoEstudio;
	$.getJSON(URL_NIVELES, function( response ) {
		$.each(response, function(idx, rec){
			if(codNivelSel!=null){
				var seleccionado = '';
				if(codNivelSel==rec.codParametro){
					seleccionado = "selected='selected'";
				}
				var html = "<option value = '"+rec.codParametro+"' "+seleccionado+" >"+rec.desParametro+"</option>";
				$('#selNivelEducativo').append(html);

			}else{
				$('#selNivelEducativo').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));	
			}
			
		});
		if(codNivelSel!=null){
			//$("#selNivelEducativo").change();
			alCambiarNivelEstudio(codNivelSel,codCicloSel);
		}
	});
};

//Se recarga cada vez que se cambia el tipo de estudios.
var recargarCarreras = function(codTipoEstudio,codCarreraSel){
	var URL_CARRERAS = CONTEXT_APP+"/registro/formacion/carreras?codTipoEstudio="+codTipoEstudio;
	$.getJSON(URL_CARRERAS, function( response ) {
		if(validaSesion(response)){
			$('#selCarrera').html("");
			$('#selCarrera').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){
				if(codCarreraSel!=null){
					var seleccionado = '';
					if(codCarreraSel==rec.codParametro){
						seleccionado = "selected='selected'";
					}
					var html = "<option value = '"+rec.codParametro+"' "+seleccionado+" >"+rec.desParametro+"</option>";
					$('#selCarrera').append(html);
					
				}else{
					$('#selCarrera').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));	
				}
			});
			if(codCarreraSel!=null){
				$("#selCarrera").trigger('change');
			}
		}
	});
};

//Se recarga solo una vez al iniciar la página.
var recargarCentrosEstudio = function(){
	var URL_CENTROS_ESTUDIO = CONTEXT_APP+"/registro/formacion/centrosEstudio";
	$.getJSON(URL_CENTROS_ESTUDIO, function( response ) {
		if(validaSesion(response)){
			$.each(response, function(idx, rec){
				$('#selCentroEstudios').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));
			});
		}
	});
};


var limpiarFormulario = function(formElement){
	 //Internal $.validator is exposed through $(form).validate()
	$(formElement).trigger("reset");
	var validator = $(formElement).validate();
	//Iterate through named elements inside of the form, and mark them as error free
	$('[name]',formElement).each(function(){
	   validator.successList.push(this);//mark as error free
	   validator.showErrors();//remove error messages if present
	   $(this).closest('.custom-form-group').removeClass('has-error');
	   $(this).closest('div').removeClass('has-error');
	   $(this).removeClass('has-error');
	});
	//validator.resetElements();
	validator.resetForm();//remove error class on name elements and clear history
	validator.reset();//remove all error and success data
};



var recargarGrillaDatosAcademicos = function(){
	
	//Recargamos la grilla con los datos de la BD
	var URL_RECARGA_DATOS = CONTEXT_APP+"/registro/formacion/listar";
	var data = {"numPostulante":$("#numPostulante").val()};
	//$.ajax({type: "POST",data:data,url: URL_RECARGA_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
    $.post(URL_RECARGA_DATOS,data,
        function(resultado){
        	var tbl = $('#tblDataAcademica').DataTable();
        	tbl.clear().draw();//Limpiamos...
        	for(var i=0;i<resultado.length;i++){
        		var r = resultado[i];
        		var linkEditar = "<a href='javascript:onClickEditarOpcionDatosAcademicos(\""+i+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/edit.png' />"
        		var linkDel = "<a href='javascript:onClickBorrarOpcionDatosAcademicos(\""+r.numIdAcadem+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/cancelar-icon.png' />"
        		var linkDocumento = '';
            	if(r.numArcPostula!=null)
            		linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + r.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
        		
            	var descCarrera = r.desEspecialidad;
            	if(r.codEspecialidad=='9995' || r.codEspecialidad=='9996' || r.codEspecialidad=='9997' || 
            			r.codEspecialidad=='9998' || r.codEspecialidad=='9999'){
            		descCarrera = r.nomProfesion;
            	}
            	
        		var descCentroEstudios = r.desCentroEstudio;
        		if(r.codCentroEstudio=='99996' || r.codCentroEstudio=='99997' ||
        			r.codCentroEstudio=='99998' || r.codCentroEstudio=='99999'){
        			descCentroEstudios = r.nomCentroEstudio;
        		}
        		tbl.row.add( [
        			r.desTipoEstudio,
        			(r.desNivel==null?'':r.desNivel),
        			(r.desCiclo==null?'':r.desCiclo),
        			(descCarrera==null?'':descCarrera),
        			(descCentroEstudios==null?'':descCentroEstudios),
        			linkDocumento,linkEditar,linkDel,
        			r.numIdAcadem,
        			r.codTipoEstudio,
        			(r.codNivelEducativ==null?'':r.codNivelEducativ),
        			(r.codEspecialidad==null?'':r.codEspecialidad),
        			(r.codCentroEstudio==null?'':r.codCentroEstudio),
        			(r.codCiclo==null?'':r.codCiclo),
        			(r.fecGrado==null?'':r.fecGrado),
        			r.fecEgreso,
        			(r.indPuestoUniv==null?'':r.indPuestoUniv),
        			(r.numArcPostula==null?'':r.numArcPostula),
        			(r.nomArchivo==null?'':''+r.nomArchivo)]).draw( true );
        	}
        }
    );
};


var onClickEditarOpcionDatosAcademicos = function(indice){
	ping();//reload session
	limpiarFormulario("#formDatosAcademicos");
	var tbl = $('#tblDataAcademica').DataTable();
	var estudios = tbl.row(indice).data();
	
	$("#numIdAcadem").val(estudios[8]);
	$("#selTipoEstudio").val(estudios[9]);
	
	
	$("#txtOtrosEspecialidad").val('');
	if(estudios[12]=='99996' || estudios[12]=='99997' ||
			estudios[12]=='99998' || estudios[12]=='99999'){
		$("#txtOtrosEspecialidad").val(estudios[4]);
	}
	
	$("#txtOtraCarrera").val('');
	if(estudios[11]=='9995' || estudios[11]=='9996' ||
			estudios[11]=='9997' || estudios[11]=='9998' || estudios[11]=='9999'){
		$("#txtOtraCarrera").val(estudios[3]);
	}
	
	
	$("#fecGrado").val(estudios[14]);
	$("#fecEgreso").val(estudios[15]);
	$("#indPuestoUniv").val(estudios[16]);
	
	$("#selCarrera").val(null);
	$("#selCarrera").trigger('change');
	
	$("#selCentroEstudios").val(estudios[12]);
	$("#selCentroEstudios").trigger('change');
	
	//----- inicio documento
	
	$("#numArcPostulaFA").val(estudios[17]);
	$("#numArcPostulaFABD").val(estudios[17]);
	$("#docFisicoFA").val("");
	if(estudios[17]!=''){
		var linkDocumento = '<a href="javascript:onClickDescargarDocumentoSustento(' + estudios[17] + ');" aria-label="descargarDocumento" alt="Descargar">'+estudios[18]+'</a>';
		$("#nomArchivoFA").html(linkDocumento);
	}else{
		$("#nomArchivoFA").html('');
	}
	
	//$("#selTipoEstudio").change();
	//alCambiarTipoEstudio(estudios[9],estudios[10],estudios[11],estudios[13]);
	
	if("1"==estudios[9]){
		mostrarOcultarTipoSecundaria(false);//ocultamos
		/*$('#selNivelEducativo').val("");
		$('#selCiclo').val("");
		$('#selCarrera').val("");
		$('#selCentroEstudios').val("");*/
		alCambiarTipoEstudio(estudios[9],null,null,null);//el nivel,la carrera y ciclo no se seleccionan
	}else{
		mostrarOcultarTipoSecundaria(true);//mostramos
		//alCambiarTipoEstudio(codTipoEstudio,null,null,null);//el nivel,la carrera y ciclo no se seleccionan
		alCambiarTipoEstudio(estudios[9],estudios[10],estudios[11],estudios[13]);
		
		if("1"==estudios[10]){
			//Si es estudiante
			$("#divFechaEgreso").hide();
			$("#lblFechaGrado").html("Fecha del Certificado/Constancia:");
			
			//si el valor de la fecha de egreso es el default 01/01/0001 entonces copiamos el valor
			if('01/01/0001'==estudios[15]){
				$("#fecEgreso").val(estudios[14]);	
			}
			
		}else{
			
			$("#divFechaEgreso").show();
			$("#lblFechaGrado").html("Fecha de Expedici&oacute;n del Grado/T&iacute;tulo:");
		}
		
	}
	
	//$("#selCarrera").trigger('change');
	/*setTimeout(function(){
		$("#selNivelEducativo").val(estudios[10]);
		$("#selNivelEducativo").change();
		$("#selCarrera").val(estudios[11]);
		$("#selCarrera").trigger('change');
	}, 5000);*/
	
	
	setTimeout(function(){
		//$("#selCiclo").val(estudios[13]);
		$("#divDatosAcademicosPopup").modal('show');
	}, 700);
	
	
	
};



var onClickBorrarOpcionDatosAcademicos = function(codigo){
	confirmarEliminacion(function(){
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/formacion/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		   recargarGrillaDatosAcademicos();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        }
	    });	
	});
	
};


//===============================================================================================
//DATOS DE ESTUDIOS DE ESPECIALIZACIÓN
//===============================================================================================
var inicializarEstudiosEspecializacion = function(){
	
	//=========================================================
	//Funciones para los estudios de especializacion...
	$("#btnAgregarEstudiosEspecializacion").click(function(){
		limpiarFormulario("#formDatosEstudiosEspecializacion");
		$("#fecInicioDiv").data("DateTimePicker").maxDate(new Date());
		$("#selCentroEstudioEstudios").val('');
		$("#selCentroEstudioEstudios").trigger('change');
		$("#numArcPostulaEEBD").val('');
		$("#numArcPostulaEE").val('');
		$("#nomArchivoEE").html('');
		$("#numIdIstAcademEspecializacion").val('');
		$("#divDatosEstudiosEspecializacionPopup").modal('show');
	});
	
	$("#divDatosEstudiosEspecializacionPopup" ).on('shown.bs.modal', function(){
		$("#nomEspecialidad").focus();
	});
	
	$("#btnCerrarPopupEstudiosEspecializacion").click(function(){
		confirmarCancelacion("divDatosEstudiosEspecializacionPopup","formDatosEstudiosEspecializacion");
	});
	
	
	$("#selCentroEstudioEstudios").change(function(){
		ping();//reload session
		var codCentroEstudio = $(this).val();
		if(codCentroEstudio=='99996' || codCentroEstudio=='99997' ||
    			codCentroEstudio=='99998' || codCentroEstudio=='99999'){
			$("#divOtroCentroEstudioEsp").show();
		}else{
			$("#divOtroCentroEstudioEsp").hide();
		}
	});
	
	
	//Configuracion de la tabla de estudios de especializacion
    $('#tblDataEstudiosEspecializacion').DataTable( {
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    $('#fecInicioDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:false,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaInicioEstudios(ev);
        return true;
    });
    
	$('#fecFinDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:false,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaFinEstudios(ev);
        return true;
    });
	
	$('#fecCertificadoDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        return true;
    });
	
	recargarGrillaEstudiosEspecializacion();
};

var esFechaValida = function(fecha){
	
	//validamos q la fecha sea mayor  a 01/01/1900;
	var ianio = 0;
	if(fecha!=null && fecha.length==10){
		ianio = parseInt(fecha.substring(6));
	}
	if(ianio<=1899)return false;
	
	var fechaAValidar = getDateFromFormat(fecha,'dd/MM/yyyy');
	var fechaMinimaTime = getDateFromFormat('01/01/1900','dd/MM/yyyy');
	return fechaAValidar>fechaMinimaTime;
	
};

var alSalirFechaInicioEstudios = function(fechaInicio){
	var fechaFin = $("#fecFin").val();
	if(fechaFin==''){
		if(typeof fechaInicio.date=='object' && esFechaValida($("#fecInicio").val())){
			$("#fecInicioDiv").data("DateTimePicker").maxDate(fechaInicio.date);
			$("#fecFin").val(formatDate(fechaInicio.date.toDate(),'dd/MM/yyyy'));
			$("#fecFinDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo
		}
	}else{
		if(typeof fechaInicio.date=='object'  && esFechaValida($("#fecInicio").val())){
			$("#fecFinDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo	
		}
	}
	
	if($("#fecFin").val()!='')$('#fecFin').valid();
	if($("#fecInicio").val()!='')$('#fecInicio').valid();
};

var alSalirFechaFinEstudios = function(fechaFin){
	if(typeof fechaFin.date=='object' && esFechaValida($("#fecFin").val())){
		$("#fecInicioDiv").data("DateTimePicker").maxDate(fechaFin.date);	
	}else{
		$("#fecInicioDiv").data("DateTimePicker").maxDate(new Date());	
	}
	var fechaInicio = $("#fecInicio").val();
	if(fechaInicio=='' && (typeof fechaFin.date=='object') && esFechaValida($("#fecFin").val())){
		$("#fecInicio").val(formatDate(fechaFin.date.toDate(),'dd/MM/yyyy'));
	}
	if($("#fecFin").val()!='')$('#fecFin').valid();
	if($("#fecInicio").val()!='')$('#fecInicio').valid();
};



var recargarGrillaEstudiosEspecializacion = function(){
	
	//Recargamos la grilla con los datos de la BD
	var URL_RECARGA_DATOS = CONTEXT_APP+"/registro/estudios/listar?indCertificacion=0";
	var data = {"numPostulante":$("#numPostulante").val()};
    $.post(URL_RECARGA_DATOS,data,
        function(resultado){
        	var tbl = $('#tblDataEstudiosEspecializacion').DataTable();
        	tbl.clear().draw();//Limpiamos...
        	for(var i=0;i<resultado.length;i++){
        		var r = resultado[i];
        		var linkDocumento = '';
                if(r.numArcPostula!=null)
                	linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + r.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
        		var linkDel = "<a href='javascript:onClickBorrarOpcionEstudiosEspecializacion(\""+r.numIdIstAcadem+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/cancelar-icon.png' />"
        		var linkEditar = "<a href='javascript:onClickEditarOpcionEstudiosEspecializacion(\""+i+"\");' aria-label='escogerOpcion' alt='Editar'><img src='/a/imagenes/edit.png' />"
        		var descCentroEstudios = r.desCentroEstudio;
        		if(r.codCentroEstudio=='99996' || r.codCentroEstudio=='99997' ||
        			r.codCentroEstudio=='99998' || r.codCentroEstudio=='99999'){
        			descCentroEstudios = r.nomCentroEstudio;
        		}
        		tbl.row.add([
        			r.nomEspecialidad,descCentroEstudios,
        			r.fecInicio,r.fecFin,r.fecCertificado,
        			r.cntHoraLectiva,linkDocumento,linkEditar,linkDel,
        			r.codCentroEstudio,
        			r.numIdIstAcadem,
        			(r.numArcPostula==null?'':r.numArcPostula),
        			(r.nomArchivo==null?'':''+r.nomArchivo),
        			]).draw( true );
        	}
        }
    );
};

var onClickBorrarOpcionEstudiosEspecializacion = function(codigo){
	confirmarEliminacion(function(){
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/estudios/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		   recargarGrillaEstudiosEspecializacion();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        }
	    });	
	});
};


var onClickEditarOpcionEstudiosEspecializacion = function(indice){
	ping();//reload session
	limpiarFormulario("#formDatosEstudiosEspecializacion");
	var tbl = $('#tblDataEstudiosEspecializacion').DataTable();
	var estudios = tbl.row(indice).data();
	
	$("#numIdIstAcademEspecializacion").val(estudios[10]);
	
	$("#nomEspecialidad").val(estudios[0]);
	$("#selCentroEstudioEstudios").val(estudios[9]);
	$("#selCentroEstudioEstudios").trigger('change');
	
	if(estudios[9]=='99996' || estudios[9]=='99997' ||
			estudios[9]=='99998' || estudios[9]=='99999'){
		$("#txtOtrosEspecialidadEsp").val(estudios[1]);
	}
	
	
	$("#fecInicio").val(estudios[2]);
	$("#fecFin").val(estudios[3]);
	$("#fecCertificado").val(estudios[4]);
	$("#cntHoraLectiva").val(estudios[5]);
	
	//----- inicio documento
	$("#numArcPostulaEE").val(estudios[11]);
	$("#numArcPostulaEEBD").val(estudios[11]);
	$("#docFisicoEE").val("");
	if(estudios[11]!=''){
		var linkDocumento = '<a href="javascript:onClickDescargarDocumentoSustento(' + estudios[11] + ');" aria-label="descargarDocumento" alt="Descargar">'+estudios[12]+'</a>';
		$("#nomArchivoEE").html(linkDocumento);
	}else{
		$("#nomArchivoEE").html('');
	}
	
	$("#selCentroEstudioEstudios").change();//para mostrar u ocultar la fecha de fin cuando se edita
	setTimeout(function(){
		$("#divDatosEstudiosEspecializacionPopup").modal('show');
	}, 500);

};



//===============================================================================================
//DATOS DE CONOCIMIENTOS TECNICOS
//===============================================================================================
var inicializarCertificacion = function(){
	$('#tblDataCertificacion').DataTable( {
		"columnDefs": [{"targets": [7,8,9,10,11,12,13], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]],
        "bLengthChange" : false, //thought this line could hide the LengthMenu
    });
	
	$("#btnAgregarCertificacion").click(function(){
		limpiarFormulario("#formDatosCertificacion");
		$("#fecInicioCertDiv").data("DateTimePicker").maxDate(new Date());
		$("#selCentroEstudioEstudiosCert").val('');
		$("#selCentroEstudioEstudiosCert").trigger('change');
		$("#numIdIstAcadem").val('');
		$("#numArcPostulaCert").val('');
		$("#numArcPostulaCertBD").val('');
		$("#nomArchivoCert").html('');
		$("#divDatosCertificacionPopup").modal('show');
	});
	
	$("#divDatosCertificacionPopup" ).on('shown.bs.modal', function(){
		$("#nomEspecialidadCert").focus();
	});
	
	$("#btnCerrarPopupCertificacion").click(function(){
		confirmarCancelacion("divDatosCertificacionPopup","formDatosCertificacion");
	});
	
	$("#selCentroEstudioEstudiosCert").change(function(){
		ping();//reload session
		var codCentroEstudio = $(this).val();
		if(codCentroEstudio=='99996' || codCentroEstudio=='99997' ||
    			codCentroEstudio=='99998' || codCentroEstudio=='99999'){
			$("#divOtroCentroEstudioCert").show();
		}else{
			$("#divOtroCentroEstudioCert").hide();
		}
	});
	
    $('#fecInicioCertDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:false,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaInicioCertificacion(ev);
        return true;
    });
    
	$('#fecFinCertDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:false
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaFinCertificacion(ev);
        return true;
    });
	
	$('#fecCertificadoCertDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        return true;
    });
	
	
	recargarGrillaCertificacion();
};

var alSalirFechaInicioCertificacion = function(fechaInicio){
	var fechaFin = $("#fecFinCert").val();
	if(fechaFin==''){
		if(typeof fechaInicio.date=='object' && esFechaValida($("#fecInicioCert").val())){
			$("#fecInicioCertDiv").data("DateTimePicker").maxDate(fechaInicio.date);
			$("#fecFinCert").val(formatDate(fechaInicio.date.toDate(),'dd/MM/yyyy'));
			$("#fecFinCertDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo
		}
	}else{
		if(typeof fechaInicio.date=='object'  && esFechaValida($("#fecInicioCert").val())){
			$("#fecFinCertDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo	
		}
	}
	
	if($("#fecFinCert").val()!='')$('#fecFinCert').valid();
	if($("#fecInicioCert").val()!='')$('#fecInicioCert').valid();
};

var alSalirFechaFinCertificacion = function(fechaFin){
	if(typeof fechaFin.date=='object' && esFechaValida($("#fecFinCert").val())){
		$("#fecInicioCertDiv").data("DateTimePicker").maxDate(fechaFin.date);	
	}else{
		$("#fecInicioCertDiv").data("DateTimePicker").maxDate(new Date());
	}
	var fechaInicio = $("#fecInicioCert").val();
	if(fechaInicio=='' && (typeof fechaFin.date=='object') && esFechaValida($("#fecFinCert").val())){
		$("#fecInicioCert").val(formatDate(fechaFin.date.toDate(),'dd/MM/yyyy'));
		$("#fecFinCertDiv").data("DateTimePicker").minDate(fechaFin.date);//colocamos la restricción.
	}
	if($("#fecFinCert").val()!='')$('#fecFinCert').valid();
	if($("#fecInicioCert").val()!='')$('#fecInicioCert').valid();
};



var agregarConocimientoTecnico = function(){
	var txtDescripcionConoTecnico = $("#txtDescripcionConoTecnico").val();
	if($.trim(txtDescripcionConoTecnico)==''){
		bootbox.alert("Ingrese el conocimiento técnico.");
		$("#txtDescripcionConoTecnico").focus();
	}else{
		//Agregamos el dato a la grilla.
		$.blockUI();
		$("#btnRegistrarConoInformatico").prop('disabled', true);
		
		var formulario = $("#formConocimientoTecnico");
		var data = $.toJSON(formToObject(formulario.serializeArray()));
		var url = CONTEXT_APP+"/registro/contecnico/registrar";
	    $.ajax({
	           type: "POST",
	           url: url,
	           dataType: 'json',	
	           data: data, 
	           contentType: "application/json; charset=utf-8",
	           success: function(resultado){
	        	   $.unblockUI();
	        	   $("#btnRegistrarConoInformatico").prop('disabled', false);
	        	   if(validaSesion(resultado)){
	        		   if(resultado.fichaActualizada==1){
		        		   bootbox.alert("Ficha Actualizada.");
		        		   recargarGrillaConocimientosTecnicos();
		        		   $('#txtDescripcionConoTecnico').val("");
		        		   $('#txtDescripcionConoTecnico').focus();
		        	   }else{
		        		   alert("Se encontraron errores...");
		        	   }   
	        	   }
	           }
	   });	
	}
};


var recargarGrillaCertificacion = function(){
	
	//Recargamos la grilla con los datos de la BD
	var URL_RECARGA_DATOS = CONTEXT_APP+"/registro/estudios/listar?indCertificacion=1";
	var data = {"numPostulante":$("#numPostulante").val()};
    $.post(URL_RECARGA_DATOS,data,
        function(resultado){
        	var tbl = $('#tblDataCertificacion').DataTable();
        	tbl.clear().draw();//Limpiamos...
        	for(var i=0;i<resultado.length;i++){
        		var r = resultado[i];
        		
        		var linkDocumento = '';
                if(r.numArcPostula!=null)
                	linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + r.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
        		
                var linkEditar = "<a href='javascript:onClickEditarOpcionCertificacion(\""+i+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/edit.png' />"
        		var linkDel = "<a href='javascript:onClickBorrarOpcionCertificacion(\""+r.numIdIstAcadem+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/cancelar-icon.png' />"
        		var descCentroEstudios = r.desCentroEstudio;
        		if(r.codCentroEstudio=='99996' || r.codCentroEstudio=='99997' ||
        			r.codCentroEstudio=='99998' || r.codCentroEstudio=='99999'){
        			descCentroEstudios = r.nomCentroEstudio;
        		}
        		tbl.row.add([r.nomEspecialidad,descCentroEstudios,r.fecInicio,r.fecFin,
        			linkDocumento,linkEditar,linkDel,
        			r.codCentroEstudio,r.fecCertificado,
        			r.nomCentroEstudio,r.nomEspecialidad,
        			(r.numArcPostula==null?'':''+r.numArcPostula),
        			r.numIdIstAcadem,
        			(r.nomArchivo==null?'':''+r.nomArchivo)]).draw( true );
        	}
        }
    );
};


var onClickBorrarOpcionCertificacion = function(codigo){
	confirmarEliminacion(function(){
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/estudios/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		 recargarGrillaCertificacion();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        }
	    });	
	});
};


var onClickEditarOpcionCertificacion = function(indice){
	ping();//reload session
	limpiarFormulario("#formDatosCertificacion");
	var tbl = $('#tblDataCertificacion').DataTable();
	var estudios = tbl.row(indice).data();
	
	$("#numIdIstAcadem").val(estudios[12]);
	$("#nomEspecialidadCert").val(estudios[10]);
	$("#selCentroEstudioEstudiosCert").val(estudios[7]);
	$("#txtOtrosEspecialidadEspCert").val(estudios[9]);
	$("#fecInicioCert").val(estudios[2]);
	$("#fecFinCert").val(estudios[3]);
	$("#fecCertificadoCert").val(estudios[8]);
	
	//----- inicio documento
	$("#numArcPostulaCert").val(estudios[11]);
	$("#numArcPostulaCertBD").val(estudios[11]);
	$("#docFisicoEL").val("");
	if(estudios[11]!=''){
		var linkDocumento = '<a href="javascript:onClickDescargarDocumentoSustento(' + estudios[11] + ');" aria-label="descargarDocumento" alt="Descargar">'+estudios[13]+'</a>';
		$("#nomArchivoCert").html(linkDocumento);
	}else{
		$("#nomArchivoCert").html('');
	}
	//----- fin documento
	
	$("#selCentroEstudioEstudiosCert").change();//para mostrar u ocultar la fecha de fin cuando se edita
	setTimeout(function(){
		//Esperamos 1 segundo hasta que se llene el otro listado.
		//$("#selTipocontrato").val(experiencia[13]);
		$("#divDatosCertificacionPopup").modal('show');
		
	}, 500);

};



var onClickBorrarOpcionConocimientosTecnicos = function(codigo){
	confirmarEliminacion(function(){
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/contecnico/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		   recargarGrillaConocimientosTecnicos();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        }
	    });	
	});
};



//===============================================================================================
//DATOS DE CONOCIMIENTOS INFORMATICOS
//===============================================================================================
var inicializarConocimientosInformaticos = function(){
	
	//=========================================================
	//Funciones para los estudios de especializacion...
	$("#btnAgregarConoInformatico").click(function(){
		ping();//reload session
		limpiarFormulario("#formDatosConocimientosInformaticos");
		$("#numIdConocimient").val("");
		$("#divDatosConoInformaticoPopup").modal('show');
	});
	
	$("#divDatosConoInformaticoPopup" ).on('shown.bs.modal', function(){
		$("#selTipoConoInformatico").focus();
	});
	
	$("#btnCerrarPopupConoInformatico").click(function(){
		confirmarCancelacion("divDatosConoInformaticoPopup","formDatosConocimientosInformaticos");
	});
	
	$("#selTipoConoInformatico").change(function(){
		var tipo = $(this).val();
		$("#selDetalleTipoConoInformatico").html("");//limpiamos...		
	
		var URL_TIPO_CONOCIMIENTO = CONTEXT_APP+"/registro/formacion/tipoconocimiento?codTipoConocimiento="+tipo;
			$.getJSON(URL_TIPO_CONOCIMIENTO, function( response ) {
			$('#selDetalleTipoConoInformatico').html("");
			$('#selDetalleTipoConoInformatico').append('<option value="">[--Seleccione--]</option>');
			$.each(response, function(idx, rec){				
				$('#selDetalleTipoConoInformatico').append($('<option />').attr('value', rec.desSiglas).text(rec.desParametro));								
			});
		});
	});
	
	
	$('#selDetalleTipoConoInformatico').change(function(){
		ping();//reload session		
		var tipo = $("#selDetalleTipoConoInformatico option:selected").text();	
		tipo == tipo.trim();
		if(tipo =='OTROS' ){
			$("#divOtroConocimiento").show();		
		}else{
			$("#divOtroConocimiento").hide();
		}
	});
	
	
	//Configuracion de la tabla de estudios de especializacion
    $('#tblDataConoInformatico').DataTable( {
    	"columnDefs": [{"targets": [5,6,7,8], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    recargarGrillaConocimientosInformaticos();
	
};

var recargarGrillaConocimientosInformaticos = function(){	
	//Recargamos la grilla con los datos de la BD
	var URL_RECARGA_DATOS = CONTEXT_APP+"/registro/contecnico/listarconocimiento";
	var data = {"numPostulante":$("#numPostulante").val()};		
	$.post(URL_RECARGA_DATOS,data,
			function(resultado)	{
        	var tbl = $('#tblDataConoInformatico').DataTable();
        	tbl.clear().draw();//Limpiamos...
        	for(var i=0;i<resultado.length;i++){
        		var r = resultado[i];
        		var tipoConocimiento = '-';        		
        		var desNivel = '-';
        		        		
        		if(r.codTipcono=='2') tipoConocimiento = "INFORMATICO";
        		if(r.codTipcono=='3') tipoConocimiento = "IDIOMAS";        		
        		
        		
        		if(r.codNivel=='A')desNivel = "AVANZADO";
        		else if(r.codNivel=='B') desNivel = "BÁSICO";
        		else if(r.codNivel=='I') desNivel = "INTERMEDIO";
        		var linkDel = "<a href='javascript:onClickBorrarOpcionConocimientosInformaticos(\""+r.numIdConocimient+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/cancelar-icon.png' />"
        		var linkEditar = "<a href='javascript:onClickEditarOpcionConoInformatico(\""+i+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/edit.png' />"
        		tbl.row.add( [tipoConocimiento,r.nomConcomiento,desNivel,
        		linkEditar,linkDel,r.codTipcono,r.codConocimiento,r.numIdConocimient,r.codNivel]).draw( true );
        	}
        }
    );
};

var onClickBorrarOpcionConocimientosInformaticos = function(codigo){
	confirmarEliminacion(function(){
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/contecnico/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		   recargarGrillaConocimientosInformaticos();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        	
	        }
	    });	
	});
	
};


var onClickEditarOpcionConoInformatico = function(indice){
	ping();//reload session
	limpiarFormulario("#formDatosConocimientosInformaticos");
	var tbl = $('#tblDataConoInformatico').DataTable();
	var conocimientos = tbl.row(indice).data();
	
	$("#numIdConocimient").val(conocimientos[7]);
	$("#selTipoConoInformatico").val(conocimientos[5]);
	$("#selTipoConoInformatico").change();
	
	setTimeout(function(){
		$("#selDetalleTipoConoInformatico").val(conocimientos[6]);
		$("#selDetalleTipoConoInformatico").change();
		if(conocimientos[6]=='0004'){
			$("#nomConocimiento").val(conocimientos[1]);	
		}
		$("#selNivelConoInformatico").val(conocimientos[8]);
		$("#divDatosConoInformaticoPopup").modal('show');
		
	}, 500);

};


//===============================================================================================
//DATOS DE EXPERIENCIA LABORAL
//===============================================================================================
var inicializarExperienciaLaboral = function(){
	
	//=========================================================
	//Funciones para la experiencia laboral...
	$("#btnAgregarExperienciaLaboral").click(function(){
		ping();//reload session
		limpiarFormulario("#formDatosExperiencia");
		resetFormExperiencia();
		fechaFinExperienciaTmp = "";//valor temporal...
		$("#fecInicioExpDiv").data("DateTimePicker").maxDate(new Date());
		$("#fecFinExpDiv").data("DateTimePicker").maxDate(new Date());
		$("#numArcPostulaEL").val('');
		$("#numArcPostulaELBD").val('');
		$("#nomArchivo").html('');
		$("#divDatosExperienciaLaboralPopup").modal('show');
	});
	
	$("#divDatosExperienciaLaboralPopup" ).on('shown.bs.modal', function(){
		$('#divDatosExperienciaLaboralPopupBody').scrollTop(0);
		$("#selTipoexpe").focus();
	});
	
	$("#btnCerrarPopupExperienciaLaboral").click(function(){
		confirmarCancelacion("divDatosExperienciaLaboralPopup","formDatosExperiencia");
	});
	
	
    //Configuracion de la tabla de experiencia laboral
    $('#tblDataExperienciaLaboral').DataTable( {
    	"columnDefs": [{"targets": [4,10,11,12,13,14,15,16,17,18,19,20,21,22,23], "visible": false,"searchable": false}],
        "paging": true,
        "ordering": false,
        "searching":false,
        "info":true,
        "language": {
            "url": "/a/js/libs/bootstrap/3.3.2/plugins/datatables-1.10.7/plug-ins/1.10.7/i18n/Spanish.json"
        },
        "lengthMenu": [[5, 10], [5, 10]]
    });
    
    $('#fecInicioExpDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaInicioExperiencia(ev);
        return true;
    });
    
	$('#fecFinExpDiv').datetimepicker({
        locale: 'es',
        format: 'DD/MM/YYYY',
        icons: {date: "fa fa-calendar",up: "fa fa-arrow-up",down: "fa fa-arrow-down"},
    	useCurrent:true,
    	maxDate:new Date()
    }).on('dp.change', function (ev) {
    	ping();//reload session
        alSalirFechaFinExperiencia(ev);
        return true;
    });
	
	$("#selTipoentidad").change(function(){
		var tipo = $(this).val();
		if(tipo!=''){
			var URL_TIPOS_CONTRATO = CONTEXT_APP+"/registro/experiencia/contratos?tipoContrato="+tipo;
			$.getJSON(URL_TIPOS_CONTRATO, function( response ) {
				$('#selTipocontrato').html("");
				$('#selTipocontrato').append('<option value="">[--Seleccione--]</option>');
				$.each(response, function(idx, rec){					
					$('#selTipocontrato').append($('<option />').attr('value', rec.codParametro).text(rec.desParametro));								
				});
			});		
		}else{
			$('#selTipocontrato').html("");
			$('#selTipocontrato').append('<option value="">[--Seleccione--]</option>');
		}
	});
	
	$("#selMotivoCese").change(function(){
		ping();//reload session
		var tipo = $(this).val();
		//Si aún sigue laborando entonces ocultamos la fecha de fin, sino la mostramos
		if(tipo=='005'){
			fechaFinExperienciaTmp = $("#fecFinExp").val();//guardamos el dato temporal
			$("#fecFinExp").val("01/01/0001");//asignamos el valor que se registrará.
			$('#divFechaFinExperiencia').hide();
		}else{
			if(fechaFinExperienciaTmp!=""){
				$("#fecFinExp").val(fechaFinExperienciaTmp);//volvemos a asignar el valor
			}
			
			if($("#fecFinExp").val()=="01/01/0001")$("#fecFinExp").val("");
			$('#divFechaFinExperiencia').show();
		}
	});
	
	
	/*$('#desLabores').on('paste', function () {
		var element = this;
		setTimeout(function () {
		    $(element).val("prohibido copiar...");
		}, 100);
	});*/
	
	recargarGrillaExperienciaLaboral();
};

var fechaFinExperienciaTmp = "";


var alSalirFechaInicioExperiencia = function(fechaInicio){
	var fechaFin = $("#fecFinExp").val();
	if(fechaFin==''){
		if(typeof fechaInicio.date=='object' && esFechaValida($("#fecInicioExp").val())){
			//$("#fecInicioExpDiv").data("DateTimePicker").maxDate(fechaInicio.date);
			$("#fecFinExp").val(formatDate(fechaInicio.date.toDate(),'dd/MM/yyyy'));
			//$("#fecFinExpDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo
		}
	}else{
		if(typeof fechaInicio.date=='object' && esFechaValida($("#fecInicioExp").val())){
			//$("#fecFinExpDiv").data("DateTimePicker").minDate(fechaInicio.date);//limite mínimo	
		}	
	}
	
	
	if($("#fecFinExp").val()!='')$('#fecFinExp').valid();
	if($("#fecInicioExp").val()!='')$('#fecInicioExp').valid();
};

var alSalirFechaFinExperiencia = function(fechaFin){
	if(typeof fechaFin.date=='object' && esFechaValida($("#fecFinExp").val())){
		//$("#fecInicioExpDiv").data("DateTimePicker").maxDate(fechaFin.date);	
	}else{
		//$("#fecInicioExpDiv").data("DateTimePicker").maxDate(new Date());	
	}
	var fechaInicio = $("#fecInicioExp").val();
	if(fechaInicio=='' && (typeof fechaFin.date=='object')  && esFechaValida($("#fecFinExp").val())){
		$("#fecInicioExp").val(formatDate(fechaFin.date.toDate(),'dd/MM/yyyy'));
	}
	if($("#fecFinExp").val()!='')$('#fecFinExp').valid();
	if($("#fecInicioExp").val()!='')$('#fecInicioExp').valid();
};




var recargarGrillaExperienciaLaboral = function(){
	
	//Recargamos la grilla con los datos de la BD
	var URL_RECARGA_DATOS = CONTEXT_APP+"/registro/experiencia/listar";
	var data = {numPostulante:$("#numPostulante").val()};
	//$.ajax({type: "POST",url: URL_RECARGA_DATOS,processData:false,data:data, dataType: 'json', contentType: "application/json; charset=utf-8",
    $.post(URL_RECARGA_DATOS,data,
        function(resultado){
        	var tbl = $('#tblDataExperienciaLaboral').DataTable();
        	tbl.clear().draw();//Limpiamos...
        	for(var i=0;i<resultado.length;i++){
        		var r = resultado[i];
        		var linkDocumento = '';
        		if(r.numArcPostula!=null)
        			linkDocumento = '&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:onClickDescargarDocumentoSustento(' + r.numArcPostula + ');" aria-label="descargarDocumento" alt="Descargar"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>';
        		var linkDel = "<a href='javascript:onClickBorrarOpcionExperienciaLaboral(\""+r.numIdExpe+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/cancelar-icon.png' />";
        		var linkUpdate = "<a href='javascript:onClickUpdateOpcionExperienciaLaboral(\""+i+"\");' aria-label='escogerOpcion' alt='Eliminar'><img src='/a/imagenes/edit.png' />";
        		var desTipoEntidad = '';
        		if(r.codTipoentidad=='1')desTipoEntidad='PUBLICO';
        		else if(r.codTipoentidad=='2')desTipoEntidad='PRIVADO';
        		
        		var fechaFin = "";
        		if(r.fecFin!='01/01/0001')	
        			fechaFin = r.fecFin;
        		
        		tbl.row.add([desTipoEntidad,//experiencia[0]
        		             r.desEntidad,//experiencia[1]
        		             r.desArea,//experiencia[2]
        		             r.desCargo,//experiencia[3]
        		             r.desLabores,//experiencia[4]
        		             r.fecInicio,//experiencia[5]
        		             fechaFin,//experiencia[6]
        		             linkDocumento,//experiencia[7]
        		             linkDel,//experiencia[8]
        		             linkUpdate,//experiencia[9]
        		             r.numIdExpe,//experiencia[10]
        		             r.codTipoentidad,//experiencia[11]
        		             r.desEntidad,//experiencia[12]
        		             r.codTipocontrato,//experiencia[13]
        		             r.codMotivoCese,//experiencia[14]
        		             r.codTipoexpe,//experiencia[15]
        		             r.nomDireccion,//experiencia[16]
        		             r.desCargoCont,//experiencia[17]
        		             r.nomContacto,//experiencia[18]
        		             r.numTelefono,//experiencia[19]
        		             r.nomCorreo,//experiencia[20]
        		             r.mtoRemu,//experiencia[21]
        		             (r.numArcPostula==null?'':''+r.numArcPostula),//experiencia[22]
        		             (r.nomArchivo==null?'':''+r.nomArchivo)//experiencia[23]
        		             ]
        		).draw( true );
        	}
        }
    );
};

var onClickBorrarOpcionExperienciaLaboral = function(codigo){
	confirmarEliminacion(function(){
		var data = {"numPostulante":$("#numPostulante").val()};
		var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/experiencia/borrar/"+codigo;
	    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
	        success: function(resultado){
	        	if(validaSesion(resultado)){
	        		if(resultado.fichaActualizada==1){
	 	     		   bootbox.alert("Ficha Actualizada.");
	 	     		   recargarGrillaExperienciaLaboral();
	 	     	    }else{
	 	     		   alert("Se encontraron errores...");
	 	     	    }	
	        	}
	        }
	    });	
	})
};

var onClickUpdateOpcionExperienciaLaboral = function(indice){
	//alert("TODO");
	ping();//reload session
	limpiarFormulario("#formDatosExperiencia");
	var tbl = $('#tblDataExperienciaLaboral').DataTable();
	var experiencia = tbl.row(indice).data();
	$("#numIdExpe").val(experiencia[10]);
	$("#selTipoexpe").val(experiencia[15]);
	$("#selTipoentidad").val(experiencia[11]);
	$("#selTipoentidad").change();
	$("#desEntidad").val(experiencia[12]);
	$("#nomDireccion").val(experiencia[16]);
	$("#desArea").val(experiencia[2]);
	$("#desCargo").val(experiencia[3]);
	$("#desLabores").val(experiencia[4]);
	$("#fecInicioExp").val(experiencia[5]);
	$("#fecFinExp").val(experiencia[6]);
	$("#mtoRemu").val(experiencia[21]);
	$("#selMotivoCese").val(experiencia[14]);
	$("#desCargoCont").val(experiencia[17]);
	$("#nomContacto").val(experiencia[18]);
	$("#numTelefono").val(experiencia[19]);
	$("#nomCorreo").val(experiencia[20]);
	
	//----- inicio documento
	$("#numArcPostulaEL").val(experiencia[22]);
	$("#numArcPostulaELBD").val(experiencia[22]);
	$("#docFisicoEL").val("");
	if(experiencia[22]!=''){
		var linkDocumento = '<a href="javascript:onClickDescargarDocumentoSustento(' + experiencia[22] + ');" aria-label="descargarDocumento" alt="Descargar">'+experiencia[23]+'</a>';
		$("#nomArchivo").html(linkDocumento);
	}else{
		$("#nomArchivo").html('');
	}
	//----- fin documento
	
	$("#selMotivoCese").change();//para mostrar u ocultar la fecha de fin cuando se edita
	setTimeout(function(){
		//Esperamos 1 segundo hasta que se llene el otro listado.
		$("#selTipocontrato").val(experiencia[13]);
		$("#divDatosExperienciaLaboralPopup").modal('show');
		
		var fechaInicio = new Date(getDateFromFormat(experiencia[5],'dd/MM/yyyy'));
		var fechaFin = new Date(getDateFromFormat(experiencia[6],'dd/MM/yyyy'));
		
		
		//$("#fecInicioExpDiv").data("DateTimePicker").maxDate(fechaInicio.date);
		//$("#fecFinExp").val(formatDate(fechaInicio.date.toDate(),'dd/MM/yyyy'));
		/*$("#fecFinExpDiv").data("DateTimePicker").minDate(fechaInicio);
		$("#fecFinExpDiv").data("DateTimePicker").maxDate(new Date());
		$("#fecInicioExpDiv").data("DateTimePicker").maxDate(fechaFin);*/
		
		
	}, 500);
	
	
	
	/*var URL_BORRADO_DATOS = CONTEXT_APP+"/registro/experiencia/borrar/"+codigo;
    $.ajax({type: "POST",url: URL_BORRADO_DATOS, dataType: 'json', contentType: "application/json; charset=utf-8",
        success: function(resultado){
        	if(resultado.fichaActualizada==1){
     		   bootbox.alert("Ficha Actualizada.");
     		  recargarGrillaExperienciaLaboral();
     	    }else{
     		   alert("Se encontraron errores...");
     	    }
        }
    });*/
};

//METODOS GENERALES
var confirmarCancelacion = function(divModal,form){
	ping();//reload session
	bootbox.confirm({
	    title: "Confirmaci&oacute;n",
	    message: "\u00BFEst&aacute; seguro de cancelar el registro\u003F",
	    buttons: {
	        cancel: {label: '<i class="fa fa-times"></i> NO'},
	        confirm: {label: '<i class="fa fa-check"></i> S&Iacute;'}
	    },
	    callback: function (result) {
	        if(result){
	        	setTimeout(function(){ 
	        		$("#"+form).trigger("reset");
	        		$("#"+divModal).modal("hide"); 
	        	}, 250);
	        }
	    }
	});
};


var confirmarEliminacion = function(callbackFunction){
	ping();//reload session
	bootbox.confirm({
	    title: "Confirmaci&oacute;n",
	    message: "\u00BFEst&aacute; seguro de eliminar el registro\u003F",
	    buttons: {
	        cancel: {label: '<i class="fa fa-times"></i> NO'},
	        confirm: {label: '<i class="fa fa-check"></i> S&Iacute;'}
	    },
	    callback: function (result) {
	        if(result){
	        	callbackFunction();
	        }
	    }
	});
};




//===============================================================================================
//CARGA DE ARCHIVOS
//===============================================================================================

/*------------------------------DATOS DE ARCHIVO TEMPORAL----------------------------*/
function getDoc(frame) {
	
	var doc = null;
	try {
		if (frame.contentWindow) {
			doc = frame.contentWindow.document;	
		}
	} catch(err) {
	}
	if(doc){
		return doc;
	}
	try {
		doc = frame.contentDocument ? frame.contentDocument : frame.document;
	} catch(err) {
		doc = frame.document;
	}
	return doc;
	
}

/*------------------------------VALIDA EL ARCHIVO SUBIDO----------------------------*/
function validarArchivoUpload(tipArchivo) {
	$("#docFisico"+tipArchivo).appendTo($('#frmArchivoValidar'));
	$('#tipArchivoValidar').val(tipArchivo);
	$('#frmArchivoValidar').submit();
	$("#docFisico"+tipArchivo).appendTo($('#manejadorArchivo'+tipArchivo));
	if(tipArchivo=='EL')
		$("#nomArchivo").appendTo($('#manejadorArchivo'+tipArchivo));
}

$("#frmArchivoValidar").submit(function(e){
	var tipArchivo = $('#tipArchivoValidar').val();
	
	var formObj = $(this);
	var iframeId = 'unique' + (new Date().getTime());
	var iframe = $('<iframe src="javascript:false;" name="'+iframeId+'" />');
	iframe.hide();
	formObj.attr('target', iframeId);
	formObj.attr('action', CONTEXT_APP + '/registro/archivo/validar');
	formObj.attr("enctype", "multipart/form-data");
	formObj.attr("encoding", "multipart/form-data");
	iframe.appendTo('body');
	
	iframe.load(function(e){
		
		var doc = getDoc(iframe[0]);
		var docRoot = doc.body ? doc.body : doc.documentElement;
		var data = docRoot.innerHTML;
		var jsonDataString;
		var response;
		var indError;
		indError = false;
		var indErrorJson = false;
		if (data.toLowerCase().indexOf("error") >= 0 || data.toLowerCase().indexOf("SUNAT Operaciones en Línea") >= 0 ) {
			indError = true;
		}
				
		if(indError) {
			$("#docFisico"+tipArchivo).appendTo($('#frmArchivoValidar'));
			$("#docFisico"+tipArchivo).appendTo($('#manejadorArchivo'+tipArchivo));
			$("#docFisico"+tipArchivo).val("");
			var mensajeExcepcion = "El tamaño de archivo máximo permitido es: 1024KB (1MB)";			
			mostrarMensaje(mensajeExcepcion);
		} else {		
			if (data.indexOf("<pre style") > -1) {
				jsonDataString = data.replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">', '');
				jsonDataString = jsonDataString.replace('</pre>', '');
				
			} else {
				jsonDataString = data.replace('<PRE>', '');
				jsonDataString = jsonDataString.replace('</PRE>', '');						
				jsonDataString = jsonDataString.replace('<pre>', '');
				jsonDataString = jsonDataString.replace('</pre>', '');
				
			}
			try{
				response = jQuery.parseJSON(jsonDataString);
			}catch(err) {
				$("#docFisico"+tipArchivo).appendTo($('#frmArchivoValidar'));
				$("#docFisico"+tipArchivo).appendTo($('#manejadorArchivo'+tipArchivo));
				$("#docFisico"+tipArchivo).val("");
				var mensajeExcepcion = "El tamaño de archivo máximo permitido es: 1024KB (1MB)";			
				mostrarMensaje(mensajeExcepcion);
				indErrorJson = true;
			}
			
			if(!indErrorJson){
				if (response.tamanoArchivoSuperado) {
					var control = $("#docFisico"+tipArchivo);
					control.replaceWith( control = control.clone( true ) );
					control.val(null);
					$("#docFisico"+tipArchivo).val("");
					var mensajeExcepcion = "El tamaño de archivo máximo permitido es: 1024KB (1MB)";
					mostrarMensaje(mensajeExcepcion);
					
				} else if(!response.extensionPermitida){
						var control = $("#docFisico"+tipArchivo);
						control.replaceWith( control = control.clone( true ) );
						control.val(null);
						$("#docFisico"+tipArchivo).val("");
						var mensajeExcepcion = "El sustento debe ser de extensión PDF.";						
						mostrarMensaje(mensajeExcepcion);
					} else if(!response.longitudnombrearchivo){
							var control = $("#docFisico"+tipArchivo);
							control.replaceWith( control = control.clone( true ) );
							control.val(null);
							$("#docFisico"+tipArchivo).val("");
							var mensajeExcepcion = "El nombre del archivo debe tener una longitud menor a 100 letras.";						
							mostrarMensaje(mensajeExcepcion);
						} else {		
							$("#nomArchivo").html('');
						}
				}
		}
  });
	
});

/*------------------------------ REGISTRAR ----------------------------*/
function registrarArchivoUpload(tipArchivo){
	if(tipArchivo == 'EL' && $("#docFisicoEL").val() == '' && $("#numArcPostulaELBD").val() != ''){//experiencia
		registrarDatosExperiencia();
	}else if(tipArchivo == 'EE' && $("#docFisicoEE").val() == ''){//especialización
		registrarDatosEstudiosEspecializacion();
	}else if(tipArchivo == 'Cert' && $("#docFisicoCert").val() == ''){//certificacion
		//bootbox.alert("Debe adjuntar el documento de sustento.");
		registrarDatosCertificacion();
	}else if(tipArchivo == 'FA' && $("#docFisicoFA").val() == ''){//formación
		registrarDatosAcademicos();
	}else{
		
		//envío de archivo
		var nomDocumentoFisico = $('#docFisico'+tipArchivo).val().replace(/\\/g, '/').replace(/.*\//, '');
		var numPostulante = $("#numPostulante").val();
		$("#tipArchivoUpload").val(tipArchivo);
		$("#nomArchivoUpload").val(nomDocumentoFisico);
		$("#numPostulanteUpload").val(numPostulante);
		
		//submit
		$("#docFisico"+tipArchivo).appendTo($('#frmArchivoUpload'));
		$('#frmArchivoUpload').submit();
		$("#docFisico"+tipArchivo).appendTo($('#manejadorArchivo'+tipArchivo));
		if(tipArchivo=='EL')
			$("#nomArchivo").appendTo($('#manejadorArchivo'+tipArchivo));
	}
  
}

$("#frmArchivoUpload").submit(function(e){
	//data
	var tipArchivo = $("#tipArchivoUpload").val(); //FA, EE, EL(experiencia laboral)
	
	var formObj = $(this);
	var iframeId = 'unique' + (new Date().getTime());
	var iframe = $('<iframe height="200" width="100" src="javascript:false;" name="'+iframeId+'" />');
	
	iframe.hide();
	formObj.attr('target', iframeId);
	formObj.attr('action', CONTEXT_APP + '/registro/archivo/registrar');
	formObj.attr("enctype", "multipart/form-data");
	formObj.attr("encoding", "multipart/form-data");
	iframe.appendTo('body');
	
	iframe.load(function(e){
		
		var doc = getDoc(iframe[0]);
		var docRoot = doc.body ? doc.body : doc.documentElement;
		var data = docRoot.innerHTML;
		var jsonDataString;
		var response;
	
		if (data.indexOf("<pre style") > -1) { 
			jsonDataString = data.replace('<pre style="word-wrap: break-word; white-space: pre-wrap;">', '');
			jsonDataString = jsonDataString.replace('</pre>', '');
			
		} else {
			jsonDataString = data.replace('<PRE>', '');
			jsonDataString = jsonDataString.replace('</PRE>', '');
			jsonDataString = jsonDataString.replace('<pre>', '');
			jsonDataString = jsonDataString.replace('</pre>', '');
		}
		response = jQuery.parseJSON(jsonDataString);
		
		if(response.status){
			
			var numArcPostula = response.numArcPostula;
			$("#numArcPostula"+tipArchivo).val(numArcPostula);
			
			if(numArcPostula != null){
				if("FA" == tipArchivo){
					registrarDatosAcademicos();
				}else if("EE" == tipArchivo){
					registrarDatosEstudiosEspecializacion();
				}else if("EL" == tipArchivo){
					registrarDatosExperiencia();
				}else if("Cert" == tipArchivo){
					registrarDatosCertificacion();
				}

			}else{
				mostrarMensaje("Ha ocurrido un error en el registro del archivo de sustento: " + response.message);
			}
		}else{
			mostrarMensaje("Ha ocurrido un error en el registro del archivo de sustento: " + response.message);
		}
		
		
  });
	iframe.hide();
});


function registrarDatosAcademicos(){
	//Registramos y actualizamos la grilla
	
	//damos formato a la fecha
	console.log("es visible:"+$("#fecEgreso").is(':visible'));
	if(!$("#fecEgreso").is(':visible')){
		$("#fecEgreso").val("01/01/0001");//dato default si es que no se visualiza
	}
		
	var formulario = $("#formDatosAcademicos");
	var formArray = formToObject(formulario.serializeArray())
	var data = $.toJSON(formArray);
	var url = CONTEXT_APP+"/registro/formacion/registrar";
	$.blockUI();
	$("#btnRegistrarDatosAcademicos").prop('disabled', true);
	
	
    $.ajax({
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){
        	   $.unblockUI();
        	   $("#btnRegistrarDatosAcademicos").prop('disabled', false);
        	   if(validaSesion(resultado)){
        		   if(resultado.fichaActualizada==1){
	        		   bootbox.alert("Ficha Actualizada.");
	        		   $("#divDatosAcademicosPopup").modal('hide');
	        		   $('#formDatosAcademicos').trigger("reset");
	        		   recargarGrillaDatosAcademicos();
	        	   }else{	        		   
	        		   if (resultado.mensajeError.length >0 ){
	        			   alert(resultado.mensajeError);
	        		   }else {
	        			   alert("Se encontraron errores...");   
	        		   }	        		   
	        	   }   
        	   }
           }
   });
}


function registrarDatosCertificacion(){
	//Registramos y actualizamos la grilla
	var formulario = $("#formDatosCertificacion");
	var formArray = formToObject(formulario.serializeArray())
	var data = $.toJSON(formArray);
	var url = CONTEXT_APP+"/registro/estudios/registrar";
    $.ajax({
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){
        	   if(validaSesion(resultado)){
        		   if(resultado.fichaActualizada==1){
	        		   bootbox.alert("Ficha Actualizada.");
	        		   $("#divDatosCertificacionPopup").modal('hide');
	        		   $('#formDatosCertificacion').trigger("reset");
	        		   recargarGrillaCertificacion();
	        	   }else{
	        		   alert("Se encontraron errores...");
	        	   }   
        	   }
           }
   });
}


function registrarDatosEstudiosEspecializacion(){
	//Registramos y actualizamos la grilla
	var formulario = $("#formDatosEstudiosEspecializacion");
	var formArray = formToObject(formulario.serializeArray())
	var data = $.toJSON(formArray);
	var url = CONTEXT_APP+"/registro/estudios/registrar";
    $.ajax({
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){        	
        	   if(validaSesion(resultado)){
        		   if(resultado.fichaActualizada==1){
	        		   bootbox.alert("Ficha Actualizada.");
	        		   $("#divDatosEstudiosEspecializacionPopup").modal('hide');
	        		   $('#formDatosEstudiosEspecializacion').trigger("reset");
	        		   recargarGrillaEstudiosEspecializacion();
	        	   }else{
	        		   alert("Se encontraron errores...");
	        	   }   
        	   }
           }
   });
}

function registrarDatosExperiencia(){
	//Registramos y actualizamos la grilla
	
	
	//modificamos l
	var desLabores = $("#desLabores").val();//formateamos el valor
	//desLabores = desLabores.replace(/\W+/g,'');
	//$("#desLabores").val(JSON.stringify(desLabores));
	
	var formulario = $("#formDatosExperiencia");
	var formArray = formToObject(formulario.serializeArray())
	var data = $.toJSON(formArray);
	var url = CONTEXT_APP+"/registro/experiencia/registrar";
	
	$.blockUI();
	$("#btnRegistrarExperienciaLaboral").prop('disabled', true);
	
	
	
    $.ajax({
           type: "POST",
           url: url,
           dataType: 'json',	
           data: data, 
           contentType: "application/json; charset=utf-8",
           success: function(resultado){
        	   $.unblockUI();
        	   $("#btnRegistrarExperienciaLaboral").prop('disabled', false);
        	   if(validaSesion(resultado)){
        		   if(resultado.fichaActualizada==1){
	        		   bootbox.alert("Ficha Actualizada.");
	        		   $("#divDatosExperienciaLaboralPopup").modal('hide');
	        		   recargarGrillaExperienciaLaboral();
	        	   }else{
	        		   alert("Se encontraron errores...");
	        	   }   
        	   }
           }
   });
}

/*------------------------------ DESCARGAR ----------------------------*/
function onClickDescargarDocumentoSustento(numArcPostula){
	if(numArcPostula==null){
		mostrarMensaje("No se adjuntó ningún archivo.");
	}else{
		$("#numArcPostulaDownload").val(numArcPostula);
		$("#frmArchivoDownload").submit();
	}
	
}
