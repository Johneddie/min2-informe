package pe.gob.sunat.recurso2.humano.seleccion.web.controller;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import pe.gob.sunat.framework.spring.web.view.JsonView;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.ArchivoPostulacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Ficha;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaConocimiento;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEducacion;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaEspecialidad;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.FichaExperiencia;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Parametro;
import pe.gob.sunat.recurso2.humano.seleccion.model.beans.Postulacion;
import pe.gob.sunat.recurso2.humano.seleccion.service.AccesoPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.BandejaPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.service.CatalogoService;
import pe.gob.sunat.recurso2.humano.seleccion.service.RegistroPostulacionService;
import pe.gob.sunat.recurso2.humano.seleccion.util.Constantes;
import pe.gob.sunat.recurso2.humano.seleccion.util.FechasUtil;
import pe.gob.sunat.recurso2.humano.seleccion.util.Internet;

@Internet
@Controller
@RequestMapping(value="/registro")
public class RegistroPostulacionController {
	
	public final Log log = LogFactory.getLog(getClass());

	@Autowired
	@Qualifier("registroPostulacionService")
	private RegistroPostulacionService registroPostulacionService;
	
	@Autowired
	@Qualifier("catalogoService")
	private CatalogoService catalogoService;
	
	@Autowired
	@Qualifier("bandejaPostulacionService")
	private BandejaPostulacionService bandejaPostulacionService;
	
	@Autowired
	@Qualifier("accesoPostulacionService")
	private AccesoPostulacionService accesoPostulacionService;
	
	@Autowired
	FileSystemResource uploadTempDirResource;
	
	@Autowired
	private JsonView jsonView;
	
	@Value("${aplicacion.version}")
	private String version;
	
	@Value("${aplicacion.buildTime}")
	private String buildTime;
	
	
	/**
	 * Visualiza la p�gina de registro del postulante
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request,
			HttpServletResponse response) {
		log.info("inhabilitando la sesion.");
		request.getSession().invalidate();
		return new ModelAndView("acceso/logout");
	}
	
	
	@RequestMapping(value = "/ping", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> ping(HttpServletRequest request,
			HttpServletResponse response) {
		//Aqu� debemos de refrescar
		Map<String, Object> respuesta = new HashMap<>();
		respuesta.put("TOKPOSTULACION", FechasUtil.getStringToken(new Date()));//por default es una sesion valida.
		return respuesta;
	}
	
	
	/**
	 * Visualiza la p�gina de registro del postulante
	 * @return ModelAndView, p�gina hacia la cual se redirige esta solicitud
	 * */
	@RequestMapping("/inicio")
	public ModelAndView iniciarRegistro(HttpServletRequest request,
			HttpServletResponse response) {
		log.info("Ingresando a la p�gina de inicio de autenticacion al postulante.");
		
		if(request.getParameter("numPostulante")==null){
			return new ModelAndView("acceso/loginForm");
		}
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		
		Map<String,Object> parametros = new HashMap<>();
		parametros.put("departamentos", catalogoService.listarDepartamentos());
		parametros.put("vias", catalogoService.listarViasDomiciliarias());
		parametros.put("zonas", catalogoService.listarZonasDomiciliarias());
		
		//parametros.put("grados", catalogoService.listarGradosAcademicos());
		parametros.put("profesiones", catalogoService.listarProfesiones()); 
		parametros.put("centrosEstudio", catalogoService.listarCentrosEstudio());
		parametros.put("indicadoresPuesto", catalogoService.listarIndicadoresPuesto());
		parametros.put("motivosCese", catalogoService.listarMotivosCese());
		parametros.put("tiposExperiencia", catalogoService.listarTiposExperiencia());
		parametros.put("tiposBrevete", catalogoService.listarTiposBrevete());
		parametros.put("tiposEstudio", catalogoService.listarTiposEstudio());		
		parametros.put("fechaMaxima", Long.valueOf(FechasUtil.getSoloFechaDesde(new Date()).getTime()));
		parametros.put("fechaMaximaString", FechasUtil.getStringFromDate(new Date()));
		
		Parametro mensajeInicio = catalogoService.getMensajeInicio();
		if(mensajeInicio!=null) {
			parametros.put("mensajeInicio", mensajeInicio);	
		}
		
		//Convocatorias...
		parametros.putAll(bandejaPostulacionService.listarPreguntasDeclaracionJurada()); //
		parametros.putAll(bandejaPostulacionService.listarRespuestasDeclaracionJurada()); //
		parametros.put("CODIGO_PREG_TIPO_COND_COLEG",Constantes.CODIGO_PREG_TIPO_COND_COLEG);
		parametros.put("CODIGO_PREG_TIPO_TIP_DISCAP",Constantes.CODIGO_PREG_TIPO_TIP_DISCAP);
		parametros.put("CODIGO_PREG_TIPO_MOD_FORM",Constantes.CODIGO_PREG_TIPO_MOD_FORM);
		parametros.put("CODIGO_PREG_DISCAP",Constantes.CODIGO_PREG_DISCAP);
		parametros.put("CODIGO_PREG_MOD_FORM",Constantes.CODIGO_PREG_MOD_FORM);
		parametros.put("CODIGO_PREG_FAMI",Constantes.CODIGO_PREG_FAMI);
		parametros.put("CODIGO_PREG_CUMPLE_CONOCIMIENTOS",Constantes.CODIGO_PREG_CUMPLE_CONOCIMIENTOS);
		
		//sacamos los datos de la ficha relacionada al usaurio
		Ficha fichaBD = registroPostulacionService.getFichaDatos(numPostulante);
		if(fichaBD!=null){
			parametros.put("ficha", fichaBD);
		}else{
			//Si la ficha no existe la registramos.
			Ficha fichaNew = new Ficha();
			fichaNew.setNumPostulante(numPostulante);
			registroPostulacionService.registrarActualizarFichaDatos(fichaNew);
		}
		
		parametros.put("usuario",accesoPostulacionService.getUsuarioPorId(numPostulante));
		parametros.put("numPostulante",numPostulante);
		parametros.put("TOKPOSTULACION",FechasUtil.getStringToken(new Date()));//fecha en el formato DDMMYYYYHHMMSS
		
		parametros.put("version", version);
		parametros.put("buildTime", buildTime);
		
		return new ModelAndView("registro/postulanteForm",parametros);
	}
	
	
	@RequestMapping(value = "/ficha", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> actualizarFicha(@RequestBody Ficha fichaRequest)  {
		log.info("Registrando/actualizando ficha....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 0);
		
		if(registroPostulacionService.registrarActualizarFichaDatos(fichaRequest)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	@RequestMapping(value = "/formacion/centrosEstudio", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarCentrosEstudio()  {
		log.info("Listando centros de estudio....");
		return catalogoService.listarCentrosEstudio();
	}
	
	
	@RequestMapping(value = "/formacion/carreras", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarCarreras(@RequestParam("codTipoEstudio") String codTipoEstudio)  {
		log.info("Listando carreras....");
		return catalogoService.listarCarreras(codTipoEstudio);
	}
	
	
	@RequestMapping(value = "/formacion/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> actualizarDatosAcademicos(@RequestBody FichaEducacion fichaRequest)  {
		log.info("Registrando/actualizando ficha con los datos acad�micos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 0);
		if(registroPostulacionService.registrarEducacion(fichaRequest)){
			respuesta.put("fichaActualizada", 1);
			respuesta.put("numIdAcadem", fichaRequest.getNumIdAcadem());			
		} else {
			respuesta.put("mensajeError", fichaRequest.getMensajeError());
		}
		return respuesta;
	}
	
	
	@RequestMapping(value = "/formacion/borrar/{numIdAcadem}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> borrarDatosAcademicos(@PathVariable("numIdAcadem") Integer numIdAcadem)  {
		log.info("Borrando registro de datos acad�micos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 1);
		if(registroPostulacionService.borrarDatosEducativos(numIdAcadem)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	//Lista los datos acad�micos del postulante
	@RequestMapping(value = "/formacion/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaEducacion> listarDatosAcademicos(HttpServletRequest request,HttpServletResponse response)  {
		log.info("Listando los datos acad�micos ficha con los datos acad�micos....");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarDatosEducativos(numPostulante);
	}
	
	
	@RequestMapping(value = "/formacion/niveles", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarNiveles(@RequestParam("codTipoEstudio") String codTipoEstudio)  {
		log.info("Listando niveles....");
		return catalogoService.listarNivelEstudio(codTipoEstudio);
	}
	
	
	@RequestMapping(value = "/formacion/ciclos", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarCiclos(@RequestParam("codTipoEstudio") String codTipoEstudio,@RequestParam("codNivel") String codNivel)  {
		log.info("Listando niveles....");
		return catalogoService.listarCiclos(codTipoEstudio,codNivel);
	}
	
	
	@RequestMapping(value = "/formacion/tipoconocimiento", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarTipoConocimiento(@RequestParam("codTipoConocimiento") String codTipoConocimiento )  {
		log.info("Entrando Formacion Conocimientos ....");	
		return catalogoService.listaTipoConocimiento(codTipoConocimiento);				
	}
	
	@RequestMapping(value = "/contecnico/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> actualizarConocimientoTecnico(@RequestBody FichaConocimiento fichaRequest)  {
		log.info("Registrando/actualizando ficha con los conocimientos tecnicos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 0);
		if(registroPostulacionService.registrarConocimientoTecnico(fichaRequest)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	@RequestMapping(value = "/contecnico/borrar/{numIdConocimient}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> borrarConocimientoTecnico(@PathVariable("numIdConocimient") Integer numIdConocimient)  {
		log.info("Borrando registro de conocimientos tecnicos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 1);
		if(registroPostulacionService.borrarConocimientoTecnico(numIdConocimient)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	//Lista los datos acad�micos del postulante
	@RequestMapping(value = "/contecnico/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaConocimiento> listarConocimientosTecnicos(HttpServletRequest request,HttpServletResponse response)  {
		log.info("Listando los conocimientos tecnicos....");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarConocimientosTecnicos(numPostulante);
	}
	
	
	//Lista los datos acad�micos del postulante
	@RequestMapping(value = "/contecnico/listarinformaticos", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaConocimiento> listarConocimientosInformaticos(HttpServletRequest request,HttpServletResponse response)  {
		log.info("Listando los conocimientos informaticos....");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarConocimientosInformaticos(numPostulante);
	}

	@RequestMapping(value = "/contecnico/listarconocimiento", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaConocimiento> listarconocimiento (HttpServletRequest request,HttpServletResponse response)  {	
		log.info("Listando los conocimientos....");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarConocimiento(numPostulante);
	}
	
	@RequestMapping(value = "/estudios/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> actualizarEstudiosEspecializacion(@RequestBody FichaEspecialidad fichaRequest)  {
		log.info("Registrando/actualizando estudios de especializacion....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 0);
		if(registroPostulacionService.registrarEstudioEspecializacion(fichaRequest)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	@RequestMapping(value = "/estudios/borrar/{numId}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> borrarEstudiosEspecializacion(@PathVariable("numId") Integer numId)  {
		log.info("Borrando registro de conocimientos tecnicos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 1);
		if(registroPostulacionService.borrarEstudioEspecializacion(numId)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	//Lista los datos acad�micos del postulante
	@RequestMapping(value = "/estudios/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaEspecialidad> listarEstudiosEspecializacion(@RequestParam("indCertificacion") String indCertificacion,
			HttpServletRequest request,HttpServletResponse response)  {
		log.info("Listando los conocimientos tecnicos....");
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarEstudiosEspecializacion(numPostulante,indCertificacion);
	}
	
	
	@RequestMapping(value = "/experiencia/contratos", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarContratos(@RequestParam("tipoContrato") String codTipoContrato)  {
		log.info("Listando tipos de contrato....");
		if("1".equals(codTipoContrato))return catalogoService.listarContratosPublicos();
		else if("2".equals(codTipoContrato))return catalogoService.listarContratosPrivados();
		return new ArrayList<>(); 
	}
	
	@RequestMapping(value = "/experiencia/registrar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> actualizarExperienciaLaboral(@RequestBody FichaExperiencia fichaRequest)  {
		log.info("Registrando/actualizando experiencia laboral....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 0);
		
		String funciones = fichaRequest.getDesLabores();
		funciones = funciones.replaceAll("[^\\x00-\\xFF]", "");
		fichaRequest.setDesLabores(funciones);
		
		if(registroPostulacionService.registrarExperienciaLaboral(fichaRequest)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	@RequestMapping(value = "/experiencia/borrar/{numId}", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Map<String,Object> borrarExperienciaLaboral(@PathVariable("numId") Integer numId)  {
		log.info("Borrando registro de conocimientos tecnicos....");
		Map<String,Object> respuesta = new HashMap<>();
		respuesta.put("fichaActualizada", 1);
		if(registroPostulacionService.borrarExperienciaLaboral(numId)){
			respuesta.put("fichaActualizada", 1);	
		}
		return respuesta;
	}
	
	
	//Lista los datos acad�micos del postulante
	@RequestMapping(value = "/experiencia/listar", method=RequestMethod.POST,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<FichaExperiencia> listarExperienciaLaboral(HttpServletRequest request,HttpServletResponse response)  {
		log.info("Listando la experiencia laboral....");
		
		String numPostulanteString = request.getParameter("numPostulante");
		log.info("postulante string:"+numPostulanteString);
		Integer numPostulante = new Integer(request.getParameter("numPostulante"));
		return registroPostulacionService.listarExperienciaLaboral(numPostulante);
	}
	
	
	
	

	@RequestMapping(value = "/departamentos/{codDepartamento}/provincias", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarProvincias(@PathVariable("codDepartamento") String codDepartamento)  {
		log.info("Listando provincias....");
		return catalogoService.listarProvincias(codDepartamento);
	}
	
	
	@RequestMapping(value = "/provincias/{codProvincia}/distritos", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<Parametro> listarDistritos(@PathVariable("codProvincia") String codProvincia)  {
		log.info("Listando distritos....");
		return catalogoService.listarDistritos(codProvincia);
	}
	
	@RequestMapping(value = "/archivo/validar", method=RequestMethod.POST)
	public ModelAndView validarArchivo(HttpServletRequest request, HttpServletResponse response) {
		if (log.isDebugEnabled()) log.debug("method validarArchivo");

		ModelAndView hmModelo = new ModelAndView(jsonView);
		MultipartHttpServletRequest multipartRequest = null;
		MultipartFile multipartFile = null;
		double tamanoPermitido = 0;
		double tamanoPermitidoMsj = Constantes.MAX_SIZE_FILE_UPLOAD_MEGAS;
		int longitudnombrearchivo = 0;

		try {
			String tipArchivoValidar = request.getParameter("tipArchivoValidar");
			multipartRequest = (MultipartHttpServletRequest) request;
			multipartFile = multipartRequest.getFile("docFisico" + tipArchivoValidar);
			tamanoPermitido = tamanoPermitidoMsj * 1048576;
			
			String nombreArchivo = multipartFile.getOriginalFilename();
			String[] listaSeparada = nombreArchivo.split("\\.");
			Integer num = listaSeparada.length;
			String extensionArchivo = listaSeparada[num - 1].toLowerCase();
			
			
			//tama�o de archivo
			if (multipartFile.getSize() <= tamanoPermitido) {
				hmModelo.addObject("tamanoArchivoSuperado", false);
			} else {
				hmModelo.addObject("tamanoArchivoSuperado", true);
				hmModelo.addObject("tamanoArchivoPermitido", tamanoPermitidoMsj);
			}

			//nombre de archivo
			longitudnombrearchivo = Constantes.LONGITUD_MAXIMA_ARCHIVOCARGA;
			if (nombreArchivo.length() > longitudnombrearchivo) {
				hmModelo.addObject("longitudnombrearchivo", false);
			} else {
				hmModelo.addObject("longitudnombrearchivo", true);
			}

			//extensiones
			String[] tipos = {"pdf"};
			List<String> lstExtensiones = new ArrayList<>(Arrays.asList(tipos)); 
			StringBuilder validaPatron = new StringBuilder();
			if (!lstExtensiones.isEmpty()) {
				validaPatron.append("(");
				for (String e : lstExtensiones) {
					validaPatron.append(e.concat("|"));
				}
				validaPatron = validaPatron.deleteCharAt(validaPatron.length() - 1);
				validaPatron.append(")");
			}
			Pattern patron = Pattern.compile(validaPatron.toString());
			Matcher matcher = patron.matcher(extensionArchivo);

			if (matcher.matches()) {
				hmModelo.addObject("extensionPermitida", true);
			} else {
				hmModelo.addObject("extensionPermitida", false);
			}

		} catch (Exception ex) {
			log.error("Ha ocurrido un error en validarArchivo: " + ex.getMessage(), ex);

		} finally {
			if (log.isDebugEnabled()) log.debug("Final - ReaperturaExpedienteVirtualController.validarArchivo");
		}
		return hmModelo;
	}
	
	@RequestMapping(value = "/archivo/registrar", method=RequestMethod.POST)
	public ModelAndView registrarArchivo(HttpServletRequest request, HttpServletResponse response){
		if (log.isDebugEnabled()) log.debug("method registrarArchivo");
        
		ModelAndView hmModelo = new ModelAndView(jsonView);
        MultipartHttpServletRequest multipartRequest = null;
        MultipartFile archivo = null;
        try {
        	String tipArchivoUpload = request.getParameter("tipArchivoUpload");
        	
			multipartRequest = (MultipartHttpServletRequest) request;
			archivo = multipartRequest.getFile("docFisico" + tipArchivoUpload);
			
        	String nomArchivo = request.getParameter("nomArchivoUpload");
			Integer numPostulante = Integer.parseInt(request.getParameter("numPostulanteUpload"));
			
			Integer numArcPostula = registroPostulacionService.registrarArchivo(nomArchivo, numPostulante, archivo.getBytes());
			hmModelo.addObject("status", true);
			hmModelo.addObject("numArcPostula", numArcPostula);
			
        } catch (Exception ex) {                
            log.error("Ha ocurrido un error en registrarArchivo: " + ex.getMessage(), ex);
            hmModelo.addObject("status", false);
            hmModelo.addObject("message",ex.getMessage());
     } finally {                
            if (log.isDebugEnabled()) log.debug("fin registrarArchivo");
     }
     return hmModelo;		
	}
	
	
	@RequestMapping(value="/archivo/descargarDocumentoSustentoPdf", method = {RequestMethod.POST})
	public ModelAndView exportarFormatoPdf(HttpServletRequest request,	HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method generarFormatoPdf");

		try {
			Integer numArcPostula= Integer.parseInt(request.getParameter("numArcPostulaDownload"));
			
			ArchivoPostulacion ap = registroPostulacionService.obtenerArchivoPostulacion(numArcPostula);
			response.setHeader("Content-Disposition", "attachment; filename=\"" + ap.getNomArchivo() + "\"");
			response.setContentType("application/pdf");
			if(ap.getArcPostula() != null)
				response.setContentLength(ap.getArcPostula().length);

			OutputStream out = response.getOutputStream();
			out.write(ap.getArcPostula());
			out.close();
			out.flush();	
		}catch(Exception e) {
			log.debug("Ocurrio una excepcion al exportar a pdf",e);
		}
		
		return new ModelAndView("registro/postulanteForm",null);
	}
	
	
	@RequestMapping(value = "/descargar", method=RequestMethod.GET,produces={MediaType.APPLICATION_JSON_VALUE})
	public void descargarFUPDesdeQR(@RequestParam(value="c",required=false) String codigo, HttpServletResponse response) {
		if(log.isDebugEnabled()) log.debug("method descargarFUPDesdeQR");

		try {
			
			byte[] dataDecodificadaArray = Base64.decodeBase64(codigo);
			String dataDecodificada = new String(dataDecodificadaArray);
			log.debug("data decodificada:"+dataDecodificada);
			String idPostulacion = dataDecodificada.substring(0, 32);
			String[] idPostulacionArray = idPostulacion.split("_");
			Short codCat = new Short(idPostulacionArray[0]);
			String codPuesto = StringUtils.leftPad((new Integer(idPostulacionArray[1])).toString(),3,"0");
			Integer numPostulante = new Integer(idPostulacionArray[2]);
			Postulacion p = bandejaPostulacionService.getPostulacion(codCat, codPuesto, numPostulante);//codCat,codPuesto,numPostulacion
			ArchivoPostulacion ap = registroPostulacionService.obtenerArchivoPostulacion(p.getNumArcFup());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + ap.getNomArchivo() + "\"");
			response.setContentType("application/pdf");
			if(ap.getArcPostula() != null)
				response.setContentLength(ap.getArcPostula().length);

			OutputStream out = response.getOutputStream();
			out.write(ap.getArcPostula());
			out.close();
			out.flush();	
		}catch(Exception e) {
			log.debug("Ocurrio una excepcion al exportar a pdf",e);
		}
		
		
	}

}
