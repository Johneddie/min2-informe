package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteDistribucion;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreo;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreoUnidad;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;

public interface T114evuorgDAO {

	List<Evaluado> listarEvaluados(Evaluado paramSearch);
	void updateByPrimaryKeySelective(Evaluado paramUpdate);
	
	List<ReporteMonitoreo> reporteInstitucional(Map<String,Object> paramSearch);
	List<ReporteMonitoreo> reporteAdjunta(Map<String,Object> paramSearch);
	List<ReporteMonitoreo> reporteOrgano(Map<String,Object> paramSearch);
	List<ReporteMonitoreo> reporteByJerarquiaUnidad(Map<String, Object> paramSearch);

	Map<String,Object> reporteCompetenciasInstitucional(Map<String,Object> paramSearch);
	Map<String,Object> reporteCompetenciasAdjunta(Map<String,Object> paramSearch);
	Map<String,Object> reporteCompetenciasOrgano(Map<String,Object> paramSearch);
	Map<String,Object> reporteCompetenciasJerarquiaUnidad(Map<String,Object> paramSearch);
	
	public List<ReporteMonitoreoUnidad> reporteMonitoreoUnidades(Map<String, Object> paramSearch);
	public ReporteMonitoreoUnidad reporteMonitoreoUnidadesTotales(Map<String, Object> paramSearch);
	
	//evaluación devuelta
	Integer contarEvaluados(Evaluado paramSearch);
	Evaluado obtenerEvaluado(Evaluado paramSearch);
	List<Evaluado> listarEvaluadosDevueltos(Evaluado paramSearch);
	//evaluación devuelta fin 
	
	List<ReporteDistribucion> reporteDistribucionByGrupo(Map<String, Object> paramSearch);
}
