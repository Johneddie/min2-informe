package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;

public interface T01paramDAO {

	Parametro selectByPrimaryKey(String codParametro, String codDataParametro);
	public List<Parametro> listarPorParametros(Parametro params);
	
}
