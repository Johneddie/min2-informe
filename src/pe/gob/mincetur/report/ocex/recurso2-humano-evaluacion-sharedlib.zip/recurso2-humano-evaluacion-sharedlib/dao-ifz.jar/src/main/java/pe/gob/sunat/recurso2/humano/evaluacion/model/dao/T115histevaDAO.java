package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.HashMap;
import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;

@SuppressWarnings("rawtypes")
public interface T115histevaDAO {

	Periodo selectByPrimaryKey(Periodo periodoSearch);
	List<Periodo> listByParameter(Periodo periodoSearch);
	public List<Periodo> listByEstados(HashMap params);
	
}
