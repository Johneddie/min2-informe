package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.model.RendimientoDetalle;

public interface T110notaindDAO {

	RendimientoDetalle selectByPrimaryKey(RendimientoDetalle paramSearch);
	List<RendimientoDetalle> listByParameter(RendimientoDetalle paramSearch);
	void insertSelective(RendimientoDetalle paramInsert);
	void updateByPrimaryKeySelective(RendimientoDetalle paramUpdate);
	
}
