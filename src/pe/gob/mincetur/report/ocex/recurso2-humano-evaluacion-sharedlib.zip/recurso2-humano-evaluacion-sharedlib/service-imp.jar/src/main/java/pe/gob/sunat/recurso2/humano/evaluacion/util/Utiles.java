package pe.gob.sunat.recurso2.humano.evaluacion.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class Utiles{
	
	private Utiles() {
		
	}

	public static Map<String, String> obtenerMapFromParameterMap(Map<String, String[]> arrayMap){
		  Map<String, String> r = new HashMap<String, String>();
		  for (Map.Entry<String, String[]> entry: arrayMap.entrySet()){
		    String[] value = entry.getValue();
		    if (value !=null && value .length>0) r.put(entry.getKey(), value[0]);
		  }
		  return r;
	}

	public static String convertirFechaTexto(Date fecha){
		String strFecha = "";
		if(fecha != null){
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			try{
				strFecha = format.format(fecha);
			}catch(Exception e){
				//error
			}
		}
		return strFecha;
	}
	
}
