package pe.gob.sunat.recurso2.humano.evaluacion.util;

public class Constantes {

	public final static String PERIODO_INICIADO = "I";
	public final static String PERIODO_NUEVO = "N";
	public final static String PERIODO_GENERADO = "G";
	public final static String PERIODO_CERRADO = "C";
	public final static String PERIODO_NIVEL_ESPERADO = "E";
	
	public final static String PARAMETRO_CARGOS = "001";//t99codigos
	public final static String PARAMETRO_GRUPOS = "005";//t99codigos
	
	public final static String PARAMETRO_CONDICION_EVALUADO = "RL1";//t01param
	public final static String PARAMETRO_ESTADO_EVALUACION = "RL2";//t01param
	public final static String PARAMETRO_CONDICION_NOTIFICADO = "RLF";//t01param
	public final static String PARAMETRO_TIPOS_ACCION = "RLG";//t01param
	
	
	public final static String CONDICION_NO_EVALUADO = "0";
	public final static String CONDICION_ERROR_TRANSFERENCIA = "0"; 
	public final static String CONDICION_EVALUADO = "E";
	public final static String CONDICION_INCOMPLETO = "I";
	public final static String CONDICION_CONFORME = "C";
	public final static String CONDICION_OBSERVADO = "O";
	public final static String CONDICION_TRANSFERIDO = "T";
	public final static String CONDICION_APELADO = "A";
	public final static String CONDICION_EN_REVISION = "V";
	public final static String CONDICION_EN_RECLAMO = "R";
	
	public final static String ESTADO_COMPORTAMIENTO_ACTIVO = "1";
	public final static String ESTADO_COMPORTAMIENTO_INACTIVO = "0";
	
	public final static String INDICADOR_BORRADO_INACTIVO = "0";
	public final static String INDICADOR_BORRADO_ACTIVO = "1";
	
	public final static String TIPO_FACTOR_COMPETENCIA = "1";
	public final static String TIPO_FACTOR_COMPORTAMIENTO = "2";
	
	public final static String TIPO_EVALUADOR = "01";
	public final static String TIPO_REVISOR = "02";
	
	public final static String CODIGO_GRUPO_I = "20";
	public final static String CODIGO_GRUPO_II = "21";
	public final static String CODIGO_GRUPO_III = "22";
	public final static String CODIGO_GRUPO_GEN = "30";
	
	public final static String CODIGO_GRUPO_I_COMPROMISO = "2001";
	public final static String CODIGO_GRUPO_I_VOCACION = "2002";
	public final static String CODIGO_GRUPO_I_TRABAJO_EQUIPO = "2003";
	public final static String CODIGO_GRUPO_I_ORIENTACION_RESULTADOS = "2004";
	
	public final static String CODIGO_GRUPO_II_LIDERAZGO = "2101";
	public final static String CODIGO_GRUPO_II_DIRECCION = "2102";
	public final static String CODIGO_GRUPO_II_TOMA_DECISIONES = "2103";
	
	public final static String CODIGO_GRUPO_III_LIDERAZGO = "2201";
	public final static String CODIGO_GRUPO_III_DIRECCION = "2202";
	public final static String CODIGO_GRUPO_III_TOMA_DECISIONES = "2203";
	
	public final static String CONTROL_EVALUADOR = "E";
	public final static String CONTROL_REVISOR = "EE";
	
	public final static String ERROR_NO_PRIVILEGIOS = "Ud. no tiene los privilegios para realizar este tipo de consultas.";
	public final static String ERROR_NO_PERIODOS = "No se ha iniciado el periodo de evaluación. Favor de consultar con su analista.";
	public final static String ERROR_CERRADOS = "No se ha encontrado algún periodo activo. Favor de consultar con su analista.";
	public final static String ERROR_NO_REGISTROS = "No se encontraron registros.";
	
	public final static String RPT_YES = "YES";
	public final static String RPT_NO = "NO";
	
	public final static String LISTA_ENVIADA_VALIDAR = "4";
	public final static String LISTA_VALIDADA = "5";
	public final static String LISTA_ENVIADA = "5";
	
	public final static String ACCION_ENCARGO_AUSENCIA = "F3";
	
	public final static String NIVEL_ORG_0 = "N0";	//institucional
	public final static String NIVEL_ORG_1 = "N1";	//adjunta
	public final static String NIVEL_ORG_2 = "N2";	//órgano
	public final static String NIVEL_ORG_3 = "N3";	//órgano
	public final static String NIVEL_ORG_4 = "N4";	//gerencia
	public final static String NIVEL_ORG_5 = "N5";	//división
	
	public final static String ESTADO_EVALUADO_INACTIVO = "0";
	public final static String ESTADO_EVALUADO_ACTIVO = "1";

	public final static String ASUNTO_CORREO = "Evaluaci�n 2018 - Comunicaci�n del Nivel Esperado";//Registro de Evaluaci�n   
	public final static String MENSAJE_CORREO = "Se ha registrado su formato de evaluaci�n.";
	
	public final static String ESTADO_INACTIVO = "0";
	public final static String ESTADO_ACTIVO = "1";
	
	public final static String INDICADOR_NO_ELIM = "0";
	public final static String INDICADOR_ELIM = "1";
	
}
