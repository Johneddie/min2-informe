package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteDistribucion;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreo;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreoUnidad;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114evuorgDAO;

@SuppressWarnings("unchecked")
public class SqlMapT114evuorgDAO extends SqlMapClientDaoSupport implements T114evuorgDAO{

	@Override
	public List<Evaluado> listarEvaluados(
			Evaluado paramSearch) {
		return (List<Evaluado>)getSqlMapClientTemplate().queryForList("T114evuorg.listarEvaluados", paramSearch);
	}
	
	@Override
	public void updateByPrimaryKeySelective(Evaluado paramUpdate) {
		getSqlMapClientTemplate().update("T114evuorg.updateByPrimaryKeySelective", paramUpdate);
	}

	@Override
	public List<ReporteMonitoreo> reporteInstitucional(
			Map<String, Object> paramSearch) {
		return (List<ReporteMonitoreo>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteMonitoreoInstitucional", paramSearch);
	}

	@Override
	public List<ReporteMonitoreo> reporteAdjunta(Map<String, Object> paramSearch) {
		return (List<ReporteMonitoreo>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteMonitoreoAdjunta", paramSearch);
	}

	@Override
	public List<ReporteMonitoreo> reporteOrgano(Map<String, Object> paramSearch) {
		return (List<ReporteMonitoreo>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteMonitoreoOrgano", paramSearch);
	}
	
	@Override
	public List<ReporteMonitoreo> reporteByJerarquiaUnidad(Map<String, Object> paramSearch) {
		return (List<ReporteMonitoreo>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteByJerarquiaUnidad", paramSearch);
	}

	@Override
	public Map<String, Object> reporteCompetenciasInstitucional(
			Map<String, Object> paramSearch) {
		return (Map<String,Object>)getSqlMapClientTemplate().queryForObject("T114evuorg.reporteCompetenciasInstitucional", paramSearch);
	}
	
	@Override
	public Map<String, Object> reporteCompetenciasAdjunta(
			Map<String, Object> paramSearch) {
		return (Map<String,Object>)getSqlMapClientTemplate().queryForObject("T114evuorg.reporteCompetenciasAdjunta", paramSearch);
	}
	
	@Override
	public Map<String, Object> reporteCompetenciasOrgano(
			Map<String, Object> paramSearch) {
		return (Map<String,Object>)getSqlMapClientTemplate().queryForObject("T114evuorg.reporteCompetenciasOrgano", paramSearch);
	}
	
	@Override
	public Map<String, Object> reporteCompetenciasJerarquiaUnidad(
			Map<String, Object> paramSearch) {
		return (Map<String,Object>)getSqlMapClientTemplate().queryForObject("T114evuorg.reporteCompetenciasJerarquiaUnidad", paramSearch);
	}
	
	
	@Override
	public List<ReporteMonitoreoUnidad> reporteMonitoreoUnidades(
			Map<String, Object> paramSearch) {
		return (List<ReporteMonitoreoUnidad>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteMonitoreoUnidades", paramSearch);
	}
	
	@Override
	public ReporteMonitoreoUnidad reporteMonitoreoUnidadesTotales(
			Map<String, Object> paramSearch) {
		return (ReporteMonitoreoUnidad)getSqlMapClientTemplate().queryForObject("T114evuorg.reporteMonitoreoUnidadesTotales", paramSearch);
	}
	
	//evaluación devuelta
	
	@Override
	public Integer contarEvaluados(Evaluado paramSearch) {
		return (Integer)getSqlMapClientTemplate().queryForObject("T114evuorg.contarEvaluados", paramSearch);
	}
	
	@Override
	public Evaluado obtenerEvaluado(Evaluado paramSearch) {
		return (Evaluado)getSqlMapClientTemplate().queryForObject("T114evuorg.obtenerEvaluado", paramSearch);
	}
	
	@Override
	public List<Evaluado> listarEvaluadosDevueltos(Evaluado paramSearch) {
		return (List<Evaluado>)getSqlMapClientTemplate().queryForList("T114evuorg.listarEvaluadosDevueltos", paramSearch);
	}
	//evaluación devuelta fin
	
	//reporte distribución
	
	@Override
	public List<ReporteDistribucion> reporteDistribucionByGrupo(Map<String, Object> paramSearch) {
		return (List<ReporteDistribucion>)getSqlMapClientTemplate().queryForList("T114evuorg.reporteDistribucionByGrupo", paramSearch);
	}

}
