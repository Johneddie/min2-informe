package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;

public interface T02perdpDAO {

	Evaluado selectByPrimaryKey(Evaluado paramSearch);
	public String obtenerNombreCompleto(String paramSearch);
	
}
