package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoEvalExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoEvalExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected ArchivoEvalExample(ArchivoEvalExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumArchivoIsNull() {
            addCriterion("num_archivo is null");
            return this;
        }

        public Criteria andNumArchivoIsNotNull() {
            addCriterion("num_archivo is not null");
            return this;
        }

        public Criteria andNumArchivoEqualTo(Integer value) {
            addCriterion("num_archivo =", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotEqualTo(Integer value) {
            addCriterion("num_archivo <>", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThan(Integer value) {
            addCriterion("num_archivo >", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_archivo >=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThan(Integer value) {
            addCriterion("num_archivo <", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoLessThanOrEqualTo(Integer value) {
            addCriterion("num_archivo <=", value, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoIn(List<Integer> values) {
            addCriterion("num_archivo in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotIn(List<Integer> values) {
            addCriterion("num_archivo not in", values, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andNumArchivoNotBetween(Integer value1, Integer value2) {
            addCriterion("num_archivo not between", value1, value2, "numArchivo");
            return this;
        }

        public Criteria andNomArchivoIsNull() {
            addCriterion("nom_archivo is null");
            return this;
        }

        public Criteria andNomArchivoIsNotNull() {
            addCriterion("nom_archivo is not null");
            return this;
        }

        public Criteria andNomArchivoEqualTo(String value) {
            addCriterion("nom_archivo =", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotEqualTo(String value) {
            addCriterion("nom_archivo <>", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoGreaterThan(String value) {
            addCriterion("nom_archivo >", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoGreaterThanOrEqualTo(String value) {
            addCriterion("nom_archivo >=", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLessThan(String value) {
            addCriterion("nom_archivo <", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLessThanOrEqualTo(String value) {
            addCriterion("nom_archivo <=", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoLike(String value) {
            addCriterion("nom_archivo like", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotLike(String value) {
            addCriterion("nom_archivo not like", value, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoIn(List<String> values) {
            addCriterion("nom_archivo in", values, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotIn(List<String> values) {
            addCriterion("nom_archivo not in", values, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoBetween(String value1, String value2) {
            addCriterion("nom_archivo between", value1, value2, "nomArchivo");
            return this;
        }

        public Criteria andNomArchivoNotBetween(String value1, String value2) {
            addCriterion("nom_archivo not between", value1, value2, "nomArchivo");
            return this;
        }

        public Criteria andNumTamanoIsNull() {
            addCriterion("num_tamano is null");
            return this;
        }

        public Criteria andNumTamanoIsNotNull() {
            addCriterion("num_tamano is not null");
            return this;
        }

        public Criteria andNumTamanoEqualTo(Integer value) {
            addCriterion("num_tamano =", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoNotEqualTo(Integer value) {
            addCriterion("num_tamano <>", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoGreaterThan(Integer value) {
            addCriterion("num_tamano >", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_tamano >=", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoLessThan(Integer value) {
            addCriterion("num_tamano <", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoLessThanOrEqualTo(Integer value) {
            addCriterion("num_tamano <=", value, "numTamano");
            return this;
        }

        public Criteria andNumTamanoIn(List<Integer> values) {
            addCriterion("num_tamano in", values, "numTamano");
            return this;
        }

        public Criteria andNumTamanoNotIn(List<Integer> values) {
            addCriterion("num_tamano not in", values, "numTamano");
            return this;
        }

        public Criteria andNumTamanoBetween(Integer value1, Integer value2) {
            addCriterion("num_tamano between", value1, value2, "numTamano");
            return this;
        }

        public Criteria andNumTamanoNotBetween(Integer value1, Integer value2) {
            addCriterion("num_tamano not between", value1, value2, "numTamano");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}