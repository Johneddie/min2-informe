package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import java.util.Map;

public interface T116jefuorgDAO {

	List<String> listarUnidadesOrganizacionales(Map<String,Object> paramSearch);
	List<String> listarPersonal(Map<String,Object> paramSearch);
	
}
