package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.CorreosDAO;

public class SqlMapCorreosDAO extends SqlMapClientDaoSupport implements CorreosDAO{

	@Override
	public String selectByPrimaryKey(String codPersonal) {
		return (String)getSqlMapClientTemplate().queryForObject("Correos.selectByPrimaryKey", codPersonal);
	}

}
