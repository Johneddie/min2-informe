package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;


import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T1536segEvalDAO;

@SuppressWarnings("deprecation")
public class SqlMapT1536segEvalDAO extends SqlMapClientDaoSupport implements T1536segEvalDAO{

	@Override
	public void insertSelective(Seguimiento paramInsert) {
		getSqlMapClientTemplate().insert("T1536seg_eval.insertSelective", paramInsert);
	}

}
