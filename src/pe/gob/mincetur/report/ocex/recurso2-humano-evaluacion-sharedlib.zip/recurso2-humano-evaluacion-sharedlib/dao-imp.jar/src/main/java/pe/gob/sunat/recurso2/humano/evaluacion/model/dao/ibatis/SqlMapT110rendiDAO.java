package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Rendimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110rendiDAO;

public class SqlMapT110rendiDAO extends SqlMapClientDaoSupport implements T110rendiDAO{

	@Override
	public Rendimiento selectByPrimaryKey(Rendimiento paramSearch) {
		return (Rendimiento)getSqlMapClientTemplate().queryForObject("T110rendi.selectByPrimaryKey", paramSearch);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Rendimiento> listByParameter(Rendimiento paramSearch) {
		return (List<Rendimiento>)getSqlMapClientTemplate().queryForList("T110rendi.listByParameter", paramSearch);
	}

	@Override
	public void insertSelective(Rendimiento paramInsert) {
		getSqlMapClientTemplate().insert("T110rendi.insertSelective", paramInsert);
	}

	@Override
	public void updateByPrimaryKeySelective(Rendimiento paramUpdate) {
		getSqlMapClientTemplate().update("T110rendi.updateByPrimaryKeySelective", paramUpdate);
	}

}
