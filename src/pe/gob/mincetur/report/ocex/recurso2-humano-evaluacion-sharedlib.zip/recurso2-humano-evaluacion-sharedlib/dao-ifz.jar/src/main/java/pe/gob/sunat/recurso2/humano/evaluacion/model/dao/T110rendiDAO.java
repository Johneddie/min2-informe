package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Rendimiento;

public interface T110rendiDAO {

	Rendimiento selectByPrimaryKey(Rendimiento paramSearch);
	List<Rendimiento> listByParameter(Rendimiento paramSearch);
	void insertSelective(Rendimiento paramInsert);
	void updateByPrimaryKeySelective(Rendimiento paramUpdate);
	
}
