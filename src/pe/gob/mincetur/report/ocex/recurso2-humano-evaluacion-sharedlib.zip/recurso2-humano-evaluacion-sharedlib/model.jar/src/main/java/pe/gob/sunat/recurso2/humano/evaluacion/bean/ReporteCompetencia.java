package pe.gob.sunat.recurso2.humano.evaluacion.bean;

import java.math.BigDecimal;

public class ReporteCompetencia {

	private String codCompetencia;
	private String desCompetencia;
	private BigDecimal pjeAvance = BigDecimal.ZERO;
	private BigDecimal cntTotalCompetencia = BigDecimal.ZERO;
	
	public String getDesCompetencia() {
		return desCompetencia;
	}
	public void setDesCompetencia(String desCompetencia) {
		this.desCompetencia = desCompetencia;
	}
	public BigDecimal getPjeAvance() {
		return pjeAvance;
	}
	public void setPjeAvance(BigDecimal pjeAvance) {
		this.pjeAvance = pjeAvance;
	}
	public BigDecimal getCntTotalCompetencia() {
		return cntTotalCompetencia;
	}
	public void setCntTotalCompetencia(BigDecimal cntTotalCompetencia) {
		this.cntTotalCompetencia = cntTotalCompetencia;
	}
	public String getCodCompetencia() {
		return codCompetencia;
	}
	public void setCodCompetencia(String codCompetencia) {
		this.codCompetencia = codCompetencia;
	}
	
}
