package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import java.util.Map;

public interface T11histoDAO {

	List<String> selectAccionesPorEncargatura(Map<String,Object> params);
	
}
