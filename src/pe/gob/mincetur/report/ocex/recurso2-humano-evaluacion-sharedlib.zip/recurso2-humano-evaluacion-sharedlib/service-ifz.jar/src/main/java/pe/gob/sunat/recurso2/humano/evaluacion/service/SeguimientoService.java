package pe.gob.sunat.recurso2.humano.evaluacion.service;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimWithBLOBs;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEval;

public interface SeguimientoService {
	public List<Periodo> listarPeriodosNivelEsperado();
	public List<Comportamiento> listarCriteriosCompetencia(String codCompetencia);
	public List<Comportamiento> listarCompetencias();
	public List<SeguimientoEval> listarSeguimientos(String codPeriodo, String codPersonal);
	public Map<String, Object> registrarAccion(SeguimientoEval seguimiento, AccionSeguimWithBLOBs accion, String usuario);
	public List<AccionSeguimWithBLOBs> listarAcciones(Integer numSeguim);
	
}
