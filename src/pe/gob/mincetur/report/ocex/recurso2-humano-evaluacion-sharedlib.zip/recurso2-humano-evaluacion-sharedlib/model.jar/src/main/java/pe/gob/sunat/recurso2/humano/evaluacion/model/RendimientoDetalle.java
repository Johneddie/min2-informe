package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.math.BigDecimal;
import java.util.Date;

public class RendimientoDetalle {

	private String codPeriodo;
	private String codPersonal;
	private String codTipEvaluador;
	private String codGrupo;
	private String codCompetencia;
	private String codComportamiento;
	private BigDecimal cntNotaComportamiento;
	private String codBorradoLogico;
	private String codRegistroEvaluador;
	private Date fecEvaluacion;
	private Date fecRegistro;
	private String codUsuario;
	
	public String getCodPeriodo() {
		return codPeriodo;
	}
	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}
	public String getCodPersonal() {
		return codPersonal;
	}
	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}
	public String getCodTipEvaluador() {
		return codTipEvaluador;
	}
	public void setCodTipEvaluador(String codTipEvaluador) {
		this.codTipEvaluador = codTipEvaluador;
	}
	public String getCodGrupo() {
		return codGrupo;
	}
	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}
	public String getCodCompetencia() {
		return codCompetencia;
	}
	public void setCodCompetencia(String codCompetencia) {
		this.codCompetencia = codCompetencia;
	}
	public String getCodComportamiento() {
		return codComportamiento;
	}
	public void setCodComportamiento(String codComportamiento) {
		this.codComportamiento = codComportamiento;
	}
	public BigDecimal getCntNotaComportamiento() {
		return cntNotaComportamiento;
	}
	public void setCntNotaComportamiento(BigDecimal cntNotaComportamiento) {
		this.cntNotaComportamiento = cntNotaComportamiento;
	}
	public String getCodRegistroEvaluador() {
		return codRegistroEvaluador;
	}
	public void setCodRegistroEvaluador(String codRegistroEvaluador) {
		this.codRegistroEvaluador = codRegistroEvaluador;
	}
	public Date getFecEvaluacion() {
		return fecEvaluacion;
	}
	public void setFecEvaluacion(Date fecEvaluacion) {
		this.fecEvaluacion = fecEvaluacion;
	}
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getCodBorradoLogico() {
		return codBorradoLogico;
	}
	public void setCodBorradoLogico(String codBorradoLogico) {
		this.codBorradoLogico = codBorradoLogico;
	}
	
}
