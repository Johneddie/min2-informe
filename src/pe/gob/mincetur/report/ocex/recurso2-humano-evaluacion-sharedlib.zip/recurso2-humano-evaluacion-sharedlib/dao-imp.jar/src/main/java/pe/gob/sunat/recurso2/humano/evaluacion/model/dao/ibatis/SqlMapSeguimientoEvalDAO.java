package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEval;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEvalExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.SeguimientoEvalDAO;

public class SqlMapSeguimientoEvalDAO extends SqlMapClientDaoSupport implements SeguimientoEvalDAO {

    public SqlMapSeguimientoEvalDAO() {
        super();
    }

    public int countByExample(SeguimientoEvalExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t9435seguimeval.countByExample", example);
        return count;
    }

    public int deleteByExample(SeguimientoEvalExample example) {
        int rows = getSqlMapClientTemplate().delete("t9435seguimeval.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numSeguim) {
        SeguimientoEval key = new SeguimientoEval();
        key.setNumSeguim(numSeguim);
        int rows = getSqlMapClientTemplate().delete("t9435seguimeval.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(SeguimientoEval record) {
        getSqlMapClientTemplate().insert("t9435seguimeval.insert", record);
    }

    public Integer insertSelective(SeguimientoEval record) {
        return (Integer)getSqlMapClientTemplate().insert("t9435seguimeval.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<SeguimientoEval> selectByExample(SeguimientoEvalExample example) {
        List<SeguimientoEval> list = getSqlMapClientTemplate().queryForList("t9435seguimeval.selectByExample", example);
        return list;
    }

    public SeguimientoEval selectByPrimaryKey(Integer numSeguim) {
        SeguimientoEval key = new SeguimientoEval();
        key.setNumSeguim(numSeguim);
        SeguimientoEval record = (SeguimientoEval) getSqlMapClientTemplate().queryForObject("t9435seguimeval.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(SeguimientoEval record, SeguimientoEvalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9435seguimeval.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(SeguimientoEval record, SeguimientoEvalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9435seguimeval.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(SeguimientoEval record) {
        int rows = getSqlMapClientTemplate().update("t9435seguimeval.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(SeguimientoEval record) {
        int rows = getSqlMapClientTemplate().update("t9435seguimeval.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends SeguimientoEvalExample {
        private Object record;

        public UpdateByExampleParms(Object record, SeguimientoEvalExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}