package pe.gob.sunat.recurso2.humano.evaluacion.bean;

public class ActaComunicacion {

	private String codPeriodo;
	
	//I. Datos del trabajador:
	private String codPersonalEvaluado;
	private String numDniPersonalEvaluado;
	private String desNombreCompletoEvaluado;
	private String codUnidadOrganizacional;
	private String desUnidadOrganizacional;
	
	//II. Datos del evaluador:
	private String codPersonalEvaluador;
	private String desNombreCompletoEvaluador;
	
	
	public String getCodPeriodo() {
		return codPeriodo;
	}
	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}
	public String getCodPersonalEvaluado() {
		return codPersonalEvaluado;
	}
	public void setCodPersonalEvaluado(String codPersonalEvaluado) {
		this.codPersonalEvaluado = codPersonalEvaluado;
	}
	public String getDesNombreCompletoEvaluado() {
		return desNombreCompletoEvaluado;
	}
	public void setDesNombreCompletoEvaluado(String desNombreCompletoEvaluado) {
		this.desNombreCompletoEvaluado = desNombreCompletoEvaluado;
	}
	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}
	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}
	public String getDesUnidadOrganizacional() {
		return desUnidadOrganizacional;
	}
	public void setDesUnidadOrganizacional(String desUnidadOrganizacional) {
		this.desUnidadOrganizacional = desUnidadOrganizacional;
	}
	public String getCodPersonalEvaluador() {
		return codPersonalEvaluador;
	}
	public void setCodPersonalEvaluador(String codPersonalEvaluador) {
		this.codPersonalEvaluador = codPersonalEvaluador;
	}
	public String getDesNombreCompletoEvaluador() {
		return desNombreCompletoEvaluador;
	}
	public void setDesNombreCompletoEvaluador(String desNombreCompletoEvaluador) {
		this.desNombreCompletoEvaluador = desNombreCompletoEvaluador;
	}
	public String getNumDniPersonalEvaluado() {
		return numDniPersonalEvaluado;
	}
	public void setNumDniPersonalEvaluado(String numDniPersonalEvaluado) {
		this.numDniPersonalEvaluado = numDniPersonalEvaluado;
	}
	
}
