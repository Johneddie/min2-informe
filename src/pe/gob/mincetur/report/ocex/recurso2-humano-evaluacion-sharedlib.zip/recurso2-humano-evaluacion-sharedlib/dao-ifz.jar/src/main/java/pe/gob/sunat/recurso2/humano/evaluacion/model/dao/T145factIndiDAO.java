package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;

public interface T145factIndiDAO {

	Comportamiento selectByPrimaryKey(Comportamiento comportamiento);
	List<Comportamiento> listarPorGrupoCompetencia(Map<String,Object> paramSearch);
	List<Comportamiento> listarPorCompetencia(Map<String,Object> paramSearch);
	public List<Comportamiento> listarPorParametros(Comportamiento params);
	
}
