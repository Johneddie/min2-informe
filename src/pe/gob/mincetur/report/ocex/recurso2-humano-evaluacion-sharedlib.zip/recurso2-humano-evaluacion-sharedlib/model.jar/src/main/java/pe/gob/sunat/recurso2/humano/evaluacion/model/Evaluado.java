package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.lang.reflect.Field;
import java.util.List;

public class Evaluado {
	
	private String codPeriodo;
	private String codPersonal;
	private String desNombreCompleto;
	
	private String codGrupo;
	private String desGrupo;
	
	private String codCategoria;
	private String desCategoria;
	
	private String indEvaluacionComunicada;
	
	private List<String> condiciones;
	
	
	/*
	 * Condici�n del evaluado:
     *  N = No Evaluado
     *  E = Evaluado
     *  C = Conforme
     *  O = Observado
     *  T = Transferido
     *  A = Apelado
	 * */
	private String indCondicion;
	
	private String desCondicion;
	
	
	/*
	 * Control para evaluadores:
	 * E   = Evaluador 1
     * EE  = Evaluador 1 y 2
     * EEE = Evaluador 1, 2  y 3
	 * */
	private String indControl;
	
	/*
	 * Estado del evaluado:
     * 0 = No Evaluado
     * 1 = Evaluado
	 * */
	private String codEstado;
	
	private String codUnidadOrganizacional;
	private String codUnidadOrganizacionalPersonal;//forma parte de la clave primaria
	private String codUnidadOrganizacionalLike;
	
	private String desUnidadOrganizacional;
	private String codPersonalEvaluador;
	private String desNombreCompletoEvaluador;
	
	private String indAccion;
	
	private String indAccionHist;
	
	private String desObservacionEvaluador;			//jquispecoi
	
	private String desCorreo;
	
	/*
	 * Estado para el monitoreo general
	 * Estado en lista de evaluaci�n
	 * Bandeja donde se encuentra
	 * Estado en el proceso de evaluaci�n
	 */
	private String estLista; 
	private String estBandeja;
	private String estProceso;
	private String esDirectivo;
	
	private String fecConsultaEvaluacion;
	
	private String desUnidadOrganizacionalPersonal;
	
	public String getEsDirectivo() {
		return esDirectivo;
	}

	public void setEsDirectivo(String esDirectivo) {
		this.esDirectivo = esDirectivo;
	}

	private String numDni;

	public Evaluado() {
		// TODO Auto-generated constructor stub
	}

	public String getDesObservacionEvaluador() {
		return desObservacionEvaluador;
	}

	public void setDesObservacionEvaluador(String desObservacionEvaluador) {
		this.desObservacionEvaluador = desObservacionEvaluador;
	}

	public String getCodPeriodo() {
		return codPeriodo;
	}

	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}

	public String getCodPersonal() {
		return codPersonal;
	}

	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}

	public String getDesNombreCompleto() {
		return desNombreCompleto;
	}

	public void setDesNombreCompleto(String desNombreCompleto) {
		this.desNombreCompleto = desNombreCompleto;
	}

	public String getCodGrupo() {
		return codGrupo;
	}

	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}

	public String getDesGrupo() {
		return desGrupo;
	}

	public void setDesGrupo(String desGrupo) {
		this.desGrupo = desGrupo;
	}

	public String getCodCategoria() {
		return codCategoria;
	}

	public void setCodCategoria(String codCategoria) {
		this.codCategoria = codCategoria;
	}

	public String getDesCategoria() {
		return desCategoria;
	}

	public void setDesCategoria(String desCategoria) {
		this.desCategoria = desCategoria;
	}

	public String getIndCondicion() {
		return indCondicion;
	}

	public void setIndCondicion(String indCondicion) {
		this.indCondicion = indCondicion;
	}

	public String getIndControl() {
		return indControl;
	}

	public void setIndControl(String indControl) {
		this.indControl = indControl;
	}

	public String getCodEstado() {
		return codEstado;
	}

	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}

	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}

	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}

	public String getIndAccion() {
		return indAccion;
	}

	public void setIndAccion(String indAccion) {
		this.indAccion = indAccion;
	}

	public String getIndAccionHist() {
		return indAccionHist;
	}

	public void setIndAccionHist(String indAccionHist) {
		this.indAccionHist = indAccionHist;
	}

	public String getDesCondicion() {
		return desCondicion;
	}

	public void setDesCondicion(String desCondicion) {
		this.desCondicion = desCondicion;
	}

	public String getCodUnidadOrganizacionalPersonal() {
		return codUnidadOrganizacionalPersonal;
	}

	public void setCodUnidadOrganizacionalPersonal(
			String codUnidadOrganizacionalPersonal) {
		this.codUnidadOrganizacionalPersonal = codUnidadOrganizacionalPersonal;
	}

	public String getIndEvaluacionComunicada() {
		return indEvaluacionComunicada;
	}

	public void setIndEvaluacionComunicada(String indEvaluacionComunicada) {
		this.indEvaluacionComunicada = indEvaluacionComunicada;
	}

	public List<String> getCondiciones() {
		return condiciones;
	}

	public void setCondiciones(List<String> condiciones) {
		this.condiciones = condiciones;
	}

	public String getDesUnidadOrganizacional() {
		return desUnidadOrganizacional;
	}

	public void setDesUnidadOrganizacional(String desUnidadOrganizacional) {
		this.desUnidadOrganizacional = desUnidadOrganizacional;
	}

	public String getCodPersonalEvaluador() {
		return codPersonalEvaluador;
	}

	public void setCodPersonalEvaluador(String codPersonalEvaluador) {
		this.codPersonalEvaluador = codPersonalEvaluador;
	}

	public String getDesNombreCompletoEvaluador() {
		return desNombreCompletoEvaluador;
	}

	public void setDesNombreCompletoEvaluador(String desNombreCompletoEvaluador) {
		this.desNombreCompletoEvaluador = desNombreCompletoEvaluador;
	}
	
	public String getDesCorreo() {
		return desCorreo;
	}

	public void setDesCorreo(String desCorreo) {
		this.desCorreo = desCorreo;
	}
	
	public String getEstLista() {
		return estLista;
	}

	public void setEstLista(String estLista) {
		this.estLista = estLista;
	}

	public String getEstBandeja() {
		return estBandeja;
	}

	public void setEstBandeja(String estBandeja) {
		this.estBandeja = estBandeja;
	}

	public String getEstProceso() {
		return estProceso;
	}

	public void setEstProceso(String estProceso) {
		this.estProceso = estProceso;
	}


	public String getCodUnidadOrganizacionalLike() {
		return codUnidadOrganizacionalLike;
	}

	public void setCodUnidadOrganizacionalLike(String codUnidadOrganizacionalLike) {
		this.codUnidadOrganizacionalLike = codUnidadOrganizacionalLike;
	}
	
	

	/**
	 * Intended only for debugging.
	 */
	@Override
	public String toString() { // jquispecoi
		StringBuilder result = new StringBuilder();
		String newLine = System.getProperty("line.separator");

		result.append(this.getClass().getName());
		result.append(" Object {");
		result.append(newLine);

		Field[] fields = this.getClass().getDeclaredFields();

		for (Field field : fields) {
			result.append("  ");
			try {
				result.append(field.getName());
				result.append(": ");
				result.append(field.get(this));
			} catch (IllegalAccessException ex) {
				System.out.println(ex);
			}
			result.append(newLine);
		}
		result.append("}");

		return result.toString();
	}

	public String getNumDni() {
		return numDni;
	}

	public void setNumDni(String numDni) {
		this.numDni = numDni;
	}

	public String getFecConsultaEvaluacion() {
		return fecConsultaEvaluacion;
	}

	public void setFecConsultaEvaluacion(String fecConsultaEvaluacion) {
		this.fecConsultaEvaluacion = fecConsultaEvaluacion;
	}

	public String getDesUnidadOrganizacionalPersonal() {
		return desUnidadOrganizacionalPersonal;
	}

	public void setDesUnidadOrganizacionalPersonal(
			String desUnidadOrganizacionalPersonal) {
		this.desUnidadOrganizacionalPersonal = desUnidadOrganizacionalPersonal;
	}
	
}
