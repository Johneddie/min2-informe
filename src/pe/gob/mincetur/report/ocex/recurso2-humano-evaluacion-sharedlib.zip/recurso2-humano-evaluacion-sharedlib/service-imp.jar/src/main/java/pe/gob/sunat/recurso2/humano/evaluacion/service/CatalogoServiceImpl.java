package pe.gob.sunat.recurso2.humano.evaluacion.service;

import static pe.gob.sunat.recurso2.humano.evaluacion.util.Constantes.ESTADO_ACTIVO;
import static pe.gob.sunat.recurso2.humano.evaluacion.util.Constantes.PARAMETRO_TIPOS_ACCION;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T01paramDAO;


@Service("catalogoService")
public class CatalogoServiceImpl implements CatalogoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	T01paramDAO parametroDAO;

	@Override
	public List<Parametro> listarTiposAccion(){
		Parametro parametro = new Parametro();
		parametro.setCodParametro(PARAMETRO_TIPOS_ACCION);
		parametro.setCodEstado(ESTADO_ACTIVO);
		return parametroDAO.listarPorParametros(parametro);		
	}
	
}
