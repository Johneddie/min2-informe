package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class Periodo {

	
	private String codPeriodo;
	private Date fecInicioAlcance;
	private Date fecFinAlcance;
	private Date fecInicioEvaluacion;
	private Date fecFinEvaluacion;
	
	private Integer cntInicioEvaluacion;
	private Integer cntEvaluar;
	private Integer cntMesesEvaluacion;
	private Integer cntMinMesesInstitucion;
	private Integer cntMinMesesUnidad;

	private String desTituloEvaluacion;
	private String codEstado;
	private Date fecRegistro;
	private String codUsuario;
	private String indBono;//0:Evaluaci�n para pago de bono, 1:Evaluaci�n que no incluye pago de bono
	private String indVisualizasHoja;
	private String indVisualizasHojaEval;
	
	public String getCodPeriodo() {
		return codPeriodo;
	}
	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}
	public Date getFecInicioAlcance() {
		return fecInicioAlcance;
	}
	public void setFecInicioAlcance(Date fecInicioAlcance) {
		this.fecInicioAlcance = fecInicioAlcance;
	}
	public Date getFecFinAlcance() {
		return fecFinAlcance;
	}
	public void setFecFinAlcance(Date fecFinAlcance) {
		this.fecFinAlcance = fecFinAlcance;
	}
	public Date getFecInicioEvaluacion() {
		return fecInicioEvaluacion;
	}
	public void setFecInicioEvaluacion(Date fecInicioEvaluacion) {
		this.fecInicioEvaluacion = fecInicioEvaluacion;
	}
	public Date getFecFinEvaluacion() {
		return fecFinEvaluacion;
	}
	public void setFecFinEvaluacion(Date fecFinEvaluacion) {
		this.fecFinEvaluacion = fecFinEvaluacion;
	}
	public Integer getCntInicioEvaluacion() {
		return cntInicioEvaluacion;
	}
	public void setCntInicioEvaluacion(Integer cntInicioEvaluacion) {
		this.cntInicioEvaluacion = cntInicioEvaluacion;
	}
	public Integer getCntEvaluar() {
		return cntEvaluar;
	}
	public void setCntEvaluar(Integer cntEvaluar) {
		this.cntEvaluar = cntEvaluar;
	}
	public Integer getCntMesesEvaluacion() {
		return cntMesesEvaluacion;
	}
	public void setCntMesesEvaluacion(Integer cntMesesEvaluacion) {
		this.cntMesesEvaluacion = cntMesesEvaluacion;
	}
	public Integer getCntMinMesesInstitucion() {
		return cntMinMesesInstitucion;
	}
	public void setCntMinMesesInstitucion(Integer cntMinMesesInstitucion) {
		this.cntMinMesesInstitucion = cntMinMesesInstitucion;
	}
	public Integer getCntMinMesesUnidad() {
		return cntMinMesesUnidad;
	}
	public void setCntMinMesesUnidad(Integer cntMinMesesUnidad) {
		this.cntMinMesesUnidad = cntMinMesesUnidad;
	}
	public String getDesTituloEvaluacion() {
		return desTituloEvaluacion;
	}
	public void setDesTituloEvaluacion(String desTituloEvaluacion) {
		this.desTituloEvaluacion = desTituloEvaluacion;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getIndBono() {
		return indBono;
	}
	public void setIndBono(String indBono) {
		this.indBono = indBono;
	}
	public String getIndVisualizasHoja() {
		return indVisualizasHoja;
	}
	public void setIndVisualizasHoja(String indVisualizasHoja) {
		this.indVisualizasHoja = indVisualizasHoja;
	}
	public String getIndVisualizasHojaEval() {
		return indVisualizasHojaEval;
	}
	public void setIndVisualizasHojaEval(String indVisualizasHojaEval) {
		this.indVisualizasHojaEval = indVisualizasHojaEval;
	}
	
	
		
}
