package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEval;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEvalExample;

public interface SeguimientoEvalDAO {
    int countByExample(SeguimientoEvalExample example);

    int deleteByExample(SeguimientoEvalExample example);

    int deleteByPrimaryKey(Integer numSeguim);

    void insert(SeguimientoEval record);

    Integer insertSelective(SeguimientoEval record);

    List<SeguimientoEval> selectByExample(SeguimientoEvalExample example);

    SeguimientoEval selectByPrimaryKey(Integer numSeguim);

    int updateByExampleSelective(SeguimientoEval record, SeguimientoEvalExample example);

    int updateByExample(SeguimientoEval record, SeguimientoEvalExample example);

    int updateByPrimaryKeySelective(SeguimientoEval record);

    int updateByPrimaryKey(SeguimientoEval record);
}