package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.math.BigDecimal;
import java.util.Date;

public class Comportamiento {

	private String codComportamiento;
	private String codTipo;//indica si es un comportamiento(2) o competencia(1)
	private String desComportamiento;
	private String desAbreviatura;
	private String codSigla;
	private BigDecimal cntPuntaje;
	private String desDetalle;
	private Date fecRegistro;
	private String codRegistro;
	private String codEstado;
	private String codNivel;
	
	
	private String desNivelAlc;
	private String desObserva1;
	private String desObserva2;
	private String desObserv;
	
	private String codCompetencia;
	private String codCriterio;
	private String codGrupo;
	
	public String getDesObserv() {
		return desObserv;
	}
	public void setDesObserv(String desObserv) {
		this.desObserv = desObserv;
	}
	//Datos de la evaluaci�n
	private BigDecimal cntNotaComportamiento;
	private String codNotaComportamiento;
	
	public String getCodComportamiento() {
		return codComportamiento;
	}
	public void setCodComportamiento(String codComportamiento) {
		this.codComportamiento = codComportamiento;
	}
	public String getCodTipo() {
		return codTipo;
	}
	public void setCodTipo(String codTipo) {
		this.codTipo = codTipo;
	}
	public String getDesComportamiento() {
		return desComportamiento;
	}
	public void setDesComportamiento(String desComportamiento) {
		this.desComportamiento = desComportamiento;
	}
	public String getDesAbreviatura() {
		return desAbreviatura;
	}
	public void setDesAbreviatura(String desAbreviatura) {
		this.desAbreviatura = desAbreviatura;
	}
	public String getCodSigla() {
		return codSigla;
	}
	public void setCodSigla(String codSigla) {
		this.codSigla = codSigla;
	}
	public BigDecimal getCntPuntaje() {
		return cntPuntaje;
	}
	public void setCntPuntaje(BigDecimal cntPuntaje) {
		this.cntPuntaje = cntPuntaje;
	}
	public String getDesDetalle() {
		return desDetalle;
	}
	public void setDesDetalle(String desDetalle) {
		this.desDetalle = desDetalle;
	}
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getCodRegistro() {
		return codRegistro;
	}
	public void setCodRegistro(String codRegistro) {
		this.codRegistro = codRegistro;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	
	public String getDesObserva1() {
		return desObserva1;
	}
	public void setDesObserva1(String desObserva1) {
		this.desObserva1 = desObserva1;
	}
	public String getDesObserva2() {
		return desObserva2;
	}
	public void setDesObserva2(String desObserva2) {
		this.desObserva2 = desObserva2;
	}
	public BigDecimal getCntNotaComportamiento() {
		return cntNotaComportamiento;
	}
	public void setCntNotaComportamiento(BigDecimal cntNotaComportamiento) {
		this.cntNotaComportamiento = cntNotaComportamiento;
	}
	public String getCodNotaComportamiento() {
		return codNotaComportamiento;
	}
	public void setCodNotaComportamiento(String codNotaComportamiento) {
		this.codNotaComportamiento = codNotaComportamiento;
	}
	
	public String getCodNivel() {
		return codNivel;
	}
	public void setCodNivel(String codNivel) {
		this.codNivel = codNivel;
	}
	public String getDesNivelAlc() {
		return desNivelAlc;
	}
	public void setDesNivelAlc(String desNivelAlc) {
		this.desNivelAlc = desNivelAlc;
	}
	public String getCodCompetencia() {
		return codCompetencia;
	}
	public void setCodCompetencia(String codCompetencia) {
		this.codCompetencia = codCompetencia;
	}
	public String getCodGrupo() {
		return codGrupo;
	}
	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}
	public String getCodCriterio() {
		return codCriterio;
	}
	public void setCodCriterio(String codCriterio) {
		this.codCriterio = codCriterio;
	}
	
}
