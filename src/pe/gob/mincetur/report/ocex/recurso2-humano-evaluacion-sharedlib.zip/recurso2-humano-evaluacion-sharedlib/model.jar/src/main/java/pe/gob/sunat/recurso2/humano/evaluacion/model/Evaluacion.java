package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Date;

public class Evaluacion {

	private String codPeriodo;//pk
	private String codPersonal;//pk
	private String codUnidadOrganizacional;//pk
	private String codGrupo;
	private BigDecimal cntNota;
	private String codEstado;
	private String desObservacionEvaluador;
	private String desComentarios;
	private String codUsuario;
	private Date fecRegistro;
	private String esEvaluacionComunicada;
	private String codEstadoConsulta;
	
	public String getCodPeriodo() {
		return codPeriodo;
	}
	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}
	public String getCodPersonal() {
		return codPersonal;
	}
	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}
	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}
	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}
	public String getCodGrupo() {
		return codGrupo;
	}
	public void setCodGrupo(String codGrupo) {
		this.codGrupo = codGrupo;
	}
	public BigDecimal getCntNota() {
		return cntNota;
	}
	public void setCntNota(BigDecimal cntNota) {
		this.cntNota = cntNota;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getDesComentarios() {
		return desComentarios;
	}
	public void setDesComentarios(String desComentarios) {
		this.desComentarios = desComentarios;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getDesObservacionEvaluador() {
		return desObservacionEvaluador;
	}
	public void setDesObservacionEvaluador(String desObservacionEvaluador) {
		this.desObservacionEvaluador = desObservacionEvaluador;
	}
	public String getEsEvaluacionComunicada() {
		return esEvaluacionComunicada;
	}
	public void setEsEvaluacionComunicada(String esEvaluacionComunicada) {
		this.esEvaluacionComunicada = esEvaluacionComunicada;
	}
	public String getCodEstadoConsulta() {
		return codEstadoConsulta;
	}
	public void setCodEstadoConsulta(String codEstadoConsulta) {
		this.codEstadoConsulta = codEstadoConsulta;
	}
	
	/**
	 * Intended only for debugging.
	 */
	@Override
	public String toString() { // jquispecoi
		StringBuilder result = new StringBuilder();
		String newLine = System.getProperty("line.separator");

		result.append(this.getClass().getName());
		result.append(" Object {");
		result.append(newLine);

		Field[] fields = this.getClass().getDeclaredFields();

		for (Field field : fields) {
			result.append("  ");
			try {
				result.append(field.getName());
				result.append(": ");
				result.append(field.get(this));
			} catch (IllegalAccessException ex) {
				System.out.println(ex);
			}
			result.append(newLine);
		}
		result.append("}");

		return result.toString();
	}
	
}
