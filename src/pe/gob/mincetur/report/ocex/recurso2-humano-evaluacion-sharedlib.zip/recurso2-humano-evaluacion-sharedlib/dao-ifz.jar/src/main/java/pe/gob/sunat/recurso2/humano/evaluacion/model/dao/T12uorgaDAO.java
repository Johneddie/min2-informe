package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import pe.gob.sunat.recurso2.humano.evaluacion.model.UnidadOrganizacional;

public interface T12uorgaDAO {

	UnidadOrganizacional selectByPrimaryKey(UnidadOrganizacional paramSearch);
	
}
