package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Accion;

public interface AccionDAO {
    /*int countByExample(AccionExample example);

    int deleteByExample(AccionExample example);

    void insert(Accion record);

    void insertSelective(Accion record);

    List<Accion> selectByExample(AccionExample example);

    int updateByExampleSelective(Accion record, AccionExample example);

    int updateByExample(Accion record, AccionExample example);*/
}