package pe.gob.sunat.recurso2.humano.evaluacion.bean;

import java.math.BigDecimal;

public class ReporteMonitoreo {

    private String codUnidadOrganizacional;
    private String desUnidadOrganizacional;
    private BigDecimal totalEvaluar;
    private BigDecimal totalTransferidos;
    private BigDecimal totalSinTransferir;
    private BigDecimal totalNoEvaluados;
    
	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}
	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}
	public String getDesUnidadOrganizacional() {
		return desUnidadOrganizacional;
	}
	public void setDesUnidadOrganizacional(String desUnidadOrganizacional) {
		this.desUnidadOrganizacional = desUnidadOrganizacional;
	}
	public BigDecimal getTotalEvaluar() {
		return totalEvaluar;
	}
	public void setTotalEvaluar(BigDecimal totalEvaluar) {
		this.totalEvaluar = totalEvaluar;
	}
	public BigDecimal getTotalTransferidos() {
		return totalTransferidos;
	}
	public void setTotalTransferidos(BigDecimal totalTransferidos) {
		this.totalTransferidos = totalTransferidos;
	}
	public BigDecimal getTotalSinTransferir() {
		return totalSinTransferir;
	}
	public void setTotalSinTransferir(BigDecimal totalSinTransferir) {
		this.totalSinTransferir = totalSinTransferir;
	}
	public BigDecimal getTotalNoEvaluados() {
		return totalNoEvaluados;
	}
	public void setTotalNoEvaluados(BigDecimal totalNoEvaluados) {
		this.totalNoEvaluados = totalNoEvaluados;
	}
	
}
