package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T11histoDAO;

@SuppressWarnings("unchecked")
public class SqlMapT11histoDAO extends SqlMapClientDaoSupport implements T11histoDAO{

	@Override
	public List<String> selectAccionesPorEncargatura(Map<String,Object> paramSearch) {
		return (List)getSqlMapClientTemplate().queryForList("T11histo.selectAccionesPorEncargatura", paramSearch);
	}

}
