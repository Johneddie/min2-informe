package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguim;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimWithBLOBs;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.AccionSeguimDAO;

public class SqlMapAccionSeguimDAO extends SqlMapClientDaoSupport implements AccionSeguimDAO {

    public SqlMapAccionSeguimDAO() {
        super();
    }

    public int countByExample(AccionSeguimExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t9437accionseguim.countByExample", example);
        return count;
    }

    public int deleteByExample(AccionSeguimExample example) {
        int rows = getSqlMapClientTemplate().delete("t9437accionseguim.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numAccion) {
        AccionSeguim key = new AccionSeguim();
        key.setNumAccion(numAccion);
        int rows = getSqlMapClientTemplate().delete("t9437accionseguim.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(AccionSeguimWithBLOBs record) {
        getSqlMapClientTemplate().insert("t9437accionseguim.insert", record);
    }

    public Integer insertSelective(AccionSeguimWithBLOBs record) {
        return (Integer)getSqlMapClientTemplate().insert("t9437accionseguim.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<AccionSeguimWithBLOBs> selectByExampleWithBLOBs(AccionSeguimExample example) {
        List<AccionSeguimWithBLOBs> list = getSqlMapClientTemplate().queryForList("t9437accionseguim.selectByExampleWithBLOBs", example);
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<AccionSeguim> selectByExampleWithoutBLOBs(AccionSeguimExample example) {
        List<AccionSeguim> list = getSqlMapClientTemplate().queryForList("t9437accionseguim.selectByExample", example);
        return list;
    }

    public AccionSeguimWithBLOBs selectByPrimaryKey(Integer numAccion) {
        AccionSeguim key = new AccionSeguim();
        key.setNumAccion(numAccion);
        AccionSeguimWithBLOBs record = (AccionSeguimWithBLOBs) getSqlMapClientTemplate().queryForObject("t9437accionseguim.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(AccionSeguimWithBLOBs record, AccionSeguimExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(AccionSeguimWithBLOBs record, AccionSeguimExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByExampleWithBLOBs", parms);
        return rows;
    }

    public int updateByExample(AccionSeguim record, AccionSeguimExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(AccionSeguimWithBLOBs record) {
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(AccionSeguimWithBLOBs record) {
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByPrimaryKeyWithBLOBs", record);
        return rows;
    }

    public int updateByPrimaryKey(AccionSeguim record) {
        int rows = getSqlMapClientTemplate().update("t9437accionseguim.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends AccionSeguimExample {
        private Object record;

        public UpdateByExampleParms(Object record, AccionSeguimExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}