package pe.gob.sunat.recurso2.humano.evaluacion.service;

import java.util.HashMap;
import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteCompetencia;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreo;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreoUnidad;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluacion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Rendimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RendimientoDetalle;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.UnidadOrganizacional;


public interface EvaluacionCompetenciaService {
	public List<Periodo> listarPeriodosIniciados();
	public List<UnidadOrganizacional> listarUUOOJefe(String codPeriodo, String codPersonal, String codTipEvaluador);
	public List<UnidadOrganizacional> listarUUOOEvaluador(String codPeriodo, String codPersonal, String codTipEvaluador);
	public List<Evaluado> listarEvaluadoresJefe(String codPeriodo, String codUnidadOrganizacional, String codTipEvaluador);
	public UnidadOrganizacional getUUOO(String codUUOO);
	public Evaluado getPersonal(String codPersonal);
	public List<Evaluado> listarPersonalEvaluable(String codPeriodo, String codUnidadOrganizacional, String indControl, String codPersonal);
	public List<Comportamiento> listarCompetenciasPorGrupo(String codGrupo,String codPers,String codPeriodo);
	public List<Comportamiento> listarComportamientosPorCompetencia(String codPersonal, String codCompetencia, String codPeriodo,String esDirectivo);
	public void getEvaluador();
	public void registrarEvaluacion(Evaluacion evaluacion, 
			Evaluado evaluado, List<RendimientoDetalle> rendimientos, 
			List<Rendimiento> competencias, String indCondicionActual);
	public void enviarEvaluacion(List<Evaluado> evaluados);
	public boolean existeRevisor(String codPeriodo, String codUnidadOrganizacional);
	public void devolverEvaluacion(List<Evaluado> evaluados);
	public void transferirEvaluacion(List<Evaluado> evaluados, String codUsuario);
	
	public void actualizarEvaluacion(Evaluado evaluado);
	
	public List<ReporteMonitoreo> reporteMonitoreoInstitucional(String codPeriodo);
	public List<ReporteMonitoreo> reporteMonitoreoPorAdjunta(String codPeriodo, String codAdjunta);
	public List<ReporteMonitoreo> reporteMonitoreoPorOrgano(String codPeriodo, String codOrgano);
	public List<ReporteMonitoreo> reporteMonitoreoPorJerarquiaUnidad(String codPeriodo, String codJerarquia, String codNivel);
	
	public List<ReporteCompetencia> reporteCompetencias(String condicion, String codPeriodo, String codAdjunta, String codOrgano);
	public List<ReporteCompetencia> reporteCompetenciasJerarquiaUnidad(String condicion, String codPeriodo, String codJerarquia, String codNivel);
	
	public void actualizarEstadoEntrevista(Evaluacion evaluacion);
	
	public List<ReporteMonitoreoUnidad> reporteMonitoreoUnidades(String codPeriodo);
	public List<Periodo> listarPeriodosNoCerrados();
	public boolean generaMonitoreoUnidadesXLSX(HashMap<String, Object> params);
	public List<Evaluado> listarPersonalMonitoreoUnidad(String codPeriodo, String codUnidadOrganizacional);
	public List<String> listarNivelesPorPeriodo(String codPeriodo);
	
	public boolean generaMonitoreoXLSX(HashMap<String, Object> params);
	public boolean registrarLogConsulta(Seguimiento seguimiento);

}
