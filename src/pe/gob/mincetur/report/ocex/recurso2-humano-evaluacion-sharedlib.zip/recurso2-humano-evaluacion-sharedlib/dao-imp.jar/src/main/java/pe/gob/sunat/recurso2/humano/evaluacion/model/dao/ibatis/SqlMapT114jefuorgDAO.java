package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114jefuorgDAO;

public class SqlMapT114jefuorgDAO extends SqlMapClientDaoSupport implements T114jefuorgDAO{

	@SuppressWarnings("unchecked")
	@Override
	public List<String> listarUnidadesOrganizacionales(
			Map<String, Object> paramSearch) {
		return (List<String>)getSqlMapClientTemplate().queryForList("T114jefuorg.listarUnidadesOrganizacionales", paramSearch);
	}

}
