package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.ArchivoEval;
import pe.gob.sunat.recurso2.humano.evaluacion.model.ArchivoEvalExample;

public interface ArchivoEvalDAO {
    int countByExample(ArchivoEvalExample example);

    int deleteByExample(ArchivoEvalExample example);

    int deleteByPrimaryKey(Integer numArchivo);

    void insert(ArchivoEval record);

    void insertSelective(ArchivoEval record);

    List<ArchivoEval> selectByExampleWithBLOBs(ArchivoEvalExample example);

    List<ArchivoEval> selectByExampleWithoutBLOBs(ArchivoEvalExample example);

    ArchivoEval selectByPrimaryKey(Integer numArchivo);

    int updateByExampleSelective(ArchivoEval record, ArchivoEvalExample example);

    int updateByExampleWithBLOBs(ArchivoEval record, ArchivoEvalExample example);

    int updateByExampleWithoutBLOBs(ArchivoEval record, ArchivoEvalExample example);

    int updateByPrimaryKeySelective(ArchivoEval record);

    int updateByPrimaryKeyWithBLOBs(ArchivoEval record);

    int updateByPrimaryKeyWithoutBLOBs(ArchivoEval record);
}