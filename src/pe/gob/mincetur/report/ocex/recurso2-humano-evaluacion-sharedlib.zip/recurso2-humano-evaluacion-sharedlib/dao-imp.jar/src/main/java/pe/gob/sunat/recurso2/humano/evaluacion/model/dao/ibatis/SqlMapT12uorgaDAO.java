package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.UnidadOrganizacional;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T12uorgaDAO;

public class SqlMapT12uorgaDAO extends SqlMapClientDaoSupport implements T12uorgaDAO{

	@Override
	public UnidadOrganizacional selectByPrimaryKey(
			UnidadOrganizacional paramSearch) {
		return (UnidadOrganizacional)getSqlMapClientTemplate().queryForObject("T12uorga.selectByPrimaryKey", paramSearch);
	}

}
