package pe.gob.sunat.recurso2.humano.evaluacion.service;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.spring.util.date.FechaBean;
import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteCompetencia;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreo;
import pe.gob.sunat.recurso2.humano.evaluacion.bean.ReporteMonitoreoUnidad;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RendimientoDetalle;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Rendimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Accion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Seguimiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.UnidadOrganizacional;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluacion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.AccionDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.CorreosDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T01paramDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T02perdpDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110notaindDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110rendiDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114evuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114jefuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T115histevaDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T116jefuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T11histoDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T12uorgaDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T145factIndiDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T1536segEvalDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T43evperDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T99codigosDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.util.Constantes;
import pe.gob.sunat.tecnologia.menu.bean.MenuCliente;
import static pe.gob.sunat.recurso2.humano.evaluacion.util.Constantes.*;

import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;

@Service("evaluacionService")
public class EvaluacionCompetenciaServiceImpl implements EvaluacionCompetenciaService {
	Propiedades propiedades = new Propiedades(getClass(), "/correo.properties");
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private T115histevaDAO periodoDAO;
	@Autowired
	private T116jefuorgDAO periodoUUOOEvaluadorDAO;
	@Autowired
	private T114jefuorgDAO periodoUUOOJefeDAO;
	@Autowired
	private T12uorgaDAO uuooDAO;
	@Autowired
	private T114evuorgDAO evaluacionDAO;
	@Autowired
	private T99codigosDAO codigosDAO;
	@Autowired
	private T01paramDAO paramDAO;
	@Autowired
	private T145factIndiDAO comportamientoDAO;
	@Autowired
	private T110rendiDAO rendimientoDAO;
	@Autowired
	private T110notaindDAO rendimientoDetalleDAO;
	@Autowired
	private T43evperDAO evaluacionDetalleDAO;
	@Autowired
	private T02perdpDAO personalDAO;
	@Autowired
	private T11histoDAO histoDAO;
	@Autowired
	private CorreosDAO correosDAO;
	@Autowired
	private T1536segEvalDAO seguimientoDAO;
	
	
	@Override
	public UnidadOrganizacional getUUOO(String codUUOO) {
		UnidadOrganizacional paramSearch = new UnidadOrganizacional();
		paramSearch.setCodUnidadOrganizacional(codUUOO);
		return uuooDAO.selectByPrimaryKey(paramSearch);
	}
	
	@Override
	public Evaluado getPersonal(String codPersonal) {
		Evaluado paramSearch = new Evaluado();
		paramSearch.setCodPersonal(codPersonal);
		return personalDAO.selectByPrimaryKey(paramSearch);
	}
	
	
	@Override
	public List<UnidadOrganizacional> listarUUOOJefe(String codPeriodo, String codPersonal, String codTipEvaluador) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codPersonal", codPersonal);
		paramSearch.put("codTipEvaluador", codTipEvaluador);
		List<String> unidades = periodoUUOOEvaluadorDAO.listarUnidadesOrganizacionales(paramSearch);
		
		//acciones
		paramSearch.put("t11tipo_acc", Constantes.ACCION_ENCARGO_AUSENCIA);
		paramSearch.put("t11cod_pers", codPersonal);
		List<String> unidadesEncargadas = histoDAO.selectAccionesPorEncargatura(paramSearch);
		unidades.addAll(unidadesEncargadas);
		
		List<UnidadOrganizacional> unidadesOrganizacionales = new ArrayList<UnidadOrganizacional>();
		String desUUOO;
		for(String codUnidad:unidades){
			if(!StringUtils.isBlank(codUnidad)){
				Evaluado paramUuoo = new Evaluado();
				paramUuoo.setCodPeriodo(codPeriodo);
				paramUuoo.setCodUnidadOrganizacional(codUnidad);
				paramUuoo.setIndAccion(Constantes.LISTA_ENVIADA);
				
				paramUuoo.setIndControl(Constantes.CONTROL_REVISOR);//solo se toma lo evaluado
				List<String> condiciones = new ArrayList<String>();
				condiciones.add(Constantes.CONDICION_CONFORME);
				condiciones.add(Constantes.CONDICION_EN_REVISION);
				condiciones.add(Constantes.CONDICION_OBSERVADO);
				paramUuoo.setCondiciones(condiciones);
				
				List<Evaluado> evaluados = evaluacionDAO.listarEvaluados(paramUuoo);
				
				log.debug("evaluados.size: "+evaluados.size());
				
				if(!evaluados.isEmpty())
					if(codUnidad.trim().length()>6){														//jquispecoi
						desUUOO = this.getUUOO(codUnidad.substring(0,6)).getDesUnidadOrganizacional();
						UnidadOrganizacional uuoo = new UnidadOrganizacional();
						uuoo.setCodUnidadOrganizacional(codUnidad);
						uuoo.setDesUnidadOrganizacional(desUUOO);
						unidadesOrganizacionales.add(uuoo);
					}else
						unidadesOrganizacionales.add(this.getUUOO(codUnidad.substring(0,6)));	
			}
		}
		return unidadesOrganizacionales;
	}
	
	@Override
	public List<Evaluado> listarEvaluadoresJefe(String codPeriodo, String codUnidadOrganizacional, String codTipEvaluador) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codUnidadOrganizacional", codUnidadOrganizacional);
		paramSearch.put("codTipEvaluador", codTipEvaluador);
		List<String> codigos = periodoUUOOEvaluadorDAO.listarPersonal(paramSearch);
		List<Evaluado> evaluadores = new ArrayList<Evaluado>();
		for(String codPersonal:codigos){
			if(!StringUtils.isBlank(codPersonal)){
				evaluadores.add(this.getPersonal(codPersonal.trim()));	
			}
		}
		return evaluadores;
	}
	
	
	
	@Override
	public List<UnidadOrganizacional> listarUUOOEvaluador(String codPeriodo, String codPersonal, String codTipEvaluador) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codPersonal", codPersonal);
		paramSearch.put("codTipEvaluador", codTipEvaluador);
		List<String> unidades = periodoUUOOEvaluadorDAO.listarUnidadesOrganizacionales(paramSearch);
		List<UnidadOrganizacional> unidadesOrganizacionales = new ArrayList<UnidadOrganizacional>();
		String desUUOO;
		for(String codUnidad:unidades){
			if(!StringUtils.isBlank(codUnidad)){
				if(codUnidad.trim().length()>6){														//jquispecoi
					desUUOO = this.getUUOO(codUnidad.substring(0,6)).getDesUnidadOrganizacional();
					UnidadOrganizacional uuoo = new UnidadOrganizacional();
					uuoo.setCodUnidadOrganizacional(codUnidad);
					uuoo.setDesUnidadOrganizacional(desUUOO);
					unidadesOrganizacionales.add(uuoo);
				}else
					unidadesOrganizacionales.add(this.getUUOO(codUnidad.substring(0,6)));	
			}
		}
		return unidadesOrganizacionales;
	}
	
	
	@Override
	public List<Periodo> listarPeriodosIniciados() {
		Periodo periodoSearch = new Periodo();
		periodoSearch.setCodEstado(PERIODO_INICIADO);
		return periodoDAO.listByParameter(periodoSearch);		
	}
	
	@Override
	public List<Periodo> listarPeriodosNoCerrados() {
		HashMap<String, Object> prmsPeriodos = new HashMap<String, Object>();
		ArrayList<String> lstEstados = new ArrayList<String>();
		lstEstados.add(PERIODO_NUEVO);
		lstEstados.add(PERIODO_GENERADO);
		lstEstados.add(PERIODO_INICIADO);
		prmsPeriodos.put("lstEstados", lstEstados);
		return periodoDAO.listByEstados(prmsPeriodos);		
	}
	

	@Override
	public void getEvaluador() {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public List<Evaluado> listarPersonalEvaluable(String codPeriodo, 
			String codUnidadOrganizacional, String indControl, String codPersonal) {
		
		Evaluado paramSearch = new Evaluado();
		paramSearch.setCodPeriodo(codPeriodo);
		paramSearch.setCodUnidadOrganizacional(codUnidadOrganizacional);
		paramSearch.setCodPersonal(codPersonal);
		paramSearch.setIndAccion(Constantes.LISTA_ENVIADA);
		
		//el indicador de control solo se envía en las revisiones
		if(Constantes.CONTROL_REVISOR.equals(indControl)){
			paramSearch.setIndControl(indControl);//solo se toma lo evaluado
			//en la revisión solo se aceptan 3 estados: En Revisión, Observados y Conformes...
			List<String> condiciones = new ArrayList<String>();
			condiciones.add(Constantes.CONDICION_CONFORME);
			condiciones.add(Constantes.CONDICION_EN_REVISION);
			condiciones.add(Constantes.CONDICION_OBSERVADO);
			paramSearch.setCondiciones(condiciones);
		}
		else{
			//Para el evaluador...
			List<String> condiciones = new ArrayList<String>();
			condiciones.add(Constantes.CONDICION_NO_EVALUADO);
			condiciones.add(Constantes.CONDICION_INCOMPLETO);
			condiciones.add(Constantes.CONDICION_EVALUADO);
			condiciones.add(Constantes.CONDICION_EN_REVISION);
			condiciones.add(Constantes.CONDICION_CONFORME);
			condiciones.add(Constantes.CONDICION_OBSERVADO);
			condiciones.add(Constantes.CONDICION_TRANSFERIDO);//*
			
			//Aquí agregamos los que están apelados y en reclamo
			condiciones.add(Constantes.CONDICION_APELADO);
			condiciones.add(Constantes.CONDICION_EN_RECLAMO);
			
			paramSearch.setCondiciones(condiciones);
			paramSearch.setIndControl(indControl);//solo se toma lo que debería estar en la bandeja del evaluador
		}
		
		List<Evaluado> evaluados = evaluacionDAO.listarEvaluados(paramSearch);
		for(Evaluado e:evaluados){
			Parametro categoria = codigosDAO.selectByPrimaryKey(Constantes.PARAMETRO_CARGOS,e.getCodCategoria());
			Parametro grupo = codigosDAO.selectByPrimaryKey(Constantes.PARAMETRO_GRUPOS,e.getCodGrupo());
			Parametro condicion = paramDAO.selectByPrimaryKey(Constantes.PARAMETRO_CONDICION_NOTIFICADO,e.getIndCondicion());
			e.setDesCategoria(categoria.getDesParametro().trim());
			e.setDesGrupo(grupo.getDesParametro().trim());
			e.setDesCondicion(condicion.getDesParametro().trim());//Hay que sacarlo de la tabla t99codigos
			
			UnidadOrganizacional uuoo = getUUOO(e.getCodUnidadOrganizacionalPersonal());
			e.setDesUnidadOrganizacionalPersonal(uuoo.getDesUnidadOrganizacional().trim());
			
			if(codPersonal != null && e.getCodPersonalEvaluador() != null)
				e.setDesNombreCompletoEvaluador(personalDAO.obtenerNombreCompleto(e.getCodPersonalEvaluador()));
			else
				e.setDesNombreCompletoEvaluador("");
			if(e.getCodPersonalEvaluador() == null)
				e.setCodPersonalEvaluador("");
			
		}
		return evaluados;
	}
	
	

	@Override
	public List<Comportamiento> listarCompetenciasPorGrupo(String codGrupo,String codPers,String codPeriodo) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codGrupo", codGrupo);
		paramSearch.put("codTipo", Constantes.TIPO_FACTOR_COMPETENCIA);
		paramSearch.put("codEstado", Constantes.ESTADO_COMPORTAMIENTO_ACTIVO);
		paramSearch.put("codPers", codPers);
		paramSearch.put("codPeriodo", codPeriodo);
		return comportamientoDAO.listarPorGrupoCompetencia(paramSearch);
	}


	@Override
	public List<Comportamiento> listarComportamientosPorCompetencia(String codPersonal, String codCompetencia, String codPeriodo,String esDirectivo) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPersonal", codPersonal);//El código de la competencia ya incluye el código del grupo...
		paramSearch.put("codCompetencia", codCompetencia);//El código de la competencia ya incluye el código del grupo...
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codTipo", Constantes.TIPO_FACTOR_COMPORTAMIENTO);
		paramSearch.put("codEstado", Constantes.ESTADO_COMPORTAMIENTO_ACTIVO);
		paramSearch.put("esDirectivo", esDirectivo);
		return comportamientoDAO.listarPorCompetencia(paramSearch);//Este método se trae también la calificación y selección del comportamiento si lo hubiera
	}
	
	@Override
	public List<String> listarNivelesPorPeriodo(String codPeriodo) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);		
		List<String> lista=null;
		return lista;//comportamientoDAO.listarNivelesPorPeriodo(paramSearch);
	}
	
	@Override
	public void registrarEvaluacion(Evaluacion evaluacion, Evaluado evaluado, 
			List<RendimientoDetalle> rendimientos,List<Rendimiento> competencias, String indCondicionActual) {
		// TODO Auto-generated method stub
		
		//1. Actualizamos el estado del evaluado a incompleto o a evaluado.
		//if(!Constantes.CONDICION_CONFORME.equals(indCondicionActual)){		//jquispecoi
			evaluacionDAO.updateByPrimaryKeySelective(evaluado);	
		//}
		
		//2. Actualizamos los comentarios del evaluado
		Evaluacion paramSearchEvaluacion = new Evaluacion();
		paramSearchEvaluacion.setCodPeriodo(evaluacion.getCodPeriodo());
		paramSearchEvaluacion.setCodPersonal(evaluacion.getCodPersonal());
		paramSearchEvaluacion.setCodUnidadOrganizacional(evaluacion.getCodUnidadOrganizacional());
		Evaluacion evaluacionBD = evaluacionDetalleDAO.selectByPrimaryKey(paramSearchEvaluacion);
		if(evaluacionBD!=null)evaluacionDetalleDAO.updateByPrimaryKeySelective(evaluacion);	
		else evaluacionDetalleDAO.insertSelective(evaluacion);
		
		//3. Actualizamos la evaluación por competencias
		for(Rendimiento rendimiento:competencias){
			Rendimiento rendimientoSearch = new Rendimiento();
			rendimientoSearch.setCodPeriodo(rendimiento.getCodPeriodo());
			rendimientoSearch.setCodPersonal(rendimiento.getCodPersonal());
			rendimientoSearch.setCodTipEvaluador(rendimiento.getCodTipEvaluador());
			rendimientoSearch.setCodCompetencia(rendimiento.getCodCompetencia());
			rendimientoSearch.setCodRegistroEvaluador(rendimiento.getCodRegistroEvaluador());
			Rendimiento rendimientoBD = rendimientoDAO.selectByPrimaryKey(rendimientoSearch);
			if(rendimientoBD!=null){
				rendimientoDAO.updateByPrimaryKeySelective(rendimiento);
			}else{
				rendimientoDAO.insertSelective(rendimiento);
			}
		}
		
		//4. Actualizamos la evaluación por comportamientos...
		for(RendimientoDetalle rendimientoDetalle:rendimientos){
			RendimientoDetalle rendimientoDetalleSearch = new RendimientoDetalle();
			rendimientoDetalleSearch.setCodPeriodo(rendimientoDetalle.getCodPeriodo());
			rendimientoDetalleSearch.setCodPersonal(rendimientoDetalle.getCodPersonal());
			rendimientoDetalleSearch.setCodTipEvaluador(rendimientoDetalle.getCodTipEvaluador());
			rendimientoDetalleSearch.setCodCompetencia(rendimientoDetalle.getCodCompetencia());
			rendimientoDetalleSearch.setCodComportamiento(rendimientoDetalle.getCodComportamiento());
			rendimientoDetalleSearch.setCodRegistroEvaluador(rendimientoDetalle.getCodRegistroEvaluador());
			RendimientoDetalle rendimientoDetalleBD = rendimientoDetalleDAO.selectByPrimaryKey(rendimientoDetalleSearch);
			if(rendimientoDetalleBD!=null){
				rendimientoDetalleDAO.updateByPrimaryKeySelective(rendimientoDetalle);
			}else{
				rendimientoDetalleDAO.insertSelective(rendimientoDetalle);
			}			
		}
		String server_intranet = "http://intranet";
		String ver_formato="2.4.2.1.2";
		String url = "/ol-ti-iaevaldesem/evaluacionCompetencia/consulta";	
		String des_link = server_intranet + MenuCliente.generaInvocacionURL(ver_formato,null, true,MenuCliente.INTRANET, url);
		if(log.isDebugEnabled()) log.debug("URL_consulta:"+des_link);
		
		
		String correoPersonal = correosDAO.selectByPrimaryKey(evaluacion.getCodPersonal());
		String nombresApellidos=personalDAO.obtenerNombreCompleto(evaluacion.getCodPersonal());
		if(log.isDebugEnabled()) log.debug("Personal:"+nombresApellidos);		 
		String asunto = Constantes.ASUNTO_CORREO;
		
		try{
			if(correoPersonal != null)
			{
				StringBuilder mensaje = new StringBuilder("<html><head><title>Notificaci&oacute;n - Comunicaci&oacute;n del Nivel Esperado</title><style>")
				.append(".T1 {font-style  : normal;font-size :10pt;color:")
				.append("#FFFFFF;background  : #336699;font-family : Tahoma,Verdana,Arial,Helvetica,sans-serif ;}</style></head>")
				.append("<body><table width='100%' align='center' class='T1'><tr><td><center><strong>Notificaci&oacute;n<br>Comunicaci&oacute;n del Nivel Esperado</strong></center></td></tr></table><br><br>")				
				.append("<table>")		
				.append("<tr><td><strong>Estimado (a)</strong></td><tr><td><em>").append(nombresApellidos)
				.append("</em></td></tr></table><table>")
				.append("<tr><td class='membrete'>Como parte del ciclo de gesti&oacute;n del desempe&ntilde;o 2018, se comunica que se ha registrado el <b><i>nivel de desarrollo esperado de las competencias transversales a ser evaluadas</i></b>. Puede revisarla haciendo clic  <a href='")
				.append(des_link)								
				.append("'>")
				.append("Aqu&iacute;</a>.</td></tr>")
				.append("<tr><td><br><br></td></tr>")
				.append("<tr><td class='dato'>")				
				.append("Lima,"+" "+ new FechaBean().getDia()+" de "+ new FechaBean().getMesletras()+" de "+ new FechaBean().getAnho())				
				.append("</td></tr>")
				.append("<tr><td>&nbsp;</td></tr>")
				.append("<tr><td>Atentamente;</td></tr>")
				.append("<tr><td>&nbsp;</td></tr>")
				.append("<tr><td>Divisi&oacute;n de Gesti&oacute;n de Talento-GDP</td></tr>")
				.append("<tr><td>Intendencia Nacional de Recursos Humanos</td></tr><br>");
				mensaje.append("</table></body></html>");							
				if(log.isDebugEnabled()) log.debug("CorreoEnviado:"+mensaje.toString());
				enviarEmail(correoPersonal, asunto, mensaje.toString(), null);
			}				
		}catch(Exception e){
			log.error("Ha ocurrido un error al enviar correo: " + e.getMessage(), e);
			
		}
		
	}
	
	
	@Override
	public void enviarEvaluacion(List<Evaluado> evaluados) {
		//Solo se le cambia el estado de los que están en revisión...
		for(Evaluado evaluado:evaluados){
			
			//1. Actualizamos el estado del evaluado a incompleto o a evaluado.
			Evaluado evaluadoUpdate = new Evaluado();
			evaluadoUpdate.setCodPeriodo(evaluado.getCodPeriodo());//pk
			evaluadoUpdate.setCodPersonal(evaluado.getCodPersonal());//pk
			evaluadoUpdate.setCodUnidadOrganizacionalPersonal(evaluado.getCodUnidadOrganizacionalPersonal());//pk

			//Solo se cambia el estado si va de Evaluado->Revisión
			if(Constantes.CONDICION_EVALUADO.equals(evaluado.getIndCondicion())){
				evaluadoUpdate.setIndCondicion(Constantes.CONDICION_EN_REVISION);	
			}
			evaluadoUpdate.setIndControl(Constantes.CONTROL_REVISOR);//Siempre actualizamos a control del revisor.
			evaluacionDAO.updateByPrimaryKeySelective(evaluadoUpdate);
		}
	}
	
	@Override
	public boolean existeRevisor(String codPeriodo, String codUnidadOrganizacional){
		HashMap<String, Object> paramSearch = new HashMap<String, Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codUnidadOrganizacional", codUnidadOrganizacional);
		paramSearch.put("codTipEvaluador", Constantes.TIPO_REVISOR);
		if(periodoUUOOEvaluadorDAO.listarPersonal(paramSearch).isEmpty())
			return false;
		else
			return true;
	}
	
	@Override
	public void devolverEvaluacion(List<Evaluado> evaluados) {
		for(Evaluado evaluado:evaluados){
			Evaluado evaluadoUpdate = new Evaluado();
			evaluadoUpdate.setCodPeriodo(evaluado.getCodPeriodo());//pk
			evaluadoUpdate.setCodPersonal(evaluado.getCodPersonal());//pk
			evaluadoUpdate.setCodUnidadOrganizacionalPersonal(evaluado.getCodUnidadOrganizacionalPersonal());//pk
			evaluadoUpdate.setIndControl(Constantes.CONTROL_EVALUADOR);
			evaluacionDAO.updateByPrimaryKeySelective(evaluadoUpdate);
		}
	}
	
	
	
	
	
	@Override
	public void transferirEvaluacion(List<Evaluado> evaluados, String codUsuario) {
		for(Evaluado evaluado:evaluados){
			Evaluado evaluadoUpdate = new Evaluado();
			evaluadoUpdate.setCodPeriodo(evaluado.getCodPeriodo());//pk
			evaluadoUpdate.setCodPersonal(evaluado.getCodPersonal());//pk
			evaluadoUpdate.setCodUnidadOrganizacionalPersonal(evaluado.getCodUnidadOrganizacionalPersonal());//pk
			evaluadoUpdate.setIndCondicion(Constantes.CONDICION_TRANSFERIDO);
			evaluacionDAO.updateByPrimaryKeySelective(evaluadoUpdate);
			
			//t43
			Evaluacion evaluacion = new Evaluacion();
			evaluacion.setCodPeriodo(evaluado.getCodPeriodo());
			evaluacion.setCodPersonal(evaluado.getCodPersonal());
			evaluacion.setCodUnidadOrganizacional(evaluado.getCodUnidadOrganizacional());
			evaluacion.setCodEstado(Constantes.CONDICION_TRANSFERIDO);
			evaluacion.setFecRegistro(new Date());
			evaluacion.setCodUsuario(codUsuario);
			evaluacionDetalleDAO.updateByPrimaryKeySelective(evaluacion);	
		}
	}

	@Override
	public void actualizarEvaluacion(Evaluado evaluado) {
		evaluacionDAO.updateByPrimaryKeySelective(evaluado);
	}

	@Override
	public List<ReporteMonitoreo> reporteMonitoreoInstitucional(
			String codPeriodo) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		
		BigDecimal totalEvaluar = BigDecimal.ZERO;
		BigDecimal totalNoEvaluados = BigDecimal.ZERO;
		BigDecimal totalSinTransferir = BigDecimal.ZERO;
		BigDecimal totalTransferidos = BigDecimal.ZERO;
		List<ReporteMonitoreo> reporte = evaluacionDAO.reporteInstitucional(paramSearch);
		for(ReporteMonitoreo r:reporte){
			totalEvaluar = totalEvaluar.add(r.getTotalEvaluar());
			totalNoEvaluados = totalNoEvaluados.add(r.getTotalNoEvaluados());
			totalSinTransferir = totalSinTransferir.add(r.getTotalSinTransferir());
			totalTransferidos = totalTransferidos.add(r.getTotalTransferidos());
		}
		ReporteMonitoreo totales = new ReporteMonitoreo();
		totales.setCodUnidadOrganizacional("000000");
		totales.setDesUnidadOrganizacional("Total General");
		totales.setTotalEvaluar(totalEvaluar);
		totales.setTotalNoEvaluados(totalNoEvaluados);
		totales.setTotalSinTransferir(totalSinTransferir);
		totales.setTotalTransferidos(totalTransferidos);
		reporte.add(totales);
		return reporte;
	}

	@Override
	public List<ReporteMonitoreo> reporteMonitoreoPorAdjunta(String codPeriodo,
			String codAdjunta) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codAdjunta", codAdjunta);
		
		BigDecimal totalEvaluar = BigDecimal.ZERO;
		BigDecimal totalNoEvaluados = BigDecimal.ZERO;
		BigDecimal totalSinTransferir = BigDecimal.ZERO;
		BigDecimal totalTransferidos = BigDecimal.ZERO;
		List<ReporteMonitoreo> reporte = evaluacionDAO.reporteAdjunta(paramSearch);
		for(ReporteMonitoreo r:reporte){
			totalEvaluar = totalEvaluar.add(r.getTotalEvaluar());
			totalNoEvaluados = totalNoEvaluados.add(r.getTotalNoEvaluados());
			totalSinTransferir = totalSinTransferir.add(r.getTotalSinTransferir());
			totalTransferidos = totalTransferidos.add(r.getTotalTransferidos());
		}
		ReporteMonitoreo totales = new ReporteMonitoreo();
		totales.setCodUnidadOrganizacional("000000");
		totales.setDesUnidadOrganizacional("Total General");
		totales.setTotalEvaluar(totalEvaluar);
		totales.setTotalNoEvaluados(totalNoEvaluados);
		totales.setTotalSinTransferir(totalSinTransferir);
		totales.setTotalTransferidos(totalTransferidos);
		reporte.add(totales);
		return reporte;
	}

	@Override
	public List<ReporteMonitoreo> reporteMonitoreoPorOrgano(String codPeriodo,
			String codOrgano) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codOrgano", codOrgano);
		BigDecimal totalEvaluar = BigDecimal.ZERO;
		BigDecimal totalNoEvaluados = BigDecimal.ZERO;
		BigDecimal totalSinTransferir = BigDecimal.ZERO;
		BigDecimal totalTransferidos = BigDecimal.ZERO;
		List<ReporteMonitoreo> reporte = evaluacionDAO.reporteOrgano(paramSearch);
		for(ReporteMonitoreo r:reporte){
			totalEvaluar = totalEvaluar.add(r.getTotalEvaluar());
			totalNoEvaluados = totalNoEvaluados.add(r.getTotalNoEvaluados());
			totalSinTransferir = totalSinTransferir.add(r.getTotalSinTransferir());
			totalTransferidos = totalTransferidos.add(r.getTotalTransferidos());
		}
		ReporteMonitoreo totales = new ReporteMonitoreo();
		totales.setCodUnidadOrganizacional("000000");
		totales.setDesUnidadOrganizacional("Total General");
		totales.setTotalEvaluar(totalEvaluar);
		totales.setTotalNoEvaluados(totalNoEvaluados);
		totales.setTotalSinTransferir(totalSinTransferir);
		totales.setTotalTransferidos(totalTransferidos);
		reporte.add(totales);
		return reporte;
	}
	
	@Override
	public List<ReporteMonitoreo> reporteMonitoreoPorJerarquiaUnidad(String codPeriodo, String codJerarquia, String codNivel) {
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codJerarquia", codJerarquia); //5E2, 5E23, 5E230
		paramSearch.put("codNivel", codNivel); //NIVEL3, NIVEL4, NIVEL5 
		BigDecimal totalEvaluar = BigDecimal.ZERO;
		BigDecimal totalNoEvaluados = BigDecimal.ZERO;
		BigDecimal totalSinTransferir = BigDecimal.ZERO;
		BigDecimal totalTransferidos = BigDecimal.ZERO;
		List<ReporteMonitoreo> reporte = evaluacionDAO.reporteByJerarquiaUnidad(paramSearch);
		for(ReporteMonitoreo r:reporte){
			totalEvaluar = totalEvaluar.add(r.getTotalEvaluar());
			totalNoEvaluados = totalNoEvaluados.add(r.getTotalNoEvaluados());
			totalSinTransferir = totalSinTransferir.add(r.getTotalSinTransferir());
			totalTransferidos = totalTransferidos.add(r.getTotalTransferidos());
		}
		ReporteMonitoreo totales = new ReporteMonitoreo();
		totales.setCodUnidadOrganizacional("000000");
		totales.setDesUnidadOrganizacional("Total General");
		totales.setTotalEvaluar(totalEvaluar);
		totales.setTotalNoEvaluados(totalNoEvaluados);
		totales.setTotalSinTransferir(totalSinTransferir);
		totales.setTotalTransferidos(totalTransferidos);
		reporte.add(totales);
		return reporte;
	}
	
	

	@Override
	public List<ReporteCompetencia> reporteCompetencias(String condicion, String codPeriodo, String codAdjunta, String codOrgano) {
		String desCondicion = "-";
		if("T".equals(condicion))
			desCondicion = "transferidos";
		else if("S".equals(condicion))
			desCondicion = "sinTransferir";
			
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codAdjunta", codAdjunta);
		paramSearch.put("codOrgano", codOrgano);
		paramSearch.put(desCondicion, "-");
		Map<String,Object> reporteMap;
		
		if(codAdjunta==null && codOrgano==null)reporteMap = evaluacionDAO.reporteCompetenciasInstitucional(paramSearch);
		else if(codOrgano==null)reporteMap = evaluacionDAO.reporteCompetenciasAdjunta(paramSearch);
		else reporteMap = evaluacionDAO.reporteCompetenciasOrgano(paramSearch);
		
		List<ReporteCompetencia> reporte = new ArrayList<ReporteCompetencia>();
		
		BigDecimal altaCompetenciaTotal = (BigDecimal)reporteMap.get("altacompetencia");
		BigDecimal competenteTotal = (BigDecimal)reporteMap.get("competente");
		BigDecimal competenciaDesarrolloTotal = (BigDecimal)reporteMap.get("competenciadesarrollo");
		BigDecimal bajaCompetenciaTotal = (BigDecimal)reporteMap.get("bajacompetencia");
		BigDecimal total = (BigDecimal)reporteMap.get("total");
		
		//prevención de posibles nulls, todo a cero.
		altaCompetenciaTotal = altaCompetenciaTotal==null?BigDecimal.ZERO:altaCompetenciaTotal; 
		competenteTotal = competenteTotal==null?BigDecimal.ZERO:competenteTotal;
		competenciaDesarrolloTotal = competenciaDesarrolloTotal==null?BigDecimal.ZERO:competenciaDesarrolloTotal;
		bajaCompetenciaTotal = bajaCompetenciaTotal==null?BigDecimal.ZERO:bajaCompetenciaTotal;
		total = total==null?BigDecimal.ZERO:total;
		
		if(!total.equals(BigDecimal.ZERO))total = total.multiply(new BigDecimal("1.00"));
		
		BigDecimal cien = new BigDecimal("100.00");
		
		ReporteCompetencia detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("01");
		detalle.setDesCompetencia("Alta Competencia");
		detalle.setCntTotalCompetencia(altaCompetenciaTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((altaCompetenciaTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("02");
		detalle.setDesCompetencia("Competente");
		detalle.setCntTotalCompetencia(competenteTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((competenteTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("03");
		detalle.setDesCompetencia("Competencia en desarrollo");
		detalle.setCntTotalCompetencia(competenciaDesarrolloTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((competenciaDesarrolloTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("04");
		detalle.setDesCompetencia("Baja competencia");
		detalle.setCntTotalCompetencia(bajaCompetenciaTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((bajaCompetenciaTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
				
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("05");
		detalle.setDesCompetencia("Total General");
		detalle.setCntTotalCompetencia(total);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((total.divide(total)).multiply(cien));
		reporte.add(detalle);
		
		return reporte;
	}
	
	
	@Override
	public List<ReporteCompetencia> reporteCompetenciasJerarquiaUnidad(String condicion, String codPeriodo, String codJerarquia, String codNivel) {
		
		String desCondicion = "-";
		if("T".equals(condicion))
			desCondicion = "transferidos";
		else if("S".equals(condicion))
			desCondicion = "sinTransferir";
			
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		paramSearch.put("codJerarquia", codJerarquia);
		paramSearch.put("codNivel", codNivel);
		paramSearch.put(desCondicion, "-");
		Map<String,Object> reporteMap;
		
		reporteMap = evaluacionDAO.reporteCompetenciasJerarquiaUnidad(paramSearch);
		
		List<ReporteCompetencia> reporte = new ArrayList<ReporteCompetencia>();
		
		BigDecimal altaCompetenciaTotal = (BigDecimal)reporteMap.get("altacompetencia");
		BigDecimal competenteTotal = (BigDecimal)reporteMap.get("competente");
		BigDecimal competenciaDesarrolloTotal = (BigDecimal)reporteMap.get("competenciadesarrollo");
		BigDecimal bajaCompetenciaTotal = (BigDecimal)reporteMap.get("bajacompetencia");
		BigDecimal total = (BigDecimal)reporteMap.get("total");
		
		//prevención de posibles nulls, todo a cero.
		altaCompetenciaTotal = altaCompetenciaTotal==null?BigDecimal.ZERO:altaCompetenciaTotal; 
		competenteTotal = competenteTotal==null?BigDecimal.ZERO:competenteTotal;
		competenciaDesarrolloTotal = competenciaDesarrolloTotal==null?BigDecimal.ZERO:competenciaDesarrolloTotal;
		bajaCompetenciaTotal = bajaCompetenciaTotal==null?BigDecimal.ZERO:bajaCompetenciaTotal;
		total = total==null?BigDecimal.ZERO:total;
		
		if(!total.equals(BigDecimal.ZERO))total = total.multiply(new BigDecimal("1.00"));
		
		BigDecimal cien = new BigDecimal("100.00");
		
		ReporteCompetencia detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("01");
		detalle.setDesCompetencia("Alta Competencia");
		detalle.setCntTotalCompetencia(altaCompetenciaTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((altaCompetenciaTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("02");
		detalle.setDesCompetencia("Competente");
		detalle.setCntTotalCompetencia(competenteTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((competenteTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("03");
		detalle.setDesCompetencia("Competencia en desarrollo");
		detalle.setCntTotalCompetencia(competenciaDesarrolloTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((competenciaDesarrolloTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
		
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("04");
		detalle.setDesCompetencia("Baja competencia");
		detalle.setCntTotalCompetencia(bajaCompetenciaTotal);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((bajaCompetenciaTotal.divide(total,4,BigDecimal.ROUND_HALF_UP)).multiply(cien));
		reporte.add(detalle);
				
		detalle = new ReporteCompetencia();
		detalle.setCodCompetencia("05");
		detalle.setDesCompetencia("Total General");
		detalle.setCntTotalCompetencia(total);
		if(!BigDecimal.ZERO.equals(total))detalle.setPjeAvance((total.divide(total)).multiply(cien));
		reporte.add(detalle);
		
		return reporte;
	}
	
	
	public void actualizarEstadoEntrevista(Evaluacion evaluacion) {
		// TODO Auto-generated method stub
		evaluacionDetalleDAO.updateByPrimaryKeySelective(evaluacion);	
	}
	
	
	@Override
	public List<ReporteMonitoreoUnidad> reporteMonitoreoUnidades(String codPeriodo) {
		if(log.isDebugEnabled()) log.debug("method reporteMonitoreoUnidades");
		Map<String,Object> paramSearch = new HashMap<String,Object>();
		paramSearch.put("codPeriodo", codPeriodo);
		
		List<ReporteMonitoreoUnidad> reportes = evaluacionDAO.reporteMonitoreoUnidades(paramSearch);//lista
		
		reportes.add(evaluacionDAO.reporteMonitoreoUnidadesTotales(paramSearch)); //totales
		
		return reportes;
	}
	
	
	/**
	 * Método exporta unidad a validar
	 * @param params
	 * @return
	 */
		public boolean generaMonitoreoUnidadesXLSX(HashMap<String, Object> params){
			boolean bExito = false;
			String sFileNameFull="";
			String sFileName="";
			ArrayList<ReporteMonitoreoUnidad> lstMonitoreoUnidades = null;
			try{		 
				lstMonitoreoUnidades = (ArrayList<ReporteMonitoreoUnidad>)params.get("lstMonitoreoUnidades");
				Workbook wb = new XSSFWorkbook();
				Sheet sheet = wb.createSheet("Información");
				Row row;
				Cell c;		
				
		        CellStyle style = wb.createCellStyle();
		        Font font = wb.createFont();
		        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		        style.setFont(font);
		        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		        
				// Creamos la cabecera
		        String[] arrTitle = {"Código UUOO","Nombre UUOO","Total evaluados","","No enviados a Validar (lista)","Enviados a Validar (lista)","Validados (lista)","","Evaluador Bandeja","Revisor Bandeja","",
		        					"Pend. de evaluar","Pend. de enviar a revisor","Pend. de revisar","Pend. de devolver a evaluador","Pend. de transferir","Tranferidos","","Registro evaluador","Nombre evaluador","Correo evaluador","","Registro revisor","Nombre revisor","Correo revisor"};
		        row = sheet.createRow(0);
		        for(int i=0; i<arrTitle.length; i++){
		        	c = row.createCell(i);
					c.setCellValue(arrTitle[i]);
					c.setCellStyle(style);
		        }

		        // información
		        int cntItems = 1;
				for(ReporteMonitoreoUnidad monitoreoUnidad:lstMonitoreoUnidades){
					row = sheet.createRow(cntItems++);
					
					c = row.createCell(0); c.setCellValue(monitoreoUnidad.getUnidadCodigo());
					c = row.createCell(1); c.setCellValue(monitoreoUnidad.getUnidadNombre());
					c = row.createCell(2); c.setCellValue(monitoreoUnidad.getTotalEvaluar());
					c = row.createCell(3); c.setCellValue("");
					c = row.createCell(4); c.setCellValue(monitoreoUnidad.getTotalNoEnviadosValidarLista());
					c = row.createCell(5); c.setCellValue(monitoreoUnidad.getTotalEnviadosValidarLista());
					c = row.createCell(6); c.setCellValue(monitoreoUnidad.getTotalValidadosLista());
					c = row.createCell(7); c.setCellValue("");
					c = row.createCell(8); c.setCellValue(monitoreoUnidad.getTotalBandejaEvaluador());
					c = row.createCell(9); c.setCellValue(monitoreoUnidad.getTotalBandejaRevisor());
					c = row.createCell(10);c.setCellValue("");
					c = row.createCell(11);c.setCellValue(monitoreoUnidad.getTotalPendientesEvaluar());
					c = row.createCell(12);c.setCellValue(monitoreoUnidad.getTotalPendientesEnviarARevisor());
					c = row.createCell(13);c.setCellValue(monitoreoUnidad.getTotalPendientesRevisar());
					c = row.createCell(14);c.setCellValue(monitoreoUnidad.getTotalPendientesDevolverAEvaluador());
					c = row.createCell(15);c.setCellValue(monitoreoUnidad.getTotalPendientesTransferir());
					c = row.createCell(16);c.setCellValue(monitoreoUnidad.getTotalBandejaTransferidos());
					c = row.createCell(17);c.setCellValue("");
					c = row.createCell(18);c.setCellValue(monitoreoUnidad.getEvaluadorRegistro());
					c = row.createCell(19);c.setCellValue(monitoreoUnidad.getEvaluadorNombre());
					c = row.createCell(20);c.setCellValue(monitoreoUnidad.getEvaluadorCorreo());
					c = row.createCell(21);c.setCellValue("");
					c = row.createCell(22);c.setCellValue(monitoreoUnidad.getRevisorRegistro());
					c = row.createCell(23);c.setCellValue(monitoreoUnidad.getRevisorNombre());
					c = row.createCell(24);c.setCellValue(monitoreoUnidad.getRevisorCorreo());
				}
				
			    // ajusta el ancho de las columnas en función de su contenido
		        final short numeroColumnas = sheet.getRow(0).getLastCellNum();
		        for (int i = 0; i < numeroColumnas; i++) 
		        	sheet.autoSizeColumn(i);
				
				//Write the Excel file
				SimpleDateFormat sdf = new SimpleDateFormat("_yyyyMMddHHmmss");
				String strToday = sdf.format(new Date());
				FileOutputStream fileOut;
				sFileName = "MONITOREO_UNIDADES_"+params.get("codigoPeriodo") + strToday + ".xlsx";
				URL urlRecurso = ((ServletContext)params.get("servletContext")).getResource("/tmp/");

				sFileNameFull = urlRecurso.getPath()+sFileName;			
				params.put("report_file_name", sFileName);
				params.put("report_full_file_name", sFileNameFull);
				fileOut = new FileOutputStream(sFileNameFull);		
				wb.write(fileOut);
				fileOut.close();
				bExito = true;
			}
			catch (Exception e) {
				bExito = false;
			 	log.error("***ERROR***",e);
			}		
			return bExito;
		}
		
		@Override
		public List<Evaluado> listarPersonalMonitoreoUnidad(String codPeriodo, String codUnidadOrganizacional) {
			if(log.isDebugEnabled()) log.debug("method listarPersonalMonitoreoUnidad");
			
			Evaluado paramSearch = new Evaluado();
			paramSearch.setCodPeriodo(codPeriodo);
			paramSearch.setCodUnidadOrganizacional(codUnidadOrganizacional);
			paramSearch.setCodEstado(Constantes.ESTADO_COMPORTAMIENTO_ACTIVO);
			String indAccion;
			String indControl;
			String indCondicion;
			
			List<Evaluado> evaluados = evaluacionDAO.listarEvaluados(paramSearch);
			for(Evaluado e:evaluados){
				if(e.getCodGrupo()!=null && e.getCodCategoria()!=null){	
					Parametro categoria = codigosDAO.selectByPrimaryKey(Constantes.PARAMETRO_CARGOS,e.getCodCategoria());
					Parametro grupo = codigosDAO.selectByPrimaryKey(Constantes.PARAMETRO_GRUPOS,e.getCodGrupo());
					Parametro condicion = paramDAO.selectByPrimaryKey(Constantes.PARAMETRO_CONDICION_EVALUADO,e.getIndCondicion());
					e.setDesCategoria(categoria.getDesParametro().trim());
					e.setDesGrupo(grupo.getDesParametro().trim());
					e.setDesCondicion(condicion.getDesParametro().trim());//Hay que sacarlo de la tabla t99codigos
				}
				
				indAccion = e.getIndAccion().trim();
				indControl = e.getIndControl()!=null?e.getIndControl().trim():"";
				indCondicion = e.getIndCondicion().trim();
				
				if(indAccion.equals(Constantes.LISTA_ENVIADA_VALIDAR))
					e.setEstLista("Enviado a Validar");
				else if(indAccion.equals(Constantes.LISTA_VALIDADA))
					e.setEstLista("Validado");
				else
					e.setEstLista("No enviado a Validar");
				
				if(indControl.equals(Constantes.CONTROL_EVALUADOR)){
					e.setEstBandeja("Evaluador");
					if(indCondicion.equals(Constantes.CONDICION_NO_EVALUADO) || indCondicion.equals(Constantes.CONDICION_INCOMPLETO))
						e.setEstProceso("Pend. de evaluar");
					else if(indCondicion.equals(Constantes.CONDICION_EVALUADO) || indCondicion.equals(Constantes.CONDICION_OBSERVADO))
						e.setEstProceso("Pend. de enviar a revisor");
					else if(indCondicion.equals(Constantes.CONDICION_CONFORME))
						e.setEstProceso("Pend. de transferir");
					else if(indCondicion.equals(Constantes.CONDICION_TRANSFERIDO))
						e.setEstProceso("Transferido");
				}else if(indControl.equals(Constantes.CONTROL_REVISOR)){
					e.setEstBandeja("Revisor");
					if(indCondicion.equals(Constantes.CONDICION_EN_REVISION))
						e.setEstProceso("Pend. de revisar");
					else if(indCondicion.equals(Constantes.CONDICION_CONFORME) || indCondicion.equals(Constantes.CONDICION_OBSERVADO))
						e.setEstProceso("Pend. de devolver a evaluador");
				}
				
			}
			return evaluados;
		}
		
		
	/**
	 * Método exporta unidad a validar
	 * @param params
	 * @return
	 */
		public boolean generaMonitoreoXLSX(HashMap<String, Object> params){
			boolean bExito = false;
			String sFileNameFull="";
			String sFileName="";
			ArrayList<ReporteMonitoreo> lstMonitoreo = null;
			String tituloUnidades;
			String tipoReporte;
			String nombreFile;
			try{		 
				lstMonitoreo = (ArrayList<ReporteMonitoreo>)params.get("lstMonitoreo");
				tipoReporte = (String)params.get("tipoReporte");
				Workbook wb = new XSSFWorkbook();
				Sheet sheet = wb.createSheet("Información");
				Row row;
				Cell c;		
				
		        CellStyle style = wb.createCellStyle();
		        Font font = wb.createFont();
		        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		        style.setFont(font);
		        style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		        
		        if(NIVEL_ORG_0.equals(tipoReporte)){
		        	nombreFile = "INTITUCIONAL";
		        	tituloUnidades = "ADJUNTA";		
		        }else if(NIVEL_ORG_1.equals(tipoReporte)){ 	
		        	nombreFile = "ADJUNTA";
		        	tituloUnidades = "ÓRGANO";		
		        }else if(NIVEL_ORG_2.equals(tipoReporte)){ 	
		        	nombreFile = "ORGANO";
		        	tituloUnidades = "SUB-ÓRGANO";	
		        }else{ 										
		        	nombreFile = "UUOO";
		        	tituloUnidades = "UUOO";			
		        }
		        
				// Creamos la cabecera
		        String[] arrTitle = {tituloUnidades,"Total a Evaluar","Total evaluados","Transferidos","Evaluados sin Transf.","No Evaluados"};
		        row = sheet.createRow(0);
		        for(int i=0; i<arrTitle.length; i++){
		        	c = row.createCell(i);
					c.setCellValue(arrTitle[i]);
					c.setCellStyle(style);
		        }

		        // información
		        int cntItems = 1;
				for(ReporteMonitoreo monitoreo:lstMonitoreo){
					row = sheet.createRow(cntItems++);
					
					c = row.createCell(0); c.setCellValue(monitoreo.getDesUnidadOrganizacional());
					c = row.createCell(1); c.setCellValue(monitoreo.getTotalEvaluar().intValue());
					c = row.createCell(2); c.setCellValue(monitoreo.getTotalTransferidos().intValue());
					c = row.createCell(4); c.setCellValue(monitoreo.getTotalSinTransferir().intValue());
					c = row.createCell(5); c.setCellValue(monitoreo.getTotalNoEvaluados().intValue());					
				}
				
			    // ajusta el ancho de las columnas en función de su contenido
		        final short numeroColumnas = sheet.getRow(0).getLastCellNum();
		        for (int i = 0; i < numeroColumnas; i++) 
		        	sheet.autoSizeColumn(i);
				
				//Write the Excel file
				SimpleDateFormat sdf = new SimpleDateFormat("_yyyyMMddHHmmss");
				String strToday = sdf.format(new Date());
				FileOutputStream fileOut;
				sFileName =  "MONITOREO_" + params.get("codigoPeriodo") + "_" + nombreFile + "_" + params.get("codUnidadOrganizacional") + strToday + ".xlsx";
				URL urlRecurso = ((ServletContext)params.get("servletContext")).getResource("/tmp/");

				sFileNameFull = urlRecurso.getPath()+sFileName;			
				params.put("report_file_name", sFileName);
				params.put("report_full_file_name", sFileNameFull);
				fileOut = new FileOutputStream(sFileNameFull);		
				wb.write(fileOut);
				fileOut.close();
				bExito = true;
			}
			catch (Exception e) {
				bExito = false;
			 	log.error("***ERROR***",e);
			}		
			return bExito;
		}
		
	
		public int enviarEmail(String destinatario, String asunto, String mensaje, File file) {
			if(log.isDebugEnabled()) log.debug("enviarEmail: " + destinatario);
			
			JavaMailSenderImpl sender = new JavaMailSenderImpl();
			sender.setHost(propiedades.leePropiedad("servidor"));
			sender.setUsername(propiedades.leePropiedad("correoRemitentePorDefecto"));
			MimeMessage message = sender.createMimeMessage();
			try {
				MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
				helper.setFrom(propiedades.leePropiedad("correoRemitentePorDefecto"), propiedades.leePropiedad("nombreRemitentePorDefecto"));
				helper.setTo(destinatario);
				helper.setSubject(asunto);
				helper.setText(mensaje, true);
				if (file != null){
					helper.addAttachment(file.getName(), file);
				}
				sender.send(message);
			} catch (Exception e) {			
				log.error("ERROR: no se pudo enviar el correo electronico a " + destinatario + "\n" + e.getMessage(), e);
				return 0;
			}
			return 1;		
		}
		
		
		@Override
		public boolean registrarLogConsulta(Seguimiento seguimiento) {
			boolean estado = false;
			try{
				//actualiza seguimiento
				seguimiento.setIndEstado("2");
				seguimiento.setDesEvaluacion("Consulta evaluacion del periodo " + seguimiento.getPerEvalua());
				seguimiento.setFecGraba(new Date());
				seguimientoDAO.insertSelective(seguimiento);
				
				//actualiza evaluacion
				Evaluacion evaluacion = new Evaluacion();
				evaluacion.setCodEstadoConsulta("2");
				evaluacion.setCodPeriodo(seguimiento.getPerEvalua());
				evaluacion.setCodPersonal(seguimiento.getCodPers());
				evaluacion.setCodUnidadOrganizacional(seguimiento.getCodUnidadOrganizacional());
				evaluacion.setFecRegistro(new Date());
				evaluacion.setCodUsuario(seguimiento.getCodUsuario());
				evaluacionDetalleDAO.updateByPrimaryKeySelective(evaluacion);
				
				estado = true;
			}catch(Exception e){
				log.error("Ha ocurrido un error en registras el log de consulta: " + e.getMessage(), e);
				
			}
			return estado;
		}
		
}
