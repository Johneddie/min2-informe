package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T01paramDAO;

public class SqlMapT01paramDAO extends SqlMapClientDaoSupport implements T01paramDAO{

	@Override
	public Parametro selectByPrimaryKey(
			String codParametro, String codDataParametro) {
		Parametro paramSearch = new Parametro();
		paramSearch.setCodParametro(codParametro);
		paramSearch.setCodDataParametro(codDataParametro);
		return (Parametro)getSqlMapClientTemplate().queryForObject("T01param.selectByPrimaryKey", paramSearch);
	}
	
	@Override
	public List<Parametro> listarPorParametros(Parametro params){
		return (List<Parametro>)getSqlMapClientTemplate().queryForList("T01param.selectByParams", params);
	}

}
