package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.math.BigDecimal;
import java.util.Date;

public class Rendimiento {

	private String codPeriodo;
	private String codPersonal;
	private String codTipEvaluador;
	private String codRegistroEvaluador;
	private Date fecEvaluacion;
	private String codCompetencia;
	private BigDecimal cntNotaCompetencia;
	private String codBorradoLogico;
	
	private Date fecRegistro;
	private String codUsuario;
	private String desObserv;
	
	public String getDesObserv() {
		return desObserv;
	}
	public void setDesObserv(String desObserv) {
		this.desObserv = desObserv;
	}
	public String getCodPeriodo() {
		return codPeriodo;
	}
	public void setCodPeriodo(String codPeriodo) {
		this.codPeriodo = codPeriodo;
	}
	public String getCodPersonal() {
		return codPersonal;
	}
	public void setCodPersonal(String codPersonal) {
		this.codPersonal = codPersonal;
	}
	public String getCodTipEvaluador() {
		return codTipEvaluador;
	}
	public void setCodTipEvaluador(String codTipEvaluador) {
		this.codTipEvaluador = codTipEvaluador;
	}
	public String getCodRegistroEvaluador() {
		return codRegistroEvaluador;
	}
	public void setCodRegistroEvaluador(String codRegistroEvaluador) {
		this.codRegistroEvaluador = codRegistroEvaluador;
	}
	public Date getFecEvaluacion() {
		return fecEvaluacion;
	}
	public void setFecEvaluacion(Date fecEvaluacion) {
		this.fecEvaluacion = fecEvaluacion;
	}
	public String getCodCompetencia() {
		return codCompetencia;
	}
	public void setCodCompetencia(String codCompetencia) {
		this.codCompetencia = codCompetencia;
	}
	public BigDecimal getCntNotaCompetencia() {
		return cntNotaCompetencia;
	}
	public void setCntNotaCompetencia(BigDecimal cntNotaCompetencia) {
		this.cntNotaCompetencia = cntNotaCompetencia;
	}
	
	public Date getFecRegistro() {
		return fecRegistro;
	}
	public void setFecRegistro(Date fecRegistro) {
		this.fecRegistro = fecRegistro;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getCodBorradoLogico() {
		return codBorradoLogico;
	}
	public void setCodBorradoLogico(String codBorradoLogico) {
		this.codBorradoLogico = codBorradoLogico;
	}
	
}
