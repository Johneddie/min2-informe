package pe.gob.sunat.recurso2.humano.evaluacion.bean;

import java.math.BigDecimal;

public class ReporteDistribucion {

	private String codCompetencia;
	private String desCompetencia;
	
	private BigDecimal cntAltaCompetencia = BigDecimal.ZERO;
	private BigDecimal cntCompetente = BigDecimal.ZERO;
	private BigDecimal cntCompetenciaDesarrollo = BigDecimal.ZERO;
	private BigDecimal cntBajaCompetencia = BigDecimal.ZERO;
	private BigDecimal cntTotal = BigDecimal.ZERO;
	
	private BigDecimal prcAltaCompetencia = BigDecimal.ZERO;
	private BigDecimal prcCompetente = BigDecimal.ZERO;
	private BigDecimal prcCompetenciaDesarrollo = BigDecimal.ZERO;
	private BigDecimal prcBajaCompetencia = BigDecimal.ZERO;
	private BigDecimal prcTotal = BigDecimal.ZERO;
	
	
	public String getCodCompetencia() {
		return codCompetencia;
	}
	public void setCodCompetencia(String codCompetencia) {
		this.codCompetencia = codCompetencia;
	}
	public String getDesCompetencia() {
		return desCompetencia;
	}
	public void setDesCompetencia(String desCompetencia) {
		this.desCompetencia = desCompetencia;
	}
	public BigDecimal getCntAltaCompetencia() {
		return cntAltaCompetencia;
	}
	public void setCntAltaCompetencia(BigDecimal cntAltaCompetencia) {
		this.cntAltaCompetencia = cntAltaCompetencia;
	}
	public BigDecimal getCntCompetente() {
		return cntCompetente;
	}
	public void setCntCompetente(BigDecimal cntCompentente) {
		this.cntCompetente = cntCompentente;
	}
	public BigDecimal getCntCompetenciaDesarrollo() {
		return cntCompetenciaDesarrollo;
	}
	public void setCntCompetenciaDesarrollo(BigDecimal cntCompetenciaDesarrollo) {
		this.cntCompetenciaDesarrollo = cntCompetenciaDesarrollo;
	}
	public BigDecimal getCntBajaCompetencia() {
		return cntBajaCompetencia;
	}
	public void setCntBajaCompetencia(BigDecimal cntBajaCompetencia) {
		this.cntBajaCompetencia = cntBajaCompetencia;
	}
	public BigDecimal getPrcAltaCompetencia() {
		return prcAltaCompetencia;
	}
	public void setPrcAltaCompetencia(BigDecimal prcAltaCompetencia) {
		this.prcAltaCompetencia = prcAltaCompetencia;
	}
	public BigDecimal getPrcCompetente() {
		return prcCompetente;
	}
	public void setPrcCompetente(BigDecimal prcCompentente) {
		this.prcCompetente = prcCompentente;
	}
	public BigDecimal getPrcCompetenciaDesarrollo() {
		return prcCompetenciaDesarrollo;
	}
	public void setPrcCompetenciaDesarrollo(BigDecimal prcCompetenciaDesarrollo) {
		this.prcCompetenciaDesarrollo = prcCompetenciaDesarrollo;
	}
	public BigDecimal getPrcBajaCompetencia() {
		return prcBajaCompetencia;
	}
	public void setPrcBajaCompetencia(BigDecimal prcBajaCompetencia) {
		this.prcBajaCompetencia = prcBajaCompetencia;
	}
	public BigDecimal getCntTotal() {
		return cntTotal;
	}
	public void setCntTotal(BigDecimal cntTotal) {
		this.cntTotal = cntTotal;
	}
	public BigDecimal getPrcTotal() {
		return prcTotal;
	}
	public void setPrcTotal(BigDecimal prcTotal) {
		this.prcTotal = prcTotal;
	}
	
	
}
