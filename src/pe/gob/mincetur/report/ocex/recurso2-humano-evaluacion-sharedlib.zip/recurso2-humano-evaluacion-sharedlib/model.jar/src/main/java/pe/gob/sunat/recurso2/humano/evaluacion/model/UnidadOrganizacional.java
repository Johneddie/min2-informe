package pe.gob.sunat.recurso2.humano.evaluacion.model;

public class UnidadOrganizacional {

	private String codUnidadOrganizacional;
	private String desUnidadOrganizacional;
	private String desCortaUnidadOrganizacional;
	
	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}
	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}
	public String getDesUnidadOrganizacional() {
		return desUnidadOrganizacional;
	}
	public void setDesUnidadOrganizacional(String desUnidadOrganizacional) {
		this.desUnidadOrganizacional = desUnidadOrganizacional;
	}
	public String getDesCortaUnidadOrganizacional() {
		return desCortaUnidadOrganizacional;
	}
	public void setDesCortaUnidadOrganizacional(String desCortaUnidadOrganizacional) {
		this.desCortaUnidadOrganizacional = desCortaUnidadOrganizacional;
	}
	
}
