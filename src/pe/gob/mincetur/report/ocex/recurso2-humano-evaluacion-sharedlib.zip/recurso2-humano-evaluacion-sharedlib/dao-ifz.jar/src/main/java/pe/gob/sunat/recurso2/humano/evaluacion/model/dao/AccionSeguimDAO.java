package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguim;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimWithBLOBs;

public interface AccionSeguimDAO {
    int countByExample(AccionSeguimExample example);

    int deleteByExample(AccionSeguimExample example);

    int deleteByPrimaryKey(Integer numAccion);

    void insert(AccionSeguimWithBLOBs record);

    Integer insertSelective(AccionSeguimWithBLOBs record);

    List<AccionSeguimWithBLOBs> selectByExampleWithBLOBs(AccionSeguimExample example);

    List<AccionSeguim> selectByExampleWithoutBLOBs(AccionSeguimExample example);

    AccionSeguimWithBLOBs selectByPrimaryKey(Integer numAccion);

    int updateByExampleSelective(AccionSeguimWithBLOBs record, AccionSeguimExample example);

    int updateByExample(AccionSeguimWithBLOBs record, AccionSeguimExample example);

    int updateByExample(AccionSeguim record, AccionSeguimExample example);

    int updateByPrimaryKeySelective(AccionSeguimWithBLOBs record);

    int updateByPrimaryKey(AccionSeguimWithBLOBs record);

    int updateByPrimaryKey(AccionSeguim record);
}