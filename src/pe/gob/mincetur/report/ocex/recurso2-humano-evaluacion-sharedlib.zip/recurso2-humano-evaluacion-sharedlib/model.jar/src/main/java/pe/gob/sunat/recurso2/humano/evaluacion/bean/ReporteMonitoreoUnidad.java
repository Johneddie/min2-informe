package pe.gob.sunat.recurso2.humano.evaluacion.bean;


public class ReporteMonitoreoUnidad {

	private String unidadCodigo;
    private String unidadNombre;
    private int totalEvaluar;
    private int totalNoEnviadosValidarLista;
    private int totalEnviadosValidarLista;
    private int totalValidadosLista;
    
    private int totalBandejaEvaluador;
    private int totalBandejaRevisor;
    private int totalBandejaTransferidos;
    private int totalPendientesEvaluar;
    private int totalPendientesEnviarARevisor;
    private int totalPendientesRevisar;
    private int totalPendientesDevolverAEvaluador;
    private int totalPendientesTransferir;
    private String evaluadorRegistro;
    private String evaluadorNombre;
    private String evaluadorCorreo;
    private String revisorRegistro;
    private String revisorNombre;
    private String revisorCorreo;
    
	public String getUnidadCodigo() {
		return unidadCodigo;
	}
	public void setUnidadCodigo(String unidadCodigo) {
		this.unidadCodigo = unidadCodigo;
	}
	public String getUnidadNombre() {
		return unidadNombre;
	}
	public void setUnidadNombre(String unidadNombre) {
		this.unidadNombre = unidadNombre;
	}
	public int getTotalEvaluar() {
		return totalEvaluar;
	}
	public void setTotalEvaluar(int totalEvaluar) {
		this.totalEvaluar = totalEvaluar;
	}
	public int getTotalBandejaEvaluador() {
		return totalBandejaEvaluador;
	}
	public void setTotalBandejaEvaluador(int totalBandejaEvaluador) {
		this.totalBandejaEvaluador = totalBandejaEvaluador;
	}
	public int getTotalBandejaRevisor() {
		return totalBandejaRevisor;
	}
	public void setTotalBandejaRevisor(int totalBandejaRevisor) {
		this.totalBandejaRevisor = totalBandejaRevisor;
	}
	public int getTotalBandejaTransferidos() {
		return totalBandejaTransferidos;
	}
	public void setTotalBandejaTransferidos(int totalBandejaTransferidos) {
		this.totalBandejaTransferidos = totalBandejaTransferidos;
	}
	public int getTotalPendientesEvaluar() {
		return totalPendientesEvaluar;
	}
	public void setTotalPendientesEvaluar(int totalPendientesEvaluar) {
		this.totalPendientesEvaluar = totalPendientesEvaluar;
	}
	public int getTotalPendientesEnviarARevisor() {
		return totalPendientesEnviarARevisor;
	}
	public void setTotalPendientesEnviarARevisor(
			int totalPendientesEnviarARevisor) {
		this.totalPendientesEnviarARevisor = totalPendientesEnviarARevisor;
	}
	public int getTotalPendientesRevisar() {
		return totalPendientesRevisar;
	}
	public void setTotalPendientesRevisar(int totalPendientesRevisar) {
		this.totalPendientesRevisar = totalPendientesRevisar;
	}
	public int getTotalPendientesDevolverAEvaluador() {
		return totalPendientesDevolverAEvaluador;
	}
	public void setTotalPendientesDevolverAEvaluador(
			int totalPendientesDevolverAEvaluador) {
		this.totalPendientesDevolverAEvaluador = totalPendientesDevolverAEvaluador;
	}
	public int getTotalPendientesTransferir() {
		return totalPendientesTransferir;
	}
	public void setTotalPendientesTransferir(int totalPendientesTransferir) {
		this.totalPendientesTransferir = totalPendientesTransferir;
	}
	public String getEvaluadorRegistro() {
		return evaluadorRegistro;
	}
	public void setEvaluadorRegistro(String evaluadorRegistro) {
		this.evaluadorRegistro = evaluadorRegistro;
	}
	public String getEvaluadorNombre() {
		return evaluadorNombre;
	}
	public void setEvaluadorNombre(String evaluadorNombre) {
		this.evaluadorNombre = evaluadorNombre;
	}
	public String getEvaluadorCorreo() {
		return evaluadorCorreo;
	}
	public void setEvaluadorCorreo(String evaluadorCorreo) {
		this.evaluadorCorreo = evaluadorCorreo;
	}
	public String getRevisorRegistro() {
		return revisorRegistro;
	}
	public void setRevisorRegistro(String revisorRegistro) {
		this.revisorRegistro = revisorRegistro;
	}
	public String getRevisorNombre() {
		return revisorNombre;
	}
	public void setRevisorNombre(String revisorNombre) {
		this.revisorNombre = revisorNombre;
	}
	public String getRevisorCorreo() {
		return revisorCorreo;
	}
	public void setRevisorCorreo(String revisorCorreo) {
		this.revisorCorreo = revisorCorreo;
	}
	public int getTotalNoEnviadosValidarLista() {
		return totalNoEnviadosValidarLista;
	}
	public void setTotalNoEnviadosValidarLista(int totalNoEnviadosValidarLista) {
		this.totalNoEnviadosValidarLista = totalNoEnviadosValidarLista;
	}
	public int getTotalEnviadosValidarLista() {
		return totalEnviadosValidarLista;
	}
	public void setTotalEnviadosValidarLista(int totalEnviadosValidarLista) {
		this.totalEnviadosValidarLista = totalEnviadosValidarLista;
	}
	public int getTotalValidadosLista() {
		return totalValidadosLista;
	}
	public void setTotalValidadosLista(int totalValidadosLista) {
		this.totalValidadosLista = totalValidadosLista;
	}
	
    
	
}
