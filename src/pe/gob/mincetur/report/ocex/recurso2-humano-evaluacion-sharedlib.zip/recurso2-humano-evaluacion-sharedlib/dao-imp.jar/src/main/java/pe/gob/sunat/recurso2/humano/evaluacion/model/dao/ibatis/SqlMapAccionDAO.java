package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Accion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.AccionDAO;

public class SqlMapAccionDAO extends SqlMapClientDaoSupport implements AccionDAO {

    public SqlMapAccionDAO() {
        super();
    }

    /*public int countByExample(AccionExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t11histo.countByExample", example);
        return count;
    }

    public int deleteByExample(AccionExample example) {
        int rows = getSqlMapClientTemplate().delete("t11histo.deleteByExample", example);
        return rows;
    }

    public void insert(Accion record) {
        getSqlMapClientTemplate().insert("t11histo.insert", record);
    }

    public void insertSelective(Accion record) {
        getSqlMapClientTemplate().insert("t11histo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Accion> selectByExample(AccionExample example) {
        List<Accion> list = getSqlMapClientTemplate().queryForList("t11histo.selectByExample", example);
        return list;
    }

    public int updateByExampleSelective(Accion record, AccionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t11histo.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Accion record, AccionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t11histo.updateByExample", parms);
        return rows;
    }

    private static class UpdateByExampleParms extends AccionExample {
        private Object record;

        public UpdateByExampleParms(Object record, AccionExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }*/
}