package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class RetroalimAccion {
    private Integer numRetroalim;

    private Integer numAccion;

    private Integer numArchivo;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    private String desRetroalim;

    public Integer getNumRetroalim() {
        return numRetroalim;
    }

    public void setNumRetroalim(Integer numRetroalim) {
        this.numRetroalim = numRetroalim;
    }

    public Integer getNumAccion() {
        return numAccion;
    }

    public void setNumAccion(Integer numAccion) {
        this.numAccion = numAccion;
    }

    public Integer getNumArchivo() {
        return numArchivo;
    }

    public void setNumArchivo(Integer numArchivo) {
        this.numArchivo = numArchivo;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

    public String getDesRetroalim() {
        return desRetroalim;
    }

    public void setDesRetroalim(String desRetroalim) {
        this.desRetroalim = desRetroalim == null ? null : desRetroalim.trim();
    }
}