package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RetroalimAccion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RetroalimAccionExample;

public interface RetroalimAccionDAO {
    int countByExample(RetroalimAccionExample example);

    int deleteByExample(RetroalimAccionExample example);

    int deleteByPrimaryKey(Integer numRetroalim);

    void insert(RetroalimAccion record);

    void insertSelective(RetroalimAccion record);

    List<RetroalimAccion> selectByExampleWithBLOBs(RetroalimAccionExample example);

    List<RetroalimAccion> selectByExampleWithoutBLOBs(RetroalimAccionExample example);

    RetroalimAccion selectByPrimaryKey(Integer numRetroalim);

    int updateByExampleSelective(RetroalimAccion record, RetroalimAccionExample example);

    int updateByExampleWithBLOBs(RetroalimAccion record, RetroalimAccionExample example);

    int updateByExampleWithoutBLOBs(RetroalimAccion record, RetroalimAccionExample example);

    int updateByPrimaryKeySelective(RetroalimAccion record);

    int updateByPrimaryKeyWithBLOBs(RetroalimAccion record);

    int updateByPrimaryKeyWithoutBLOBs(RetroalimAccion record);
}