package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T99codigosDAO;

public class SqlMapT99codigosDAO extends SqlMapClientDaoSupport implements T99codigosDAO{

	@Override
	public Parametro selectByPrimaryKey(
			String codParametro, String codDataParametro) {
		Parametro paramSearch = new Parametro();
		paramSearch.setCodParametro(codParametro);
		paramSearch.setCodDataParametro(codDataParametro);
		return (Parametro)getSqlMapClientTemplate().queryForObject("T99codigos.selectByPrimaryKey", paramSearch);
	}
	
	@Override
	public List<Parametro> listarPorParametros(Parametro params){
		return (List<Parametro>)getSqlMapClientTemplate().queryForList("T99codigos.selectByParams", params);
	}

}
