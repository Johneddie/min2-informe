package pe.gob.sunat.recurso2.humano.evaluacion.service;

import java.util.List;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;

public interface CatalogoService {

	public List<Parametro> listarTiposAccion();

}
