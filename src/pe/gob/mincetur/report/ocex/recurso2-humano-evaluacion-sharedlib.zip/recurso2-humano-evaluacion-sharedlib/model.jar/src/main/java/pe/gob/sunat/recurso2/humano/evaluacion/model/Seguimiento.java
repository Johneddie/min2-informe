package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class Seguimiento {

	private String codPers;
	private String perEvalua;
	private String indEstado;
	private String codUsuario;
	private String numIp;
	private String numPc;
	private String desEvaluacion;
	private Date fecGraba;
	private String codUserGraba;
	private String codUnidadOrganizacional;
	
	public String getCodPers() {
		return codPers;
	}
	public void setCodPers(String codPers) {
		this.codPers = codPers;
	}
	public String getPerEvalua() {
		return perEvalua;
	}
	public void setPerEvalua(String perEvalua) {
		this.perEvalua = perEvalua;
	}
	public String getIndEstado() {
		return indEstado;
	}
	public void setIndEstado(String indEstado) {
		this.indEstado = indEstado;
	}
	public String getCodUsuario() {
		return codUsuario;
	}
	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}
	public String getNumIp() {
		return numIp;
	}
	public void setNumIp(String numIp) {
		this.numIp = numIp;
	}
	public String getNumPc() {
		return numPc;
	}
	public void setNumPc(String numPc) {
		this.numPc = numPc;
	}
	public String getDesEvaluacion() {
		return desEvaluacion;
	}
	public void setDesEvaluacion(String desEvaluacion) {
		this.desEvaluacion = desEvaluacion;
	}
	public Date getFecGraba() {
		return fecGraba;
	}
	public void setFecGraba(Date fecGraba) {
		this.fecGraba = fecGraba;
	}
	public String getCodUserGraba() {
		return codUserGraba;
	}
	public void setCodUserGraba(String codUserGraba) {
		this.codUserGraba = codUserGraba;
	}
	public String getCodUnidadOrganizacional() {
		return codUnidadOrganizacional;
	}
	public void setCodUnidadOrganizacional(String codUnidadOrganizacional) {
		this.codUnidadOrganizacional = codUnidadOrganizacional;
	}
	

}
