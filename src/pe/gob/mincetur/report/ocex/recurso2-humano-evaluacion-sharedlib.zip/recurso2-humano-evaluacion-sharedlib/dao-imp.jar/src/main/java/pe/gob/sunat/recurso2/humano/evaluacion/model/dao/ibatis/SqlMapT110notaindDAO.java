package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.RendimientoDetalle;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110notaindDAO;

public class SqlMapT110notaindDAO extends SqlMapClientDaoSupport implements T110notaindDAO{

	@Override
	public RendimientoDetalle selectByPrimaryKey(RendimientoDetalle paramSearch) {
		return (RendimientoDetalle)getSqlMapClientTemplate().queryForObject("T110notaind.selectByPrimaryKey", paramSearch);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RendimientoDetalle> listByParameter(RendimientoDetalle paramSearch) {
		return (List<RendimientoDetalle>)getSqlMapClientTemplate().queryForList("T110notaind.listByParameter", paramSearch);
	}

	@Override
	public void insertSelective(RendimientoDetalle paramInsert) {
		getSqlMapClientTemplate().insert("T110notaind.insertSelective", paramInsert);
	}

	@Override
	public void updateByPrimaryKeySelective(RendimientoDetalle paramUpdate) {
		getSqlMapClientTemplate().update("T110notaind.updateByPrimaryKeySelective", paramUpdate);
	}

}
