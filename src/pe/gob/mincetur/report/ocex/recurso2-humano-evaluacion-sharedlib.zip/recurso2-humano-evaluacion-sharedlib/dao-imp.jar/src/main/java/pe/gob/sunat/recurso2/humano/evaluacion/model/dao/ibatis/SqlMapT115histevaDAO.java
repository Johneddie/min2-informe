package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.HashMap;
import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T115histevaDAO;

@SuppressWarnings({"unchecked","rawtypes"})
public class SqlMapT115histevaDAO extends SqlMapClientDaoSupport implements T115histevaDAO{

	@Override
	public Periodo selectByPrimaryKey(Periodo periodoSearch) {
		Periodo result = (Periodo) getSqlMapClientTemplate().queryForObject("T115histeva.selectByPrimaryKey", periodoSearch);
	    return result;
	}

	@Override
	public List<Periodo> listByParameter(Periodo periodoSearch) {
		return (List<Periodo>)getSqlMapClientTemplate().queryForList("T115histeva.listByParameter", periodoSearch);
	}
	
	
	@Override
	public List<Periodo> listByEstados(HashMap params) {
		return (List<Periodo>)getSqlMapClientTemplate().queryForList("T115histeva.listByEstados", params);
	}

}
