package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class AccionSeguim {
    private Integer numAccion;

    private Integer numSeguim;

    private String codCompetencia;

    private String codCriterio;

    private String codTipAccion;

    private Integer numArchivo;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;

    
    private String codEvaluador;
    private String desCompetencia;
    private String desCriterio;
    private String desTipAccion;
    

    public Integer getNumAccion() {
        return numAccion;
    }

    public void setNumAccion(Integer numAccion) {
        this.numAccion = numAccion;
    }

    public Integer getNumSeguim() {
        return numSeguim;
    }

    public void setNumSeguim(Integer numSeguim) {
        this.numSeguim = numSeguim;
    }

    public String getCodCompetencia() {
        return codCompetencia;
    }

    public void setCodCompetencia(String codCompetencia) {
        this.codCompetencia = codCompetencia == null ? null : codCompetencia.trim();
    }

    public String getCodCriterio() {
        return codCriterio;
    }

    public void setCodCriterio(String codCriterio) {
        this.codCriterio = codCriterio == null ? null : codCriterio.trim();
    }

    public String getCodTipAccion() {
        return codTipAccion;
    }

    public void setCodTipAccion(String codTipAccion) {
        this.codTipAccion = codTipAccion == null ? null : codTipAccion.trim();
    }

    public Integer getNumArchivo() {
        return numArchivo;
    }

    public void setNumArchivo(Integer numArchivo) {
        this.numArchivo = numArchivo;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

	public String getCodEvaluador() {
		return codEvaluador;
	}

	public void setCodEvaluador(String codEvaluador) {
		this.codEvaluador = codEvaluador;
	}

	public String getDesCompetencia() {
		return desCompetencia;
	}

	public void setDesCompetencia(String desCompetencia) {
		this.desCompetencia = desCompetencia;
	}

	public String getDesCriterio() {
		return desCriterio;
	}

	public void setDesCriterio(String desCriterio) {
		this.desCriterio = desCriterio;
	}

	public String getDesTipAccion() {
		return desTipAccion;
	}

	public void setDesTipAccion(String desTipAccion) {
		this.desTipAccion = desTipAccion;
	}
    
}