package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T145factIndiDAO;
@SuppressWarnings({"unchecked","deprecation"})
public class SqlMapT145factIndiDAO extends SqlMapClientDaoSupport implements T145factIndiDAO{

	@Override
	public Comportamiento selectByPrimaryKey(Comportamiento comportamiento) {
		return (Comportamiento)getSqlMapClientTemplate().queryForObject("T145fact_indi.selectByPrimaryKey", comportamiento);
	}

	@Override
	public List<Comportamiento> listarPorGrupoCompetencia(
			Map<String, Object> paramSearch) {
		return (List<Comportamiento>)getSqlMapClientTemplate().queryForList("T145fact_indi.listarPorGrupoCompetencia", paramSearch);
	}

	@Override
	public List<Comportamiento> listarPorCompetencia(
			Map<String, Object> paramSearch) {
		return (List<Comportamiento>)getSqlMapClientTemplate().queryForList("T145fact_indi.listarPorCompetencia", paramSearch);
	}
	
	@Override
	public List<Comportamiento> listarPorParametros(Comportamiento params){
		return (List<Comportamiento>)getSqlMapClientTemplate().queryForList("T145fact_indi.selectByParams", params);
	}

}
