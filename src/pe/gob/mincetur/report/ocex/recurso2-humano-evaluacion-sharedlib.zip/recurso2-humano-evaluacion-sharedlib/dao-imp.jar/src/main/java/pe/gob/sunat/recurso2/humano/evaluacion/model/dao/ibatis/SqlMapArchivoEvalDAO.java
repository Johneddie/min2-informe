package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.evaluacion.model.ArchivoEval;
import pe.gob.sunat.recurso2.humano.evaluacion.model.ArchivoEvalExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ArchivoEvalDAO;

public class SqlMapArchivoEvalDAO extends SqlMapClientDaoSupport implements ArchivoEvalDAO {

    public SqlMapArchivoEvalDAO() {
        super();
    }

    public int countByExample(ArchivoEvalExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t9439archivoeval.countByExample", example);
        return count;
    }

    public int deleteByExample(ArchivoEvalExample example) {
        int rows = getSqlMapClientTemplate().delete("t9439archivoeval.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numArchivo) {
        ArchivoEval key = new ArchivoEval();
        key.setNumArchivo(numArchivo);
        int rows = getSqlMapClientTemplate().delete("t9439archivoeval.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(ArchivoEval record) {
        getSqlMapClientTemplate().insert("t9439archivoeval.insert", record);
    }

    public void insertSelective(ArchivoEval record) {
        getSqlMapClientTemplate().insert("t9439archivoeval.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoEval> selectByExampleWithBLOBs(ArchivoEvalExample example) {
        List<ArchivoEval> list = getSqlMapClientTemplate().queryForList("t9439archivoeval.selectByExampleWithBLOBs", example);
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoEval> selectByExampleWithoutBLOBs(ArchivoEvalExample example) {
        List<ArchivoEval> list = getSqlMapClientTemplate().queryForList("t9439archivoeval.selectByExample", example);
        return list;
    }

    public ArchivoEval selectByPrimaryKey(Integer numArchivo) {
        ArchivoEval key = new ArchivoEval();
        key.setNumArchivo(numArchivo);
        ArchivoEval record = (ArchivoEval) getSqlMapClientTemplate().queryForObject("t9439archivoeval.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(ArchivoEval record, ArchivoEvalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExampleWithBLOBs(ArchivoEval record, ArchivoEvalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByExampleWithBLOBs", parms);
        return rows;
    }

    public int updateByExampleWithoutBLOBs(ArchivoEval record, ArchivoEvalExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(ArchivoEval record) {
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKeyWithBLOBs(ArchivoEval record) {
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByPrimaryKeyWithBLOBs", record);
        return rows;
    }

    public int updateByPrimaryKeyWithoutBLOBs(ArchivoEval record) {
        int rows = getSqlMapClientTemplate().update("t9439archivoeval.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ArchivoEvalExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoEvalExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}