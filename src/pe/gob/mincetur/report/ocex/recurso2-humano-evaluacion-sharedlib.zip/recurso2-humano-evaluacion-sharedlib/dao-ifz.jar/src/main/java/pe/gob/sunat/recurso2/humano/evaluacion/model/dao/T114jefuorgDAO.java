package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;
import java.util.Map;

public interface T114jefuorgDAO {

	List<String> listarUnidadesOrganizacionales(Map<String,Object> paramSearch);
	
}
