package pe.gob.sunat.recurso2.humano.evaluacion.service;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.framework.util.Propiedades;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Comportamiento;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Parametro;
import pe.gob.sunat.recurso2.humano.evaluacion.model.Periodo;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguim;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimWithBLOBs;
import pe.gob.sunat.recurso2.humano.evaluacion.model.AccionSeguimExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEval;
import pe.gob.sunat.recurso2.humano.evaluacion.model.SeguimientoEvalExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.CorreosDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T01paramDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T02perdpDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110notaindDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T110rendiDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114evuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T114jefuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T115histevaDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T116jefuorgDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T11histoDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T12uorgaDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T145factIndiDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T1536segEvalDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T43evperDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T99codigosDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.SeguimientoEvalDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.AccionSeguimDAO;
import pe.gob.sunat.recurso2.humano.evaluacion.util.Utiles;
import static pe.gob.sunat.recurso2.humano.evaluacion.util.Constantes.*;

@Service("seguimientoService")
public class SeguimientoServiceImpl implements SeguimientoService {
	Propiedades propiedades = new Propiedades(getClass(), "/correo.properties");
	protected final Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private T115histevaDAO periodoDAO;
	@Autowired
	private T145factIndiDAO comportamientoDAO;
	@Autowired
	private SeguimientoEvalDAO seguimientoEvalDAO;
	@Autowired
	private T02perdpDAO personalDAO;
	@Autowired
	private AccionSeguimDAO accionSeguimDAO;
	@Autowired
	T01paramDAO parametroDAO;
	
	@Override
	public List<Periodo> listarPeriodosNivelEsperado(){
		Periodo prmPeriodo = new Periodo();
		prmPeriodo.setCodEstado(PERIODO_NIVEL_ESPERADO);
		return periodoDAO.listByParameter(prmPeriodo);		
	}
	
	@Override
	public List<Comportamiento> listarCriteriosCompetencia(String codCompetencia){
		Comportamiento prmComportamiento = new Comportamiento();
		prmComportamiento.setCodCompetencia(CODIGO_GRUPO_GEN+codCompetencia);
		prmComportamiento.setCodTipo("2");
		prmComportamiento.setCodEstado(ESTADO_ACTIVO);
		return comportamientoDAO.listarPorParametros(prmComportamiento);		
	}
	
	@Override
	public List<Comportamiento> listarCompetencias(){
		Comportamiento prmComportamiento = new Comportamiento();
		prmComportamiento.setCodGrupo(CODIGO_GRUPO_GEN);
		prmComportamiento.setCodTipo("1");
		prmComportamiento.setCodEstado(ESTADO_ACTIVO);
		return comportamientoDAO.listarPorParametros(prmComportamiento);		
	}
	
	@Override
	public List<SeguimientoEval> listarSeguimientos(String codPeriodo, String codPersonal){
		SeguimientoEvalExample params = new SeguimientoEvalExample();
		SeguimientoEvalExample.Criteria criterio = params.createCriteria();
		criterio.andCodPeriodoEqualTo(codPeriodo);
		criterio.andCodPersonalEqualTo(codPersonal);
		criterio.andIndDelEqualTo(INDICADOR_NO_ELIM);
		List<SeguimientoEval> lstSeguimientos = seguimientoEvalDAO.selectByExample(params);
		for(SeguimientoEval s:lstSeguimientos){
			s.setDesNombres(personalDAO.obtenerNombreCompleto(s.getCodPersonal()));
			s.setDesNombresEvaluador(personalDAO.obtenerNombreCompleto(s.getCodEvaluador()));
			s.setDesFecRegis(Utiles.convertirFechaTexto(s.getFecRegis()));
			s.setDesFecConsulta(Utiles.convertirFechaTexto(s.getFecConsulta()));
		}
		return lstSeguimientos;
	}
	
	public Map<String, Object> registrarAccion(SeguimientoEval seguimiento, AccionSeguimWithBLOBs accion, String usuario){
		Map<String, Object> hmResult = new HashMap<String, Object>();
		hmResult.put("registrado", false);
		Date today = new Date();
		Integer numSeguim = 0;
		Integer numAccion = 0;
		//seguimiento
		if(seguimiento.getNumSeguim() == null){
			seguimiento.setCodGrupo(CODIGO_GRUPO_GEN);
			seguimiento.setFecRegis(today);
			seguimiento.setCodUsuregis(usuario);
			seguimiento.setIndDel(INDICADOR_NO_ELIM);
			numSeguim = seguimientoEvalDAO.insertSelective(seguimiento);
		}else{
			numSeguim = seguimiento.getNumSeguim();
		}
		//acciones
		if(accion.getNumAccion() != null){
			numAccion = accion.getNumAccion();
			AccionSeguimWithBLOBs accionUpdate = new AccionSeguimWithBLOBs();
			accionUpdate.setNumAccion(numAccion);
			accionUpdate.setDesSeguim(accion.getDesSeguim());
			accionUpdate.setDesAccMejora(accion.getDesAccMejora());
			accionUpdate.setFecModif(today);
			accionUpdate.setCodUsumodif(usuario);
			accionSeguimDAO.updateByPrimaryKeySelective(accionUpdate);
		}else{
//			accion.setCodCompetencia(accion.getCodCompetencia().substring(2, 4));
//			accion.setCodCriterio(accion.getCodCriterio().substring(4, 6));
			accion.setNumSeguim(numSeguim);
			accion.setFecRegis(today);
			accion.setCodUsuregis(usuario);
			accion.setIndDel(INDICADOR_NO_ELIM);
			numAccion = accionSeguimDAO.insertSelective(accion);
		}
		hmResult.put("registrado", true);
		hmResult.put("numSeguim", numSeguim);
		hmResult.put("numAccion", numAccion);
		
		return hmResult;
	}
	
	
	public List<AccionSeguimWithBLOBs> listarAcciones(Integer numSeguim){
		AccionSeguimExample params = new AccionSeguimExample();
		AccionSeguimExample.Criteria criterioAcc = params.createCriteria();
		criterioAcc.andNumSeguimEqualTo(numSeguim);
		criterioAcc.andIndDelEqualTo(INDICADOR_NO_ELIM);
		
		SeguimientoEval seguimiento = seguimientoEvalDAO.selectByPrimaryKey(numSeguim);
		
		List<AccionSeguimWithBLOBs> lstAcciones = accionSeguimDAO.selectByExampleWithBLOBs(params);
		for(AccionSeguimWithBLOBs a:lstAcciones){
			a.setCodEvaluador(seguimiento.getCodEvaluador());
			//comportamiento
			Comportamiento paramCompet = new Comportamiento();
			paramCompet.setCodComportamiento(CODIGO_GRUPO_GEN+a.getCodCompetencia()+"01");
			paramCompet.setCodTipo("1");
			Comportamiento competencia = comportamientoDAO.selectByPrimaryKey(paramCompet);
			//criterio
			Comportamiento paramCriterio = new Comportamiento();
			paramCriterio.setCodComportamiento(CODIGO_GRUPO_GEN+a.getCodCompetencia()+a.getCodCriterio());
			paramCriterio.setCodTipo("2");
			Comportamiento criterio = comportamientoDAO.selectByPrimaryKey(paramCriterio);
			//tipoaccion
			Parametro tipoAcc = parametroDAO.selectByPrimaryKey(PARAMETRO_TIPOS_ACCION, a.getCodTipAccion());
			
			a.setDesCompetencia(competencia.getDesComportamiento());
			a.setDesCriterio(criterio.getDesDetalle());
			a.setDesTipAccion(tipoAcc.getDesParametro());
		}
		return lstAcciones;
	}
	
	
}
