package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T116jefuorgDAO;

public class SqlMapT116jefuorgDAO extends SqlMapClientDaoSupport implements T116jefuorgDAO{

	@SuppressWarnings("unchecked")
	@Override
	public List<String> listarUnidadesOrganizacionales(
			Map<String, Object> paramSearch) {
		return (List<String>)getSqlMapClientTemplate().queryForList("T116jefuorg.listarUnidadesOrganizacionales", paramSearch);
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<String> listarPersonal(Map<String, Object> paramSearch) {
		return (List<String>)getSqlMapClientTemplate().queryForList("T116jefuorg.listarPersonal", paramSearch);
	}

}
