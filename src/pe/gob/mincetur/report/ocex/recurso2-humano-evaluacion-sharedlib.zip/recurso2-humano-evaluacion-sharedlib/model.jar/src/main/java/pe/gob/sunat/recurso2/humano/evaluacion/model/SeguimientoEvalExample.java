package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SeguimientoEvalExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public SeguimientoEvalExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected SeguimientoEvalExample(SeguimientoEvalExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andNumSeguimIsNull() {
            addCriterion("num_seguim is null");
            return this;
        }

        public Criteria andNumSeguimIsNotNull() {
            addCriterion("num_seguim is not null");
            return this;
        }

        public Criteria andNumSeguimEqualTo(Integer value) {
            addCriterion("num_seguim =", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotEqualTo(Integer value) {
            addCriterion("num_seguim <>", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThan(Integer value) {
            addCriterion("num_seguim >", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_seguim >=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThan(Integer value) {
            addCriterion("num_seguim <", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimLessThanOrEqualTo(Integer value) {
            addCriterion("num_seguim <=", value, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimIn(List<Integer> values) {
            addCriterion("num_seguim in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotIn(List<Integer> values) {
            addCriterion("num_seguim not in", values, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimBetween(Integer value1, Integer value2) {
            addCriterion("num_seguim between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andNumSeguimNotBetween(Integer value1, Integer value2) {
            addCriterion("num_seguim not between", value1, value2, "numSeguim");
            return this;
        }

        public Criteria andCodPeriodoIsNull() {
            addCriterion("cod_periodo is null");
            return this;
        }

        public Criteria andCodPeriodoIsNotNull() {
            addCriterion("cod_periodo is not null");
            return this;
        }

        public Criteria andCodPeriodoEqualTo(String value) {
            addCriterion("cod_periodo =", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoNotEqualTo(String value) {
            addCriterion("cod_periodo <>", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoGreaterThan(String value) {
            addCriterion("cod_periodo >", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_periodo >=", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoLessThan(String value) {
            addCriterion("cod_periodo <", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoLessThanOrEqualTo(String value) {
            addCriterion("cod_periodo <=", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoLike(String value) {
            addCriterion("cod_periodo like", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoNotLike(String value) {
            addCriterion("cod_periodo not like", value, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoIn(List<String> values) {
            addCriterion("cod_periodo in", values, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoNotIn(List<String> values) {
            addCriterion("cod_periodo not in", values, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoBetween(String value1, String value2) {
            addCriterion("cod_periodo between", value1, value2, "codPeriodo");
            return this;
        }

        public Criteria andCodPeriodoNotBetween(String value1, String value2) {
            addCriterion("cod_periodo not between", value1, value2, "codPeriodo");
            return this;
        }

        public Criteria andCodPersonalIsNull() {
            addCriterion("cod_personal is null");
            return this;
        }

        public Criteria andCodPersonalIsNotNull() {
            addCriterion("cod_personal is not null");
            return this;
        }

        public Criteria andCodPersonalEqualTo(String value) {
            addCriterion("cod_personal =", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotEqualTo(String value) {
            addCriterion("cod_personal <>", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThan(String value) {
            addCriterion("cod_personal >", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_personal >=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThan(String value) {
            addCriterion("cod_personal <", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLessThanOrEqualTo(String value) {
            addCriterion("cod_personal <=", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalLike(String value) {
            addCriterion("cod_personal like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotLike(String value) {
            addCriterion("cod_personal not like", value, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalIn(List<String> values) {
            addCriterion("cod_personal in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotIn(List<String> values) {
            addCriterion("cod_personal not in", values, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalBetween(String value1, String value2) {
            addCriterion("cod_personal between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodPersonalNotBetween(String value1, String value2) {
            addCriterion("cod_personal not between", value1, value2, "codPersonal");
            return this;
        }

        public Criteria andCodEvaluadorIsNull() {
            addCriterion("cod_evaluador is null");
            return this;
        }

        public Criteria andCodEvaluadorIsNotNull() {
            addCriterion("cod_evaluador is not null");
            return this;
        }

        public Criteria andCodEvaluadorEqualTo(String value) {
            addCriterion("cod_evaluador =", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorNotEqualTo(String value) {
            addCriterion("cod_evaluador <>", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorGreaterThan(String value) {
            addCriterion("cod_evaluador >", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorGreaterThanOrEqualTo(String value) {
            addCriterion("cod_evaluador >=", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorLessThan(String value) {
            addCriterion("cod_evaluador <", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorLessThanOrEqualTo(String value) {
            addCriterion("cod_evaluador <=", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorLike(String value) {
            addCriterion("cod_evaluador like", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorNotLike(String value) {
            addCriterion("cod_evaluador not like", value, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorIn(List<String> values) {
            addCriterion("cod_evaluador in", values, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorNotIn(List<String> values) {
            addCriterion("cod_evaluador not in", values, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorBetween(String value1, String value2) {
            addCriterion("cod_evaluador between", value1, value2, "codEvaluador");
            return this;
        }

        public Criteria andCodEvaluadorNotBetween(String value1, String value2) {
            addCriterion("cod_evaluador not between", value1, value2, "codEvaluador");
            return this;
        }

        public Criteria andCodUorgaEvalIsNull() {
            addCriterion("cod_uorga_eval is null");
            return this;
        }

        public Criteria andCodUorgaEvalIsNotNull() {
            addCriterion("cod_uorga_eval is not null");
            return this;
        }

        public Criteria andCodUorgaEvalEqualTo(String value) {
            addCriterion("cod_uorga_eval =", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalNotEqualTo(String value) {
            addCriterion("cod_uorga_eval <>", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalGreaterThan(String value) {
            addCriterion("cod_uorga_eval >", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalGreaterThanOrEqualTo(String value) {
            addCriterion("cod_uorga_eval >=", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalLessThan(String value) {
            addCriterion("cod_uorga_eval <", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalLessThanOrEqualTo(String value) {
            addCriterion("cod_uorga_eval <=", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalLike(String value) {
            addCriterion("cod_uorga_eval like", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalNotLike(String value) {
            addCriterion("cod_uorga_eval not like", value, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalIn(List<String> values) {
            addCriterion("cod_uorga_eval in", values, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalNotIn(List<String> values) {
            addCriterion("cod_uorga_eval not in", values, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalBetween(String value1, String value2) {
            addCriterion("cod_uorga_eval between", value1, value2, "codUorgaEval");
            return this;
        }

        public Criteria andCodUorgaEvalNotBetween(String value1, String value2) {
            addCriterion("cod_uorga_eval not between", value1, value2, "codUorgaEval");
            return this;
        }

        public Criteria andCodGrupoIsNull() {
            addCriterion("cod_grupo is null");
            return this;
        }

        public Criteria andCodGrupoIsNotNull() {
            addCriterion("cod_grupo is not null");
            return this;
        }

        public Criteria andCodGrupoEqualTo(String value) {
            addCriterion("cod_grupo =", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoNotEqualTo(String value) {
            addCriterion("cod_grupo <>", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoGreaterThan(String value) {
            addCriterion("cod_grupo >", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_grupo >=", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoLessThan(String value) {
            addCriterion("cod_grupo <", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoLessThanOrEqualTo(String value) {
            addCriterion("cod_grupo <=", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoLike(String value) {
            addCriterion("cod_grupo like", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoNotLike(String value) {
            addCriterion("cod_grupo not like", value, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoIn(List<String> values) {
            addCriterion("cod_grupo in", values, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoNotIn(List<String> values) {
            addCriterion("cod_grupo not in", values, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoBetween(String value1, String value2) {
            addCriterion("cod_grupo between", value1, value2, "codGrupo");
            return this;
        }

        public Criteria andCodGrupoNotBetween(String value1, String value2) {
            addCriterion("cod_grupo not between", value1, value2, "codGrupo");
            return this;
        }

        public Criteria andFecConsultaIsNull() {
            addCriterion("fec_consulta is null");
            return this;
        }

        public Criteria andFecConsultaIsNotNull() {
            addCriterion("fec_consulta is not null");
            return this;
        }

        public Criteria andFecConsultaEqualTo(Date value) {
            addCriterion("fec_consulta =", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaNotEqualTo(Date value) {
            addCriterion("fec_consulta <>", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaGreaterThan(Date value) {
            addCriterion("fec_consulta >", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_consulta >=", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaLessThan(Date value) {
            addCriterion("fec_consulta <", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaLessThanOrEqualTo(Date value) {
            addCriterion("fec_consulta <=", value, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaIn(List<Date> values) {
            addCriterion("fec_consulta in", values, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaNotIn(List<Date> values) {
            addCriterion("fec_consulta not in", values, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaBetween(Date value1, Date value2) {
            addCriterion("fec_consulta between", value1, value2, "fecConsulta");
            return this;
        }

        public Criteria andFecConsultaNotBetween(Date value1, Date value2) {
            addCriterion("fec_consulta not between", value1, value2, "fecConsulta");
            return this;
        }

        public Criteria andIndDelIsNull() {
            addCriterion("ind_del is null");
            return this;
        }

        public Criteria andIndDelIsNotNull() {
            addCriterion("ind_del is not null");
            return this;
        }

        public Criteria andIndDelEqualTo(String value) {
            addCriterion("ind_del =", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotEqualTo(String value) {
            addCriterion("ind_del <>", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThan(String value) {
            addCriterion("ind_del >", value, "indDel");
            return this;
        }

        public Criteria andIndDelGreaterThanOrEqualTo(String value) {
            addCriterion("ind_del >=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThan(String value) {
            addCriterion("ind_del <", value, "indDel");
            return this;
        }

        public Criteria andIndDelLessThanOrEqualTo(String value) {
            addCriterion("ind_del <=", value, "indDel");
            return this;
        }

        public Criteria andIndDelLike(String value) {
            addCriterion("ind_del like", value, "indDel");
            return this;
        }

        public Criteria andIndDelNotLike(String value) {
            addCriterion("ind_del not like", value, "indDel");
            return this;
        }

        public Criteria andIndDelIn(List<String> values) {
            addCriterion("ind_del in", values, "indDel");
            return this;
        }

        public Criteria andIndDelNotIn(List<String> values) {
            addCriterion("ind_del not in", values, "indDel");
            return this;
        }

        public Criteria andIndDelBetween(String value1, String value2) {
            addCriterion("ind_del between", value1, value2, "indDel");
            return this;
        }

        public Criteria andIndDelNotBetween(String value1, String value2) {
            addCriterion("ind_del not between", value1, value2, "indDel");
            return this;
        }

        public Criteria andCodUsuregisIsNull() {
            addCriterion("cod_usuregis is null");
            return this;
        }

        public Criteria andCodUsuregisIsNotNull() {
            addCriterion("cod_usuregis is not null");
            return this;
        }

        public Criteria andCodUsuregisEqualTo(String value) {
            addCriterion("cod_usuregis =", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotEqualTo(String value) {
            addCriterion("cod_usuregis <>", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThan(String value) {
            addCriterion("cod_usuregis >", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usuregis >=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThan(String value) {
            addCriterion("cod_usuregis <", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLessThanOrEqualTo(String value) {
            addCriterion("cod_usuregis <=", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisLike(String value) {
            addCriterion("cod_usuregis like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotLike(String value) {
            addCriterion("cod_usuregis not like", value, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisIn(List<String> values) {
            addCriterion("cod_usuregis in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotIn(List<String> values) {
            addCriterion("cod_usuregis not in", values, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisBetween(String value1, String value2) {
            addCriterion("cod_usuregis between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andCodUsuregisNotBetween(String value1, String value2) {
            addCriterion("cod_usuregis not between", value1, value2, "codUsuregis");
            return this;
        }

        public Criteria andFecRegisIsNull() {
            addCriterion("fec_regis is null");
            return this;
        }

        public Criteria andFecRegisIsNotNull() {
            addCriterion("fec_regis is not null");
            return this;
        }

        public Criteria andFecRegisEqualTo(Date value) {
            addCriterion("fec_regis =", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotEqualTo(Date value) {
            addCriterion("fec_regis <>", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThan(Date value) {
            addCriterion("fec_regis >", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_regis >=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThan(Date value) {
            addCriterion("fec_regis <", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisLessThanOrEqualTo(Date value) {
            addCriterion("fec_regis <=", value, "fecRegis");
            return this;
        }

        public Criteria andFecRegisIn(List<Date> values) {
            addCriterion("fec_regis in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotIn(List<Date> values) {
            addCriterion("fec_regis not in", values, "fecRegis");
            return this;
        }

        public Criteria andFecRegisBetween(Date value1, Date value2) {
            addCriterion("fec_regis between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andFecRegisNotBetween(Date value1, Date value2) {
            addCriterion("fec_regis not between", value1, value2, "fecRegis");
            return this;
        }

        public Criteria andCodUsumodifIsNull() {
            addCriterion("cod_usumodif is null");
            return this;
        }

        public Criteria andCodUsumodifIsNotNull() {
            addCriterion("cod_usumodif is not null");
            return this;
        }

        public Criteria andCodUsumodifEqualTo(String value) {
            addCriterion("cod_usumodif =", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotEqualTo(String value) {
            addCriterion("cod_usumodif <>", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThan(String value) {
            addCriterion("cod_usumodif >", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumodif >=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThan(String value) {
            addCriterion("cod_usumodif <", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLessThanOrEqualTo(String value) {
            addCriterion("cod_usumodif <=", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifLike(String value) {
            addCriterion("cod_usumodif like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotLike(String value) {
            addCriterion("cod_usumodif not like", value, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifIn(List<String> values) {
            addCriterion("cod_usumodif in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotIn(List<String> values) {
            addCriterion("cod_usumodif not in", values, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifBetween(String value1, String value2) {
            addCriterion("cod_usumodif between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andCodUsumodifNotBetween(String value1, String value2) {
            addCriterion("cod_usumodif not between", value1, value2, "codUsumodif");
            return this;
        }

        public Criteria andFecModifIsNull() {
            addCriterion("fec_modif is null");
            return this;
        }

        public Criteria andFecModifIsNotNull() {
            addCriterion("fec_modif is not null");
            return this;
        }

        public Criteria andFecModifEqualTo(Date value) {
            addCriterion("fec_modif =", value, "fecModif");
            return this;
        }

        public Criteria andFecModifNotEqualTo(Date value) {
            addCriterion("fec_modif <>", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThan(Date value) {
            addCriterion("fec_modif >", value, "fecModif");
            return this;
        }

        public Criteria andFecModifGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_modif >=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThan(Date value) {
            addCriterion("fec_modif <", value, "fecModif");
            return this;
        }

        public Criteria andFecModifLessThanOrEqualTo(Date value) {
            addCriterion("fec_modif <=", value, "fecModif");
            return this;
        }

        public Criteria andFecModifIn(List<Date> values) {
            addCriterion("fec_modif in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifNotIn(List<Date> values) {
            addCriterion("fec_modif not in", values, "fecModif");
            return this;
        }

        public Criteria andFecModifBetween(Date value1, Date value2) {
            addCriterion("fec_modif between", value1, value2, "fecModif");
            return this;
        }

        public Criteria andFecModifNotBetween(Date value1, Date value2) {
            addCriterion("fec_modif not between", value1, value2, "fecModif");
            return this;
        }
    }
}