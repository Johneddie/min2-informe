package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RetroalimAccion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.RetroalimAccionExample;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.RetroalimAccionDAO;

public class SqlMapRetroalimAccionDAO extends SqlMapClientDaoSupport implements RetroalimAccionDAO {

    public SqlMapRetroalimAccionDAO() {
        super();
    }

    public int countByExample(RetroalimAccionExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t9438retroalimacc.countByExample", example);
        return count;
    }

    public int deleteByExample(RetroalimAccionExample example) {
        int rows = getSqlMapClientTemplate().delete("t9438retroalimacc.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer numRetroalim) {
        RetroalimAccion key = new RetroalimAccion();
        key.setNumRetroalim(numRetroalim);
        int rows = getSqlMapClientTemplate().delete("t9438retroalimacc.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(RetroalimAccion record) {
        getSqlMapClientTemplate().insert("t9438retroalimacc.insert", record);
    }

    public void insertSelective(RetroalimAccion record) {
        getSqlMapClientTemplate().insert("t9438retroalimacc.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<RetroalimAccion> selectByExampleWithBLOBs(RetroalimAccionExample example) {
        List<RetroalimAccion> list = getSqlMapClientTemplate().queryForList("t9438retroalimacc.selectByExampleWithBLOBs", example);
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<RetroalimAccion> selectByExampleWithoutBLOBs(RetroalimAccionExample example) {
        List<RetroalimAccion> list = getSqlMapClientTemplate().queryForList("t9438retroalimacc.selectByExample", example);
        return list;
    }

    public RetroalimAccion selectByPrimaryKey(Integer numRetroalim) {
        RetroalimAccion key = new RetroalimAccion();
        key.setNumRetroalim(numRetroalim);
        RetroalimAccion record = (RetroalimAccion) getSqlMapClientTemplate().queryForObject("t9438retroalimacc.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(RetroalimAccion record, RetroalimAccionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExampleWithBLOBs(RetroalimAccion record, RetroalimAccionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByExampleWithBLOBs", parms);
        return rows;
    }

    public int updateByExampleWithoutBLOBs(RetroalimAccion record, RetroalimAccionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(RetroalimAccion record) {
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKeyWithBLOBs(RetroalimAccion record) {
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByPrimaryKeyWithBLOBs", record);
        return rows;
    }

    public int updateByPrimaryKeyWithoutBLOBs(RetroalimAccion record) {
        int rows = getSqlMapClientTemplate().update("t9438retroalimacc.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends RetroalimAccionExample {
        private Object record;

        public UpdateByExampleParms(Object record, RetroalimAccionExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}