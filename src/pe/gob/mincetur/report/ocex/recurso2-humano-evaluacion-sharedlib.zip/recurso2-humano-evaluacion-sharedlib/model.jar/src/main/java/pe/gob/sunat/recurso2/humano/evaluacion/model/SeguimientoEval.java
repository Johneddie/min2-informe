package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class SeguimientoEval {
    private Integer numSeguim;

    private String codPeriodo;

    private String codPersonal;

    private String codEvaluador;

    private String codUorgaEval;

    private String codGrupo;

    private Date fecConsulta;

    private String indDel;

    private String codUsuregis;

    private Date fecRegis;

    private String codUsumodif;

    private Date fecModif;
    
    
    private String desNombres;
    
    private String desNombresEvaluador;
    
    private String desFecRegis;
    
    private String desFecConsulta;

    public Integer getNumSeguim() {
        return numSeguim;
    }

    public void setNumSeguim(Integer numSeguim) {
        this.numSeguim = numSeguim;
    }

    public String getCodPeriodo() {
        return codPeriodo;
    }

    public void setCodPeriodo(String codPeriodo) {
        this.codPeriodo = codPeriodo == null ? null : codPeriodo.trim();
    }

    public String getCodPersonal() {
        return codPersonal;
    }

    public void setCodPersonal(String codPersonal) {
        this.codPersonal = codPersonal == null ? null : codPersonal.trim();
    }

    public String getCodEvaluador() {
        return codEvaluador;
    }

    public void setCodEvaluador(String codEvaluador) {
        this.codEvaluador = codEvaluador == null ? null : codEvaluador.trim();
    }

    public String getCodUorgaEval() {
        return codUorgaEval;
    }

    public void setCodUorgaEval(String codUorgaEval) {
        this.codUorgaEval = codUorgaEval == null ? null : codUorgaEval.trim();
    }

    public String getCodGrupo() {
        return codGrupo;
    }

    public void setCodGrupo(String codGrupo) {
        this.codGrupo = codGrupo == null ? null : codGrupo.trim();
    }

    public Date getFecConsulta() {
        return fecConsulta;
    }

    public void setFecConsulta(Date fecConsulta) {
        this.fecConsulta = fecConsulta;
    }

    public String getIndDel() {
        return indDel;
    }

    public void setIndDel(String indDel) {
        this.indDel = indDel == null ? null : indDel.trim();
    }

    public String getCodUsuregis() {
        return codUsuregis;
    }

    public void setCodUsuregis(String codUsuregis) {
        this.codUsuregis = codUsuregis == null ? null : codUsuregis.trim();
    }

    public Date getFecRegis() {
        return fecRegis;
    }

    public void setFecRegis(Date fecRegis) {
        this.fecRegis = fecRegis;
    }

    public String getCodUsumodif() {
        return codUsumodif;
    }

    public void setCodUsumodif(String codUsumodif) {
        this.codUsumodif = codUsumodif == null ? null : codUsumodif.trim();
    }

    public Date getFecModif() {
        return fecModif;
    }

    public void setFecModif(Date fecModif) {
        this.fecModif = fecModif;
    }

	public String getDesNombres() {
		return desNombres;
	}

	public void setDesNombres(String desNombres) {
		this.desNombres = desNombres;
	}

	public String getDesNombresEvaluador() {
		return desNombresEvaluador;
	}

	public void setDesNombresEvaluador(String desNombresEvaluador) {
		this.desNombresEvaluador = desNombresEvaluador;
	}

	public String getDesFecRegis() {
		return desFecRegis;
	}

	public void setDesFecRegis(String desFecRegis) {
		this.desFecRegis = desFecRegis;
	}

	public String getDesFecConsulta() {
		return desFecConsulta;
	}

	public void setDesFecConsulta(String desFecConsulta) {
		this.desFecConsulta = desFecConsulta;
	}
    
    
}