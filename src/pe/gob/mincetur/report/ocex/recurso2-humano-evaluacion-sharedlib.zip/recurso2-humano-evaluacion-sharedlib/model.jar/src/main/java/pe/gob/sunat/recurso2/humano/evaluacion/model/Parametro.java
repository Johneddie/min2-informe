package pe.gob.sunat.recurso2.humano.evaluacion.model;

public class Parametro {
    
    private String codParametro;
    private String codDataParametro;
    private String desParametro;
    private String desSiglas;
    private String codEstado;
    private String desAbreviatura;
    
	public String getCodParametro() {
		return codParametro;
	}
	public void setCodParametro(String codParametro) {
		this.codParametro = codParametro;
	}
	public String getCodDataParametro() {
		return codDataParametro;
	}
	public void setCodDataParametro(String codDataParametro) {
		this.codDataParametro = codDataParametro;
	}
	public String getDesParametro() {
		return desParametro;
	}
	public void setDesParametro(String desParametro) {
		this.desParametro = desParametro;
	}
	public String getDesSiglas() {
		return desSiglas;
	}
	public void setDesSiglas(String desSiglas) {
		this.desSiglas = desSiglas;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getDesAbreviatura() {
		return desAbreviatura;
	}
	public void setDesAbreviatura(String desAbreviatura) {
		this.desAbreviatura = desAbreviatura;
	}
}
