package pe.gob.sunat.recurso2.humano.evaluacion.model;

public class AccionSeguimWithBLOBs extends AccionSeguim {
    private String desSeguim;

    private String desAccMejora;

    public String getDesSeguim() {
        return desSeguim;
    }

    public void setDesSeguim(String desSeguim) {
        this.desSeguim = desSeguim == null ? null : desSeguim.trim();
    }

    public String getDesAccMejora() {
        return desAccMejora;
    }

    public void setDesAccMejora(String desAccMejora) {
        this.desAccMejora = desAccMejora == null ? null : desAccMejora.trim();
    }
}