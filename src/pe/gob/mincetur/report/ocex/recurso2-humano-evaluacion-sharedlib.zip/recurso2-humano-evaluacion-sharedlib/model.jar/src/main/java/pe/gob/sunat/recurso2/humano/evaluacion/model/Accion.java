package pe.gob.sunat.recurso2.humano.evaluacion.model;

import java.util.Date;

public class Accion {
    private String anho;

    private String numAcc;

    private String tipoAcc;

    private String codPers;

    private String codUorg;

    private String codUorgAnte;

    private String codCate;

    private String codCateAnte;

    private String codCarg;

    private Date finicio;

    private Date ffin;

    private String observa;

    private Date femision;

    private String codCont;

    private String libElec;

    private String estado;

    private String accionPermuta;

    private Date fgraba;

    private String codUser;

    public String getAnho() {
        return anho;
    }

    public void setAnho(String anho) {
        this.anho = anho == null ? null : anho.trim();
    }

    public String getNumAcc() {
        return numAcc;
    }

    public void setNumAcc(String numAcc) {
        this.numAcc = numAcc == null ? null : numAcc.trim();
    }

    public String getTipoAcc() {
        return tipoAcc;
    }

    public void setTipoAcc(String tipoAcc) {
        this.tipoAcc = tipoAcc == null ? null : tipoAcc.trim();
    }

    public String getCodPers() {
        return codPers;
    }

    public void setCodPers(String codPers) {
        this.codPers = codPers == null ? null : codPers.trim();
    }

    public String getCodUorg() {
        return codUorg;
    }

    public void setCodUorg(String codUorg) {
        this.codUorg = codUorg == null ? null : codUorg.trim();
    }

    public String getCodUorgAnte() {
        return codUorgAnte;
    }

    public void setCodUorgAnte(String codUorgAnte) {
        this.codUorgAnte = codUorgAnte == null ? null : codUorgAnte.trim();
    }

    public String getCodCate() {
        return codCate;
    }

    public void setCodCate(String codCate) {
        this.codCate = codCate == null ? null : codCate.trim();
    }

    public String getCodCateAnte() {
        return codCateAnte;
    }

    public void setCodCateAnte(String codCateAnte) {
        this.codCateAnte = codCateAnte == null ? null : codCateAnte.trim();
    }

    public String getCodCarg() {
        return codCarg;
    }

    public void setCodCarg(String codCarg) {
        this.codCarg = codCarg == null ? null : codCarg.trim();
    }

    public Date getfinicio() {
        return finicio;
    }

    public void setfinicio(Date finicio) {
        this.finicio = finicio;
    }

    public Date getFfin() {
        return ffin;
    }

    public void setFfin(Date ffin) {
        this.ffin = ffin;
    }

    public String getObserva() {
        return observa;
    }

    public void setObserva(String observa) {
        this.observa = observa == null ? null : observa.trim();
    }

    public Date getFemision() {
        return femision;
    }

    public void setFemision(Date femision) {
        this.femision = femision;
    }

    public String getCodCont() {
        return codCont;
    }

    public void setCodCont(String codCont) {
        this.codCont = codCont == null ? null : codCont.trim();
    }

    public String getLibElec() {
        return libElec;
    }

    public void setLibElec(String libElec) {
        this.libElec = libElec == null ? null : libElec.trim();
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado =estado == null ? null : estado.trim();
    }

    public String getAccionPermuta() {
        return accionPermuta;
    }

    public void setAccionPermuta(String accionPermuta) {
        this.accionPermuta = accionPermuta == null ? null : accionPermuta.trim();
    }

    public Date getFgraba() {
        return fgraba;
    }

    public void setFgraba(Date fgraba) {
        this.fgraba = fgraba;
    }

    public String getCodUser() {
        return codUser;
    }

    public void setCodUser(String codUser) {
        this.codUser = codUser == null ? null : codUser.trim();
    }
}