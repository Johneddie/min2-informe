package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluacion;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T43evperDAO;

public class SqlMapT43evperDAO extends SqlMapClientDaoSupport implements T43evperDAO{

	@Override
	public Evaluacion selectByPrimaryKey(Evaluacion paramSearch) {
		return (Evaluacion)getSqlMapClientTemplate().queryForObject("T43evper.selectByPrimaryKey", paramSearch);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Evaluacion> listByParameter(Evaluacion paramSearch) {
		return (List<Evaluacion>)getSqlMapClientTemplate().queryForList("T43evper.listByParameter", paramSearch);
	}

	@Override
	public void insertSelective(Evaluacion paramInsert) {
		getSqlMapClientTemplate().insert("T43evper.insertSelective", paramInsert);
	}

	@Override
	public void updateByPrimaryKeySelective(Evaluacion paramUpdate) {
		getSqlMapClientTemplate().update("T43evper.updateByPrimaryKeySelective", paramUpdate);
	}

}
