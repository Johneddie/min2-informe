package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Seguimiento;

public interface T1536segEvalDAO {

	void insertSelective(Seguimiento paramInsert);
	
}
