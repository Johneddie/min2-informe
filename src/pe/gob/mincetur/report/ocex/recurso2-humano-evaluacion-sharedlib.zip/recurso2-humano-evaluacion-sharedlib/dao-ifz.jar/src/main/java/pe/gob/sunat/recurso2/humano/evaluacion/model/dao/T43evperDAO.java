package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;

import java.util.List;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluacion;

public interface T43evperDAO {

	Evaluacion selectByPrimaryKey(Evaluacion paramSearch);
	List<Evaluacion> listByParameter(Evaluacion paramSearch);
	void insertSelective(Evaluacion paramInsert);
	void updateByPrimaryKeySelective(Evaluacion paramUpdate);
	
}
