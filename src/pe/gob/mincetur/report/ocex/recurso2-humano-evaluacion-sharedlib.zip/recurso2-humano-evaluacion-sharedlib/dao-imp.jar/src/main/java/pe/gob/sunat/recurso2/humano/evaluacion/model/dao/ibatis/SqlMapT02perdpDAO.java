package pe.gob.sunat.recurso2.humano.evaluacion.model.dao.ibatis;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import pe.gob.sunat.recurso2.humano.evaluacion.model.Evaluado;
import pe.gob.sunat.recurso2.humano.evaluacion.model.dao.T02perdpDAO;

@SuppressWarnings("deprecation")
public class SqlMapT02perdpDAO extends SqlMapClientDaoSupport implements T02perdpDAO{

	@Override
	public Evaluado selectByPrimaryKey(
			Evaluado paramSearch) {
		return (Evaluado)getSqlMapClientTemplate().queryForObject("T02perdp.selectByPrimaryKey", paramSearch);
	}
	
	@Override
	public String obtenerNombreCompleto(String paramSearch) {
		return (String)getSqlMapClientTemplate().queryForObject("T02perdp.getNombreCompleto", paramSearch);
	}

}
