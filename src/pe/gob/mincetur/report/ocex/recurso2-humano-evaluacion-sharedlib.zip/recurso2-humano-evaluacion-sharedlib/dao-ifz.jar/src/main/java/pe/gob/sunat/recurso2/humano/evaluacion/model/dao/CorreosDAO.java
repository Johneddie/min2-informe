package pe.gob.sunat.recurso2.humano.evaluacion.model.dao;


public interface CorreosDAO {

	String selectByPrimaryKey(String codPersonal);
	
}
