package pe.gob.sunat.sp.asistencia.bean;

public class BeanArchivo {
	Integer numSeqDoc;
	String nomArchivo ="";
	String desArchivo ="";
	String numArchivo =""; 
	String codTiparc ="";
	String rutAdjunto ="";
	String indicador ="";
	Integer numArcdet ;
	public Integer getNumSeqDoc() {
		return numSeqDoc;
	}
	public void setNumSeqDoc(Integer numSeqDoc) {
		this.numSeqDoc = numSeqDoc;
	}
	public String getNomArchivo() {
		return nomArchivo;
	}
	public void setNomArchivo(String nomArchivo) {
		this.nomArchivo = nomArchivo;
	}
	public String getDesArchivo() {
		return desArchivo;
	}
	public void setDesArchivo(String desArchivo) {
		this.desArchivo = desArchivo;
	}
	public String getNumArchivo() {
		return numArchivo;
	}
	public void setNumArchivo(String numArchivo) {
		this.numArchivo = numArchivo;
	}
	public String getCodTiparc() {
		return codTiparc;
	}
	public void setCodTiparc(String codTiparc) {
		this.codTiparc = codTiparc;
	}
	public String getRutAdjunto() {
		return rutAdjunto;
	}
	public void setRutAdjunto(String rutAdjunto) {
		this.rutAdjunto = rutAdjunto;
	}
	public String getIndicador() {
		return indicador;
	}
	public void setIndicador(String indicador) {
		this.indicador = indicador;
	}
	public Integer getNumArcdet() {
		return numArcdet;
	}
	public void setNumArcdet(Integer numArcdet) {
		this.numArcdet = numArcdet;
	}
	
 
	 
}
