package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensajeExample;

public interface NotificacionMensajeDAO {
    int countByExample(NotificacionMensajeExample example);

    int deleteByExample(NotificacionMensajeExample example);

    int deleteByPrimaryKey(Integer codNotimensaje);

    void insert(NotificacionMensaje record);

    void insertSelective(NotificacionMensaje record);

    List<NotificacionMensaje> selectByExample(NotificacionMensajeExample example);

    NotificacionMensaje selectByPrimaryKey(Integer codNotimensaje);

    int updateByExampleSelective(NotificacionMensaje record, NotificacionMensajeExample example);

    int updateByExample(NotificacionMensaje record, NotificacionMensajeExample example);

    int updateByPrimaryKeySelective(NotificacionMensaje record);

    int updateByPrimaryKey(NotificacionMensaje record);
}