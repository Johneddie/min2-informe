package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Usuario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.UsuarioExample;

public interface UsuarioDAO {
    int countByExample(UsuarioExample example);

    int deleteByExample(UsuarioExample example);

    int deleteByPrimaryKey(Integer codUsuario);

    void insert(Usuario record);

    void insertSelective(Usuario record);

    List<Usuario> selectByExample(UsuarioExample example);

    Usuario selectByPrimaryKey(Integer codUsuario);

    int updateByExampleSelective(Usuario record, UsuarioExample example);

    int updateByExample(Usuario record, UsuarioExample example);

    int updateByPrimaryKeySelective(Usuario record);

    int updateByPrimaryKey(Usuario record);
}