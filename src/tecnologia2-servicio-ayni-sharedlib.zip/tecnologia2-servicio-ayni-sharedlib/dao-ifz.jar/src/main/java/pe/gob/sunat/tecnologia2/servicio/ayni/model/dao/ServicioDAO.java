package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Servicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ServicioExample;

public interface ServicioDAO {
    int countByExample(ServicioExample example);

    int deleteByExample(ServicioExample example);

    int deleteByPrimaryKey(Integer codServicio);

    void insert(Servicio record);

    void insertSelective(Servicio record);

    List<Servicio> selectByExample(ServicioExample example);

    Servicio selectByPrimaryKey(Integer codServicio);

    int updateByExampleSelective(Servicio record, ServicioExample example);

    int updateByExample(Servicio record, ServicioExample example);

    int updateByPrimaryKeySelective(Servicio record);

    int updateByPrimaryKey(Servicio record);
}