package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Persona;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PersonaExample;

public interface PersonaDAO {
    int countByExample(PersonaExample example);

    int deleteByExample(PersonaExample example);

    int deleteByPrimaryKey(Integer codPersona);

    void insert(Persona record);

    void insertSelective(Persona record);

    List<Persona> selectByExample(PersonaExample example);

    Persona selectByPrimaryKey(Integer codPersona);

    int updateByExampleSelective(Persona record, PersonaExample example);

    int updateByExample(Persona record, PersonaExample example);

    int updateByPrimaryKeySelective(Persona record);

    int updateByPrimaryKey(Persona record);
}