package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreoExample;

public interface NotificacionCorreoDAO {
    int countByExample(NotificacionCorreoExample example);

    int deleteByExample(NotificacionCorreoExample example);

    int deleteByPrimaryKey(Integer codNotiCorreo);

    void insert(NotificacionCorreo record);

    void insertSelective(NotificacionCorreo record);

    List<NotificacionCorreo> selectByExample(NotificacionCorreoExample example);

    NotificacionCorreo selectByPrimaryKey(Integer codNotiCorreo);

    int updateByExampleSelective(NotificacionCorreo record, NotificacionCorreoExample example);

    int updateByExample(NotificacionCorreo record, NotificacionCorreoExample example);

    int updateByPrimaryKeySelective(NotificacionCorreo record);

    int updateByPrimaryKey(NotificacionCorreo record);
}