package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreoExample;

public interface PlantillaCorreoDAO {
    int countByExample(PlantillaCorreoExample example);

    int deleteByExample(PlantillaCorreoExample example);

    int deleteByPrimaryKey(Integer codPlantilla);

    void insert(PlantillaCorreo record);

    void insertSelective(PlantillaCorreo record);

    List<PlantillaCorreo> selectByExample(PlantillaCorreoExample example);

    PlantillaCorreo selectByPrimaryKey(Integer codPlantilla);

    int updateByExampleSelective(PlantillaCorreo record, PlantillaCorreoExample example);

    int updateByExample(PlantillaCorreo record, PlantillaCorreoExample example);

    int updateByPrimaryKeySelective(PlantillaCorreo record);

    int updateByPrimaryKey(PlantillaCorreo record);
}