package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Experto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ExpertoExample;

public interface ExpertoDAO {
    int countByExample(ExpertoExample example);

    int deleteByExample(ExpertoExample example);

    int deleteByPrimaryKey(Integer codExperto);

    void insert(Experto record);

    void insertSelective(Experto record);

    List<Experto> selectByExample(ExpertoExample example);

    Experto selectByPrimaryKey(Integer codExperto);

    int updateByExampleSelective(Experto record, ExpertoExample example);

    int updateByExample(Experto record, ExpertoExample example);

    int updateByPrimaryKeySelective(Experto record);

    int updateByPrimaryKey(Experto record);
}