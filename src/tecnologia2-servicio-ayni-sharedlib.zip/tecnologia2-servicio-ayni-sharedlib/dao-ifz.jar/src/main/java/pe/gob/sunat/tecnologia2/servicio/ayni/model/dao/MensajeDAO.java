package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Mensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MensajeExample;

public interface MensajeDAO {
    int countByExample(MensajeExample example);

    int deleteByExample(MensajeExample example);

    int deleteByPrimaryKey(Integer codMensaje);

    void insert(Mensaje record);

    void insertSelective(Mensaje record);

    List<Mensaje> selectByExample(MensajeExample example);

    Mensaje selectByPrimaryKey(Integer codMensaje);

    int updateByExampleSelective(Mensaje record, MensajeExample example);

    int updateByExample(Mensaje record, MensajeExample example);

    int updateByPrimaryKeySelective(Mensaje record);

    int updateByPrimaryKey(Mensaje record);
}