package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Parametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ParametroExample;

public interface ParametroDAO {
    int countByExample(ParametroExample example);

    int deleteByExample(ParametroExample example);

    int deleteByPrimaryKey(Integer codParam);

    void insert(Parametro record);

    void insertSelective(Parametro record);

    List<Parametro> selectByExample(ParametroExample example);

    Parametro selectByPrimaryKey(Integer codParam);

    int updateByExampleSelective(Parametro record, ParametroExample example);

    int updateByExample(Parametro record, ParametroExample example);

    int updateByPrimaryKeySelective(Parametro record);

    int updateByPrimaryKey(Parametro record);
}