package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Especialidad;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.EspecialidadExample;

public interface EspecialidadDAO {
    int countByExample(EspecialidadExample example);

    int deleteByExample(EspecialidadExample example);

    int deleteByPrimaryKey(Integer codEspec);

    void insert(Especialidad record);

    void insertSelective(Especialidad record);

    List<Especialidad> selectByExample(EspecialidadExample example);

    Especialidad selectByPrimaryKey(Integer codEspec);

    int updateByExampleSelective(Especialidad record, EspecialidadExample example);

    int updateByExample(Especialidad record, EspecialidadExample example);

    int updateByPrimaryKeySelective(Especialidad record);

    int updateByPrimaryKey(Especialidad record);
}