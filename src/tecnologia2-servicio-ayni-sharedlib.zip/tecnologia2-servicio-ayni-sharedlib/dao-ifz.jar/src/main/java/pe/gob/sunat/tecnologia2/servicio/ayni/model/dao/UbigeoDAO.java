package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Ubigeo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.UbigeoExample;

public interface UbigeoDAO {
    int countByExample(UbigeoExample example);

    int deleteByExample(UbigeoExample example);

    int deleteByPrimaryKey(Integer codUbigeo);

    void insert(Ubigeo record);

    void insertSelective(Ubigeo record);

    List<Ubigeo> selectByExample(UbigeoExample example);

    Ubigeo selectByPrimaryKey(Integer codUbigeo);

    int updateByExampleSelective(Ubigeo record, UbigeoExample example);

    int updateByExample(Ubigeo record, UbigeoExample example);

    int updateByPrimaryKeySelective(Ubigeo record);

    int updateByPrimaryKey(Ubigeo record);
}