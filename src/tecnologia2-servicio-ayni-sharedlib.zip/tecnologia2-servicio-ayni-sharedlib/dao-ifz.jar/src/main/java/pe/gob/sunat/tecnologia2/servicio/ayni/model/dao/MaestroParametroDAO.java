package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametroExample;

public interface MaestroParametroDAO {
    int countByExample(MaestroParametroExample example);

    int deleteByExample(MaestroParametroExample example);

    int deleteByPrimaryKey(Integer codMaestro);

    void insert(MaestroParametro record);

    void insertSelective(MaestroParametro record);

    List<MaestroParametro> selectByExample(MaestroParametroExample example);

    MaestroParametro selectByPrimaryKey(Integer codMaestro);

    int updateByExampleSelective(MaestroParametro record, MaestroParametroExample example);

    int updateByExample(MaestroParametro record, MaestroParametroExample example);

    int updateByPrimaryKeySelective(MaestroParametro record);

    int updateByPrimaryKey(MaestroParametro record);
}