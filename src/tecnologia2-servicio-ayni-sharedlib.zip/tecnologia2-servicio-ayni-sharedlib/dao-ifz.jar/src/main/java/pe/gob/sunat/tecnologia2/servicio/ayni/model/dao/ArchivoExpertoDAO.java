package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExperto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExpertoExample;

public interface ArchivoExpertoDAO {
    int countByExample(ArchivoExpertoExample example);

    int deleteByExample(ArchivoExpertoExample example);

    int deleteByPrimaryKey(Integer codArchExpert);

    void insert(ArchivoExperto record);

    void insertSelective(ArchivoExperto record);

    List<ArchivoExperto> selectByExample(ArchivoExpertoExample example);

    ArchivoExperto selectByPrimaryKey(Integer codArchExpert);

    int updateByExampleSelective(ArchivoExperto record, ArchivoExpertoExample example);

    int updateByExample(ArchivoExperto record, ArchivoExpertoExample example);

    int updateByPrimaryKeySelective(ArchivoExperto record);

    int updateByPrimaryKey(ArchivoExperto record);
}