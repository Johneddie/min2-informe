package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicioExample;

public interface ArchivoServicioDAO {
    int countByExample(ArchivoServicioExample example);

    int deleteByExample(ArchivoServicioExample example);

    int deleteByPrimaryKey(Integer codArchServ);

    void insert(ArchivoServicio record);

    void insertSelective(ArchivoServicio record);

    List<ArchivoServicio> selectByExample(ArchivoServicioExample example);

    ArchivoServicio selectByPrimaryKey(Integer codArchServ);

    int updateByExampleSelective(ArchivoServicio record, ArchivoServicioExample example);

    int updateByExample(ArchivoServicio record, ArchivoServicioExample example);

    int updateByPrimaryKeySelective(ArchivoServicio record);

    int updateByPrimaryKey(ArchivoServicio record);
}