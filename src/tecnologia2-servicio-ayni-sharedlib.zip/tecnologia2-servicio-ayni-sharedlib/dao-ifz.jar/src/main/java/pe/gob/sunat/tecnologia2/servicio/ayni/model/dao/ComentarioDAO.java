package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Comentario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ComentarioExample;

public interface ComentarioDAO {
    int countByExample(ComentarioExample example);

    int deleteByExample(ComentarioExample example);

    int deleteByPrimaryKey(Integer codComent);

    void insert(Comentario record);

    void insertSelective(Comentario record);

    List<Comentario> selectByExample(ComentarioExample example);

    Comentario selectByPrimaryKey(Integer codComent);

    int updateByExampleSelective(Comentario record, ComentarioExample example);

    int updateByExample(Comentario record, ComentarioExample example);

    int updateByPrimaryKeySelective(Comentario record);

    int updateByPrimaryKey(Comentario record);
}