package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Diccionario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.DiccionarioExample;

public interface DiccionarioDAO {
    int countByExample(DiccionarioExample example);

    int deleteByExample(DiccionarioExample example);

    int deleteByPrimaryKey(Integer codPalabra);

    void insert(Diccionario record);

    void insertSelective(Diccionario record);

    List<Diccionario> selectByExample(DiccionarioExample example);

    Diccionario selectByPrimaryKey(Integer codPalabra);

    int updateByExampleSelective(Diccionario record, DiccionarioExample example);

    int updateByExample(Diccionario record, DiccionarioExample example);

    int updateByPrimaryKeySelective(Diccionario record);

    int updateByPrimaryKey(Diccionario record);
}