package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Sesion;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.SesionExample;

public interface SesionDAO {
    int countByExample(SesionExample example);

    int deleteByExample(SesionExample example);

    int deleteByPrimaryKey(Integer codSesion);

    void insert(Sesion record);

    void insertSelective(Sesion record);

    List<Sesion> selectByExample(SesionExample example);

    Sesion selectByPrimaryKey(Integer codSesion);

    int updateByExampleSelective(Sesion record, SesionExample example);

    int updateByExample(Sesion record, SesionExample example);

    int updateByPrimaryKeySelective(Sesion record);

    int updateByPrimaryKey(Sesion record);
}