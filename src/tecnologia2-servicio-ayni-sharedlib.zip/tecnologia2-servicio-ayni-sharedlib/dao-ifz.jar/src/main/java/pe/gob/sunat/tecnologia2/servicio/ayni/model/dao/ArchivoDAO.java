package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao;

import java.util.List;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Archivo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExample;

public interface ArchivoDAO {
    int countByExample(ArchivoExample example);

    int deleteByExample(ArchivoExample example);

    int deleteByPrimaryKey(Integer codArchivo);

    void insert(Archivo record);

    void insertSelective(Archivo record);

    List<Archivo> selectByExampleWithBLOBs(ArchivoExample example);

    List<Archivo> selectByExampleWithoutBLOBs(ArchivoExample example);

    Archivo selectByPrimaryKey(Integer codArchivo);

    int updateByExampleSelective(Archivo record, ArchivoExample example);

    int updateByExampleWithBLOBs(Archivo record, ArchivoExample example);

    int updateByExampleWithoutBLOBs(Archivo record, ArchivoExample example);

    int updateByPrimaryKeySelective(Archivo record);

    int updateByPrimaryKeyWithBLOBs(Archivo record);

    int updateByPrimaryKeyWithoutBLOBs(Archivo record);
}