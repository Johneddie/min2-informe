package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Persona;

public interface PersonaService {

	public Persona obtenerPersona(Integer key);

	public int eliminarPersona(Integer key);

	public int actualizarPersona(Persona entidad);

	public void insertarPersona(Persona entidad);

}
