package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensaje;

public interface NotificacionMensajeService {

	public NotificacionMensaje obtenerNotificacionMensaje(Integer key);

	public int eliminarNotificacionMensaje(Integer key);

	public int actualizarNotificacionMensaje(NotificacionMensaje entidad);

	public void insertarNotificacionMensaje(NotificacionMensaje entidad);

}
