package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicio;

public interface ArchivoServicioService {

	public ArchivoServicio obtenerArchivoServicio(Integer key);

	public int eliminarArchivoServicio(Integer key);

	public int actualizarArchivoServicio(ArchivoServicio entidad);

	public void insertarArchivoServicio(ArchivoServicio entidad);

}
