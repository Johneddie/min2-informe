package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExperto;

public interface ArchivoExpertoService {

	public ArchivoExperto obtenerArchivoExperto(Integer key);

	public int eliminarArchivoExperto(Integer key);

	public int actualizarArchivoExperto(ArchivoExperto entidad);

	public void insertarArchivoExperto(ArchivoExperto entidad);

}
