package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Sesion;

public interface SesionService {

	public Sesion obtenerSesion(Integer key);

	public int eliminarSesion(Integer key);

	public int actualizarSesion(Sesion entidad);

	public void insertarSesion(Sesion entidad);

}
