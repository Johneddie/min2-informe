package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Diccionario;

public interface DiccionarioService {

	public Diccionario obtenerDiccionario(Integer key);

	public int eliminarDiccionario(Integer key);

	public int actualizarDiccionario(Diccionario entidad);

	public void insertarDiccionario(Diccionario entidad);

}
