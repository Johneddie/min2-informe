package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreo;

public interface PlantillaCorreoService {

	public PlantillaCorreo obtenerPlantillaCorreo(Integer key);

	public int eliminarPlantillaCorreo(Integer key);

	public int actualizarPlantillaCorreo(PlantillaCorreo entidad);

	public void insertarPlantillaCorreo(PlantillaCorreo entidad);

}
