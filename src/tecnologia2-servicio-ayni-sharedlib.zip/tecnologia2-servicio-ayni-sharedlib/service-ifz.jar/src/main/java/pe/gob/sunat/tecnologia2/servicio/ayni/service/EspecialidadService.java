package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Especialidad;

public interface EspecialidadService {

	public Especialidad obtenerEspecialidad(Integer key);

	public int eliminarEspecialidad(Integer key);

	public int actualizarEspecialidad(Especialidad entidad);

	public void insertarEspecialidad(Especialidad entidad);

}
