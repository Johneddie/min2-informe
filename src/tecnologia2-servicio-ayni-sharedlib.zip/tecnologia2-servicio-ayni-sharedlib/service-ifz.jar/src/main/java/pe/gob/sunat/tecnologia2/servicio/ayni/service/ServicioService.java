package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Servicio;

public interface ServicioService {

	public Servicio obtenerServicio(Integer key);

	public int eliminarServicio(Integer key);

	public int actualizarServicio(Servicio entidad);

	public void insertarServicio(Servicio entidad);

}
