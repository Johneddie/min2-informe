package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Usuario;

public interface UsuarioService {

	public Usuario obtenerUsuario(Integer key);

	public int eliminarUsuario(Integer key);

	public int actualizarUsuario(Usuario entidad);

	public void insertarUsuario(Usuario entidad);

}
