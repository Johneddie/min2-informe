package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametro;

public interface MaestroParametroService {

	public MaestroParametro obtenerMaestroParametro(Integer key);

	public int eliminarMaestroParametro(Integer key);

	public int actualizarMaestroParametro(MaestroParametro entidad);

	public void insertarMaestroParametro(MaestroParametro entidad);

}
