package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Archivo;

public interface ArchivoService {

	public Archivo obtenerArchivo(Integer key);

	public int eliminarArchivo(Integer key);

	public int actualizarArchivo(Archivo entidad);

	public void insertarArchivo(Archivo entidad);

}
