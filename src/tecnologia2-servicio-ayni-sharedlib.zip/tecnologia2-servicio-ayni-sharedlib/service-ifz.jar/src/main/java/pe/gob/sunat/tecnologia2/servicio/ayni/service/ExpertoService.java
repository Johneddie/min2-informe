package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Experto;

public interface ExpertoService {

	public Experto obtenerExperto(Integer key);

	public int eliminarExperto(Integer key);

	public int actualizarExperto(Experto entidad);

	public void insertarExperto(Experto entidad);

}
