package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Parametro;

public interface ParametroService {

	public Parametro obtenerParametro(Integer key);

	public int eliminarParametro(Integer key);

	public int actualizarParametro(Parametro entidad);

	public void insertarParametro(Parametro entidad);

}
