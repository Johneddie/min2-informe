package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreo;

public interface NotificacionCorreoService {

	public NotificacionCorreo obtenerNotificacionCorreo(Integer key);

	public int eliminarNotificacionCorreo(Integer key);

	public int actualizarNotificacionCorreo(NotificacionCorreo entidad);

	public void insertarNotificacionCorreo(NotificacionCorreo entidad);

}
