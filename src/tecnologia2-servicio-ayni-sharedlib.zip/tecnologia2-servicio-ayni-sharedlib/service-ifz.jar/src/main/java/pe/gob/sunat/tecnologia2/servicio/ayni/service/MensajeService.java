package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Mensaje;

public interface MensajeService {

	public Mensaje obtenerMensaje(Integer key);

	public int eliminarMensaje(Integer key);

	public int actualizarMensaje(Mensaje entidad);

	public void insertarMensaje(Mensaje entidad);

}
