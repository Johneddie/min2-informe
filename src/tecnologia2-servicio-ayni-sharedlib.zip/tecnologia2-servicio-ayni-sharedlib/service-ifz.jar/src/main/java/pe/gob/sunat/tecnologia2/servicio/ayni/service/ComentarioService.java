package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Comentario;

public interface ComentarioService {

	public Comentario obtenerComentario(Integer key);

	public int eliminarComentario(Integer key);

	public int actualizarComentario(Comentario entidad);

	public void insertarComentario(Comentario entidad);

}
