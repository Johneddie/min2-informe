package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Ubigeo;

public interface UbigeoService {

	public Ubigeo obtenerUbigeo(Integer key);

	public int eliminarUbigeo(Integer key);

	public int actualizarUbigeo(Ubigeo entidad);

	public void insertarUbigeo(Ubigeo entidad);

}
