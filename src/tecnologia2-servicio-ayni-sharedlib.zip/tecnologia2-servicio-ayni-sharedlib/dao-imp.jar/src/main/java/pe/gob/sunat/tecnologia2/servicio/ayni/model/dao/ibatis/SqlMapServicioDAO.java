package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Servicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ServicioExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ServicioDAO;

public class SqlMapServicioDAO extends SqlMapClientDaoSupport implements ServicioDAO {

    public SqlMapServicioDAO() {
        super();
    }

    public int countByExample(ServicioExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t016servicio.countByExample", example);
        return count;
    }

    public int deleteByExample(ServicioExample example) {
        int rows = getSqlMapClientTemplate().delete("t016servicio.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codServicio) {
        Servicio key = new Servicio();
        key.setCodServicio(codServicio);
        int rows = getSqlMapClientTemplate().delete("t016servicio.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Servicio record) {
        getSqlMapClientTemplate().insert("t016servicio.insert", record);
    }

    public void insertSelective(Servicio record) {
        getSqlMapClientTemplate().insert("t016servicio.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Servicio> selectByExample(ServicioExample example) {
        List<Servicio> list = getSqlMapClientTemplate().queryForList("t016servicio.selectByExample", example);
        return list;
    }

    public Servicio selectByPrimaryKey(Integer codServicio) {
        Servicio key = new Servicio();
        key.setCodServicio(codServicio);
        Servicio record = (Servicio) getSqlMapClientTemplate().queryForObject("t016servicio.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Servicio record, ServicioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t016servicio.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Servicio record, ServicioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t016servicio.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Servicio record) {
        int rows = getSqlMapClientTemplate().update("t016servicio.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Servicio record) {
        int rows = getSqlMapClientTemplate().update("t016servicio.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ServicioExample {
        private Object record;

        public UpdateByExampleParms(Object record, ServicioExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}