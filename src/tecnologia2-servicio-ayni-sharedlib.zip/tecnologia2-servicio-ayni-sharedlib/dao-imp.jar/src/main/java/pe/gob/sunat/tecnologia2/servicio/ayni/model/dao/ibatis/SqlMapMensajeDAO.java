package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Mensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MensajeExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.MensajeDAO;

public class SqlMapMensajeDAO extends SqlMapClientDaoSupport implements MensajeDAO {

    public SqlMapMensajeDAO() {
        super();
    }

    public int countByExample(MensajeExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t005mensaje.countByExample", example);
        return count;
    }

    public int deleteByExample(MensajeExample example) {
        int rows = getSqlMapClientTemplate().delete("t005mensaje.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codMensaje) {
        Mensaje key = new Mensaje();
        key.setCodMensaje(codMensaje);
        int rows = getSqlMapClientTemplate().delete("t005mensaje.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Mensaje record) {
        getSqlMapClientTemplate().insert("t005mensaje.insert", record);
    }

    public void insertSelective(Mensaje record) {
        getSqlMapClientTemplate().insert("t005mensaje.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Mensaje> selectByExample(MensajeExample example) {
        List<Mensaje> list = getSqlMapClientTemplate().queryForList("t005mensaje.selectByExample", example);
        return list;
    }

    public Mensaje selectByPrimaryKey(Integer codMensaje) {
        Mensaje key = new Mensaje();
        key.setCodMensaje(codMensaje);
        Mensaje record = (Mensaje) getSqlMapClientTemplate().queryForObject("t005mensaje.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Mensaje record, MensajeExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t005mensaje.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Mensaje record, MensajeExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t005mensaje.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Mensaje record) {
        int rows = getSqlMapClientTemplate().update("t005mensaje.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Mensaje record) {
        int rows = getSqlMapClientTemplate().update("t005mensaje.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends MensajeExample {
        private Object record;

        public UpdateByExampleParms(Object record, MensajeExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}