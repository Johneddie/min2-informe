package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Sesion;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.SesionExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.SesionDAO;

public class SqlMapSesionDAO extends SqlMapClientDaoSupport implements SesionDAO {

    public SqlMapSesionDAO() {
        super();
    }

    public int countByExample(SesionExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t018sesion.countByExample", example);
        return count;
    }

    public int deleteByExample(SesionExample example) {
        int rows = getSqlMapClientTemplate().delete("t018sesion.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codSesion) {
        Sesion key = new Sesion();
        key.setCodSesion(codSesion);
        int rows = getSqlMapClientTemplate().delete("t018sesion.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Sesion record) {
        getSqlMapClientTemplate().insert("t018sesion.insert", record);
    }

    public void insertSelective(Sesion record) {
        getSqlMapClientTemplate().insert("t018sesion.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Sesion> selectByExample(SesionExample example) {
        List<Sesion> list = getSqlMapClientTemplate().queryForList("t018sesion.selectByExample", example);
        return list;
    }

    public Sesion selectByPrimaryKey(Integer codSesion) {
        Sesion key = new Sesion();
        key.setCodSesion(codSesion);
        Sesion record = (Sesion) getSqlMapClientTemplate().queryForObject("t018sesion.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Sesion record, SesionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t018sesion.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Sesion record, SesionExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t018sesion.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Sesion record) {
        int rows = getSqlMapClientTemplate().update("t018sesion.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Sesion record) {
        int rows = getSqlMapClientTemplate().update("t018sesion.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends SesionExample {
        private Object record;

        public UpdateByExampleParms(Object record, SesionExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}