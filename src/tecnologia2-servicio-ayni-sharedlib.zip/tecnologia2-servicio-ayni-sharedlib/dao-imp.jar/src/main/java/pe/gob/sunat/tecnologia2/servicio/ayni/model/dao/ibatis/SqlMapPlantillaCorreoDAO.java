package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.PlantillaCorreoDAO;

public class SqlMapPlantillaCorreoDAO extends SqlMapClientDaoSupport implements PlantillaCorreoDAO {

    public SqlMapPlantillaCorreoDAO() {
        super();
    }

    public int countByExample(PlantillaCorreoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t014plantilla_correo.countByExample", example);
        return count;
    }

    public int deleteByExample(PlantillaCorreoExample example) {
        int rows = getSqlMapClientTemplate().delete("t014plantilla_correo.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codPlantilla) {
        PlantillaCorreo key = new PlantillaCorreo();
        key.setCodPlantilla(codPlantilla);
        int rows = getSqlMapClientTemplate().delete("t014plantilla_correo.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(PlantillaCorreo record) {
        getSqlMapClientTemplate().insert("t014plantilla_correo.insert", record);
    }

    public void insertSelective(PlantillaCorreo record) {
        getSqlMapClientTemplate().insert("t014plantilla_correo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<PlantillaCorreo> selectByExample(PlantillaCorreoExample example) {
        List<PlantillaCorreo> list = getSqlMapClientTemplate().queryForList("t014plantilla_correo.selectByExample", example);
        return list;
    }

    public PlantillaCorreo selectByPrimaryKey(Integer codPlantilla) {
        PlantillaCorreo key = new PlantillaCorreo();
        key.setCodPlantilla(codPlantilla);
        PlantillaCorreo record = (PlantillaCorreo) getSqlMapClientTemplate().queryForObject("t014plantilla_correo.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(PlantillaCorreo record, PlantillaCorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t014plantilla_correo.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(PlantillaCorreo record, PlantillaCorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t014plantilla_correo.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(PlantillaCorreo record) {
        int rows = getSqlMapClientTemplate().update("t014plantilla_correo.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(PlantillaCorreo record) {
        int rows = getSqlMapClientTemplate().update("t014plantilla_correo.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends PlantillaCorreoExample {
        private Object record;

        public UpdateByExampleParms(Object record, PlantillaCorreoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}