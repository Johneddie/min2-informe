package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExperto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExpertoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoExpertoDAO;

public class SqlMapArchivoExpertoDAO extends SqlMapClientDaoSupport implements ArchivoExpertoDAO {

    public SqlMapArchivoExpertoDAO() {
        super();
    }

    public int countByExample(ArchivoExpertoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t007archivo_expert.countByExample", example);
        return count;
    }

    public int deleteByExample(ArchivoExpertoExample example) {
        int rows = getSqlMapClientTemplate().delete("t007archivo_expert.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codArchExpert) {
        ArchivoExperto key = new ArchivoExperto();
        key.setCodArchExpert(codArchExpert);
        int rows = getSqlMapClientTemplate().delete("t007archivo_expert.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(ArchivoExperto record) {
        getSqlMapClientTemplate().insert("t007archivo_expert.insert", record);
    }

    public void insertSelective(ArchivoExperto record) {
        getSqlMapClientTemplate().insert("t007archivo_expert.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoExperto> selectByExample(ArchivoExpertoExample example) {
        List<ArchivoExperto> list = getSqlMapClientTemplate().queryForList("t007archivo_expert.selectByExample", example);
        return list;
    }

    public ArchivoExperto selectByPrimaryKey(Integer codArchExpert) {
        ArchivoExperto key = new ArchivoExperto();
        key.setCodArchExpert(codArchExpert);
        ArchivoExperto record = (ArchivoExperto) getSqlMapClientTemplate().queryForObject("t007archivo_expert.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(ArchivoExperto record, ArchivoExpertoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t007archivo_expert.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(ArchivoExperto record, ArchivoExpertoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t007archivo_expert.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(ArchivoExperto record) {
        int rows = getSqlMapClientTemplate().update("t007archivo_expert.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(ArchivoExperto record) {
        int rows = getSqlMapClientTemplate().update("t007archivo_expert.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ArchivoExpertoExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoExpertoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}