package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Archivo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoDAO;

public class SqlMapArchivoDAO extends SqlMapClientDaoSupport implements ArchivoDAO {

    public SqlMapArchivoDAO() {
        super();
    }

    public int countByExample(ArchivoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t004archivo.countByExample", example);
        return count;
    }

    public int deleteByExample(ArchivoExample example) {
        int rows = getSqlMapClientTemplate().delete("t004archivo.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codArchivo) {
        Archivo key = new Archivo();
        key.setCodArchivo(codArchivo);
        int rows = getSqlMapClientTemplate().delete("t004archivo.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Archivo record) {
        getSqlMapClientTemplate().insert("t004archivo.insert", record);
    }

    public void insertSelective(Archivo record) {
        getSqlMapClientTemplate().insert("t004archivo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Archivo> selectByExampleWithBLOBs(ArchivoExample example) {
        List<Archivo> list = getSqlMapClientTemplate().queryForList("t004archivo.selectByExampleWithBLOBs", example);
        return list;
    }

    @SuppressWarnings("unchecked")
    public List<Archivo> selectByExampleWithoutBLOBs(ArchivoExample example) {
        List<Archivo> list = getSqlMapClientTemplate().queryForList("t004archivo.selectByExample", example);
        return list;
    }

    public Archivo selectByPrimaryKey(Integer codArchivo) {
        Archivo key = new Archivo();
        key.setCodArchivo(codArchivo);
        Archivo record = (Archivo) getSqlMapClientTemplate().queryForObject("t004archivo.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExampleWithBLOBs(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByExampleWithBLOBs", parms);
        return rows;
    }

    public int updateByExampleWithoutBLOBs(Archivo record, ArchivoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Archivo record) {
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKeyWithBLOBs(Archivo record) {
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByPrimaryKeyWithBLOBs", record);
        return rows;
    }

    public int updateByPrimaryKeyWithoutBLOBs(Archivo record) {
        int rows = getSqlMapClientTemplate().update("t004archivo.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ArchivoExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}