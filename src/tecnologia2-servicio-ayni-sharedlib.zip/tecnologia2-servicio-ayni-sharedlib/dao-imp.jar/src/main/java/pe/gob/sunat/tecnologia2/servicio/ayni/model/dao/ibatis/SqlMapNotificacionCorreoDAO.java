package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.NotificacionCorreoDAO;

public class SqlMapNotificacionCorreoDAO extends SqlMapClientDaoSupport implements NotificacionCorreoDAO {

    public SqlMapNotificacionCorreoDAO() {
        super();
    }

    public int countByExample(NotificacionCorreoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t015notif_correo.countByExample", example);
        return count;
    }

    public int deleteByExample(NotificacionCorreoExample example) {
        int rows = getSqlMapClientTemplate().delete("t015notif_correo.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codNotiCorreo) {
        NotificacionCorreo key = new NotificacionCorreo();
        key.setCodNotiCorreo(codNotiCorreo);
        int rows = getSqlMapClientTemplate().delete("t015notif_correo.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(NotificacionCorreo record) {
        getSqlMapClientTemplate().insert("t015notif_correo.insert", record);
    }

    public void insertSelective(NotificacionCorreo record) {
        getSqlMapClientTemplate().insert("t015notif_correo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<NotificacionCorreo> selectByExample(NotificacionCorreoExample example) {
        List<NotificacionCorreo> list = getSqlMapClientTemplate().queryForList("t015notif_correo.selectByExample", example);
        return list;
    }

    public NotificacionCorreo selectByPrimaryKey(Integer codNotiCorreo) {
        NotificacionCorreo key = new NotificacionCorreo();
        key.setCodNotiCorreo(codNotiCorreo);
        NotificacionCorreo record = (NotificacionCorreo) getSqlMapClientTemplate().queryForObject("t015notif_correo.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(NotificacionCorreo record, NotificacionCorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t015notif_correo.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(NotificacionCorreo record, NotificacionCorreoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t015notif_correo.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(NotificacionCorreo record) {
        int rows = getSqlMapClientTemplate().update("t015notif_correo.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(NotificacionCorreo record) {
        int rows = getSqlMapClientTemplate().update("t015notif_correo.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends NotificacionCorreoExample {
        private Object record;

        public UpdateByExampleParms(Object record, NotificacionCorreoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}