package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Comentario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ComentarioExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ComentarioDAO;

public class SqlMapComentarioDAO extends SqlMapClientDaoSupport implements ComentarioDAO {

    public SqlMapComentarioDAO() {
        super();
    }

    public int countByExample(ComentarioExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t008comentario.countByExample", example);
        return count;
    }

    public int deleteByExample(ComentarioExample example) {
        int rows = getSqlMapClientTemplate().delete("t008comentario.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codComent) {
        Comentario key = new Comentario();
        key.setCodComent(codComent);
        int rows = getSqlMapClientTemplate().delete("t008comentario.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Comentario record) {
        getSqlMapClientTemplate().insert("t008comentario.insert", record);
    }

    public void insertSelective(Comentario record) {
        getSqlMapClientTemplate().insert("t008comentario.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Comentario> selectByExample(ComentarioExample example) {
        List<Comentario> list = getSqlMapClientTemplate().queryForList("t008comentario.selectByExample", example);
        return list;
    }

    public Comentario selectByPrimaryKey(Integer codComent) {
        Comentario key = new Comentario();
        key.setCodComent(codComent);
        Comentario record = (Comentario) getSqlMapClientTemplate().queryForObject("t008comentario.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Comentario record, ComentarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t008comentario.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Comentario record, ComentarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t008comentario.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Comentario record) {
        int rows = getSqlMapClientTemplate().update("t008comentario.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Comentario record) {
        int rows = getSqlMapClientTemplate().update("t008comentario.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ComentarioExample {
        private Object record;

        public UpdateByExampleParms(Object record, ComentarioExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}