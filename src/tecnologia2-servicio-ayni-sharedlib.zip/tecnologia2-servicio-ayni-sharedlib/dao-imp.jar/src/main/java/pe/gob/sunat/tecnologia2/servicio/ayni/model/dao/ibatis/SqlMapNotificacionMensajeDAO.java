package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensajeExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.NotificacionMensajeDAO;

public class SqlMapNotificacionMensajeDAO extends SqlMapClientDaoSupport implements NotificacionMensajeDAO {

    public SqlMapNotificacionMensajeDAO() {
        super();
    }

    public int countByExample(NotificacionMensajeExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t006notif_mensaje.countByExample", example);
        return count;
    }

    public int deleteByExample(NotificacionMensajeExample example) {
        int rows = getSqlMapClientTemplate().delete("t006notif_mensaje.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codNotimensaje) {
        NotificacionMensaje key = new NotificacionMensaje();
        key.setCodNotimensaje(codNotimensaje);
        int rows = getSqlMapClientTemplate().delete("t006notif_mensaje.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(NotificacionMensaje record) {
        getSqlMapClientTemplate().insert("t006notif_mensaje.insert", record);
    }

    public void insertSelective(NotificacionMensaje record) {
        getSqlMapClientTemplate().insert("t006notif_mensaje.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<NotificacionMensaje> selectByExample(NotificacionMensajeExample example) {
        List<NotificacionMensaje> list = getSqlMapClientTemplate().queryForList("t006notif_mensaje.selectByExample", example);
        return list;
    }

    public NotificacionMensaje selectByPrimaryKey(Integer codNotimensaje) {
        NotificacionMensaje key = new NotificacionMensaje();
        key.setCodNotimensaje(codNotimensaje);
        NotificacionMensaje record = (NotificacionMensaje) getSqlMapClientTemplate().queryForObject("t006notif_mensaje.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(NotificacionMensaje record, NotificacionMensajeExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t006notif_mensaje.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(NotificacionMensaje record, NotificacionMensajeExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t006notif_mensaje.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(NotificacionMensaje record) {
        int rows = getSqlMapClientTemplate().update("t006notif_mensaje.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(NotificacionMensaje record) {
        int rows = getSqlMapClientTemplate().update("t006notif_mensaje.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends NotificacionMensajeExample {
        private Object record;

        public UpdateByExampleParms(Object record, NotificacionMensajeExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}