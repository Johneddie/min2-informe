package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Diccionario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.DiccionarioExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.DiccionarioDAO;

public class SqlMapDiccionarioDAO extends SqlMapClientDaoSupport implements DiccionarioDAO {

    public SqlMapDiccionarioDAO() {
        super();
    }

    public int countByExample(DiccionarioExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t013diccionario.countByExample", example);
        return count;
    }

    public int deleteByExample(DiccionarioExample example) {
        int rows = getSqlMapClientTemplate().delete("t013diccionario.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codPalabra) {
        Diccionario key = new Diccionario();
        key.setCodPalabra(codPalabra);
        int rows = getSqlMapClientTemplate().delete("t013diccionario.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Diccionario record) {
        getSqlMapClientTemplate().insert("t013diccionario.insert", record);
    }

    public void insertSelective(Diccionario record) {
        getSqlMapClientTemplate().insert("t013diccionario.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Diccionario> selectByExample(DiccionarioExample example) {
        List<Diccionario> list = getSqlMapClientTemplate().queryForList("t013diccionario.selectByExample", example);
        return list;
    }

    public Diccionario selectByPrimaryKey(Integer codPalabra) {
        Diccionario key = new Diccionario();
        key.setCodPalabra(codPalabra);
        Diccionario record = (Diccionario) getSqlMapClientTemplate().queryForObject("t013diccionario.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Diccionario record, DiccionarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t013diccionario.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Diccionario record, DiccionarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t013diccionario.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Diccionario record) {
        int rows = getSqlMapClientTemplate().update("t013diccionario.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Diccionario record) {
        int rows = getSqlMapClientTemplate().update("t013diccionario.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends DiccionarioExample {
        private Object record;

        public UpdateByExampleParms(Object record, DiccionarioExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}