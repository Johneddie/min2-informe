package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Especialidad;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.EspecialidadExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.EspecialidadDAO;

public class SqlMapEspecialidadDAO extends SqlMapClientDaoSupport implements EspecialidadDAO {

    public SqlMapEspecialidadDAO() {
        super();
    }

    public int countByExample(EspecialidadExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t003especialidad.countByExample", example);
        return count;
    }

    public int deleteByExample(EspecialidadExample example) {
        int rows = getSqlMapClientTemplate().delete("t003especialidad.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codEspec) {
        Especialidad key = new Especialidad();
        key.setCodEspec(codEspec);
        int rows = getSqlMapClientTemplate().delete("t003especialidad.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Especialidad record) {
        getSqlMapClientTemplate().insert("t003especialidad.insert", record);
    }

    public void insertSelective(Especialidad record) {
        getSqlMapClientTemplate().insert("t003especialidad.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Especialidad> selectByExample(EspecialidadExample example) {
        List<Especialidad> list = getSqlMapClientTemplate().queryForList("t003especialidad.selectByExample", example);
        return list;
    }

    public Especialidad selectByPrimaryKey(Integer codEspec) {
        Especialidad key = new Especialidad();
        key.setCodEspec(codEspec);
        Especialidad record = (Especialidad) getSqlMapClientTemplate().queryForObject("t003especialidad.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Especialidad record, EspecialidadExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t003especialidad.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Especialidad record, EspecialidadExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t003especialidad.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Especialidad record) {
        int rows = getSqlMapClientTemplate().update("t003especialidad.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Especialidad record) {
        int rows = getSqlMapClientTemplate().update("t003especialidad.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends EspecialidadExample {
        private Object record;

        public UpdateByExampleParms(Object record, EspecialidadExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}