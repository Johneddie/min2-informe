package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicioExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoServicioDAO;

public class SqlMapArchivoServicioDAO extends SqlMapClientDaoSupport implements ArchivoServicioDAO {

    public SqlMapArchivoServicioDAO() {
        super();
    }

    public int countByExample(ArchivoServicioExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t017archivo_serv.countByExample", example);
        return count;
    }

    public int deleteByExample(ArchivoServicioExample example) {
        int rows = getSqlMapClientTemplate().delete("t017archivo_serv.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codArchServ) {
        ArchivoServicio key = new ArchivoServicio();
        key.setCodArchServ(codArchServ);
        int rows = getSqlMapClientTemplate().delete("t017archivo_serv.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(ArchivoServicio record) {
        getSqlMapClientTemplate().insert("t017archivo_serv.insert", record);
    }

    public void insertSelective(ArchivoServicio record) {
        getSqlMapClientTemplate().insert("t017archivo_serv.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<ArchivoServicio> selectByExample(ArchivoServicioExample example) {
        List<ArchivoServicio> list = getSqlMapClientTemplate().queryForList("t017archivo_serv.selectByExample", example);
        return list;
    }

    public ArchivoServicio selectByPrimaryKey(Integer codArchServ) {
        ArchivoServicio key = new ArchivoServicio();
        key.setCodArchServ(codArchServ);
        ArchivoServicio record = (ArchivoServicio) getSqlMapClientTemplate().queryForObject("t017archivo_serv.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(ArchivoServicio record, ArchivoServicioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t017archivo_serv.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(ArchivoServicio record, ArchivoServicioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t017archivo_serv.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(ArchivoServicio record) {
        int rows = getSqlMapClientTemplate().update("t017archivo_serv.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(ArchivoServicio record) {
        int rows = getSqlMapClientTemplate().update("t017archivo_serv.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ArchivoServicioExample {
        private Object record;

        public UpdateByExampleParms(Object record, ArchivoServicioExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}