package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Usuario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.UsuarioExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.UsuarioDAO;

public class SqlMapUsuarioDAO extends SqlMapClientDaoSupport implements UsuarioDAO {

    public SqlMapUsuarioDAO() {
        super();
    }

    public int countByExample(UsuarioExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t009usuario.countByExample", example);
        return count;
    }

    public int deleteByExample(UsuarioExample example) {
        int rows = getSqlMapClientTemplate().delete("t009usuario.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codUsuario) {
        Usuario key = new Usuario();
        key.setCodUsuario(codUsuario);
        int rows = getSqlMapClientTemplate().delete("t009usuario.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Usuario record) {
        getSqlMapClientTemplate().insert("t009usuario.insert", record);
    }

    public void insertSelective(Usuario record) {
        getSqlMapClientTemplate().insert("t009usuario.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Usuario> selectByExample(UsuarioExample example) {
        List<Usuario> list = getSqlMapClientTemplate().queryForList("t009usuario.selectByExample", example);
        return list;
    }

    public Usuario selectByPrimaryKey(Integer codUsuario) {
        Usuario key = new Usuario();
        key.setCodUsuario(codUsuario);
        Usuario record = (Usuario) getSqlMapClientTemplate().queryForObject("t009usuario.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Usuario record, UsuarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t009usuario.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Usuario record, UsuarioExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t009usuario.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Usuario record) {
        int rows = getSqlMapClientTemplate().update("t009usuario.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Usuario record) {
        int rows = getSqlMapClientTemplate().update("t009usuario.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends UsuarioExample {
        private Object record;

        public UpdateByExampleParms(Object record, UsuarioExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}