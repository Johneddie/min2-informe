package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Persona;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.PersonaExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.PersonaDAO;

public class SqlMapPersonaDAO extends SqlMapClientDaoSupport implements PersonaDAO {

    public SqlMapPersonaDAO() {
        super();
    }

    public int countByExample(PersonaExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t001persona.countByExample", example);
        return count;
    }

    public int deleteByExample(PersonaExample example) {
        int rows = getSqlMapClientTemplate().delete("t001persona.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codPersona) {
        Persona key = new Persona();
        key.setCodPersona(codPersona);
        int rows = getSqlMapClientTemplate().delete("t001persona.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Persona record) {
        getSqlMapClientTemplate().insert("t001persona.insert", record);
    }

    public void insertSelective(Persona record) {
        getSqlMapClientTemplate().insert("t001persona.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Persona> selectByExample(PersonaExample example) {
        List<Persona> list = getSqlMapClientTemplate().queryForList("t001persona.selectByExample", example);
        return list;
    }

    public Persona selectByPrimaryKey(Integer codPersona) {
        Persona key = new Persona();
        key.setCodPersona(codPersona);
        Persona record = (Persona) getSqlMapClientTemplate().queryForObject("t001persona.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Persona record, PersonaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t001persona.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Persona record, PersonaExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t001persona.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Persona record) {
        int rows = getSqlMapClientTemplate().update("t001persona.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Persona record) {
        int rows = getSqlMapClientTemplate().update("t001persona.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends PersonaExample {
        private Object record;

        public UpdateByExampleParms(Object record, PersonaExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}