package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Experto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ExpertoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ExpertoDAO;

public class SqlMapExpertoDAO extends SqlMapClientDaoSupport implements ExpertoDAO {

    public SqlMapExpertoDAO() {
        super();
    }

    public int countByExample(ExpertoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t002experto.countByExample", example);
        return count;
    }

    public int deleteByExample(ExpertoExample example) {
        int rows = getSqlMapClientTemplate().delete("t002experto.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codExperto) {
        Experto key = new Experto();
        key.setCodExperto(codExperto);
        int rows = getSqlMapClientTemplate().delete("t002experto.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Experto record) {
        getSqlMapClientTemplate().insert("t002experto.insert", record);
    }

    public void insertSelective(Experto record) {
        getSqlMapClientTemplate().insert("t002experto.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Experto> selectByExample(ExpertoExample example) {
        List<Experto> list = getSqlMapClientTemplate().queryForList("t002experto.selectByExample", example);
        return list;
    }

    public Experto selectByPrimaryKey(Integer codExperto) {
        Experto key = new Experto();
        key.setCodExperto(codExperto);
        Experto record = (Experto) getSqlMapClientTemplate().queryForObject("t002experto.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Experto record, ExpertoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t002experto.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Experto record, ExpertoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t002experto.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Experto record) {
        int rows = getSqlMapClientTemplate().update("t002experto.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Experto record) {
        int rows = getSqlMapClientTemplate().update("t002experto.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ExpertoExample {
        private Object record;

        public UpdateByExampleParms(Object record, ExpertoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}