package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Ubigeo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.UbigeoExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.UbigeoDAO;

public class SqlMapUbigeoDAO extends SqlMapClientDaoSupport implements UbigeoDAO {

    public SqlMapUbigeoDAO() {
        super();
    }

    public int countByExample(UbigeoExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t011ubigeo.countByExample", example);
        return count;
    }

    public int deleteByExample(UbigeoExample example) {
        int rows = getSqlMapClientTemplate().delete("t011ubigeo.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codUbigeo) {
        Ubigeo key = new Ubigeo();
        key.setCodUbigeo(codUbigeo);
        int rows = getSqlMapClientTemplate().delete("t011ubigeo.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Ubigeo record) {
        getSqlMapClientTemplate().insert("t011ubigeo.insert", record);
    }

    public void insertSelective(Ubigeo record) {
        getSqlMapClientTemplate().insert("t011ubigeo.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Ubigeo> selectByExample(UbigeoExample example) {
        List<Ubigeo> list = getSqlMapClientTemplate().queryForList("t011ubigeo.selectByExample", example);
        return list;
    }

    public Ubigeo selectByPrimaryKey(Integer codUbigeo) {
        Ubigeo key = new Ubigeo();
        key.setCodUbigeo(codUbigeo);
        Ubigeo record = (Ubigeo) getSqlMapClientTemplate().queryForObject("t011ubigeo.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Ubigeo record, UbigeoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t011ubigeo.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Ubigeo record, UbigeoExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t011ubigeo.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Ubigeo record) {
        int rows = getSqlMapClientTemplate().update("t011ubigeo.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Ubigeo record) {
        int rows = getSqlMapClientTemplate().update("t011ubigeo.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends UbigeoExample {
        private Object record;

        public UpdateByExampleParms(Object record, UbigeoExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}