package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.Parametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.ParametroExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ParametroDAO;

public class SqlMapParametroDAO extends SqlMapClientDaoSupport implements ParametroDAO {

    public SqlMapParametroDAO() {
        super();
    }

    public int countByExample(ParametroExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t010parametro.countByExample", example);
        return count;
    }

    public int deleteByExample(ParametroExample example) {
        int rows = getSqlMapClientTemplate().delete("t010parametro.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codParam) {
        Parametro key = new Parametro();
        key.setCodParam(codParam);
        int rows = getSqlMapClientTemplate().delete("t010parametro.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(Parametro record) {
        getSqlMapClientTemplate().insert("t010parametro.insert", record);
    }

    public void insertSelective(Parametro record) {
        getSqlMapClientTemplate().insert("t010parametro.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<Parametro> selectByExample(ParametroExample example) {
        List<Parametro> list = getSqlMapClientTemplate().queryForList("t010parametro.selectByExample", example);
        return list;
    }

    public Parametro selectByPrimaryKey(Integer codParam) {
        Parametro key = new Parametro();
        key.setCodParam(codParam);
        Parametro record = (Parametro) getSqlMapClientTemplate().queryForObject("t010parametro.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(Parametro record, ParametroExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t010parametro.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(Parametro record, ParametroExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t010parametro.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(Parametro record) {
        int rows = getSqlMapClientTemplate().update("t010parametro.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(Parametro record) {
        int rows = getSqlMapClientTemplate().update("t010parametro.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends ParametroExample {
        private Object record;

        public UpdateByExampleParms(Object record, ParametroExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}