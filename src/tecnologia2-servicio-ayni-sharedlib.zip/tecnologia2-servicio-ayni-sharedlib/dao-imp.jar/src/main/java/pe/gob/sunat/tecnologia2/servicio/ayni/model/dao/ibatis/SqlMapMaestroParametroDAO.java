package pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ibatis;

import java.util.List;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametroExample;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.MaestroParametroDAO;

public class SqlMapMaestroParametroDAO extends SqlMapClientDaoSupport implements MaestroParametroDAO {

    public SqlMapMaestroParametroDAO() {
        super();
    }

    public int countByExample(MaestroParametroExample example) {
        Integer count = (Integer)  getSqlMapClientTemplate().queryForObject("t012maestro_param.countByExample", example);
        return count;
    }

    public int deleteByExample(MaestroParametroExample example) {
        int rows = getSqlMapClientTemplate().delete("t012maestro_param.deleteByExample", example);
        return rows;
    }

    public int deleteByPrimaryKey(Integer codMaestro) {
        MaestroParametro key = new MaestroParametro();
        key.setCodMaestro(codMaestro);
        int rows = getSqlMapClientTemplate().delete("t012maestro_param.deleteByPrimaryKey", key);
        return rows;
    }

    public void insert(MaestroParametro record) {
        getSqlMapClientTemplate().insert("t012maestro_param.insert", record);
    }

    public void insertSelective(MaestroParametro record) {
        getSqlMapClientTemplate().insert("t012maestro_param.insertSelective", record);
    }

    @SuppressWarnings("unchecked")
    public List<MaestroParametro> selectByExample(MaestroParametroExample example) {
        List<MaestroParametro> list = getSqlMapClientTemplate().queryForList("t012maestro_param.selectByExample", example);
        return list;
    }

    public MaestroParametro selectByPrimaryKey(Integer codMaestro) {
        MaestroParametro key = new MaestroParametro();
        key.setCodMaestro(codMaestro);
        MaestroParametro record = (MaestroParametro) getSqlMapClientTemplate().queryForObject("t012maestro_param.selectByPrimaryKey", key);
        return record;
    }

    public int updateByExampleSelective(MaestroParametro record, MaestroParametroExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t012maestro_param.updateByExampleSelective", parms);
        return rows;
    }

    public int updateByExample(MaestroParametro record, MaestroParametroExample example) {
        UpdateByExampleParms parms = new UpdateByExampleParms(record, example);
        int rows = getSqlMapClientTemplate().update("t012maestro_param.updateByExample", parms);
        return rows;
    }

    public int updateByPrimaryKeySelective(MaestroParametro record) {
        int rows = getSqlMapClientTemplate().update("t012maestro_param.updateByPrimaryKeySelective", record);
        return rows;
    }

    public int updateByPrimaryKey(MaestroParametro record) {
        int rows = getSqlMapClientTemplate().update("t012maestro_param.updateByPrimaryKey", record);
        return rows;
    }

    private static class UpdateByExampleParms extends MaestroParametroExample {
        private Object record;

        public UpdateByExampleParms(Object record, MaestroParametroExample example) {
            super(example);
            this.record = record;
        }

        public Object getRecord() {
            return record;
        }
    }
}