package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotificacionCorreoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public NotificacionCorreoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected NotificacionCorreoExample(NotificacionCorreoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodNotiCorreoIsNull() {
            addCriterion("cod_noti_correo is null");
            return this;
        }

        public Criteria andCodNotiCorreoIsNotNull() {
            addCriterion("cod_noti_correo is not null");
            return this;
        }

        public Criteria andCodNotiCorreoEqualTo(Integer value) {
            addCriterion("cod_noti_correo =", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoNotEqualTo(Integer value) {
            addCriterion("cod_noti_correo <>", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoGreaterThan(Integer value) {
            addCriterion("cod_noti_correo >", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_noti_correo >=", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoLessThan(Integer value) {
            addCriterion("cod_noti_correo <", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoLessThanOrEqualTo(Integer value) {
            addCriterion("cod_noti_correo <=", value, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoIn(List<Integer> values) {
            addCriterion("cod_noti_correo in", values, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoNotIn(List<Integer> values) {
            addCriterion("cod_noti_correo not in", values, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoBetween(Integer value1, Integer value2) {
            addCriterion("cod_noti_correo between", value1, value2, "codNotiCorreo");
            return this;
        }

        public Criteria andCodNotiCorreoNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_noti_correo not between", value1, value2, "codNotiCorreo");
            return this;
        }

        public Criteria andCodPlantillaIsNull() {
            addCriterion("cod_plantilla is null");
            return this;
        }

        public Criteria andCodPlantillaIsNotNull() {
            addCriterion("cod_plantilla is not null");
            return this;
        }

        public Criteria andCodPlantillaEqualTo(Integer value) {
            addCriterion("cod_plantilla =", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaNotEqualTo(Integer value) {
            addCriterion("cod_plantilla <>", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaGreaterThan(Integer value) {
            addCriterion("cod_plantilla >", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_plantilla >=", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaLessThan(Integer value) {
            addCriterion("cod_plantilla <", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaLessThanOrEqualTo(Integer value) {
            addCriterion("cod_plantilla <=", value, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaIn(List<Integer> values) {
            addCriterion("cod_plantilla in", values, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaNotIn(List<Integer> values) {
            addCriterion("cod_plantilla not in", values, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaBetween(Integer value1, Integer value2) {
            addCriterion("cod_plantilla between", value1, value2, "codPlantilla");
            return this;
        }

        public Criteria andCodPlantillaNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_plantilla not between", value1, value2, "codPlantilla");
            return this;
        }

        public Criteria andDesDataIsNull() {
            addCriterion("des_data is null");
            return this;
        }

        public Criteria andDesDataIsNotNull() {
            addCriterion("des_data is not null");
            return this;
        }

        public Criteria andDesDataEqualTo(String value) {
            addCriterion("des_data =", value, "desData");
            return this;
        }

        public Criteria andDesDataNotEqualTo(String value) {
            addCriterion("des_data <>", value, "desData");
            return this;
        }

        public Criteria andDesDataGreaterThan(String value) {
            addCriterion("des_data >", value, "desData");
            return this;
        }

        public Criteria andDesDataGreaterThanOrEqualTo(String value) {
            addCriterion("des_data >=", value, "desData");
            return this;
        }

        public Criteria andDesDataLessThan(String value) {
            addCriterion("des_data <", value, "desData");
            return this;
        }

        public Criteria andDesDataLessThanOrEqualTo(String value) {
            addCriterion("des_data <=", value, "desData");
            return this;
        }

        public Criteria andDesDataLike(String value) {
            addCriterion("des_data like", value, "desData");
            return this;
        }

        public Criteria andDesDataNotLike(String value) {
            addCriterion("des_data not like", value, "desData");
            return this;
        }

        public Criteria andDesDataIn(List<String> values) {
            addCriterion("des_data in", values, "desData");
            return this;
        }

        public Criteria andDesDataNotIn(List<String> values) {
            addCriterion("des_data not in", values, "desData");
            return this;
        }

        public Criteria andDesDataBetween(String value1, String value2) {
            addCriterion("des_data between", value1, value2, "desData");
            return this;
        }

        public Criteria andDesDataNotBetween(String value1, String value2) {
            addCriterion("des_data not between", value1, value2, "desData");
            return this;
        }

        public Criteria andFecEnvioIsNull() {
            addCriterion("fec_envio is null");
            return this;
        }

        public Criteria andFecEnvioIsNotNull() {
            addCriterion("fec_envio is not null");
            return this;
        }

        public Criteria andFecEnvioEqualTo(Date value) {
            addCriterion("fec_envio =", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioNotEqualTo(Date value) {
            addCriterion("fec_envio <>", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioGreaterThan(Date value) {
            addCriterion("fec_envio >", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_envio >=", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioLessThan(Date value) {
            addCriterion("fec_envio <", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioLessThanOrEqualTo(Date value) {
            addCriterion("fec_envio <=", value, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioIn(List<Date> values) {
            addCriterion("fec_envio in", values, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioNotIn(List<Date> values) {
            addCriterion("fec_envio not in", values, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioBetween(Date value1, Date value2) {
            addCriterion("fec_envio between", value1, value2, "fecEnvio");
            return this;
        }

        public Criteria andFecEnvioNotBetween(Date value1, Date value2) {
            addCriterion("fec_envio not between", value1, value2, "fecEnvio");
            return this;
        }

        public Criteria andCodUsuDestIsNull() {
            addCriterion("cod_usu_dest is null");
            return this;
        }

        public Criteria andCodUsuDestIsNotNull() {
            addCriterion("cod_usu_dest is not null");
            return this;
        }

        public Criteria andCodUsuDestEqualTo(Integer value) {
            addCriterion("cod_usu_dest =", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestNotEqualTo(Integer value) {
            addCriterion("cod_usu_dest <>", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestGreaterThan(Integer value) {
            addCriterion("cod_usu_dest >", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_usu_dest >=", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestLessThan(Integer value) {
            addCriterion("cod_usu_dest <", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestLessThanOrEqualTo(Integer value) {
            addCriterion("cod_usu_dest <=", value, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestIn(List<Integer> values) {
            addCriterion("cod_usu_dest in", values, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestNotIn(List<Integer> values) {
            addCriterion("cod_usu_dest not in", values, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestBetween(Integer value1, Integer value2) {
            addCriterion("cod_usu_dest between", value1, value2, "codUsuDest");
            return this;
        }

        public Criteria andCodUsuDestNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_usu_dest not between", value1, value2, "codUsuDest");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}