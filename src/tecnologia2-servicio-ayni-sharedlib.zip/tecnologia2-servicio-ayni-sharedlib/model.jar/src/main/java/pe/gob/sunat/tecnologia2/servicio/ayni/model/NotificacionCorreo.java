package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class NotificacionCorreo {
    private Integer codNotiCorreo;

    private Integer codPlantilla;

    private String desData;

    private Date fecEnvio;

    private Integer codUsuDest;

    private String codEstado;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodNotiCorreo() {
        return codNotiCorreo;
    }

    public void setCodNotiCorreo(Integer codNotiCorreo) {
        this.codNotiCorreo = codNotiCorreo;
    }

    public Integer getCodPlantilla() {
        return codPlantilla;
    }

    public void setCodPlantilla(Integer codPlantilla) {
        this.codPlantilla = codPlantilla;
    }

    public String getDesData() {
        return desData;
    }

    public void setDesData(String desData) {
        this.desData = desData == null ? null : desData.trim();
    }

    public Date getFecEnvio() {
        return fecEnvio;
    }

    public void setFecEnvio(Date fecEnvio) {
        this.fecEnvio = fecEnvio;
    }

    public Integer getCodUsuDest() {
        return codUsuDest;
    }

    public void setCodUsuDest(Integer codUsuDest) {
        this.codUsuDest = codUsuDest;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}