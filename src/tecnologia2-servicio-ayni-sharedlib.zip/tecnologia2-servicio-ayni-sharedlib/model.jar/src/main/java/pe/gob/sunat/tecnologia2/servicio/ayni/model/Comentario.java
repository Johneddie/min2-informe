package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Comentario {
    private Integer codComent;

    private Integer codExperto;

    private String desComent;

    private Integer numCalif;

    private Boolean indActivo;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodComent() {
        return codComent;
    }

    public void setCodComent(Integer codComent) {
        this.codComent = codComent;
    }

    public Integer getCodExperto() {
        return codExperto;
    }

    public void setCodExperto(Integer codExperto) {
        this.codExperto = codExperto;
    }

    public String getDesComent() {
        return desComent;
    }

    public void setDesComent(String desComent) {
        this.desComent = desComent == null ? null : desComent.trim();
    }

    public Integer getNumCalif() {
        return numCalif;
    }

    public void setNumCalif(Integer numCalif) {
        this.numCalif = numCalif;
    }

    public Boolean getIndActivo() {
        return indActivo;
    }

    public void setIndActivo(Boolean indActivo) {
        this.indActivo = indActivo;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}