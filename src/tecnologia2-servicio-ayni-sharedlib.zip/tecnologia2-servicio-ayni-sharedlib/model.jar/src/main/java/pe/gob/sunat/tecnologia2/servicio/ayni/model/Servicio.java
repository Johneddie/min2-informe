package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Servicio {
    private Integer codServicio;

    private Date fecIniServ;

    private Date fecFinServ;

    private Integer codEstado;

    private Integer codExperto;

    private Integer codUsuClien;

    private Integer numCalifClien;

    private String desComent;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodServicio() {
        return codServicio;
    }

    public void setCodServicio(Integer codServicio) {
        this.codServicio = codServicio;
    }

    public Date getFecIniServ() {
        return fecIniServ;
    }

    public void setFecIniServ(Date fecIniServ) {
        this.fecIniServ = fecIniServ;
    }

    public Date getFecFinServ() {
        return fecFinServ;
    }

    public void setFecFinServ(Date fecFinServ) {
        this.fecFinServ = fecFinServ;
    }

    public Integer getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(Integer codEstado) {
        this.codEstado = codEstado;
    }

    public Integer getCodExperto() {
        return codExperto;
    }

    public void setCodExperto(Integer codExperto) {
        this.codExperto = codExperto;
    }

    public Integer getCodUsuClien() {
        return codUsuClien;
    }

    public void setCodUsuClien(Integer codUsuClien) {
        this.codUsuClien = codUsuClien;
    }

    public Integer getNumCalifClien() {
        return numCalifClien;
    }

    public void setNumCalifClien(Integer numCalifClien) {
        this.numCalifClien = numCalifClien;
    }

    public String getDesComent() {
        return desComent;
    }

    public void setDesComent(String desComent) {
        this.desComent = desComent == null ? null : desComent.trim();
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}