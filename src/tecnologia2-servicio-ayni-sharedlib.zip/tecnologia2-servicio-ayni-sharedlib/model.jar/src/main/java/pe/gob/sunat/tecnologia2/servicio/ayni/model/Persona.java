package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.math.BigDecimal;
import java.util.Date;

public class Persona {
    private Integer codPersona;

    private Integer codUsuario;

    private Integer codTipDoc;

    private String numDoc;

    private String desApellidos;

    private String desNombres;

    private Integer codSexo;

    private String desCorreo;

    private String numTelef;

    private Integer codDirUbigeo;

    private String desDireccion;

    private BigDecimal numLatDir;

    private BigDecimal numLonDir;

    private Boolean indActivPosi;

    private Date fecNacim;

    private Boolean indCliente;

    private Boolean indEspec;

    private Boolean indDispon;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodPersona() {
        return codPersona;
    }

    public void setCodPersona(Integer codPersona) {
        this.codPersona = codPersona;
    }

    public Integer getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(Integer codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Integer getCodTipDoc() {
        return codTipDoc;
    }

    public void setCodTipDoc(Integer codTipDoc) {
        this.codTipDoc = codTipDoc;
    }

    public String getNumDoc() {
        return numDoc;
    }

    public void setNumDoc(String numDoc) {
        this.numDoc = numDoc == null ? null : numDoc.trim();
    }

    public String getDesApellidos() {
        return desApellidos;
    }

    public void setDesApellidos(String desApellidos) {
        this.desApellidos = desApellidos == null ? null : desApellidos.trim();
    }

    public String getDesNombres() {
        return desNombres;
    }

    public void setDesNombres(String desNombres) {
        this.desNombres = desNombres == null ? null : desNombres.trim();
    }

    public Integer getCodSexo() {
        return codSexo;
    }

    public void setCodSexo(Integer codSexo) {
        this.codSexo = codSexo;
    }

    public String getDesCorreo() {
        return desCorreo;
    }

    public void setDesCorreo(String desCorreo) {
        this.desCorreo = desCorreo == null ? null : desCorreo.trim();
    }

    public String getNumTelef() {
        return numTelef;
    }

    public void setNumTelef(String numTelef) {
        this.numTelef = numTelef == null ? null : numTelef.trim();
    }

    public Integer getCodDirUbigeo() {
        return codDirUbigeo;
    }

    public void setCodDirUbigeo(Integer codDirUbigeo) {
        this.codDirUbigeo = codDirUbigeo;
    }

    public String getDesDireccion() {
        return desDireccion;
    }

    public void setDesDireccion(String desDireccion) {
        this.desDireccion = desDireccion == null ? null : desDireccion.trim();
    }

    public BigDecimal getNumLatDir() {
        return numLatDir;
    }

    public void setNumLatDir(BigDecimal numLatDir) {
        this.numLatDir = numLatDir;
    }

    public BigDecimal getNumLonDir() {
        return numLonDir;
    }

    public void setNumLonDir(BigDecimal numLonDir) {
        this.numLonDir = numLonDir;
    }

    public Boolean getIndActivPosi() {
        return indActivPosi;
    }

    public void setIndActivPosi(Boolean indActivPosi) {
        this.indActivPosi = indActivPosi;
    }

    public Date getFecNacim() {
        return fecNacim;
    }

    public void setFecNacim(Date fecNacim) {
        this.fecNacim = fecNacim;
    }

    public Boolean getIndCliente() {
        return indCliente;
    }

    public void setIndCliente(Boolean indCliente) {
        this.indCliente = indCliente;
    }

    public Boolean getIndEspec() {
        return indEspec;
    }

    public void setIndEspec(Boolean indEspec) {
        this.indEspec = indEspec;
    }

    public Boolean getIndDispon() {
        return indDispon;
    }

    public void setIndDispon(Boolean indDispon) {
        this.indDispon = indDispon;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}