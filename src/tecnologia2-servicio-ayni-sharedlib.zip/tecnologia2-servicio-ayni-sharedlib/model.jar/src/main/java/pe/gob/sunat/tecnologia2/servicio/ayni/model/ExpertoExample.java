package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpertoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ExpertoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected ExpertoExample(ExpertoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodExpertoIsNull() {
            addCriterion("cod_experto is null");
            return this;
        }

        public Criteria andCodExpertoIsNotNull() {
            addCriterion("cod_experto is not null");
            return this;
        }

        public Criteria andCodExpertoEqualTo(Integer value) {
            addCriterion("cod_experto =", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoNotEqualTo(Integer value) {
            addCriterion("cod_experto <>", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoGreaterThan(Integer value) {
            addCriterion("cod_experto >", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_experto >=", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoLessThan(Integer value) {
            addCriterion("cod_experto <", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoLessThanOrEqualTo(Integer value) {
            addCriterion("cod_experto <=", value, "codExperto");
            return this;
        }

        public Criteria andCodExpertoIn(List<Integer> values) {
            addCriterion("cod_experto in", values, "codExperto");
            return this;
        }

        public Criteria andCodExpertoNotIn(List<Integer> values) {
            addCriterion("cod_experto not in", values, "codExperto");
            return this;
        }

        public Criteria andCodExpertoBetween(Integer value1, Integer value2) {
            addCriterion("cod_experto between", value1, value2, "codExperto");
            return this;
        }

        public Criteria andCodExpertoNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_experto not between", value1, value2, "codExperto");
            return this;
        }

        public Criteria andCodPersonaIsNull() {
            addCriterion("cod_persona is null");
            return this;
        }

        public Criteria andCodPersonaIsNotNull() {
            addCriterion("cod_persona is not null");
            return this;
        }

        public Criteria andCodPersonaEqualTo(Integer value) {
            addCriterion("cod_persona =", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotEqualTo(Integer value) {
            addCriterion("cod_persona <>", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaGreaterThan(Integer value) {
            addCriterion("cod_persona >", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_persona >=", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaLessThan(Integer value) {
            addCriterion("cod_persona <", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaLessThanOrEqualTo(Integer value) {
            addCriterion("cod_persona <=", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaIn(List<Integer> values) {
            addCriterion("cod_persona in", values, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotIn(List<Integer> values) {
            addCriterion("cod_persona not in", values, "codPersona");
            return this;
        }

        public Criteria andCodPersonaBetween(Integer value1, Integer value2) {
            addCriterion("cod_persona between", value1, value2, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_persona not between", value1, value2, "codPersona");
            return this;
        }

        public Criteria andCodEspecIsNull() {
            addCriterion("cod_espec is null");
            return this;
        }

        public Criteria andCodEspecIsNotNull() {
            addCriterion("cod_espec is not null");
            return this;
        }

        public Criteria andCodEspecEqualTo(Integer value) {
            addCriterion("cod_espec =", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecNotEqualTo(Integer value) {
            addCriterion("cod_espec <>", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecGreaterThan(Integer value) {
            addCriterion("cod_espec >", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_espec >=", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecLessThan(Integer value) {
            addCriterion("cod_espec <", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecLessThanOrEqualTo(Integer value) {
            addCriterion("cod_espec <=", value, "codEspec");
            return this;
        }

        public Criteria andCodEspecIn(List<Integer> values) {
            addCriterion("cod_espec in", values, "codEspec");
            return this;
        }

        public Criteria andCodEspecNotIn(List<Integer> values) {
            addCriterion("cod_espec not in", values, "codEspec");
            return this;
        }

        public Criteria andCodEspecBetween(Integer value1, Integer value2) {
            addCriterion("cod_espec between", value1, value2, "codEspec");
            return this;
        }

        public Criteria andCodEspecNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_espec not between", value1, value2, "codEspec");
            return this;
        }

        public Criteria andDesResumenIsNull() {
            addCriterion("des_resumen is null");
            return this;
        }

        public Criteria andDesResumenIsNotNull() {
            addCriterion("des_resumen is not null");
            return this;
        }

        public Criteria andDesResumenEqualTo(String value) {
            addCriterion("des_resumen =", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenNotEqualTo(String value) {
            addCriterion("des_resumen <>", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenGreaterThan(String value) {
            addCriterion("des_resumen >", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenGreaterThanOrEqualTo(String value) {
            addCriterion("des_resumen >=", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenLessThan(String value) {
            addCriterion("des_resumen <", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenLessThanOrEqualTo(String value) {
            addCriterion("des_resumen <=", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenLike(String value) {
            addCriterion("des_resumen like", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenNotLike(String value) {
            addCriterion("des_resumen not like", value, "desResumen");
            return this;
        }

        public Criteria andDesResumenIn(List<String> values) {
            addCriterion("des_resumen in", values, "desResumen");
            return this;
        }

        public Criteria andDesResumenNotIn(List<String> values) {
            addCriterion("des_resumen not in", values, "desResumen");
            return this;
        }

        public Criteria andDesResumenBetween(String value1, String value2) {
            addCriterion("des_resumen between", value1, value2, "desResumen");
            return this;
        }

        public Criteria andDesResumenNotBetween(String value1, String value2) {
            addCriterion("des_resumen not between", value1, value2, "desResumen");
            return this;
        }

        public Criteria andDesDetalleIsNull() {
            addCriterion("des_detalle is null");
            return this;
        }

        public Criteria andDesDetalleIsNotNull() {
            addCriterion("des_detalle is not null");
            return this;
        }

        public Criteria andDesDetalleEqualTo(String value) {
            addCriterion("des_detalle =", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleNotEqualTo(String value) {
            addCriterion("des_detalle <>", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleGreaterThan(String value) {
            addCriterion("des_detalle >", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleGreaterThanOrEqualTo(String value) {
            addCriterion("des_detalle >=", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleLessThan(String value) {
            addCriterion("des_detalle <", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleLessThanOrEqualTo(String value) {
            addCriterion("des_detalle <=", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleLike(String value) {
            addCriterion("des_detalle like", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleNotLike(String value) {
            addCriterion("des_detalle not like", value, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleIn(List<String> values) {
            addCriterion("des_detalle in", values, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleNotIn(List<String> values) {
            addCriterion("des_detalle not in", values, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleBetween(String value1, String value2) {
            addCriterion("des_detalle between", value1, value2, "desDetalle");
            return this;
        }

        public Criteria andDesDetalleNotBetween(String value1, String value2) {
            addCriterion("des_detalle not between", value1, value2, "desDetalle");
            return this;
        }

        public Criteria andIndDisponIsNull() {
            addCriterion("ind_dispon is null");
            return this;
        }

        public Criteria andIndDisponIsNotNull() {
            addCriterion("ind_dispon is not null");
            return this;
        }

        public Criteria andIndDisponEqualTo(Boolean value) {
            addCriterion("ind_dispon =", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotEqualTo(Boolean value) {
            addCriterion("ind_dispon <>", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponGreaterThan(Boolean value) {
            addCriterion("ind_dispon >", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_dispon >=", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponLessThan(Boolean value) {
            addCriterion("ind_dispon <", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_dispon <=", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponIn(List<Boolean> values) {
            addCriterion("ind_dispon in", values, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotIn(List<Boolean> values) {
            addCriterion("ind_dispon not in", values, "indDispon");
            return this;
        }

        public Criteria andIndDisponBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_dispon between", value1, value2, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_dispon not between", value1, value2, "indDispon");
            return this;
        }

        public Criteria andIndActivoIsNull() {
            addCriterion("ind_activo is null");
            return this;
        }

        public Criteria andIndActivoIsNotNull() {
            addCriterion("ind_activo is not null");
            return this;
        }

        public Criteria andIndActivoEqualTo(Boolean value) {
            addCriterion("ind_activo =", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoNotEqualTo(Boolean value) {
            addCriterion("ind_activo <>", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoGreaterThan(Boolean value) {
            addCriterion("ind_activo >", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_activo >=", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoLessThan(Boolean value) {
            addCriterion("ind_activo <", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_activo <=", value, "indActivo");
            return this;
        }

        public Criteria andIndActivoIn(List<Boolean> values) {
            addCriterion("ind_activo in", values, "indActivo");
            return this;
        }

        public Criteria andIndActivoNotIn(List<Boolean> values) {
            addCriterion("ind_activo not in", values, "indActivo");
            return this;
        }

        public Criteria andIndActivoBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_activo between", value1, value2, "indActivo");
            return this;
        }

        public Criteria andIndActivoNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_activo not between", value1, value2, "indActivo");
            return this;
        }

        public Criteria andIndElimIsNull() {
            addCriterion("ind_elim is null");
            return this;
        }

        public Criteria andIndElimIsNotNull() {
            addCriterion("ind_elim is not null");
            return this;
        }

        public Criteria andIndElimEqualTo(Boolean value) {
            addCriterion("ind_elim =", value, "indElim");
            return this;
        }

        public Criteria andIndElimNotEqualTo(Boolean value) {
            addCriterion("ind_elim <>", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThan(Boolean value) {
            addCriterion("ind_elim >", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim >=", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThan(Boolean value) {
            addCriterion("ind_elim <", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim <=", value, "indElim");
            return this;
        }

        public Criteria andIndElimIn(List<Boolean> values) {
            addCriterion("ind_elim in", values, "indElim");
            return this;
        }

        public Criteria andIndElimNotIn(List<Boolean> values) {
            addCriterion("ind_elim not in", values, "indElim");
            return this;
        }

        public Criteria andIndElimBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim between", value1, value2, "indElim");
            return this;
        }

        public Criteria andIndElimNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim not between", value1, value2, "indElim");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}