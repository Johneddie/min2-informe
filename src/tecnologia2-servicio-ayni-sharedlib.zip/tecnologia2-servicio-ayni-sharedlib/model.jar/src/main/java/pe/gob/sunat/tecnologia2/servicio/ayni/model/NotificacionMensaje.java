package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class NotificacionMensaje {
    private Integer codNotimensaje;

    private Integer codMensaje;

    private Integer codNotiCorreo;

    private Boolean indAtendido;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodNotimensaje() {
        return codNotimensaje;
    }

    public void setCodNotimensaje(Integer codNotimensaje) {
        this.codNotimensaje = codNotimensaje;
    }

    public Integer getCodMensaje() {
        return codMensaje;
    }

    public void setCodMensaje(Integer codMensaje) {
        this.codMensaje = codMensaje;
    }

    public Integer getCodNotiCorreo() {
        return codNotiCorreo;
    }

    public void setCodNotiCorreo(Integer codNotiCorreo) {
        this.codNotiCorreo = codNotiCorreo;
    }

    public Boolean getIndAtendido() {
        return indAtendido;
    }

    public void setIndAtendido(Boolean indAtendido) {
        this.indAtendido = indAtendido;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}