package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.math.BigDecimal;
import java.util.Date;

public class Sesion {
    private Integer codSesion;

    private Integer codUsuario;

    private Integer codTipDisp;

    private Date fecIniSes;

    private BigDecimal numLati;

    private BigDecimal numLong;

    private String numIp;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodSesion() {
        return codSesion;
    }

    public void setCodSesion(Integer codSesion) {
        this.codSesion = codSesion;
    }

    public Integer getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(Integer codUsuario) {
        this.codUsuario = codUsuario;
    }

    public Integer getCodTipDisp() {
        return codTipDisp;
    }

    public void setCodTipDisp(Integer codTipDisp) {
        this.codTipDisp = codTipDisp;
    }

    public Date getFecIniSes() {
        return fecIniSes;
    }

    public void setFecIniSes(Date fecIniSes) {
        this.fecIniSes = fecIniSes;
    }

    public BigDecimal getNumLati() {
        return numLati;
    }

    public void setNumLati(BigDecimal numLati) {
        this.numLati = numLati;
    }

    public BigDecimal getNumLong() {
        return numLong;
    }

    public void setNumLong(BigDecimal numLong) {
        this.numLong = numLong;
    }

    public String getNumIp() {
        return numIp;
    }

    public void setNumIp(String numIp) {
        this.numIp = numIp == null ? null : numIp.trim();
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}