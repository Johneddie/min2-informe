package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class ArchivoExperto {
    private Integer codArchExpert;

    private Integer codExperto;

    private Integer codArchivo;

    private Boolean indActivo;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodArchExpert() {
        return codArchExpert;
    }

    public void setCodArchExpert(Integer codArchExpert) {
        this.codArchExpert = codArchExpert;
    }

    public Integer getCodExperto() {
        return codExperto;
    }

    public void setCodExperto(Integer codExperto) {
        this.codExperto = codExperto;
    }

    public Integer getCodArchivo() {
        return codArchivo;
    }

    public void setCodArchivo(Integer codArchivo) {
        this.codArchivo = codArchivo;
    }

    public Boolean getIndActivo() {
        return indActivo;
    }

    public void setIndActivo(Boolean indActivo) {
        this.indActivo = indActivo;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}