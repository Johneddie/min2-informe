package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Usuario {
    private Integer codUsuario;

    private String desCorreo;

    private String numTelef;

    private Integer numToken;

    private Date fecGenToken;

    private String desPass;

    private String codEstado;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodUsuario() {
        return codUsuario;
    }

    public void setCodUsuario(Integer codUsuario) {
        this.codUsuario = codUsuario;
    }

    public String getDesCorreo() {
        return desCorreo;
    }

    public void setDesCorreo(String desCorreo) {
        this.desCorreo = desCorreo == null ? null : desCorreo.trim();
    }

    public String getNumTelef() {
        return numTelef;
    }

    public void setNumTelef(String numTelef) {
        this.numTelef = numTelef == null ? null : numTelef.trim();
    }

    public Integer getNumToken() {
        return numToken;
    }

    public void setNumToken(Integer numToken) {
        this.numToken = numToken;
    }

    public Date getFecGenToken() {
        return fecGenToken;
    }

    public void setFecGenToken(Date fecGenToken) {
        this.fecGenToken = fecGenToken;
    }

    public String getDesPass() {
        return desPass;
    }

    public void setDesPass(String desPass) {
        this.desPass = desPass == null ? null : desPass.trim();
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}