package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SesionExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public SesionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected SesionExample(SesionExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodSesionIsNull() {
            addCriterion("cod_sesion is null");
            return this;
        }

        public Criteria andCodSesionIsNotNull() {
            addCriterion("cod_sesion is not null");
            return this;
        }

        public Criteria andCodSesionEqualTo(Integer value) {
            addCriterion("cod_sesion =", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionNotEqualTo(Integer value) {
            addCriterion("cod_sesion <>", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionGreaterThan(Integer value) {
            addCriterion("cod_sesion >", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_sesion >=", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionLessThan(Integer value) {
            addCriterion("cod_sesion <", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionLessThanOrEqualTo(Integer value) {
            addCriterion("cod_sesion <=", value, "codSesion");
            return this;
        }

        public Criteria andCodSesionIn(List<Integer> values) {
            addCriterion("cod_sesion in", values, "codSesion");
            return this;
        }

        public Criteria andCodSesionNotIn(List<Integer> values) {
            addCriterion("cod_sesion not in", values, "codSesion");
            return this;
        }

        public Criteria andCodSesionBetween(Integer value1, Integer value2) {
            addCriterion("cod_sesion between", value1, value2, "codSesion");
            return this;
        }

        public Criteria andCodSesionNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_sesion not between", value1, value2, "codSesion");
            return this;
        }

        public Criteria andCodUsuarioIsNull() {
            addCriterion("cod_usuario is null");
            return this;
        }

        public Criteria andCodUsuarioIsNotNull() {
            addCriterion("cod_usuario is not null");
            return this;
        }

        public Criteria andCodUsuarioEqualTo(Integer value) {
            addCriterion("cod_usuario =", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotEqualTo(Integer value) {
            addCriterion("cod_usuario <>", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThan(Integer value) {
            addCriterion("cod_usuario >", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario >=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThan(Integer value) {
            addCriterion("cod_usuario <", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario <=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioIn(List<Integer> values) {
            addCriterion("cod_usuario in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotIn(List<Integer> values) {
            addCriterion("cod_usuario not in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario not between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andCodTipDispIsNull() {
            addCriterion("cod_tip_disp is null");
            return this;
        }

        public Criteria andCodTipDispIsNotNull() {
            addCriterion("cod_tip_disp is not null");
            return this;
        }

        public Criteria andCodTipDispEqualTo(Integer value) {
            addCriterion("cod_tip_disp =", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispNotEqualTo(Integer value) {
            addCriterion("cod_tip_disp <>", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispGreaterThan(Integer value) {
            addCriterion("cod_tip_disp >", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_tip_disp >=", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispLessThan(Integer value) {
            addCriterion("cod_tip_disp <", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispLessThanOrEqualTo(Integer value) {
            addCriterion("cod_tip_disp <=", value, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispIn(List<Integer> values) {
            addCriterion("cod_tip_disp in", values, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispNotIn(List<Integer> values) {
            addCriterion("cod_tip_disp not in", values, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispBetween(Integer value1, Integer value2) {
            addCriterion("cod_tip_disp between", value1, value2, "codTipDisp");
            return this;
        }

        public Criteria andCodTipDispNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_tip_disp not between", value1, value2, "codTipDisp");
            return this;
        }

        public Criteria andFecIniSesIsNull() {
            addCriterion("fec_ini_ses is null");
            return this;
        }

        public Criteria andFecIniSesIsNotNull() {
            addCriterion("fec_ini_ses is not null");
            return this;
        }

        public Criteria andFecIniSesEqualTo(Date value) {
            addCriterion("fec_ini_ses =", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesNotEqualTo(Date value) {
            addCriterion("fec_ini_ses <>", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesGreaterThan(Date value) {
            addCriterion("fec_ini_ses >", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_ini_ses >=", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesLessThan(Date value) {
            addCriterion("fec_ini_ses <", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesLessThanOrEqualTo(Date value) {
            addCriterion("fec_ini_ses <=", value, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesIn(List<Date> values) {
            addCriterion("fec_ini_ses in", values, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesNotIn(List<Date> values) {
            addCriterion("fec_ini_ses not in", values, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesBetween(Date value1, Date value2) {
            addCriterion("fec_ini_ses between", value1, value2, "fecIniSes");
            return this;
        }

        public Criteria andFecIniSesNotBetween(Date value1, Date value2) {
            addCriterion("fec_ini_ses not between", value1, value2, "fecIniSes");
            return this;
        }

        public Criteria andNumLatiIsNull() {
            addCriterion("num_lati is null");
            return this;
        }

        public Criteria andNumLatiIsNotNull() {
            addCriterion("num_lati is not null");
            return this;
        }

        public Criteria andNumLatiEqualTo(BigDecimal value) {
            addCriterion("num_lati =", value, "numLati");
            return this;
        }

        public Criteria andNumLatiNotEqualTo(BigDecimal value) {
            addCriterion("num_lati <>", value, "numLati");
            return this;
        }

        public Criteria andNumLatiGreaterThan(BigDecimal value) {
            addCriterion("num_lati >", value, "numLati");
            return this;
        }

        public Criteria andNumLatiGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lati >=", value, "numLati");
            return this;
        }

        public Criteria andNumLatiLessThan(BigDecimal value) {
            addCriterion("num_lati <", value, "numLati");
            return this;
        }

        public Criteria andNumLatiLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lati <=", value, "numLati");
            return this;
        }

        public Criteria andNumLatiIn(List<BigDecimal> values) {
            addCriterion("num_lati in", values, "numLati");
            return this;
        }

        public Criteria andNumLatiNotIn(List<BigDecimal> values) {
            addCriterion("num_lati not in", values, "numLati");
            return this;
        }

        public Criteria andNumLatiBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lati between", value1, value2, "numLati");
            return this;
        }

        public Criteria andNumLatiNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lati not between", value1, value2, "numLati");
            return this;
        }

        public Criteria andNumLongIsNull() {
            addCriterion("num_long is null");
            return this;
        }

        public Criteria andNumLongIsNotNull() {
            addCriterion("num_long is not null");
            return this;
        }

        public Criteria andNumLongEqualTo(BigDecimal value) {
            addCriterion("num_long =", value, "numLong");
            return this;
        }

        public Criteria andNumLongNotEqualTo(BigDecimal value) {
            addCriterion("num_long <>", value, "numLong");
            return this;
        }

        public Criteria andNumLongGreaterThan(BigDecimal value) {
            addCriterion("num_long >", value, "numLong");
            return this;
        }

        public Criteria andNumLongGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_long >=", value, "numLong");
            return this;
        }

        public Criteria andNumLongLessThan(BigDecimal value) {
            addCriterion("num_long <", value, "numLong");
            return this;
        }

        public Criteria andNumLongLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_long <=", value, "numLong");
            return this;
        }

        public Criteria andNumLongIn(List<BigDecimal> values) {
            addCriterion("num_long in", values, "numLong");
            return this;
        }

        public Criteria andNumLongNotIn(List<BigDecimal> values) {
            addCriterion("num_long not in", values, "numLong");
            return this;
        }

        public Criteria andNumLongBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_long between", value1, value2, "numLong");
            return this;
        }

        public Criteria andNumLongNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_long not between", value1, value2, "numLong");
            return this;
        }

        public Criteria andNumIpIsNull() {
            addCriterion("num_ip is null");
            return this;
        }

        public Criteria andNumIpIsNotNull() {
            addCriterion("num_ip is not null");
            return this;
        }

        public Criteria andNumIpEqualTo(String value) {
            addCriterion("num_ip =", value, "numIp");
            return this;
        }

        public Criteria andNumIpNotEqualTo(String value) {
            addCriterion("num_ip <>", value, "numIp");
            return this;
        }

        public Criteria andNumIpGreaterThan(String value) {
            addCriterion("num_ip >", value, "numIp");
            return this;
        }

        public Criteria andNumIpGreaterThanOrEqualTo(String value) {
            addCriterion("num_ip >=", value, "numIp");
            return this;
        }

        public Criteria andNumIpLessThan(String value) {
            addCriterion("num_ip <", value, "numIp");
            return this;
        }

        public Criteria andNumIpLessThanOrEqualTo(String value) {
            addCriterion("num_ip <=", value, "numIp");
            return this;
        }

        public Criteria andNumIpLike(String value) {
            addCriterion("num_ip like", value, "numIp");
            return this;
        }

        public Criteria andNumIpNotLike(String value) {
            addCriterion("num_ip not like", value, "numIp");
            return this;
        }

        public Criteria andNumIpIn(List<String> values) {
            addCriterion("num_ip in", values, "numIp");
            return this;
        }

        public Criteria andNumIpNotIn(List<String> values) {
            addCriterion("num_ip not in", values, "numIp");
            return this;
        }

        public Criteria andNumIpBetween(String value1, String value2) {
            addCriterion("num_ip between", value1, value2, "numIp");
            return this;
        }

        public Criteria andNumIpNotBetween(String value1, String value2) {
            addCriterion("num_ip not between", value1, value2, "numIp");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}