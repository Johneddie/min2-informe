package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Archivo {
    private Integer codArchivo;

    private String codTipArchivo;

    private String desNomArchivo;

    private String codEstado;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    private byte[] datArchivo;

    public Integer getCodArchivo() {
        return codArchivo;
    }

    public void setCodArchivo(Integer codArchivo) {
        this.codArchivo = codArchivo;
    }

    public String getCodTipArchivo() {
        return codTipArchivo;
    }

    public void setCodTipArchivo(String codTipArchivo) {
        this.codTipArchivo = codTipArchivo == null ? null : codTipArchivo.trim();
    }

    public String getDesNomArchivo() {
        return desNomArchivo;
    }

    public void setDesNomArchivo(String desNomArchivo) {
        this.desNomArchivo = desNomArchivo == null ? null : desNomArchivo.trim();
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }

    public byte[] getDatArchivo() {
        return datArchivo;
    }

    public void setDatArchivo(byte[] datArchivo) {
        this.datArchivo = datArchivo;
    }
}