package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArchivoExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public ArchivoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected ArchivoExample(ArchivoExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodArchivoIsNull() {
            addCriterion("cod_archivo is null");
            return this;
        }

        public Criteria andCodArchivoIsNotNull() {
            addCriterion("cod_archivo is not null");
            return this;
        }

        public Criteria andCodArchivoEqualTo(Integer value) {
            addCriterion("cod_archivo =", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoNotEqualTo(Integer value) {
            addCriterion("cod_archivo <>", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoGreaterThan(Integer value) {
            addCriterion("cod_archivo >", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_archivo >=", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoLessThan(Integer value) {
            addCriterion("cod_archivo <", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoLessThanOrEqualTo(Integer value) {
            addCriterion("cod_archivo <=", value, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoIn(List<Integer> values) {
            addCriterion("cod_archivo in", values, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoNotIn(List<Integer> values) {
            addCriterion("cod_archivo not in", values, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoBetween(Integer value1, Integer value2) {
            addCriterion("cod_archivo between", value1, value2, "codArchivo");
            return this;
        }

        public Criteria andCodArchivoNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_archivo not between", value1, value2, "codArchivo");
            return this;
        }

        public Criteria andCodTipArchivoIsNull() {
            addCriterion("cod_tip_archivo is null");
            return this;
        }

        public Criteria andCodTipArchivoIsNotNull() {
            addCriterion("cod_tip_archivo is not null");
            return this;
        }

        public Criteria andCodTipArchivoEqualTo(String value) {
            addCriterion("cod_tip_archivo =", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoNotEqualTo(String value) {
            addCriterion("cod_tip_archivo <>", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoGreaterThan(String value) {
            addCriterion("cod_tip_archivo >", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_tip_archivo >=", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoLessThan(String value) {
            addCriterion("cod_tip_archivo <", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoLessThanOrEqualTo(String value) {
            addCriterion("cod_tip_archivo <=", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoLike(String value) {
            addCriterion("cod_tip_archivo like", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoNotLike(String value) {
            addCriterion("cod_tip_archivo not like", value, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoIn(List<String> values) {
            addCriterion("cod_tip_archivo in", values, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoNotIn(List<String> values) {
            addCriterion("cod_tip_archivo not in", values, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoBetween(String value1, String value2) {
            addCriterion("cod_tip_archivo between", value1, value2, "codTipArchivo");
            return this;
        }

        public Criteria andCodTipArchivoNotBetween(String value1, String value2) {
            addCriterion("cod_tip_archivo not between", value1, value2, "codTipArchivo");
            return this;
        }

        public Criteria andDesNomArchivoIsNull() {
            addCriterion("des_nom_archivo is null");
            return this;
        }

        public Criteria andDesNomArchivoIsNotNull() {
            addCriterion("des_nom_archivo is not null");
            return this;
        }

        public Criteria andDesNomArchivoEqualTo(String value) {
            addCriterion("des_nom_archivo =", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoNotEqualTo(String value) {
            addCriterion("des_nom_archivo <>", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoGreaterThan(String value) {
            addCriterion("des_nom_archivo >", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoGreaterThanOrEqualTo(String value) {
            addCriterion("des_nom_archivo >=", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoLessThan(String value) {
            addCriterion("des_nom_archivo <", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoLessThanOrEqualTo(String value) {
            addCriterion("des_nom_archivo <=", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoLike(String value) {
            addCriterion("des_nom_archivo like", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoNotLike(String value) {
            addCriterion("des_nom_archivo not like", value, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoIn(List<String> values) {
            addCriterion("des_nom_archivo in", values, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoNotIn(List<String> values) {
            addCriterion("des_nom_archivo not in", values, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoBetween(String value1, String value2) {
            addCriterion("des_nom_archivo between", value1, value2, "desNomArchivo");
            return this;
        }

        public Criteria andDesNomArchivoNotBetween(String value1, String value2) {
            addCriterion("des_nom_archivo not between", value1, value2, "desNomArchivo");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andIndElimIsNull() {
            addCriterion("ind_elim is null");
            return this;
        }

        public Criteria andIndElimIsNotNull() {
            addCriterion("ind_elim is not null");
            return this;
        }

        public Criteria andIndElimEqualTo(Boolean value) {
            addCriterion("ind_elim =", value, "indElim");
            return this;
        }

        public Criteria andIndElimNotEqualTo(Boolean value) {
            addCriterion("ind_elim <>", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThan(Boolean value) {
            addCriterion("ind_elim >", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim >=", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThan(Boolean value) {
            addCriterion("ind_elim <", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim <=", value, "indElim");
            return this;
        }

        public Criteria andIndElimIn(List<Boolean> values) {
            addCriterion("ind_elim in", values, "indElim");
            return this;
        }

        public Criteria andIndElimNotIn(List<Boolean> values) {
            addCriterion("ind_elim not in", values, "indElim");
            return this;
        }

        public Criteria andIndElimBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim between", value1, value2, "indElim");
            return this;
        }

        public Criteria andIndElimNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim not between", value1, value2, "indElim");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}