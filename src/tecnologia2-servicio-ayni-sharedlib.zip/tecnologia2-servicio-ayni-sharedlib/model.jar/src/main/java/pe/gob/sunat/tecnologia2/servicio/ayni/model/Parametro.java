package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Parametro {
    private Integer codParam;

    private Integer codMaestro;

    private String desParam;

    private String desAbrev;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodParam() {
        return codParam;
    }

    public void setCodParam(Integer codParam) {
        this.codParam = codParam;
    }

    public Integer getCodMaestro() {
        return codMaestro;
    }

    public void setCodMaestro(Integer codMaestro) {
        this.codMaestro = codMaestro;
    }

    public String getDesParam() {
        return desParam;
    }

    public void setDesParam(String desParam) {
        this.desParam = desParam == null ? null : desParam.trim();
    }

    public String getDesAbrev() {
        return desAbrev;
    }

    public void setDesAbrev(String desAbrev) {
        this.desAbrev = desAbrev == null ? null : desAbrev.trim();
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}