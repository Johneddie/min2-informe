package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Experto {
    private Integer codExperto;

    private Integer codPersona;

    private Integer codEspec;

    private String desResumen;

    private String desDetalle;

    private Boolean indDispon;

    private Boolean indActivo;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodExperto() {
        return codExperto;
    }

    public void setCodExperto(Integer codExperto) {
        this.codExperto = codExperto;
    }

    public Integer getCodPersona() {
        return codPersona;
    }

    public void setCodPersona(Integer codPersona) {
        this.codPersona = codPersona;
    }

    public Integer getCodEspec() {
        return codEspec;
    }

    public void setCodEspec(Integer codEspec) {
        this.codEspec = codEspec;
    }

    public String getDesResumen() {
        return desResumen;
    }

    public void setDesResumen(String desResumen) {
        this.desResumen = desResumen == null ? null : desResumen.trim();
    }

    public String getDesDetalle() {
        return desDetalle;
    }

    public void setDesDetalle(String desDetalle) {
        this.desDetalle = desDetalle == null ? null : desDetalle.trim();
    }

    public Boolean getIndDispon() {
        return indDispon;
    }

    public void setIndDispon(Boolean indDispon) {
        this.indDispon = indDispon;
    }

    public Boolean getIndActivo() {
        return indActivo;
    }

    public void setIndActivo(Boolean indActivo) {
        this.indActivo = indActivo;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}