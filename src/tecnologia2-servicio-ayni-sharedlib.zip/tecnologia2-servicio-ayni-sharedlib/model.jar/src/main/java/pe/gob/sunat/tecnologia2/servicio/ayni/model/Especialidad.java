package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Especialidad {
    private Integer codEspec;

    private String desNomEspec;

    private String desEspec;

    private Boolean indActivo;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodEspec() {
        return codEspec;
    }

    public void setCodEspec(Integer codEspec) {
        this.codEspec = codEspec;
    }

    public String getDesNomEspec() {
        return desNomEspec;
    }

    public void setDesNomEspec(String desNomEspec) {
        this.desNomEspec = desNomEspec == null ? null : desNomEspec.trim();
    }

    public String getDesEspec() {
        return desEspec;
    }

    public void setDesEspec(String desEspec) {
        this.desEspec = desEspec == null ? null : desEspec.trim();
    }

    public Boolean getIndActivo() {
        return indActivo;
    }

    public void setIndActivo(Boolean indActivo) {
        this.indActivo = indActivo;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}