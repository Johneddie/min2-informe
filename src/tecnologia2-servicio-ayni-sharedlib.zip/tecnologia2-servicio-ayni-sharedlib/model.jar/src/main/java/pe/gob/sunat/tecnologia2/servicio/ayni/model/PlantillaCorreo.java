package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class PlantillaCorreo {
    private Integer codPlantilla;

    private String desAsunto;

    private String desCuerpo;

    private Integer codEstado;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodPlantilla() {
        return codPlantilla;
    }

    public void setCodPlantilla(Integer codPlantilla) {
        this.codPlantilla = codPlantilla;
    }

    public String getDesAsunto() {
        return desAsunto;
    }

    public void setDesAsunto(String desAsunto) {
        this.desAsunto = desAsunto == null ? null : desAsunto.trim();
    }

    public String getDesCuerpo() {
        return desCuerpo;
    }

    public void setDesCuerpo(String desCuerpo) {
        this.desCuerpo = desCuerpo == null ? null : desCuerpo.trim();
    }

    public Integer getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(Integer codEstado) {
        this.codEstado = codEstado;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}