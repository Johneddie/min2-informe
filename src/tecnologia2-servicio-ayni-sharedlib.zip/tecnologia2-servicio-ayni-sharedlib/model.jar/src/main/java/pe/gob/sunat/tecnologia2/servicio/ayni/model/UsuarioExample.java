package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public UsuarioExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected UsuarioExample(UsuarioExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodUsuarioIsNull() {
            addCriterion("cod_usuario is null");
            return this;
        }

        public Criteria andCodUsuarioIsNotNull() {
            addCriterion("cod_usuario is not null");
            return this;
        }

        public Criteria andCodUsuarioEqualTo(Integer value) {
            addCriterion("cod_usuario =", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotEqualTo(Integer value) {
            addCriterion("cod_usuario <>", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThan(Integer value) {
            addCriterion("cod_usuario >", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario >=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThan(Integer value) {
            addCriterion("cod_usuario <", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario <=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioIn(List<Integer> values) {
            addCriterion("cod_usuario in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotIn(List<Integer> values) {
            addCriterion("cod_usuario not in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario not between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTokenIsNull() {
            addCriterion("num_token is null");
            return this;
        }

        public Criteria andNumTokenIsNotNull() {
            addCriterion("num_token is not null");
            return this;
        }

        public Criteria andNumTokenEqualTo(Integer value) {
            addCriterion("num_token =", value, "numToken");
            return this;
        }

        public Criteria andNumTokenNotEqualTo(Integer value) {
            addCriterion("num_token <>", value, "numToken");
            return this;
        }

        public Criteria andNumTokenGreaterThan(Integer value) {
            addCriterion("num_token >", value, "numToken");
            return this;
        }

        public Criteria andNumTokenGreaterThanOrEqualTo(Integer value) {
            addCriterion("num_token >=", value, "numToken");
            return this;
        }

        public Criteria andNumTokenLessThan(Integer value) {
            addCriterion("num_token <", value, "numToken");
            return this;
        }

        public Criteria andNumTokenLessThanOrEqualTo(Integer value) {
            addCriterion("num_token <=", value, "numToken");
            return this;
        }

        public Criteria andNumTokenIn(List<Integer> values) {
            addCriterion("num_token in", values, "numToken");
            return this;
        }

        public Criteria andNumTokenNotIn(List<Integer> values) {
            addCriterion("num_token not in", values, "numToken");
            return this;
        }

        public Criteria andNumTokenBetween(Integer value1, Integer value2) {
            addCriterion("num_token between", value1, value2, "numToken");
            return this;
        }

        public Criteria andNumTokenNotBetween(Integer value1, Integer value2) {
            addCriterion("num_token not between", value1, value2, "numToken");
            return this;
        }

        public Criteria andFecGenTokenIsNull() {
            addCriterion("fec_gen_token is null");
            return this;
        }

        public Criteria andFecGenTokenIsNotNull() {
            addCriterion("fec_gen_token is not null");
            return this;
        }

        public Criteria andFecGenTokenEqualTo(Date value) {
            addCriterion("fec_gen_token =", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenNotEqualTo(Date value) {
            addCriterion("fec_gen_token <>", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenGreaterThan(Date value) {
            addCriterion("fec_gen_token >", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_gen_token >=", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenLessThan(Date value) {
            addCriterion("fec_gen_token <", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenLessThanOrEqualTo(Date value) {
            addCriterion("fec_gen_token <=", value, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenIn(List<Date> values) {
            addCriterion("fec_gen_token in", values, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenNotIn(List<Date> values) {
            addCriterion("fec_gen_token not in", values, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenBetween(Date value1, Date value2) {
            addCriterion("fec_gen_token between", value1, value2, "fecGenToken");
            return this;
        }

        public Criteria andFecGenTokenNotBetween(Date value1, Date value2) {
            addCriterion("fec_gen_token not between", value1, value2, "fecGenToken");
            return this;
        }

        public Criteria andDesPassIsNull() {
            addCriterion("des_pass is null");
            return this;
        }

        public Criteria andDesPassIsNotNull() {
            addCriterion("des_pass is not null");
            return this;
        }

        public Criteria andDesPassEqualTo(String value) {
            addCriterion("des_pass =", value, "desPass");
            return this;
        }

        public Criteria andDesPassNotEqualTo(String value) {
            addCriterion("des_pass <>", value, "desPass");
            return this;
        }

        public Criteria andDesPassGreaterThan(String value) {
            addCriterion("des_pass >", value, "desPass");
            return this;
        }

        public Criteria andDesPassGreaterThanOrEqualTo(String value) {
            addCriterion("des_pass >=", value, "desPass");
            return this;
        }

        public Criteria andDesPassLessThan(String value) {
            addCriterion("des_pass <", value, "desPass");
            return this;
        }

        public Criteria andDesPassLessThanOrEqualTo(String value) {
            addCriterion("des_pass <=", value, "desPass");
            return this;
        }

        public Criteria andDesPassLike(String value) {
            addCriterion("des_pass like", value, "desPass");
            return this;
        }

        public Criteria andDesPassNotLike(String value) {
            addCriterion("des_pass not like", value, "desPass");
            return this;
        }

        public Criteria andDesPassIn(List<String> values) {
            addCriterion("des_pass in", values, "desPass");
            return this;
        }

        public Criteria andDesPassNotIn(List<String> values) {
            addCriterion("des_pass not in", values, "desPass");
            return this;
        }

        public Criteria andDesPassBetween(String value1, String value2) {
            addCriterion("des_pass between", value1, value2, "desPass");
            return this;
        }

        public Criteria andDesPassNotBetween(String value1, String value2) {
            addCriterion("des_pass not between", value1, value2, "desPass");
            return this;
        }

        public Criteria andCodEstadoIsNull() {
            addCriterion("cod_estado is null");
            return this;
        }

        public Criteria andCodEstadoIsNotNull() {
            addCriterion("cod_estado is not null");
            return this;
        }

        public Criteria andCodEstadoEqualTo(String value) {
            addCriterion("cod_estado =", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotEqualTo(String value) {
            addCriterion("cod_estado <>", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThan(String value) {
            addCriterion("cod_estado >", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoGreaterThanOrEqualTo(String value) {
            addCriterion("cod_estado >=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThan(String value) {
            addCriterion("cod_estado <", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLessThanOrEqualTo(String value) {
            addCriterion("cod_estado <=", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoLike(String value) {
            addCriterion("cod_estado like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotLike(String value) {
            addCriterion("cod_estado not like", value, "codEstado");
            return this;
        }

        public Criteria andCodEstadoIn(List<String> values) {
            addCriterion("cod_estado in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotIn(List<String> values) {
            addCriterion("cod_estado not in", values, "codEstado");
            return this;
        }

        public Criteria andCodEstadoBetween(String value1, String value2) {
            addCriterion("cod_estado between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andCodEstadoNotBetween(String value1, String value2) {
            addCriterion("cod_estado not between", value1, value2, "codEstado");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}