package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Mensaje {
    private Integer codMensaje;

    private Integer codUsuEmisor;

    private Integer codUsuRecep;

    private Date fecEnvio;

    private Date fecRecep;

    private Date fecLectura;

    private String desMensaje;

    private Integer codArchivo;

    private Integer codArcOptimo;

    private String codEstado;

    private Boolean indVisuEmisor;

    private Boolean indVisuRecep;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodMensaje() {
        return codMensaje;
    }

    public void setCodMensaje(Integer codMensaje) {
        this.codMensaje = codMensaje;
    }

    public Integer getCodUsuEmisor() {
        return codUsuEmisor;
    }

    public void setCodUsuEmisor(Integer codUsuEmisor) {
        this.codUsuEmisor = codUsuEmisor;
    }

    public Integer getCodUsuRecep() {
        return codUsuRecep;
    }

    public void setCodUsuRecep(Integer codUsuRecep) {
        this.codUsuRecep = codUsuRecep;
    }

    public Date getFecEnvio() {
        return fecEnvio;
    }

    public void setFecEnvio(Date fecEnvio) {
        this.fecEnvio = fecEnvio;
    }

    public Date getFecRecep() {
        return fecRecep;
    }

    public void setFecRecep(Date fecRecep) {
        this.fecRecep = fecRecep;
    }

    public Date getFecLectura() {
        return fecLectura;
    }

    public void setFecLectura(Date fecLectura) {
        this.fecLectura = fecLectura;
    }

    public String getDesMensaje() {
        return desMensaje;
    }

    public void setDesMensaje(String desMensaje) {
        this.desMensaje = desMensaje == null ? null : desMensaje.trim();
    }

    public Integer getCodArchivo() {
        return codArchivo;
    }

    public void setCodArchivo(Integer codArchivo) {
        this.codArchivo = codArchivo;
    }

    public Integer getCodArcOptimo() {
        return codArcOptimo;
    }

    public void setCodArcOptimo(Integer codArcOptimo) {
        this.codArcOptimo = codArcOptimo;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public Boolean getIndVisuEmisor() {
        return indVisuEmisor;
    }

    public void setIndVisuEmisor(Boolean indVisuEmisor) {
        this.indVisuEmisor = indVisuEmisor;
    }

    public Boolean getIndVisuRecep() {
        return indVisuRecep;
    }

    public void setIndVisuRecep(Boolean indVisuRecep) {
        this.indVisuRecep = indVisuRecep;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}