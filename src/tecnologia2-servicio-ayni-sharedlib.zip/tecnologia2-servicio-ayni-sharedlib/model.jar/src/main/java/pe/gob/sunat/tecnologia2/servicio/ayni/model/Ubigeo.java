package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class Ubigeo {
    private Integer codUbigeo;

    private String desNombre;

    private Integer codUbiPadre;

    private Integer numNivel;

    private String codEstado;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodUbigeo() {
        return codUbigeo;
    }

    public void setCodUbigeo(Integer codUbigeo) {
        this.codUbigeo = codUbigeo;
    }

    public String getDesNombre() {
        return desNombre;
    }

    public void setDesNombre(String desNombre) {
        this.desNombre = desNombre == null ? null : desNombre.trim();
    }

    public Integer getCodUbiPadre() {
        return codUbiPadre;
    }

    public void setCodUbiPadre(Integer codUbiPadre) {
        this.codUbiPadre = codUbiPadre;
    }

    public Integer getNumNivel() {
        return numNivel;
    }

    public void setNumNivel(Integer numNivel) {
        this.numNivel = numNivel;
    }

    public String getCodEstado() {
        return codEstado;
    }

    public void setCodEstado(String codEstado) {
        this.codEstado = codEstado == null ? null : codEstado.trim();
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}