package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.util.Date;

public class ArchivoServicio {
    private Integer codArchServ;

    private Integer codServicio;

    private Integer codArchivo;

    private Boolean indElim;

    private Date fecCrea;

    private String codUsucrea;

    private Date fecMod;

    private String codUsumod;

    public Integer getCodArchServ() {
        return codArchServ;
    }

    public void setCodArchServ(Integer codArchServ) {
        this.codArchServ = codArchServ;
    }

    public Integer getCodServicio() {
        return codServicio;
    }

    public void setCodServicio(Integer codServicio) {
        this.codServicio = codServicio;
    }

    public Integer getCodArchivo() {
        return codArchivo;
    }

    public void setCodArchivo(Integer codArchivo) {
        this.codArchivo = codArchivo;
    }

    public Boolean getIndElim() {
        return indElim;
    }

    public void setIndElim(Boolean indElim) {
        this.indElim = indElim;
    }

    public Date getFecCrea() {
        return fecCrea;
    }

    public void setFecCrea(Date fecCrea) {
        this.fecCrea = fecCrea;
    }

    public String getCodUsucrea() {
        return codUsucrea;
    }

    public void setCodUsucrea(String codUsucrea) {
        this.codUsucrea = codUsucrea == null ? null : codUsucrea.trim();
    }

    public Date getFecMod() {
        return fecMod;
    }

    public void setFecMod(Date fecMod) {
        this.fecMod = fecMod;
    }

    public String getCodUsumod() {
        return codUsumod;
    }

    public void setCodUsumod(String codUsumod) {
        this.codUsumod = codUsumod == null ? null : codUsumod.trim();
    }
}