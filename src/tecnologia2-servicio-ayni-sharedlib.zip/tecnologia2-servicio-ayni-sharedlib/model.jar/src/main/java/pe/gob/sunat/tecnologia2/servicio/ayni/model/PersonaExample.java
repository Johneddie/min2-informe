package pe.gob.sunat.tecnologia2.servicio.ayni.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PersonaExample {
    protected String orderByClause;

    protected List<Criteria> oredCriteria;

    public PersonaExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    protected PersonaExample(PersonaExample example) {
        this.orderByClause = example.orderByClause;
        this.oredCriteria = example.oredCriteria;
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
    }

    public static class Criteria {
        protected List<String> criteriaWithoutValue;

        protected List<Map<String, Object>> criteriaWithSingleValue;

        protected List<Map<String, Object>> criteriaWithListValue;

        protected List<Map<String, Object>> criteriaWithBetweenValue;

        protected Criteria() {
            super();
            criteriaWithoutValue = new ArrayList<String>();
            criteriaWithSingleValue = new ArrayList<Map<String, Object>>();
            criteriaWithListValue = new ArrayList<Map<String, Object>>();
            criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();
        }

        public boolean isValid() {
            return criteriaWithoutValue.size() > 0
                || criteriaWithSingleValue.size() > 0
                || criteriaWithListValue.size() > 0
                || criteriaWithBetweenValue.size() > 0;
        }

        public List<String> getCriteriaWithoutValue() {
            return criteriaWithoutValue;
        }

        public List<Map<String, Object>> getCriteriaWithSingleValue() {
            return criteriaWithSingleValue;
        }

        public List<Map<String, Object>> getCriteriaWithListValue() {
            return criteriaWithListValue;
        }

        public List<Map<String, Object>> getCriteriaWithBetweenValue() {
            return criteriaWithBetweenValue;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteriaWithoutValue.add(condition);
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("value", value);
            criteriaWithSingleValue.add(map);
        }

        protected void addCriterion(String condition, List<? extends Object> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", values);
            criteriaWithListValue.add(map);
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            List<Object> list = new ArrayList<Object>();
            list.add(value1);
            list.add(value2);
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("condition", condition);
            map.put("values", list);
            criteriaWithBetweenValue.add(map);
        }

        public Criteria andCodPersonaIsNull() {
            addCriterion("cod_persona is null");
            return this;
        }

        public Criteria andCodPersonaIsNotNull() {
            addCriterion("cod_persona is not null");
            return this;
        }

        public Criteria andCodPersonaEqualTo(Integer value) {
            addCriterion("cod_persona =", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotEqualTo(Integer value) {
            addCriterion("cod_persona <>", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaGreaterThan(Integer value) {
            addCriterion("cod_persona >", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_persona >=", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaLessThan(Integer value) {
            addCriterion("cod_persona <", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaLessThanOrEqualTo(Integer value) {
            addCriterion("cod_persona <=", value, "codPersona");
            return this;
        }

        public Criteria andCodPersonaIn(List<Integer> values) {
            addCriterion("cod_persona in", values, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotIn(List<Integer> values) {
            addCriterion("cod_persona not in", values, "codPersona");
            return this;
        }

        public Criteria andCodPersonaBetween(Integer value1, Integer value2) {
            addCriterion("cod_persona between", value1, value2, "codPersona");
            return this;
        }

        public Criteria andCodPersonaNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_persona not between", value1, value2, "codPersona");
            return this;
        }

        public Criteria andCodUsuarioIsNull() {
            addCriterion("cod_usuario is null");
            return this;
        }

        public Criteria andCodUsuarioIsNotNull() {
            addCriterion("cod_usuario is not null");
            return this;
        }

        public Criteria andCodUsuarioEqualTo(Integer value) {
            addCriterion("cod_usuario =", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotEqualTo(Integer value) {
            addCriterion("cod_usuario <>", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThan(Integer value) {
            addCriterion("cod_usuario >", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario >=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThan(Integer value) {
            addCriterion("cod_usuario <", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioLessThanOrEqualTo(Integer value) {
            addCriterion("cod_usuario <=", value, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioIn(List<Integer> values) {
            addCriterion("cod_usuario in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotIn(List<Integer> values) {
            addCriterion("cod_usuario not in", values, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andCodUsuarioNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_usuario not between", value1, value2, "codUsuario");
            return this;
        }

        public Criteria andCodTipDocIsNull() {
            addCriterion("cod_tip_doc is null");
            return this;
        }

        public Criteria andCodTipDocIsNotNull() {
            addCriterion("cod_tip_doc is not null");
            return this;
        }

        public Criteria andCodTipDocEqualTo(Integer value) {
            addCriterion("cod_tip_doc =", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocNotEqualTo(Integer value) {
            addCriterion("cod_tip_doc <>", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocGreaterThan(Integer value) {
            addCriterion("cod_tip_doc >", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_tip_doc >=", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocLessThan(Integer value) {
            addCriterion("cod_tip_doc <", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocLessThanOrEqualTo(Integer value) {
            addCriterion("cod_tip_doc <=", value, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocIn(List<Integer> values) {
            addCriterion("cod_tip_doc in", values, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocNotIn(List<Integer> values) {
            addCriterion("cod_tip_doc not in", values, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocBetween(Integer value1, Integer value2) {
            addCriterion("cod_tip_doc between", value1, value2, "codTipDoc");
            return this;
        }

        public Criteria andCodTipDocNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_tip_doc not between", value1, value2, "codTipDoc");
            return this;
        }

        public Criteria andNumDocIsNull() {
            addCriterion("num_doc is null");
            return this;
        }

        public Criteria andNumDocIsNotNull() {
            addCriterion("num_doc is not null");
            return this;
        }

        public Criteria andNumDocEqualTo(String value) {
            addCriterion("num_doc =", value, "numDoc");
            return this;
        }

        public Criteria andNumDocNotEqualTo(String value) {
            addCriterion("num_doc <>", value, "numDoc");
            return this;
        }

        public Criteria andNumDocGreaterThan(String value) {
            addCriterion("num_doc >", value, "numDoc");
            return this;
        }

        public Criteria andNumDocGreaterThanOrEqualTo(String value) {
            addCriterion("num_doc >=", value, "numDoc");
            return this;
        }

        public Criteria andNumDocLessThan(String value) {
            addCriterion("num_doc <", value, "numDoc");
            return this;
        }

        public Criteria andNumDocLessThanOrEqualTo(String value) {
            addCriterion("num_doc <=", value, "numDoc");
            return this;
        }

        public Criteria andNumDocLike(String value) {
            addCriterion("num_doc like", value, "numDoc");
            return this;
        }

        public Criteria andNumDocNotLike(String value) {
            addCriterion("num_doc not like", value, "numDoc");
            return this;
        }

        public Criteria andNumDocIn(List<String> values) {
            addCriterion("num_doc in", values, "numDoc");
            return this;
        }

        public Criteria andNumDocNotIn(List<String> values) {
            addCriterion("num_doc not in", values, "numDoc");
            return this;
        }

        public Criteria andNumDocBetween(String value1, String value2) {
            addCriterion("num_doc between", value1, value2, "numDoc");
            return this;
        }

        public Criteria andNumDocNotBetween(String value1, String value2) {
            addCriterion("num_doc not between", value1, value2, "numDoc");
            return this;
        }

        public Criteria andDesApellidosIsNull() {
            addCriterion("des_apellidos is null");
            return this;
        }

        public Criteria andDesApellidosIsNotNull() {
            addCriterion("des_apellidos is not null");
            return this;
        }

        public Criteria andDesApellidosEqualTo(String value) {
            addCriterion("des_apellidos =", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosNotEqualTo(String value) {
            addCriterion("des_apellidos <>", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosGreaterThan(String value) {
            addCriterion("des_apellidos >", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosGreaterThanOrEqualTo(String value) {
            addCriterion("des_apellidos >=", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosLessThan(String value) {
            addCriterion("des_apellidos <", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosLessThanOrEqualTo(String value) {
            addCriterion("des_apellidos <=", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosLike(String value) {
            addCriterion("des_apellidos like", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosNotLike(String value) {
            addCriterion("des_apellidos not like", value, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosIn(List<String> values) {
            addCriterion("des_apellidos in", values, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosNotIn(List<String> values) {
            addCriterion("des_apellidos not in", values, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosBetween(String value1, String value2) {
            addCriterion("des_apellidos between", value1, value2, "desApellidos");
            return this;
        }

        public Criteria andDesApellidosNotBetween(String value1, String value2) {
            addCriterion("des_apellidos not between", value1, value2, "desApellidos");
            return this;
        }

        public Criteria andDesNombresIsNull() {
            addCriterion("des_nombres is null");
            return this;
        }

        public Criteria andDesNombresIsNotNull() {
            addCriterion("des_nombres is not null");
            return this;
        }

        public Criteria andDesNombresEqualTo(String value) {
            addCriterion("des_nombres =", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresNotEqualTo(String value) {
            addCriterion("des_nombres <>", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresGreaterThan(String value) {
            addCriterion("des_nombres >", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresGreaterThanOrEqualTo(String value) {
            addCriterion("des_nombres >=", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresLessThan(String value) {
            addCriterion("des_nombres <", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresLessThanOrEqualTo(String value) {
            addCriterion("des_nombres <=", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresLike(String value) {
            addCriterion("des_nombres like", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresNotLike(String value) {
            addCriterion("des_nombres not like", value, "desNombres");
            return this;
        }

        public Criteria andDesNombresIn(List<String> values) {
            addCriterion("des_nombres in", values, "desNombres");
            return this;
        }

        public Criteria andDesNombresNotIn(List<String> values) {
            addCriterion("des_nombres not in", values, "desNombres");
            return this;
        }

        public Criteria andDesNombresBetween(String value1, String value2) {
            addCriterion("des_nombres between", value1, value2, "desNombres");
            return this;
        }

        public Criteria andDesNombresNotBetween(String value1, String value2) {
            addCriterion("des_nombres not between", value1, value2, "desNombres");
            return this;
        }

        public Criteria andCodSexoIsNull() {
            addCriterion("cod_sexo is null");
            return this;
        }

        public Criteria andCodSexoIsNotNull() {
            addCriterion("cod_sexo is not null");
            return this;
        }

        public Criteria andCodSexoEqualTo(Integer value) {
            addCriterion("cod_sexo =", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoNotEqualTo(Integer value) {
            addCriterion("cod_sexo <>", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoGreaterThan(Integer value) {
            addCriterion("cod_sexo >", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_sexo >=", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoLessThan(Integer value) {
            addCriterion("cod_sexo <", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoLessThanOrEqualTo(Integer value) {
            addCriterion("cod_sexo <=", value, "codSexo");
            return this;
        }

        public Criteria andCodSexoIn(List<Integer> values) {
            addCriterion("cod_sexo in", values, "codSexo");
            return this;
        }

        public Criteria andCodSexoNotIn(List<Integer> values) {
            addCriterion("cod_sexo not in", values, "codSexo");
            return this;
        }

        public Criteria andCodSexoBetween(Integer value1, Integer value2) {
            addCriterion("cod_sexo between", value1, value2, "codSexo");
            return this;
        }

        public Criteria andCodSexoNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_sexo not between", value1, value2, "codSexo");
            return this;
        }

        public Criteria andDesCorreoIsNull() {
            addCriterion("des_correo is null");
            return this;
        }

        public Criteria andDesCorreoIsNotNull() {
            addCriterion("des_correo is not null");
            return this;
        }

        public Criteria andDesCorreoEqualTo(String value) {
            addCriterion("des_correo =", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotEqualTo(String value) {
            addCriterion("des_correo <>", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThan(String value) {
            addCriterion("des_correo >", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoGreaterThanOrEqualTo(String value) {
            addCriterion("des_correo >=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThan(String value) {
            addCriterion("des_correo <", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLessThanOrEqualTo(String value) {
            addCriterion("des_correo <=", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoLike(String value) {
            addCriterion("des_correo like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotLike(String value) {
            addCriterion("des_correo not like", value, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoIn(List<String> values) {
            addCriterion("des_correo in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotIn(List<String> values) {
            addCriterion("des_correo not in", values, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoBetween(String value1, String value2) {
            addCriterion("des_correo between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andDesCorreoNotBetween(String value1, String value2) {
            addCriterion("des_correo not between", value1, value2, "desCorreo");
            return this;
        }

        public Criteria andNumTelefIsNull() {
            addCriterion("num_telef is null");
            return this;
        }

        public Criteria andNumTelefIsNotNull() {
            addCriterion("num_telef is not null");
            return this;
        }

        public Criteria andNumTelefEqualTo(String value) {
            addCriterion("num_telef =", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotEqualTo(String value) {
            addCriterion("num_telef <>", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThan(String value) {
            addCriterion("num_telef >", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefGreaterThanOrEqualTo(String value) {
            addCriterion("num_telef >=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThan(String value) {
            addCriterion("num_telef <", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLessThanOrEqualTo(String value) {
            addCriterion("num_telef <=", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefLike(String value) {
            addCriterion("num_telef like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotLike(String value) {
            addCriterion("num_telef not like", value, "numTelef");
            return this;
        }

        public Criteria andNumTelefIn(List<String> values) {
            addCriterion("num_telef in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotIn(List<String> values) {
            addCriterion("num_telef not in", values, "numTelef");
            return this;
        }

        public Criteria andNumTelefBetween(String value1, String value2) {
            addCriterion("num_telef between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andNumTelefNotBetween(String value1, String value2) {
            addCriterion("num_telef not between", value1, value2, "numTelef");
            return this;
        }

        public Criteria andCodDirUbigeoIsNull() {
            addCriterion("cod_dir_ubigeo is null");
            return this;
        }

        public Criteria andCodDirUbigeoIsNotNull() {
            addCriterion("cod_dir_ubigeo is not null");
            return this;
        }

        public Criteria andCodDirUbigeoEqualTo(Integer value) {
            addCriterion("cod_dir_ubigeo =", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoNotEqualTo(Integer value) {
            addCriterion("cod_dir_ubigeo <>", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoGreaterThan(Integer value) {
            addCriterion("cod_dir_ubigeo >", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoGreaterThanOrEqualTo(Integer value) {
            addCriterion("cod_dir_ubigeo >=", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoLessThan(Integer value) {
            addCriterion("cod_dir_ubigeo <", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoLessThanOrEqualTo(Integer value) {
            addCriterion("cod_dir_ubigeo <=", value, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoIn(List<Integer> values) {
            addCriterion("cod_dir_ubigeo in", values, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoNotIn(List<Integer> values) {
            addCriterion("cod_dir_ubigeo not in", values, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoBetween(Integer value1, Integer value2) {
            addCriterion("cod_dir_ubigeo between", value1, value2, "codDirUbigeo");
            return this;
        }

        public Criteria andCodDirUbigeoNotBetween(Integer value1, Integer value2) {
            addCriterion("cod_dir_ubigeo not between", value1, value2, "codDirUbigeo");
            return this;
        }

        public Criteria andDesDireccionIsNull() {
            addCriterion("des_direccion is null");
            return this;
        }

        public Criteria andDesDireccionIsNotNull() {
            addCriterion("des_direccion is not null");
            return this;
        }

        public Criteria andDesDireccionEqualTo(String value) {
            addCriterion("des_direccion =", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionNotEqualTo(String value) {
            addCriterion("des_direccion <>", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionGreaterThan(String value) {
            addCriterion("des_direccion >", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionGreaterThanOrEqualTo(String value) {
            addCriterion("des_direccion >=", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionLessThan(String value) {
            addCriterion("des_direccion <", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionLessThanOrEqualTo(String value) {
            addCriterion("des_direccion <=", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionLike(String value) {
            addCriterion("des_direccion like", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionNotLike(String value) {
            addCriterion("des_direccion not like", value, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionIn(List<String> values) {
            addCriterion("des_direccion in", values, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionNotIn(List<String> values) {
            addCriterion("des_direccion not in", values, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionBetween(String value1, String value2) {
            addCriterion("des_direccion between", value1, value2, "desDireccion");
            return this;
        }

        public Criteria andDesDireccionNotBetween(String value1, String value2) {
            addCriterion("des_direccion not between", value1, value2, "desDireccion");
            return this;
        }

        public Criteria andNumLatDirIsNull() {
            addCriterion("num_lat_dir is null");
            return this;
        }

        public Criteria andNumLatDirIsNotNull() {
            addCriterion("num_lat_dir is not null");
            return this;
        }

        public Criteria andNumLatDirEqualTo(BigDecimal value) {
            addCriterion("num_lat_dir =", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirNotEqualTo(BigDecimal value) {
            addCriterion("num_lat_dir <>", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirGreaterThan(BigDecimal value) {
            addCriterion("num_lat_dir >", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lat_dir >=", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirLessThan(BigDecimal value) {
            addCriterion("num_lat_dir <", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lat_dir <=", value, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirIn(List<BigDecimal> values) {
            addCriterion("num_lat_dir in", values, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirNotIn(List<BigDecimal> values) {
            addCriterion("num_lat_dir not in", values, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lat_dir between", value1, value2, "numLatDir");
            return this;
        }

        public Criteria andNumLatDirNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lat_dir not between", value1, value2, "numLatDir");
            return this;
        }

        public Criteria andNumLonDirIsNull() {
            addCriterion("num_lon_dir is null");
            return this;
        }

        public Criteria andNumLonDirIsNotNull() {
            addCriterion("num_lon_dir is not null");
            return this;
        }

        public Criteria andNumLonDirEqualTo(BigDecimal value) {
            addCriterion("num_lon_dir =", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirNotEqualTo(BigDecimal value) {
            addCriterion("num_lon_dir <>", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirGreaterThan(BigDecimal value) {
            addCriterion("num_lon_dir >", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lon_dir >=", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirLessThan(BigDecimal value) {
            addCriterion("num_lon_dir <", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirLessThanOrEqualTo(BigDecimal value) {
            addCriterion("num_lon_dir <=", value, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirIn(List<BigDecimal> values) {
            addCriterion("num_lon_dir in", values, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirNotIn(List<BigDecimal> values) {
            addCriterion("num_lon_dir not in", values, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lon_dir between", value1, value2, "numLonDir");
            return this;
        }

        public Criteria andNumLonDirNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("num_lon_dir not between", value1, value2, "numLonDir");
            return this;
        }

        public Criteria andIndActivPosiIsNull() {
            addCriterion("ind_activ_posi is null");
            return this;
        }

        public Criteria andIndActivPosiIsNotNull() {
            addCriterion("ind_activ_posi is not null");
            return this;
        }

        public Criteria andIndActivPosiEqualTo(Boolean value) {
            addCriterion("ind_activ_posi =", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiNotEqualTo(Boolean value) {
            addCriterion("ind_activ_posi <>", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiGreaterThan(Boolean value) {
            addCriterion("ind_activ_posi >", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_activ_posi >=", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiLessThan(Boolean value) {
            addCriterion("ind_activ_posi <", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_activ_posi <=", value, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiIn(List<Boolean> values) {
            addCriterion("ind_activ_posi in", values, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiNotIn(List<Boolean> values) {
            addCriterion("ind_activ_posi not in", values, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_activ_posi between", value1, value2, "indActivPosi");
            return this;
        }

        public Criteria andIndActivPosiNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_activ_posi not between", value1, value2, "indActivPosi");
            return this;
        }

        public Criteria andFecNacimIsNull() {
            addCriterion("fec_nacim is null");
            return this;
        }

        public Criteria andFecNacimIsNotNull() {
            addCriterion("fec_nacim is not null");
            return this;
        }

        public Criteria andFecNacimEqualTo(Date value) {
            addCriterion("fec_nacim =", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimNotEqualTo(Date value) {
            addCriterion("fec_nacim <>", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimGreaterThan(Date value) {
            addCriterion("fec_nacim >", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_nacim >=", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimLessThan(Date value) {
            addCriterion("fec_nacim <", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimLessThanOrEqualTo(Date value) {
            addCriterion("fec_nacim <=", value, "fecNacim");
            return this;
        }

        public Criteria andFecNacimIn(List<Date> values) {
            addCriterion("fec_nacim in", values, "fecNacim");
            return this;
        }

        public Criteria andFecNacimNotIn(List<Date> values) {
            addCriterion("fec_nacim not in", values, "fecNacim");
            return this;
        }

        public Criteria andFecNacimBetween(Date value1, Date value2) {
            addCriterion("fec_nacim between", value1, value2, "fecNacim");
            return this;
        }

        public Criteria andFecNacimNotBetween(Date value1, Date value2) {
            addCriterion("fec_nacim not between", value1, value2, "fecNacim");
            return this;
        }

        public Criteria andIndClienteIsNull() {
            addCriterion("ind_cliente is null");
            return this;
        }

        public Criteria andIndClienteIsNotNull() {
            addCriterion("ind_cliente is not null");
            return this;
        }

        public Criteria andIndClienteEqualTo(Boolean value) {
            addCriterion("ind_cliente =", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteNotEqualTo(Boolean value) {
            addCriterion("ind_cliente <>", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteGreaterThan(Boolean value) {
            addCriterion("ind_cliente >", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_cliente >=", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteLessThan(Boolean value) {
            addCriterion("ind_cliente <", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_cliente <=", value, "indCliente");
            return this;
        }

        public Criteria andIndClienteIn(List<Boolean> values) {
            addCriterion("ind_cliente in", values, "indCliente");
            return this;
        }

        public Criteria andIndClienteNotIn(List<Boolean> values) {
            addCriterion("ind_cliente not in", values, "indCliente");
            return this;
        }

        public Criteria andIndClienteBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_cliente between", value1, value2, "indCliente");
            return this;
        }

        public Criteria andIndClienteNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_cliente not between", value1, value2, "indCliente");
            return this;
        }

        public Criteria andIndEspecIsNull() {
            addCriterion("ind_espec is null");
            return this;
        }

        public Criteria andIndEspecIsNotNull() {
            addCriterion("ind_espec is not null");
            return this;
        }

        public Criteria andIndEspecEqualTo(Boolean value) {
            addCriterion("ind_espec =", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecNotEqualTo(Boolean value) {
            addCriterion("ind_espec <>", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecGreaterThan(Boolean value) {
            addCriterion("ind_espec >", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_espec >=", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecLessThan(Boolean value) {
            addCriterion("ind_espec <", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_espec <=", value, "indEspec");
            return this;
        }

        public Criteria andIndEspecIn(List<Boolean> values) {
            addCriterion("ind_espec in", values, "indEspec");
            return this;
        }

        public Criteria andIndEspecNotIn(List<Boolean> values) {
            addCriterion("ind_espec not in", values, "indEspec");
            return this;
        }

        public Criteria andIndEspecBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_espec between", value1, value2, "indEspec");
            return this;
        }

        public Criteria andIndEspecNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_espec not between", value1, value2, "indEspec");
            return this;
        }

        public Criteria andIndDisponIsNull() {
            addCriterion("ind_dispon is null");
            return this;
        }

        public Criteria andIndDisponIsNotNull() {
            addCriterion("ind_dispon is not null");
            return this;
        }

        public Criteria andIndDisponEqualTo(Boolean value) {
            addCriterion("ind_dispon =", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotEqualTo(Boolean value) {
            addCriterion("ind_dispon <>", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponGreaterThan(Boolean value) {
            addCriterion("ind_dispon >", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_dispon >=", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponLessThan(Boolean value) {
            addCriterion("ind_dispon <", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_dispon <=", value, "indDispon");
            return this;
        }

        public Criteria andIndDisponIn(List<Boolean> values) {
            addCriterion("ind_dispon in", values, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotIn(List<Boolean> values) {
            addCriterion("ind_dispon not in", values, "indDispon");
            return this;
        }

        public Criteria andIndDisponBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_dispon between", value1, value2, "indDispon");
            return this;
        }

        public Criteria andIndDisponNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_dispon not between", value1, value2, "indDispon");
            return this;
        }

        public Criteria andIndElimIsNull() {
            addCriterion("ind_elim is null");
            return this;
        }

        public Criteria andIndElimIsNotNull() {
            addCriterion("ind_elim is not null");
            return this;
        }

        public Criteria andIndElimEqualTo(Boolean value) {
            addCriterion("ind_elim =", value, "indElim");
            return this;
        }

        public Criteria andIndElimNotEqualTo(Boolean value) {
            addCriterion("ind_elim <>", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThan(Boolean value) {
            addCriterion("ind_elim >", value, "indElim");
            return this;
        }

        public Criteria andIndElimGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim >=", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThan(Boolean value) {
            addCriterion("ind_elim <", value, "indElim");
            return this;
        }

        public Criteria andIndElimLessThanOrEqualTo(Boolean value) {
            addCriterion("ind_elim <=", value, "indElim");
            return this;
        }

        public Criteria andIndElimIn(List<Boolean> values) {
            addCriterion("ind_elim in", values, "indElim");
            return this;
        }

        public Criteria andIndElimNotIn(List<Boolean> values) {
            addCriterion("ind_elim not in", values, "indElim");
            return this;
        }

        public Criteria andIndElimBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim between", value1, value2, "indElim");
            return this;
        }

        public Criteria andIndElimNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ind_elim not between", value1, value2, "indElim");
            return this;
        }

        public Criteria andFecCreaIsNull() {
            addCriterion("fec_crea is null");
            return this;
        }

        public Criteria andFecCreaIsNotNull() {
            addCriterion("fec_crea is not null");
            return this;
        }

        public Criteria andFecCreaEqualTo(Date value) {
            addCriterion("fec_crea =", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotEqualTo(Date value) {
            addCriterion("fec_crea <>", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThan(Date value) {
            addCriterion("fec_crea >", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_crea >=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThan(Date value) {
            addCriterion("fec_crea <", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaLessThanOrEqualTo(Date value) {
            addCriterion("fec_crea <=", value, "fecCrea");
            return this;
        }

        public Criteria andFecCreaIn(List<Date> values) {
            addCriterion("fec_crea in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotIn(List<Date> values) {
            addCriterion("fec_crea not in", values, "fecCrea");
            return this;
        }

        public Criteria andFecCreaBetween(Date value1, Date value2) {
            addCriterion("fec_crea between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andFecCreaNotBetween(Date value1, Date value2) {
            addCriterion("fec_crea not between", value1, value2, "fecCrea");
            return this;
        }

        public Criteria andCodUsucreaIsNull() {
            addCriterion("cod_usucrea is null");
            return this;
        }

        public Criteria andCodUsucreaIsNotNull() {
            addCriterion("cod_usucrea is not null");
            return this;
        }

        public Criteria andCodUsucreaEqualTo(String value) {
            addCriterion("cod_usucrea =", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotEqualTo(String value) {
            addCriterion("cod_usucrea <>", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThan(String value) {
            addCriterion("cod_usucrea >", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usucrea >=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThan(String value) {
            addCriterion("cod_usucrea <", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLessThanOrEqualTo(String value) {
            addCriterion("cod_usucrea <=", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaLike(String value) {
            addCriterion("cod_usucrea like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotLike(String value) {
            addCriterion("cod_usucrea not like", value, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaIn(List<String> values) {
            addCriterion("cod_usucrea in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotIn(List<String> values) {
            addCriterion("cod_usucrea not in", values, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaBetween(String value1, String value2) {
            addCriterion("cod_usucrea between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andCodUsucreaNotBetween(String value1, String value2) {
            addCriterion("cod_usucrea not between", value1, value2, "codUsucrea");
            return this;
        }

        public Criteria andFecModIsNull() {
            addCriterion("fec_mod is null");
            return this;
        }

        public Criteria andFecModIsNotNull() {
            addCriterion("fec_mod is not null");
            return this;
        }

        public Criteria andFecModEqualTo(Date value) {
            addCriterion("fec_mod =", value, "fecMod");
            return this;
        }

        public Criteria andFecModNotEqualTo(Date value) {
            addCriterion("fec_mod <>", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThan(Date value) {
            addCriterion("fec_mod >", value, "fecMod");
            return this;
        }

        public Criteria andFecModGreaterThanOrEqualTo(Date value) {
            addCriterion("fec_mod >=", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThan(Date value) {
            addCriterion("fec_mod <", value, "fecMod");
            return this;
        }

        public Criteria andFecModLessThanOrEqualTo(Date value) {
            addCriterion("fec_mod <=", value, "fecMod");
            return this;
        }

        public Criteria andFecModIn(List<Date> values) {
            addCriterion("fec_mod in", values, "fecMod");
            return this;
        }

        public Criteria andFecModNotIn(List<Date> values) {
            addCriterion("fec_mod not in", values, "fecMod");
            return this;
        }

        public Criteria andFecModBetween(Date value1, Date value2) {
            addCriterion("fec_mod between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andFecModNotBetween(Date value1, Date value2) {
            addCriterion("fec_mod not between", value1, value2, "fecMod");
            return this;
        }

        public Criteria andCodUsumodIsNull() {
            addCriterion("cod_usumod is null");
            return this;
        }

        public Criteria andCodUsumodIsNotNull() {
            addCriterion("cod_usumod is not null");
            return this;
        }

        public Criteria andCodUsumodEqualTo(String value) {
            addCriterion("cod_usumod =", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotEqualTo(String value) {
            addCriterion("cod_usumod <>", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThan(String value) {
            addCriterion("cod_usumod >", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodGreaterThanOrEqualTo(String value) {
            addCriterion("cod_usumod >=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThan(String value) {
            addCriterion("cod_usumod <", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLessThanOrEqualTo(String value) {
            addCriterion("cod_usumod <=", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodLike(String value) {
            addCriterion("cod_usumod like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotLike(String value) {
            addCriterion("cod_usumod not like", value, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodIn(List<String> values) {
            addCriterion("cod_usumod in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotIn(List<String> values) {
            addCriterion("cod_usumod not in", values, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodBetween(String value1, String value2) {
            addCriterion("cod_usumod between", value1, value2, "codUsumod");
            return this;
        }

        public Criteria andCodUsumodNotBetween(String value1, String value2) {
            addCriterion("cod_usumod not between", value1, value2, "codUsumod");
            return this;
        }
    }
}