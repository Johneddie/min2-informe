package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Especialidad;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.EspecialidadDAO;

@Service("especialidadService")
public class EspecialidadServiceImpl implements EspecialidadService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	EspecialidadDAO especialidadDAO;

	public Especialidad obtenerEspecialidad(Integer key){
		return especialidadDAO.selectByPrimaryKey(key);
	}

	public int eliminarEspecialidad(Integer key){
		return especialidadDAO.deleteByPrimaryKey(key);
	}

	public int actualizarEspecialidad(Especialidad entidad){
		return especialidadDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarEspecialidad(Especialidad entidad){
		especialidadDAO.insertSelective(entidad);
	}

}
