package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Sesion;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.SesionDAO;

@Service("sesionService")
public class SesionServiceImpl implements SesionService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	SesionDAO sesionDAO;

	public Sesion obtenerSesion(Integer key){
		return sesionDAO.selectByPrimaryKey(key);
	}

	public int eliminarSesion(Integer key){
		return sesionDAO.deleteByPrimaryKey(key);
	}

	public int actualizarSesion(Sesion entidad){
		return sesionDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarSesion(Sesion entidad){
		sesionDAO.insertSelective(entidad);
	}

}
