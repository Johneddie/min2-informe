package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Archivo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoDAO;

@Service("archivoService")
public class ArchivoServiceImpl implements ArchivoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ArchivoDAO archivoDAO;

	public Archivo obtenerArchivo(Integer key){
		return archivoDAO.selectByPrimaryKey(key);
	}

	public int eliminarArchivo(Integer key){
		return archivoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarArchivo(Archivo entidad){
		return archivoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarArchivo(Archivo entidad){
		archivoDAO.insertSelective(entidad);
	}

}
