package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Servicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ServicioDAO;

@Service("servicioService")
public class ServicioServiceImpl implements ServicioService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ServicioDAO servicioDAO;

	public Servicio obtenerServicio(Integer key){
		return servicioDAO.selectByPrimaryKey(key);
	}

	public int eliminarServicio(Integer key){
		return servicioDAO.deleteByPrimaryKey(key);
	}

	public int actualizarServicio(Servicio entidad){
		return servicioDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarServicio(Servicio entidad){
		servicioDAO.insertSelective(entidad);
	}

}
