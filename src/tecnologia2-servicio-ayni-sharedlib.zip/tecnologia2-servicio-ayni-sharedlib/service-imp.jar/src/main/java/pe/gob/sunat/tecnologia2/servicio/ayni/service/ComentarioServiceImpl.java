package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Comentario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ComentarioDAO;

@Service("comentarioService")
public class ComentarioServiceImpl implements ComentarioService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ComentarioDAO comentarioDAO;

	public Comentario obtenerComentario(Integer key){
		return comentarioDAO.selectByPrimaryKey(key);
	}

	public int eliminarComentario(Integer key){
		return comentarioDAO.deleteByPrimaryKey(key);
	}

	public int actualizarComentario(Comentario entidad){
		return comentarioDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarComentario(Comentario entidad){
		comentarioDAO.insertSelective(entidad);
	}

}
