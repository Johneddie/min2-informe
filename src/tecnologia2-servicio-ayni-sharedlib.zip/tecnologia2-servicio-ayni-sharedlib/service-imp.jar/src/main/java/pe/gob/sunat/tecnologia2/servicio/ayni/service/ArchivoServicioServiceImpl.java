package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoServicioDAO;

@Service("archivoServicioService")
public class ArchivoServicioServiceImpl implements ArchivoServicioService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ArchivoServicioDAO archivoServicioDAO;

	public ArchivoServicio obtenerArchivoServicio(Integer key){
		return archivoServicioDAO.selectByPrimaryKey(key);
	}

	public int eliminarArchivoServicio(Integer key){
		return archivoServicioDAO.deleteByPrimaryKey(key);
	}

	public int actualizarArchivoServicio(ArchivoServicio entidad){
		return archivoServicioDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarArchivoServicio(ArchivoServicio entidad){
		archivoServicioDAO.insertSelective(entidad);
	}

}
