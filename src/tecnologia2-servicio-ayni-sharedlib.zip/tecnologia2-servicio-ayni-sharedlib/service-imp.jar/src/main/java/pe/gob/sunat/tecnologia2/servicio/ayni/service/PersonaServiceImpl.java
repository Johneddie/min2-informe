package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Persona;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.PersonaDAO;

@Service("personaService")
public class PersonaServiceImpl implements PersonaService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	PersonaDAO personaDAO;

	public Persona obtenerPersona(Integer key){
		return personaDAO.selectByPrimaryKey(key);
	}

	public int eliminarPersona(Integer key){
		return personaDAO.deleteByPrimaryKey(key);
	}

	public int actualizarPersona(Persona entidad){
		return personaDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarPersona(Persona entidad){
		personaDAO.insertSelective(entidad);
	}

}
