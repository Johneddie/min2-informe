package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionMensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.NotificacionMensajeDAO;

@Service("notificacionMensajeService")
public class NotificacionMensajeServiceImpl implements NotificacionMensajeService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	NotificacionMensajeDAO notificacionMensajeDAO;

	public NotificacionMensaje obtenerNotificacionMensaje(Integer key){
		return notificacionMensajeDAO.selectByPrimaryKey(key);
	}

	public int eliminarNotificacionMensaje(Integer key){
		return notificacionMensajeDAO.deleteByPrimaryKey(key);
	}

	public int actualizarNotificacionMensaje(NotificacionMensaje entidad){
		return notificacionMensajeDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarNotificacionMensaje(NotificacionMensaje entidad){
		notificacionMensajeDAO.insertSelective(entidad);
	}

}
