package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Ubigeo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.UbigeoDAO;

@Service("ubigeoService")
public class UbigeoServiceImpl implements UbigeoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	UbigeoDAO ubigeoDAO;

	public Ubigeo obtenerUbigeo(Integer key){
		return ubigeoDAO.selectByPrimaryKey(key);
	}

	public int eliminarUbigeo(Integer key){
		return ubigeoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarUbigeo(Ubigeo entidad){
		return ubigeoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarUbigeo(Ubigeo entidad){
		ubigeoDAO.insertSelective(entidad);
	}

}
