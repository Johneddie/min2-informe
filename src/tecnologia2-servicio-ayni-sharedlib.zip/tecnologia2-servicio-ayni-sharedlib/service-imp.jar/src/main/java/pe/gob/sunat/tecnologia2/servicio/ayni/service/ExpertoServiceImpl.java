package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Experto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ExpertoDAO;

@Service("expertoService")
public class ExpertoServiceImpl implements ExpertoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ExpertoDAO expertoDAO;

	public Experto obtenerExperto(Integer key){
		return expertoDAO.selectByPrimaryKey(key);
	}

	public int eliminarExperto(Integer key){
		return expertoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarExperto(Experto entidad){
		return expertoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarExperto(Experto entidad){
		expertoDAO.insertSelective(entidad);
	}

}
