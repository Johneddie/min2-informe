package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Diccionario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.DiccionarioDAO;

@Service("diccionarioService")
public class DiccionarioServiceImpl implements DiccionarioService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	DiccionarioDAO diccionarioDAO;

	public Diccionario obtenerDiccionario(Integer key){
		return diccionarioDAO.selectByPrimaryKey(key);
	}

	public int eliminarDiccionario(Integer key){
		return diccionarioDAO.deleteByPrimaryKey(key);
	}

	public int actualizarDiccionario(Diccionario entidad){
		return diccionarioDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarDiccionario(Diccionario entidad){
		diccionarioDAO.insertSelective(entidad);
	}

}
