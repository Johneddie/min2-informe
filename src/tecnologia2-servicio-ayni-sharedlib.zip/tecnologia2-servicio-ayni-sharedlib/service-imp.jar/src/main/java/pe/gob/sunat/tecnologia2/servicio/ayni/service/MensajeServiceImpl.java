package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Mensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.MensajeDAO;

@Service("mensajeService")
public class MensajeServiceImpl implements MensajeService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	MensajeDAO mensajeDAO;

	public Mensaje obtenerMensaje(Integer key){
		return mensajeDAO.selectByPrimaryKey(key);
	}

	public int eliminarMensaje(Integer key){
		return mensajeDAO.deleteByPrimaryKey(key);
	}

	public int actualizarMensaje(Mensaje entidad){
		return mensajeDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarMensaje(Mensaje entidad){
		mensajeDAO.insertSelective(entidad);
	}

}
