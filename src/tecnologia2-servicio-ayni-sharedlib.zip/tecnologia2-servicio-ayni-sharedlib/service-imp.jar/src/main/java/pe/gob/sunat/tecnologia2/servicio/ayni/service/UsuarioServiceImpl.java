package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Usuario;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.UsuarioDAO;

@Service("usuarioService")
public class UsuarioServiceImpl implements UsuarioService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	UsuarioDAO usuarioDAO;

	public Usuario obtenerUsuario(Integer key){
		return usuarioDAO.selectByPrimaryKey(key);
	}

	public int eliminarUsuario(Integer key){
		return usuarioDAO.deleteByPrimaryKey(key);
	}

	public int actualizarUsuario(Usuario entidad){
		return usuarioDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarUsuario(Usuario entidad){
		usuarioDAO.insertSelective(entidad);
	}

}
