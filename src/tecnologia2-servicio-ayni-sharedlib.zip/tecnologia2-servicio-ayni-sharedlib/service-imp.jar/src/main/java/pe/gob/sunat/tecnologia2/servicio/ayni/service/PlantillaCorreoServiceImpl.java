package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.PlantillaCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.PlantillaCorreoDAO;

@Service("plantillaCorreoService")
public class PlantillaCorreoServiceImpl implements PlantillaCorreoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	PlantillaCorreoDAO plantillaCorreoDAO;

	public PlantillaCorreo obtenerPlantillaCorreo(Integer key){
		return plantillaCorreoDAO.selectByPrimaryKey(key);
	}

	public int eliminarPlantillaCorreo(Integer key){
		return plantillaCorreoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarPlantillaCorreo(PlantillaCorreo entidad){
		return plantillaCorreoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarPlantillaCorreo(PlantillaCorreo entidad){
		plantillaCorreoDAO.insertSelective(entidad);
	}

}
