package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.MaestroParametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.MaestroParametroDAO;

@Service("maestroParametroService")
public class MaestroParametroServiceImpl implements MaestroParametroService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	MaestroParametroDAO maestroParametroDAO;

	public MaestroParametro obtenerMaestroParametro(Integer key){
		return maestroParametroDAO.selectByPrimaryKey(key);
	}

	public int eliminarMaestroParametro(Integer key){
		return maestroParametroDAO.deleteByPrimaryKey(key);
	}

	public int actualizarMaestroParametro(MaestroParametro entidad){
		return maestroParametroDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarMaestroParametro(MaestroParametro entidad){
		maestroParametroDAO.insertSelective(entidad);
	}

}
