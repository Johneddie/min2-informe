package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Parametro;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ParametroDAO;

@Service("parametroService")
public class ParametroServiceImpl implements ParametroService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ParametroDAO parametroDAO;

	public Parametro obtenerParametro(Integer key){
		return parametroDAO.selectByPrimaryKey(key);
	}

	public int eliminarParametro(Integer key){
		return parametroDAO.deleteByPrimaryKey(key);
	}

	public int actualizarParametro(Parametro entidad){
		return parametroDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarParametro(Parametro entidad){
		parametroDAO.insertSelective(entidad);
	}

}
