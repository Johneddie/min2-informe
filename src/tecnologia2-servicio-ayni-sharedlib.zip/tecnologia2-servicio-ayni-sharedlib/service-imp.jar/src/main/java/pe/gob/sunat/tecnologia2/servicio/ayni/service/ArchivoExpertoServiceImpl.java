package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoExperto;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.ArchivoExpertoDAO;

@Service("archivoExpertoService")
public class ArchivoExpertoServiceImpl implements ArchivoExpertoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ArchivoExpertoDAO archivoExpertoDAO;

	public ArchivoExperto obtenerArchivoExperto(Integer key){
		return archivoExpertoDAO.selectByPrimaryKey(key);
	}

	public int eliminarArchivoExperto(Integer key){
		return archivoExpertoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarArchivoExperto(ArchivoExperto entidad){
		return archivoExpertoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarArchivoExperto(ArchivoExperto entidad){
		archivoExpertoDAO.insertSelective(entidad);
	}

}
