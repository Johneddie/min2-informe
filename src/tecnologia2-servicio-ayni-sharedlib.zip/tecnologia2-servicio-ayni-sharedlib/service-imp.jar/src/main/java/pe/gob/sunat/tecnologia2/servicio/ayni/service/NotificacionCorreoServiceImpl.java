package pe.gob.sunat.tecnologia2.servicio.ayni.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.NotificacionCorreo;
import pe.gob.sunat.tecnologia2.servicio.ayni.model.dao.NotificacionCorreoDAO;

@Service("notificacionCorreoService")
public class NotificacionCorreoServiceImpl implements NotificacionCorreoService {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	NotificacionCorreoDAO notificacionCorreoDAO;

	public NotificacionCorreo obtenerNotificacionCorreo(Integer key){
		return notificacionCorreoDAO.selectByPrimaryKey(key);
	}

	public int eliminarNotificacionCorreo(Integer key){
		return notificacionCorreoDAO.deleteByPrimaryKey(key);
	}

	public int actualizarNotificacionCorreo(NotificacionCorreo entidad){
		return notificacionCorreoDAO.updateByPrimaryKeySelective(entidad);
	}

	public void insertarNotificacionCorreo(NotificacionCorreo entidad){
		notificacionCorreoDAO.insertSelective(entidad);
	}

}
