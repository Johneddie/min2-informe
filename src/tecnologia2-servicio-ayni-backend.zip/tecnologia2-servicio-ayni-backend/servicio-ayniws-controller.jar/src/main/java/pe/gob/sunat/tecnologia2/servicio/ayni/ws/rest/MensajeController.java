package pe.gob.sunat.tecnologia2.servicio.ayni.ws.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Mensaje;
import pe.gob.sunat.tecnologia2.servicio.ayni.service.MensajeService;

@Controller
@RequestMapping(value="/mensaje")
public class MensajeController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	MensajeService mensajeService;


	@RequestMapping(method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody void registrarMensaje(@RequestBody Mensaje mensaje) {
		mensajeService.insertarMensaje(mensaje);
		return;
	}


	@RequestMapping(value = "/{key}",method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Mensaje buscarMensaje(@PathVariable Integer key) {
		return mensajeService.obtenerMensaje(key);
	}

}
