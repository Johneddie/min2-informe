package pe.gob.sunat.tecnologia2.servicio.ayni.ws.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.Ubigeo;
import pe.gob.sunat.tecnologia2.servicio.ayni.service.UbigeoService;

@Controller
@RequestMapping(value="/ubigeo")
public class UbigeoController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	UbigeoService ubigeoService;


	@RequestMapping(method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody void registrarUbigeo(@RequestBody Ubigeo ubigeo) {
		ubigeoService.insertarUbigeo(ubigeo);
		return;
	}


	@RequestMapping(value = "/{key}",method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Ubigeo buscarUbigeo(@PathVariable Integer key) {
		return ubigeoService.obtenerUbigeo(key);
	}

}
