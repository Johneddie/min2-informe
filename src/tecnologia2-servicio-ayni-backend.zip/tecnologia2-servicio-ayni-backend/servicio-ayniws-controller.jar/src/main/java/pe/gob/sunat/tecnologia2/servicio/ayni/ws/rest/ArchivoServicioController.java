package pe.gob.sunat.tecnologia2.servicio.ayni.ws.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import pe.gob.sunat.tecnologia2.servicio.ayni.model.ArchivoServicio;
import pe.gob.sunat.tecnologia2.servicio.ayni.service.ArchivoServicioService;

@Controller
@RequestMapping(value="/archivoServicio")
public class ArchivoServicioController {

	protected final Log log = LogFactory.getLog(getClass());

	@Autowired
	ArchivoServicioService archivoServicioService;


	@RequestMapping(method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody void registrarArchivoServicio(@RequestBody ArchivoServicio archivoServicio) {
		archivoServicioService.insertarArchivoServicio(archivoServicio);
		return;
	}


	@RequestMapping(value = "/{key}",method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ArchivoServicio buscarArchivoServicio(@PathVariable Integer key) {
		return archivoServicioService.obtenerArchivoServicio(key);
	}

}
