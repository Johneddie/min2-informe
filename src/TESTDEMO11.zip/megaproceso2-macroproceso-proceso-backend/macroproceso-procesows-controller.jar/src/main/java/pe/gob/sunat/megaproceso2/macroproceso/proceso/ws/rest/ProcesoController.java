package pe.gob.sunat.megaproceso2.macroproceso.proceso.ws.rest;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

/**
 * Handles requests for the application home page.
 * 
 * /proceso.htm?action=tarea1
 * /proceso/tarea1 
 */
@Controller
@RequestMapping(value="/proceso")
public class ProcesoController {
	

	@Autowired
	ConsultaCacheable consultaCacheable;
	
	protected final Log log = LogFactory.getLog(getClass());
	
	@RequestMapping(value="lista",
			method={RequestMethod.GET},
			produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<DemoEntidad> getListaFromCache(){
		List<DemoEntidad> entidades = consultaCacheable.getListaFromCache();
		if(log.isDebugEnabled()){
			log.debug("Por aqui no paso");
		}
		
		return entidades;
	}

	@RequestMapping(value="testlog",
			method={RequestMethod.GET},
			produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody String testLog(){
		if(log.isDebugEnabled()){
			log.debug("Por aqui no paso");
		}
		return log.toString();
	}
	
	
}
