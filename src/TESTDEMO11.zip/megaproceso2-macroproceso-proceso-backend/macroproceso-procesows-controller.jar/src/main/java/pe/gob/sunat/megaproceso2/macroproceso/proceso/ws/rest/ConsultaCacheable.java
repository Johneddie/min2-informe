package pe.gob.sunat.megaproceso2.macroproceso.proceso.ws.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springmodules.cache.CachingModel;

import pe.gob.sunat.framework.spring.util.cache2.bean.CacheParamProvider;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.service.DemoProcesoService;

@Service
public class ConsultaCacheable {
	
	@Autowired
	FabricaDeServicios serviceFactory;
	
	@Autowired
	@Qualifier("cacheProvider")
	CacheParamProvider cache;
	
	@SuppressWarnings("unchecked")
	public List<DemoEntidad> getListaFromCache(){
		List<DemoEntidad> entidades = new ArrayList<DemoEntidad>();
		entidades = (List<DemoEntidad>) cache.getCacheProvider().getFromCache("123", cache.getCachingModelData());
		if(entidades == null){
			System.out.println("Consultando a la BD");
			DemoProcesoService service = serviceFactory.getService("proceso.demoProcesoService");
			entidades = service.listarDemoEntidad();
			CachingModel cachingModel =  cache.getCachingModelData();
			System.out.println("guardando en cache");
			cache.getCacheProvider().putInCache("123", cachingModel, entidades);
		}
		return entidades;
	}
}
