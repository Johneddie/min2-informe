package pe.gob.sunat.megaproceso2.macroproceso.proceso.ws.rest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;

import pe.gob.sunat.framework.spring.util.exception.BusinessValidationException;
import pe.gob.sunat.framework.spring.util.factory.FabricaDeServicios;
import pe.gob.sunat.framework.spring.util.ws.rest.Hyperlink;
import pe.gob.sunat.framework.spring.util.ws.rest.RequestParamParser;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.EntidadConHyperlinks;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.service.DemoProcesoService;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.service.SubRecursoService;

/**
 * Controller REST de ejemplo 
 * @author nsullcar
 */
@Controller
@RequestMapping(value="/recursosuno")
public class RecursoUnoRestController {
	

	@Autowired
	FabricaDeServicios serviceFactory;

	//definimos un variable para almacenar el URI este Recurso http://api.sunat.peru/v1/dominio/proceso/e/recursosuno
	public final static String URI_RECURSO = Hyperlink.getURLv1ServicioEntidad("dominio", "proceso","recursosuno");
	
	@RequestMapping(
					method=RequestMethod.GET,
					produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<DemoEntidad> listarRecursoUnoConAtribFilter(@RequestParam Map<String, String> requestParams) {
		DemoProcesoService service = serviceFactory.getService("proceso.demoProcesoService");
		List<DemoEntidad> entidades = new ArrayList<DemoEntidad>();
		if(requestParams == null || requestParams.isEmpty()){
			entidades = service.listarDemoEntidad();
		}else{
			//Parsear los request params
			entidades = service.listarDemoEntidadWithFilters(RequestParamParser.parse(requestParams));
		}
		return entidades;
	}
	
	@RequestMapping(method=RequestMethod.POST,
					consumes={MediaType.APPLICATION_JSON_VALUE},
					produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody DemoEntidad registrarRecursoUno(DemoEntidad entidad,@RequestParam Map<String, String> requestParams) {
		entidad.setCodCatalogo("nuevo");
		return entidad;
	}	
	
	@RequestMapping(value = "/{id1:[^-]+}", method=RequestMethod.GET,
											produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody DemoEntidad obtenerRecursoUnoPorID(@PathVariable String id1) throws Exception {
		DemoProcesoService service = serviceFactory.getService("proceso.demoProcesoService");
		DemoEntidad entidad = service.obtenerDemoEntidadPorID("999",id1);
		if (entidad == null){//404
			throw new NoSuchRequestHandlingMethodException("/recursosuno/"+id1, "obtenerRecursoUnoPorID",null);	
		}
		return entidad;
	}

	@RequestMapping(value = "/{id1}-{id2}", method=RequestMethod.GET,
											produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody DemoEntidad obtenerRecursoUnoPorIDCompuesto(@PathVariable("id1") String id1, @PathVariable("id2") String id2) throws Exception {
		DemoProcesoService service = serviceFactory.getService("proceso.demoProcesoService");
		DemoEntidad entidad = service.obtenerDemoEntidadPorID(id1,id2);
		if (entidad == null){//404
			throw new NoSuchRequestHandlingMethodException("/"+id1+"-"+id2, this.getClass());
		}
		return entidad;
	}
	
	@RequestMapping(value = "/{id}",method=RequestMethod.PUT,
									consumes={MediaType.APPLICATION_JSON_VALUE},
									produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody DemoEntidad actualizarRecursoUnoPorID(@PathVariable("id") String id,
															   @RequestBody DemoEntidad entidad
															  ) {
		entidad.setCodEstado("actualizado");
		return entidad;
	}
	
	@RequestMapping(value = "/{id1:[^-]+}/subrecursos", method=RequestMethod.GET,
														produces={MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody List<DemoEntidad> listarSubRecursoDeRecursoUnoPorID(@PathVariable String id1) throws Exception {
		SubRecursoService srservice = serviceFactory.getService("proceso.subRecursoService");
		List<DemoEntidad> listaentidades = srservice.listarSubRecursos();
		return listaentidades;
	}


/** Estos dos metodos son solo para ejemplo de un exception y una validacion no se debenn copiar ni implementar**/
	//Este lanzara un NullPointerException (en teoria no esperado)
	@RequestMapping(value = "/exception", method = RequestMethod.GET)
	public @ResponseBody DemoEntidad getException() {
		DemoEntidad entidad=null;
		entidad.setCodEstado("exception"); //NullPointer
		entidad.setDesDatacat("descri");
		return entidad;
	}
	
	//Este lanzara un BusinessValidationException programaticamente
	@RequestMapping(value = "/validation", method = RequestMethod.GET)
	public @ResponseBody DemoEntidad getValidation() throws Exception {
		Map<String, String> resp= new HashMap<String, String>();
		resp.put("cod", "12345");
		resp.put("msg", "El RUC 123455676 es Invalido");
		
		throw new BusinessValidationException(resp);
	}

	@RequestMapping(value = "/hyperlinks" , method = RequestMethod.GET)
	public @ResponseBody EntidadConHyperlinks getEntidadConHyperlinks() throws Exception {
		//Clase Entidad que extiende de RestModelBase
		EntidadConHyperlinks e = new EntidadConHyperlinks();
		//Seteamos algunos atributos
		e.setAtrib1("atrib1");
		e.setAtrib2("atrib2");
		//Creamos 2 hyperlinks
		Hyperlink hl = new Hyperlink(  URI_RECURSO + "/hyperlinks").withRel(Hyperlink.REL_SELF);
		Hyperlink hl2 = new Hyperlink( URI_RECURSO + "/otrorecurso" ).withRel("otrarel");
		
		//le adicionamos los hyperlinks a la Entidad
		e.add(hl);
		e.add(hl2);
		//devolvemos
		return e;
	}

}
