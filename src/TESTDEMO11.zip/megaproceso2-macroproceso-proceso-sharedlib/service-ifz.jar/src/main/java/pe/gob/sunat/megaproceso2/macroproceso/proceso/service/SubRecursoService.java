package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.List;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

public interface SubRecursoService {
		
	public List<DemoEntidad> listarSubRecursos();

	public DemoEntidad obtenerSubRecursoPorID(String idSubrecurso);

}
