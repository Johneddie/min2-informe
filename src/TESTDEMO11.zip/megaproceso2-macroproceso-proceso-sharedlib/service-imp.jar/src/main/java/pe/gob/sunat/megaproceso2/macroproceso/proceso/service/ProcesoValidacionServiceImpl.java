package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

@Service("proceso.procesoValidacionService")
public class ProcesoValidacionServiceImpl implements ProcesoValidacionService {

	@Override
	public List<Map<String, String>> validarAlgunaCosa(DemoEntidad entidad) {
		List<Map<String, String>> listaErrores = new ArrayList<Map<String,String>>();
		Map<String, String> resp= new HashMap<String, String>();
		
		//Validar el RUC		
		resp.put("cod", "10004");
		resp.put("msg", "El RUC 123455676 es Invalido");
		listaErrores.add(resp);
		//Validar otro Dato
		resp.put("cod", "20004");
		resp.put("msg", "La fecha 21/02/2015 esta fuera del intervalo 01/01/2015 - 31/01/2015");
		listaErrores.add(resp);
		
		
		return listaErrores;
	}

}
