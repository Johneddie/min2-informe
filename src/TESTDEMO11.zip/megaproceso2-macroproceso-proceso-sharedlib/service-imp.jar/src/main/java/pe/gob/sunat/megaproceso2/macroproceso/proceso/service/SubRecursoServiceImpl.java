package pe.gob.sunat.megaproceso2.macroproceso.proceso.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

@Service("proceso.subRecursoService")
public class SubRecursoServiceImpl implements SubRecursoService {

	@Override
	public List<DemoEntidad> listarSubRecursos() {
		List<DemoEntidad> lista = new ArrayList<DemoEntidad>();
		DemoEntidad entidad = new DemoEntidad();
		entidad.setCodCatalogo("999");
		entidad.setCodDatacat("XXX");
		lista.add(entidad);
		entidad = new DemoEntidad();
		entidad.setCodCatalogo("999");
		entidad.setCodDatacat("YYY");
		lista.add(entidad);
		return lista;
	}

	@Override
	public DemoEntidad obtenerSubRecursoPorID(String idSubrecurso) {
		DemoEntidad entidad = new DemoEntidad();
		entidad.setCodCatalogo("999");
		entidad.setCodDatacat(idSubrecurso);
		return entidad;
	}

}
