package pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.ibatis;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.Empleado;
import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao.EmpleadoDAO;

public class SqlMapEmpleadoDAO implements EmpleadoDAO {

	@Override
	public List<Empleado> obtenerListaEmpleados() {
		List<Empleado> lista = new ArrayList<Empleado>(); 
		Empleado e = new Empleado();
		e.setNombre("nombre1");
		e.setCargo("cargo1");
		e.setSalario(new BigDecimal("200.45"));
		e.setFechaIngreso(new Date());

		lista.add(e);
		
		e = new Empleado();
		e.setNombre("nombre2");
		e.setCargo("cargo2");
		e.setSalario(new BigDecimal("201.45"));
		e.setFechaIngreso(new Date());
		
		lista.add(e);
		
		e = new Empleado();
		e.setNombre("nombre3");
		e.setCargo("cargo3");
		e.setSalario(new BigDecimal("202.45"));
		e.setFechaIngreso(new Date());
		
		lista.add(e);

		return lista;
	}

}
