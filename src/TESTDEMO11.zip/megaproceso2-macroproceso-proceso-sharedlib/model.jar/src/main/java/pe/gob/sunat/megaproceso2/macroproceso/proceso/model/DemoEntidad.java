package pe.gob.sunat.megaproceso2.macroproceso.proceso.model;

import java.util.Date;

public class DemoEntidad {
	
	private String codCatalogo; 
    private String codDatacat; 
    private Date fecInidatcat; 
    private String desDatacat; 
    private String codEstado; 
	private String indRegActual;
	//linea1
	//linea2
	//linea3
	 //linea4 otros datos
	public String getCodCatalogo() {
		return codCatalogo;
	}
	public void setCodCatalogo(String codCatalogo) {
		this.codCatalogo = codCatalogo;
	}
	public String getCodDatacat() {
		return codDatacat;
	}
	public void setCodDatacat(String codDatacat) {
		this.codDatacat = codDatacat;
	}
	public Date getFecInidatcat() {
		return fecInidatcat;
	}
	public void setFecInidatcat(Date fecInidatcat) {
		this.fecInidatcat = fecInidatcat;
	}
	public String getDesDatacat() {
		return desDatacat;
	}
	public void setDesDatacat(String desDatacat) {
		this.desDatacat = desDatacat;
	}
	public String getCodEstado() {
		return codEstado;
	}
	public void setCodEstado(String codEstado) {
		this.codEstado = codEstado;
	}
	public String getIndRegActual() {
		return indRegActual;
	}
	public void setIndRegActual(String indRegActual) {
		this.indRegActual = indRegActual;
	}

	
	
}
