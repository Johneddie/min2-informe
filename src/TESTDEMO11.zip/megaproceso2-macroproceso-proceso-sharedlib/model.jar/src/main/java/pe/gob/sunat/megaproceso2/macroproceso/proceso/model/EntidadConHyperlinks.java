package pe.gob.sunat.megaproceso2.macroproceso.proceso.model;

import java.io.Serializable;

import pe.gob.sunat.framework.spring.util.ws.rest.RestModelBase;

public class EntidadConHyperlinks extends RestModelBase implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//linea3
	//linea4 mas datos
	
	private String atrib1;
	private String atrib2;
	public String getAtrib1() {
		return atrib1;
	}
	public void setAtrib1(String atrib1) {
		this.atrib1 = atrib1;
	}
	public String getAtrib2() {
		return atrib2;
	}
	public void setAtrib2(String atrib2) {
		this.atrib2 = atrib2;
	}
	
	
}
