package pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao;

import java.util.List;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.Empleado;

public interface EmpleadoDAO {
	public List<Empleado> obtenerListaEmpleados();
}
