package pe.gob.sunat.megaproceso2.macroproceso.proceso.model.dao;

import java.util.List;
import java.util.Map;

import pe.gob.sunat.megaproceso2.macroproceso.proceso.model.DemoEntidad;

public interface DemoEntidadDAO {

	public List<DemoEntidad>  listarDemoEntidad();
	
	public DemoEntidad obtenerDemoEntidadPorID(String codCatalogo,String codDatacat);

	public DemoEntidad registrarDemoEntidad(DemoEntidad entidad);
	
	public DemoEntidad actualizarDemoEntidad(DemoEntidad entidad);

	public List<DemoEntidad> listarDemoEntidadWithColumnFilter(Map params);
	
}
