package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author oachahuic
 *
 */
public class CreaProyectoGit {
	public static final String APLICACION_BACKEND = "backend";
	public static final String APLICACION_BATCH = "batch";
	public static final String APLICACION_SHARELIDLIB = "sharedlib";
	public static final String APLICACION_WEBAPP = "webapp";
	public static final String NEXT_LINE = "\r\n";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("INICIO--->CreaProyectoGit");
		////////////////////// INICIO MODIFICAR PARAMETROS //////////////////////
		//PARAMETROS GLOBALES
		Map<String, String> mapParam = new HashMap<String, String>();
		mapParam.put("rutaRaiz", "D:\\proyectos\\GIT3");
		mapParam.put("megaproceso", "recaudacion");
		mapParam.put("megaproceso2", "recaudacion2");
		mapParam.put("negocio", "tributaria");
		mapParam.put("macroproceso", "gestiondeuda");
		mapParam.put("proceso", "embargos");
		mapParam.put("numPase", "PAS20175E230300051");
		mapParam.put("baseDatos", "sigmce");
		
		//PARAMETROS PARA EL WEBAPP
		List<Map<String, String>> listMapContextWebApp = new ArrayList<Map<String, String>>();
		Map<String, String> mapContextWebApp = new HashMap<String, String>();
		mapContextWebApp.put("nomWar", "iagestiondeuda-embargos");//SIN EXTENCIÓN
		mapContextWebApp.put("contexto", "cl-at-iagestiondeuda-embargos");
		listMapContextWebApp.add(mapContextWebApp);//PUEDEN AGREGAR MAS CONTEXTOS INICIALIZANDO EL mapContextWebApp Y ADD AL listMapContextWebApp
		mapParam.put("clase-controller", "ConsultaValoresController");
		
		//PARAMETROS PARA EL BACKEND
		Map<String, String> mapContextBackend = new HashMap<String, String>();
		mapContextBackend.put("nomWar", "iagestiondeuda-embargos-ws");//SIN EXTENCIÓN
		mapContextBackend.put("contexto", "ol-ti-iagestiondeuda-embargos-ws");
		mapParam.put("clase-rest-controller", "ValoresRestController");
		mapParam.put("recurso", "valores");
		
		//PARAMETROS PARA EL SHAREDLIB - CLASES INICIALES
		mapParam.put("entidad", "valores");
		mapParam.put("clase-model", "Valores");
		mapParam.put("clase-dao-ifz", "ValoresDAO");
		mapParam.put("clase-dao-imp", "SqlMapValoresDAO");
		mapParam.put("clase-service-ifz", "ConsultaValoresService");
		mapParam.put("clase-service-imp", "ConsultaValoresServiceImpl");
		mapParam.put("rutaCopiaEar", "d:/ears");
		
		//DEPENDENCIAS
		mapParam.put("sharedlib-tercero-spe-version", "2.0");
		mapParam.put("sharedlib-tercero-imp-version", "2.10.92");
		mapParam.put("sharedlib-seguridad-spe-version", "1.0");
		mapParam.put("sharedlib-seguridad-imp-version", "1.4.0");
		mapParam.put("sharedlib-framework2-spe-version", "2.0");
		mapParam.put("sharedlib-framework2-imp-version", "2.7.1");
		
		try {
			//DESCOMENTAR LOS PROYECTOS A GENERAR
			generarProyectoSharedlib(mapParam);
			generarProyectoWebApp(mapParam, listMapContextWebApp);
			generarProyectoBackend(mapParam, mapContextBackend);
			generarProyectoBatch(mapParam);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//////////////////// FIN MODIFICAR PARAMETROS //////////////////////
		System.out.println("FIN--->CreaProyectoGit");
	}
	
	private static void generarProyectoSharedlib(Map<String, String> mapParam) throws IOException {
		System.out.println("INICIO--->generarProyectoSharedlib");
		
		StringBuilder dirProyecto = new StringBuilder(mapParam.get("rutaRaiz"));
		dirProyecto.append("\\");
		dirProyecto.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			dirProyecto.append(mapParam.get("negocio")).append("-");
		}
		dirProyecto.append(mapParam.get("macroproceso")).append("-");
		dirProyecto.append(mapParam.get("proceso")).append("-sharedlib");

		//ELIMINAR DIRECTORIO DEL PROYECTO
		delete(new File(dirProyecto.toString()));

		//CREANDO DIRECTORIO DEL PROYECTO
		File file = new File(dirProyecto.toString());
		file.mkdirs();
		
		//CREAR ARCHIVOS DEL DIRECTORIO PRINCIPAL
		file = new File(dirProyecto.toString(), ".gitignore");
		file.createNewFile();
		agregarTextoGitignore(file.getPath());
		file = new File(dirProyecto.toString(), "build.gradle");
		file.createNewFile();
		agregarTextoBuilGradleRaiz(file.getPath(), mapParam, "sharedlib");
		file = new File(dirProyecto.toString(), "Readme.txt");
		file.createNewFile();
		file = new File(dirProyecto.toString(), "settings.gradle");
		file.createNewFile();
		agregarTextoSettingsSharedlib(file.getPath(), mapParam);
		
		List<String> listDep = new ArrayList<String>();
		StringBuilder desMacroYProc = new StringBuilder();
		desMacroYProc.append(mapParam.get("macroproceso"));
		desMacroYProc.append("-");
		desMacroYProc.append(mapParam.get("proceso"));
		
		//CREAR CARPETAS COMPONENTES
		mapParam.put("dirProyecto", dirProyecto.toString());
		mapParam.put("componente", "model.jar");
		crearDirComponenteSharedlib(mapParam, listDep);
		
		mapParam.put("componente", "dao-ifz.jar");
		listDep.add(desMacroYProc.toString() + "-model");
		crearDirComponenteSharedlib(mapParam, listDep);
		
		mapParam.put("componente", "dao-imp.jar");
		listDep = new ArrayList<String>();
		listDep.add(desMacroYProc.toString() + "-model");
		listDep.add(desMacroYProc.toString() + "-dao-ifz");
		crearDirComponenteSharedlib(mapParam, listDep);
		
		mapParam.put("componente", "service-ifz.jar");
		listDep = new ArrayList<String>();
		listDep.add(desMacroYProc.toString() + "-model");
		listDep.add(desMacroYProc.toString() + "-dao-ifz");
		crearDirComponenteSharedlib(mapParam, listDep);

		mapParam.put("componente", "service-imp.jar");
		listDep = new ArrayList<String>();
		listDep.add(desMacroYProc.toString() + "-model");
		listDep.add(desMacroYProc.toString() + "-dao-ifz");
		listDep.add(desMacroYProc.toString() + "-service-ifz");
		crearDirComponenteSharedlib(mapParam, listDep);
		
		//CREAR CARPETA SLB
		StringBuilder dirSlb = new StringBuilder(dirProyecto);
		dirSlb.append("\\slb.ear");
		file = new File(dirSlb.toString());
		file.mkdirs();
		file = new File(dirSlb.toString(), "build.gradle");
		file.createNewFile();
		agregarTextoBuilGradleSlb(file.getPath(), desMacroYProc.toString(), mapParam.get("rutaCopiaEar"));
		dirSlb.append("\\src\\main\\application\\META-INF");
		file = new File(dirSlb.toString());
		file.mkdirs();
		file = new File(dirSlb.toString(), "weblogic-application.xml");
		file.createNewFile();
		
		System.out.println("FIN--->generarProyectoSharedlib");
	}
	
	private static void crearDirComponenteSharedlib(Map<String, String> mapParametros, List<String> listDep) throws IOException {
		System.out.println("INICIO--->crearDirComponente--->" + mapParametros.get("componente"));
		StringBuilder sbFileXml = null;
		StringBuilder dirComponente = new StringBuilder(mapParametros.get("dirProyecto"));
		dirComponente.append("\\").append(mapParametros.get("componente"));
		File file = new File(dirComponente.toString());
		file.mkdirs();
		file = new File(dirComponente.toString(), "build.gradle");
		file.createNewFile();
		//AGREGAR TEXTO AL ARCHIVO CREADO
		agregarTextoBuilGradleJar(file.getPath(), listDep);
		
		System.out.println("dirComponente--->" + dirComponente.toString());
		StringBuilder dirJava = new StringBuilder(dirComponente);
		dirJava.append("\\src\\main\\java\\pe\\gob\\sunat\\");
		StringBuilder packageJava = new StringBuilder("pe.gob.sunat");
		dirJava.append(mapParametros.get("megaproceso2")).append("\\");
		packageJava.append(".").append(mapParametros.get("megaproceso2"));
		if (mapParametros.get("negocio") != null) {
			dirJava.append(mapParametros.get("negocio")).append("\\");
			packageJava.append(".").append(mapParametros.get("negocio"));
		}
		dirJava.append(mapParametros.get("macroproceso")).append("\\");
		packageJava.append(".").append(mapParametros.get("macroproceso"));
		dirJava.append(mapParametros.get("proceso"));
		packageJava.append(".").append(mapParametros.get("proceso"));
		
		if ("model.jar".equals(mapParametros.get("componente"))) {
			dirJava.append("\\model");
			packageJava.append(".").append("model");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParametros.get("clase-model") + ".java");
			file.createNewFile();
			agregarTextClaseJava(file.getPath(), packageJava.toString(), "model" , mapParametros);
		} else if ("dao-ifz.jar".equals(mapParametros.get("componente"))) {
			dirJava.append("\\model\\dao");
			packageJava.append(".").append("model.dao");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParametros.get("clase-dao-ifz") + ".java");
			file.createNewFile();
			agregarTextClaseJava(file.getPath(), packageJava.toString(), "dao-ifz" , mapParametros);
		} else if ("dao-imp.jar".equals(mapParametros.get("componente"))) {
			//CREAR DIR JAVA
			dirJava.append("\\model\\dao\\ibatis");
			packageJava.append(".").append("model.dao.ibatis");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParametros.get("clase-dao-imp") + ".java");
			file.createNewFile();
			agregarTextClaseJava(file.getPath(), packageJava.toString(), "dao-imp" , mapParametros);
			//CREAR DIR Y ARCHIVOS RESOURCES
			StringBuilder dirResources = new StringBuilder(dirComponente);
			System.out.println("dirResources--->" + dirResources.toString());
			dirResources.append("\\src\\main\\resources");
			file = new File(dirResources.toString());
			file.mkdirs();
			sbFileXml = new StringBuilder(mapParametros.get("macroproceso"));
			sbFileXml.append("-");
			sbFileXml.append(mapParametros.get("proceso"));
			sbFileXml.append("-data.xml");
			file = new File(dirResources.toString(), sbFileXml.toString());
			file.createNewFile();
			sbFileXml = new StringBuilder("sql-map-config-");
			sbFileXml.append(mapParametros.get("proceso"));
			sbFileXml.append(".xml");
			file = new File(dirResources.toString(), sbFileXml.toString());
			file.createNewFile();
			dirResources.append("\\pe\\gob\\sunat\\");
			dirResources.append(mapParametros.get("megaproceso2")).append("\\");
			if (mapParametros.get("negocio") != null) {
				dirResources.append(mapParametros.get("negocio")).append("\\");
			}
			dirResources.append(mapParametros.get("macroproceso")).append("\\");
			dirResources.append(mapParametros.get("proceso"));
			dirResources.append("\\model\\dao\\ibatis\\maps");
			file = new File(dirResources.toString());
			file.mkdirs();
			file = new File(dirResources.toString(), mapParametros.get("entidad") + ".xml");
			file.createNewFile();
		} else if ("service-ifz.jar".equals(mapParametros.get("componente"))) {
			dirJava.append("\\service");
			packageJava.append(".").append("service");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParametros.get("clase-service-ifz") + ".java");
			file.createNewFile();
			agregarTextClaseJava(file.getPath(), packageJava.toString(), "service-ifz" , mapParametros);
		} else if ("service-imp.jar".equals(mapParametros.get("componente"))) {
			//CREAR DIR JAVA
			dirJava.append("\\service");
			packageJava.append(".").append("service");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParametros.get("clase-service-imp") + ".java");
			file.createNewFile();
			agregarTextClaseJava(file.getPath(), packageJava.toString(), "service-imp" , mapParametros);
			//CREAR DIR Y ARCHIVOS RESOURCES
			StringBuilder dirResources = new StringBuilder(dirComponente);
			System.out.println("dirResources--->" + dirResources.toString());
			dirResources.append("\\src\\main\\resources");
			file = new File(dirResources.toString());
			file.mkdirs();
			sbFileXml = new StringBuilder(mapParametros.get("macroproceso"));
			sbFileXml.append("-");
			sbFileXml.append(mapParametros.get("proceso"));
			sbFileXml.append("-service.xml");
			file = new File(dirResources.toString(), sbFileXml.toString());
			file.createNewFile();
		} else {
			System.out.println(mapParametros.get("componente") + "SIN IMPLEMENTACIÓN");
		}
		System.out.println("FIN--->crearDirComponente--->" + mapParametros.get("componente"));
	}

	private static void generarProyectoBackend(Map<String, String> mapParam, Map<String, String> mapContextBackend) throws IOException {
		System.out.println("INICIO--->generarProyectoBackend");
		
		//NOMBRE DEL EAR
		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append("-");
		}
		sbTemp.append(mapParam.get("macroproceso")).append("-");
		sbTemp.append(mapParam.get("proceso")).append("-backend.ear");
		mapParam.put("nomEar", sbTemp.toString());
		
		//NOMBRE DEL WAR
		sbTemp = new StringBuilder();
		sbTemp.append(mapContextBackend.get("nomWar")).append(".war");
		mapParam.put("nomWar", sbTemp.toString());

		//NOMBRE DEL JAR
		sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("macroproceso")).append("-").append(mapParam.get("proceso")).append("ws-controller.jar");
		mapParam.put("nomJar", sbTemp.toString());
		
		//PACKAGE CONTROLLER REST
		sbTemp = new StringBuilder("pe.gob.sunat.");
		sbTemp.append(mapParam.get("megaproceso2")).append(".");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append(".");
		}
		sbTemp.append(mapParam.get("macroproceso")).append(".");
		sbTemp.append(mapParam.get("proceso"));
		mapParam.put("packageProceso", sbTemp.toString());
		
		
		//DEFINIR DIRECTORIO PRINCIPAL
		StringBuilder dirProyecto = new StringBuilder(mapParam.get("rutaRaiz"));
		dirProyecto.append("\\");
		dirProyecto.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			dirProyecto.append(mapParam.get("negocio")).append("-");
		}
		dirProyecto.append(mapParam.get("macroproceso")).append("-");
		dirProyecto.append(mapParam.get("proceso")).append("-backend");

		//ELIMINAR DIRECTORIO DEL PROYECTO
		delete(new File(dirProyecto.toString()));
		
		//CREAR DIRECTORIO DEL PROYECTO
		File file = new File(dirProyecto.toString());
		file.mkdirs();
		
		mapParam.put("dirProyecto", dirProyecto.toString());
		
		//CREAR DIRECTORIO WAR
		crearDirWar(mapParam, mapContextBackend, APLICACION_BACKEND);
		
		//CREAR DIRECTORIO JAR
		crearDirControllerJar(mapParam, APLICACION_BACKEND);
		
		//CREAR DIRECTORIO EAR
		List<Map<String, String>> listMapContext = new ArrayList<Map<String, String>>();
		listMapContext.add(mapContextBackend);
		crearDirEar(mapParam, listMapContext, APLICACION_BACKEND);
		
		//CREAR ARCHIVOS DEL DIRECTORIO PRINCIPAL
		file = new File(dirProyecto.toString(), ".gitignore");
		file.createNewFile();
		agregarTextoGitignore(file.getPath());
		file = new File(dirProyecto.toString(), "build.gradle");
		agregarTextoBuilGradleRaiz(file.getPath(), mapParam, "backend");
		file.createNewFile();
		file = new File(dirProyecto.toString(), "Readme.txt");
		file.createNewFile();
		file = new File(dirProyecto.toString(), "settings.gradle");
		file.createNewFile();
		agregarTextoSettingsBackend(file.getPath(), mapParam);
		System.out.println("FIN--->generarProyectoBackend");
	}
	
	private static void generarProyectoWebApp(Map<String, String> mapParam, List<Map<String, String>> listMapContexto) throws IOException {
		System.out.println("INICIO--->generarProyectoWebApp");
		//NOMBRE DEL EAR
		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append("-");
		}
		sbTemp.append(mapParam.get("macroproceso")).append("-");
		sbTemp.append(mapParam.get("proceso")).append(".ear");
		mapParam.put("nomEar", sbTemp.toString());
		
		//PACKAGE CONTROLLER
		sbTemp = new StringBuilder("pe.gob.sunat.");
		sbTemp.append(mapParam.get("megaproceso2")).append(".");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append(".");
		}
		sbTemp.append(mapParam.get("macroproceso")).append(".");
		sbTemp.append(mapParam.get("proceso"));
		mapParam.put("packageProceso", sbTemp.toString());
		
		//DIRECTORIO PROYECTO
		StringBuilder dirProyecto = new StringBuilder(mapParam.get("rutaRaiz"));
		dirProyecto.append("\\");
		dirProyecto.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			dirProyecto.append(mapParam.get("negocio")).append("-");
		}
		dirProyecto.append(mapParam.get("macroproceso")).append("-");
		dirProyecto.append(mapParam.get("proceso")).append("-webapp");
		
		//ELIMINAR DIRECTORIO DEL PROYECTO
		delete(new File(dirProyecto.toString()));

		//CREANDO DIRECTORIO DEL PROYECTO
		File file = new File(dirProyecto.toString());
		file.mkdirs();
		
		//CREAR ARCHIVOS DEL DIRECTORIO PRINCIPAL
		file = new File(dirProyecto.toString(), ".gitignore");
		file.createNewFile();
		agregarTextoGitignore(file.getPath());
		file = new File(dirProyecto.toString(), "build.gradle");
		file.createNewFile();
		agregarTextoBuilGradleRaiz(file.getPath(), mapParam, "webapp");
		file = new File(dirProyecto.toString(), "Readme.txt");
		file.createNewFile();
		file = new File(dirProyecto.toString(), "settings.gradle");
		file.createNewFile();
		agregarTextoSettingsWebApp(file.getPath(), mapParam, listMapContexto);
		
		mapParam.put("dirProyecto", dirProyecto.toString());
		for (Map<String, String> mapContexto : listMapContexto) {
			crearDirWar(mapParam, mapContexto, APLICACION_WEBAPP);
		}
		crearDirControllerJar(mapParam, APLICACION_WEBAPP);
		crearDirEar(mapParam, listMapContexto, APLICACION_WEBAPP);
		System.out.println("FIN--->generarProyectoWebApp");
	}
	
	private static void crearDirWar(Map<String, String> mapParam, Map<String, String> mapContexto, String tipApp) throws IOException {
		StringBuilder dirWar = new StringBuilder(mapParam.get("dirProyecto"));
		dirWar.append("\\").append(mapContexto.get("nomWar"));
		dirWar.append(".war");
		File file = new File(dirWar.toString());
		file.mkdirs();
		
		file = new File(dirWar.toString(), "build.gradle");
		file.createNewFile();
		modificarBuildGradleWar(file);
		
		dirWar.append("\\src\\main\\webapp\\WEB-INF");
		file = new File(dirWar.toString());
		file.mkdirs();
		
		StringBuilder sbFileXml = null;
		
		if (APLICACION_WEBAPP.equals(tipApp)) {
			sbFileXml = new StringBuilder();
			sbFileXml.append(mapContexto.get("nomWar"));
			sbFileXml.append("-security.xml");
			file = new File(dirWar.toString(), sbFileXml.toString());
			file.createNewFile();
			agregarTextoSecurityXml(file.getPath(), mapContexto.get("nomWar"));
		}
		
		sbFileXml = new StringBuilder();
		sbFileXml.append(mapContexto.get("nomWar"));
		sbFileXml.append("-servlet.xml");
		file = new File(dirWar.toString(), sbFileXml.toString());
		file.createNewFile();
		agregarTextoServletXml(file.getPath(), mapParam.get("packageProceso"), tipApp);
		
		file = new File(dirWar.toString(), "web.xml");
		file.createNewFile();
		agregarTextoWebXml(file.getPath(), mapContexto.get("nomWar"), mapParam, tipApp);
		
		file = new File(dirWar.toString(), "weblogic.xml");
		file.createNewFile();
		agregarTextoWeblogicWebApp(file.getPath(), mapContexto);
		
		if (APLICACION_WEBAPP.equals(tipApp)) {
			dirWar.append("\\jsp");
			file = new File(dirWar.toString());
			file.mkdirs();	

			file = new File(dirWar.toString(), "PagM.jsp");
			file.createNewFile();
			agregarTextoPagMJsp(file.getPath());
			
			file = new File(dirWar.toString(), "home.jsp");
			file.createNewFile();
			agregarTextoHomeJsp(file.getPath());
		}
	}
	
	private static void crearDirControllerJar(Map<String, String> mapParam, String tipApp) throws IOException {
		StringBuilder dirController = new StringBuilder(mapParam.get("dirProyecto"));
		if (APLICACION_BATCH.endsWith(tipApp)) {
			dirController.append("\\ejb").append(mapParam.get("macroproceso"));
		} else {
			dirController.append("\\").append(mapParam.get("macroproceso"));
		}
		dirController.append("-");
		dirController.append(mapParam.get("proceso"));
		if (APLICACION_WEBAPP.equals(tipApp)) {
			dirController.append("-controller.jar");
		} else if (APLICACION_BACKEND.equals(tipApp)) {
			dirController.append("ws-controller.jar");
		} else {//BATCH
			dirController.append("mdb.jar");
		}
		File file = new File(dirController.toString());
		file.mkdirs();
		
		file = new File(dirController.toString(), "build.gradle");
		file.createNewFile();
		modificarBuildGradleController(file, mapParam);
		
		dirController.append("\\src\\main");
		
		StringBuilder dirJava = new StringBuilder(dirController);
		dirJava.append("\\java\\pe\\gob\\sunat\\");
		dirJava.append(mapParam.get("megaproceso2")).append("\\");
		if (mapParam.get("negocio") != null) {
			dirJava.append(mapParam.get("negocio")).append("\\");
		}
		dirJava.append(mapParam.get("macroproceso")).append("\\");
		dirJava.append(mapParam.get("proceso")).append("\\");
		if (APLICACION_WEBAPP.equals(tipApp)) {
			dirJava.append("web\\controller");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParam.get("clase-controller") + ".java");
			file.createNewFile();
		} else if (APLICACION_BACKEND.equals(tipApp)) {
			dirJava.append("ws\\rest");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParam.get("clase-rest-controller") + ".java");
			file.createNewFile();
		} else {//BATCH
			dirJava.append("ejb\\mdb");
			file = new File(dirJava.toString());
			file.mkdirs();
			file = new File(dirJava.toString(), mapParam.get("clase-MDB") + ".java");
			file.createNewFile();
		}
		if (APLICACION_WEBAPP.equals(tipApp)) {
			agregarTextoControllerWebApp(file.getPath(), mapParam);
		} else if (APLICACION_BACKEND.equals(tipApp)) {
			agregarTextoRestController(file.getPath(), mapParam);
		} else {//BATCH
			
		}
		
		StringBuilder dirResources = new StringBuilder(dirController);
		dirResources.append("\\resources");
		file = new File(dirResources.toString());
		file.mkdirs();
		
		StringBuilder sbFileXml = new StringBuilder();
		sbFileXml.append(mapParam.get("megaproceso2"));
		sbFileXml.append("-");
		sbFileXml.append(mapParam.get("macroproceso"));
		sbFileXml.append("-beanRefContext.xml");
		file = new File(dirResources.toString(), sbFileXml.toString());
		file.createNewFile();
		agregarTextoBeanRefContext(file.getPath(), mapParam);
		
		sbFileXml = new StringBuilder();
		sbFileXml.append(mapParam.get("megaproceso2"));
		sbFileXml.append("-");
		sbFileXml.append(mapParam.get("macroproceso"));
		sbFileXml.append("-service.xml");
		file = new File(dirResources.toString(), sbFileXml.toString());
		file.createNewFile();
		agregarTextoServiceXmlController(file.getPath(), mapParam, tipApp);
		
		sbFileXml = new StringBuilder();
		sbFileXml.append(mapParam.get("proceso"));
		sbFileXml.append(".properties");
		file = new File(dirResources.toString(), sbFileXml.toString());
		file.createNewFile();
	}
	
	private static void crearDirEar(Map<String, String> mapParam, List<Map<String, String>> listMapContexto, String tipApp) throws IOException {
		StringBuilder dirEar = new StringBuilder(mapParam.get("dirProyecto"));
		dirEar.append("\\");
		dirEar.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			dirEar.append(mapParam.get("negocio")).append("-");
		}
		dirEar.append(mapParam.get("macroproceso")).append("-");
		dirEar.append(mapParam.get("proceso"));
		if (!APLICACION_WEBAPP.equals(tipApp)) {
			dirEar.append("-");
			dirEar.append(tipApp);
		}
		dirEar.append(".ear");
		
		File file = new File(dirEar.toString());
		file.mkdirs();
		
		file = new File(dirEar.toString(), "build.gradle");
		file.createNewFile();
		StringBuilder desMacroYProc = new StringBuilder();
		if (APLICACION_BATCH.equals(tipApp)) {
			desMacroYProc.append("ejb");
		}
		desMacroYProc.append(mapParam.get("macroproceso"));
		desMacroYProc.append("-");
		if (APLICACION_WEBAPP.equals(tipApp)) {
			desMacroYProc.append(mapParam.get("proceso"));
		} else if (APLICACION_BACKEND.equals(tipApp)) {
			desMacroYProc.append(mapParam.get("proceso")).append("ws");
		} else {//BATCH
			desMacroYProc.append(mapParam.get("proceso")).append("mdb");
		}
		agregarTextoBuilGradleWebAppEar(file.getPath(), desMacroYProc.toString(), mapParam.get("rutaCopiaEar"), listMapContexto);
		
		dirEar.append("\\src\\main\\application\\META-INF");
		file = new File(dirEar.toString());
		file.mkdirs();
		
		file = new File(dirEar.toString(), "weblogic-application.xml");
		file.createNewFile();
		agregarTextoWeblogicApplicationApp(file.getPath(), mapParam);
	}
	
	private static void generarProyectoBatch(Map<String, String> mapParam) throws IOException {
		System.out.println("INICIO--->generarProyectoBatch");
		StringBuilder dirProyecto = new StringBuilder(mapParam.get("rutaRaiz"));
		dirProyecto.append("\\");
		dirProyecto.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			dirProyecto.append(mapParam.get("negocio")).append("-");
		}
		dirProyecto.append(mapParam.get("macroproceso")).append("-");
		dirProyecto.append(mapParam.get("proceso")).append("-batch");

		//ELIMINAR DIRECTORIO DEL PROYECTO
		delete(new File(dirProyecto.toString()));
		
		//CREANDO DIRECTORIO DEL PROYECTO
		File file = new File(dirProyecto.toString());
		file.mkdirs();
		
		//CREAR ARCHIVOS DEL DIRECTORIO PRINCIPAL
		file = new File(dirProyecto.toString(), ".gitignore");
		file.createNewFile();
		agregarTextoGitignore(file.getPath());
		file = new File(dirProyecto.toString(), "build.gradle");
		file.createNewFile();
		agregarTextoBuilGradleRaiz(file.getPath(), mapParam, "batch");
		file = new File(dirProyecto.toString(), "Readme.txt");
		file.createNewFile();
		file = new File(dirProyecto.toString(), "settings.gradle");
		file.createNewFile();

		mapParam.put("dirProyecto", dirProyecto.toString());
		crearDirMdb(mapParam);
		crearDirEar(mapParam, new ArrayList<Map<String, String>>(), APLICACION_BATCH);
		System.out.println("FIN--->generarProyectoBatch");
	}

	private static void crearDirMdb(Map<String, String> mapParam) throws IOException {
		StringBuilder dirController = new StringBuilder(mapParam.get("dirProyecto"));
		dirController.append("\\ejb").append(mapParam.get("macroproceso"));
		dirController.append("-");
		dirController.append(mapParam.get("proceso"));
		dirController.append("mdb.jar");
		File file = new File(dirController.toString());
		file.mkdirs();
		
		file = new File(dirController.toString(), "build.gradle");
		file.createNewFile();
		
		dirController.append("\\src\\main");
		
		StringBuilder dirJava = new StringBuilder(dirController);
		dirJava.append("\\java\\pe\\gob\\sunat\\");
		dirJava.append(mapParam.get("megaproceso")).append("\\");
		if (mapParam.get("negocio") != null) {
			dirJava.append(mapParam.get("negocio")).append("\\");
		}
		dirJava.append(mapParam.get("macroproceso")).append("\\");
		dirJava.append(mapParam.get("proceso")).append("\\");
		dirJava.append("ejb\\mdb");
		file = new File(dirJava.toString());
		file.mkdirs();
		
		StringBuilder dirResources = new StringBuilder(dirController);
		dirResources.append("\\resources");
		file = new File(dirResources.toString());
		file.mkdirs();
		
		file = new File(dirResources.toString(), "beanRefContext.xml");
		file.createNewFile();
		
		StringBuilder sbFileXml = new StringBuilder();
		sbFileXml.append(mapParam.get("macroproceso"));
		sbFileXml.append("-");
		sbFileXml.append(mapParam.get("proceso"));
		sbFileXml.append("mdb-service.xml");
		file = new File(dirResources.toString(), sbFileXml.toString());
		file.createNewFile();
		
		dirResources.append("\\META-INF");
		file = new File(dirResources.toString());
		file.mkdirs();
		
		file = new File(dirResources.toString(), "weblogic-ejb-jar.xml");
		file.createNewFile();
		
	}

	private static void modificarBuildGradleWar(File file) throws IOException {
		FileWriter fw = new FileWriter(file);
		fw.append("apply plugin: 'warConventions'").append(NEXT_LINE).append(NEXT_LINE);
		fw.append("war {").append(NEXT_LINE);
		fw.append("\t").append("webInf {").append(NEXT_LINE);
		fw.append("\t\t").append("from 'src/main/resources'").append(NEXT_LINE);
		fw.append("\t").append("}").append(NEXT_LINE);
		fw.append("\t").append("classpath = configurations.runtime").append(NEXT_LINE);
		fw.append("}");
		fw.flush();
		fw.close();
	}
	
	private static void modificarBuildGradleController(File file, Map<String, String> mapParam) throws IOException {
		FileWriter fw = new FileWriter(file);
		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2")).append(".");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append(".");
		} else {
			sbTemp.append(mapParam.get("macroproceso")).append(".");
		}
		sbTemp.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			sbTemp.append(mapParam.get("negocio")).append("-");
		}
		sbTemp.append(mapParam.get("macroproceso")).append("-");
		sbTemp.append(mapParam.get("proceso")).append("-sharedlib");
		
		
		fw.append("apply plugin: \"jarConventions\"").append(NEXT_LINE);
		fw.append(NEXT_LINE);
		fw.append("dependenciesAndVersions {").append(NEXT_LINE);
		fw.append("\t").append("useGlobalFiles()").append(NEXT_LINE);
		fw.append("}").append(NEXT_LINE);
		fw.append(NEXT_LINE);
		fw.append("dependencies {").append(NEXT_LINE);
		fw.append("\t").append("compile (group: 'procesos.").append(sbTemp.toString()).append("', name: '");
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-model', version: '1.0.0')").append(NEXT_LINE);
		fw.append("\t").append("compile (group: 'procesos.").append(sbTemp.toString()).append("', name: '");
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-service-ifz', version: '1.0.0')").append(NEXT_LINE);
		fw.append("}");
		fw.flush();
		fw.close();
	}

	private static void modificarBuildGradleEarWebApp(File file, Map<String, String> mapParam) throws IOException {
		FileWriter fw = new FileWriter(file);
		fw.append("apply plugin: 'earApplicationConventions'").append(NEXT_LINE).append(NEXT_LINE);
		
		fw.append("evaluationDependsOn(':");
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-controller')").append(NEXT_LINE);
		fw.append("evaluationDependsOn(':");
		fw.append(mapParam.get("nomWar")).append("')").append(NEXT_LINE).append(NEXT_LINE);
		
		fw.append("dependencies{").append(NEXT_LINE);
		fw.append("\t").append("deploy project(':");
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-controller')").append(NEXT_LINE);
		fw.append("\t").append("deploy project(path:':");
		fw.append(mapParam.get("nomWar")).append("',configuration:\"archives\")").append(NEXT_LINE);
		
		
		
		
		
		fw.append("dependencies{").append(NEXT_LINE);
		fw.append("\t").append("compile (group: 'procesos.");
		fw.append(mapParam.get("megaproceso2")).append(".");
		if (mapParam.get("negocio") != null) {
			fw.append(mapParam.get("negocio")).append(".");
		} else {
			fw.append(mapParam.get("macroproceso")).append(".");
		}
		fw.append(mapParam.get("megaproceso2")).append("-");
		if (mapParam.get("negocio") != null) {
			fw.append(mapParam.get("negocio")).append("-");
		}
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-sharedlib', name: '");
		fw.append(mapParam.get("macroproceso")).append("-");
		fw.append(mapParam.get("proceso")).append("-service-ifz', version: '1.0.0')").append(NEXT_LINE);
		fw.append("}");
		fw.flush();
		fw.close();
	}

	private static void delete(File f) throws IOException {
		if (f.exists()) {
			if (f.isDirectory()) {
				for (File c : f.listFiles())
					delete(c);
			}
			if (!f.delete())
				throw new FileNotFoundException("Failed to delete file: " + f);
		}			
	}
	
	private static void agregarTextoGitignore(String nombreArch) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write("build\r\n");
        out.write("bin\r\n");
        out.write(".gradle\r\n");
        out.write(".settings\r\n");
        out.write(".classpath\r\n");
        out.write(".project");
        out.close();
        fstream.close();
	}

	private static void agregarTextoSettingsSharedlib(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write("include 'model.jar',\r\n");
        out.write("\t\t'dao-ifz.jar',\r\n");
        out.write("\t\t'dao-imp.jar',\r\n");
        out.write("\t\t'service-ifz.jar',\r\n");
        out.write("\t\t'service-imp.jar',\r\n");
        out.write("\t\t'slb.ear'\r\n\r\n");
        StringBuilder sbTemp = new StringBuilder();
        sbTemp.append("project(':model.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-model'\r\n");
        out.write(sbTemp.toString());
        sbTemp = new StringBuilder();
        sbTemp.append("project(':dao-ifz.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-dao-ifz'\r\n");
        out.write(sbTemp.toString());
        sbTemp = new StringBuilder();
        sbTemp.append("project(':dao-imp.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-dao-imp'\r\n");
        out.write(sbTemp.toString());
        sbTemp = new StringBuilder();
        sbTemp.append("project(':service-ifz.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-service-ifz'\r\n");
        out.write(sbTemp.toString());
        sbTemp = new StringBuilder();
        sbTemp.append("project(':service-imp.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-service-imp'\r\n");
        out.write(sbTemp.toString());
        sbTemp = new StringBuilder();
        sbTemp.append("project(':slb.ear').name='");
        sbTemp.append(mapParam.get("megaproceso2")).append("-");
        if (mapParam.get("negocio") != null) {
        	sbTemp.append(mapParam.get("negocio")).append("-");
        }
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-sharedlib.ear'");
        out.write(sbTemp.toString());
        
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoBuilGradleJar(String nombreArch, List<String> listDep) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write("apply plugin: \"jarConventions\"\r\n");
        out.write("\r\n");
        out.write("dependenciesAndVersions {\r\n");
        out.write("\tuseGlobalFiles()\r\n");
        out.write("}\r\n");
        if (!listDep.isEmpty()) {
        	out.write("\r\n");
        	out.write("dependencies{\r\n");
            for (String dep : listDep) {
            	out.write("\tcompile project(':" + dep + "')\r\n");
            }
        	out.write("}");
        }
        out.close();
        fstream.close();
	}

	private static void agregarTextoBuilGradleRaiz(String nombreArch, Map<String, String> mapParam, String tipo) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbContenido = new StringBuilder();
        
        sbContenido.append("buildscript {\r\n");
        sbContenido.append("\trepositories {\r\n");
        sbContenido.append("\t\tmaven {\r\n");
        sbContenido.append("\t\t\turl \"$artifactoryUrl/plugins-release\"\r\n");
        sbContenido.append("\t\t}\r\n");
        sbContenido.append("\t}\r\n");
        sbContenido.append("\tdependencies {\r\n");
        sbContenido.append("\t\tclasspath(group: 'procesos.gestion.configuracion', name: 'build-gradle', version: '1.9.15')\r\n");
        sbContenido.append("\t}\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("apply plugin: \"parentConventions\"\r\n");
        sbContenido.append("apply plugin: \"dependenciesAndVersions\"\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("dependenciesAndVersions {\r\n");
        sbContenido.append("\tdependenciesBranch = 'master'\r\n");
        sbContenido.append("\tversionsBranch = 'master'\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("subprojects {subproject->\r\n");
        sbContenido.append("\tgroup = \"procesos.");
        sbContenido.append(mapParam.get("megaproceso2")).append(".");
        if (mapParam.get("negocio") != null) {
        	sbContenido.append(mapParam.get("negocio")).append(".");
        } else {
            sbContenido.append(mapParam.get("macroproceso")).append(".");
        }
        sbContenido.append(mapParam.get("megaproceso2")).append("-");
        if (mapParam.get("negocio") != null) {
        	sbContenido.append(mapParam.get("negocio")).append("-");
        }
        sbContenido.append(mapParam.get("macroproceso")).append("-");
        sbContenido.append(mapParam.get("proceso")).append("-").append(tipo).append("\"\r\n");
        sbContenido.append("\tversion = '1.0.0'\r\n");
        sbContenido.append("\tpaseNro = '").append(mapParam.get("numPase")).append("'\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("\trepositories {\r\n");
        sbContenido.append("\t\tmavenLocal()\r\n");
        sbContenido.append("\t}\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("}\r\n");
        
        out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoBuilGradleSlb(String nombreArch, String desMacroYProc, String rutaCopiaEar) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write("apply plugin: \"earSharedLibConventions\"\r\n");
        out.write("\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-model')\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-dao-ifz')\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-dao-imp')\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-service-ifz')\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-service-imp')\r\n");
        out.write("\r\n");
        out.write("dependencies {\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-model')\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-dao-ifz')\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-dao-imp')\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-service-ifz')\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-service-imp')\r\n");
        out.write("}\r\n");
        out.write("\r\n");
        out.write("import pe.gob.sunat.framework.build.ear.LibModule\r\n");
        out.write("\r\n");
        out.write("ear {\r\n");
        out.write("\tdeploymentDescriptor {\r\n");
        out.write("\t\tmodule(new LibModule(project(':" + desMacroYProc + "-model').jar.archiveName), \"java\")\r\n");
        out.write("\t\tmodule(new LibModule(project(':" + desMacroYProc + "-dao-ifz').jar.archiveName), \"java\")\r\n");
        out.write("\t\tmodule(new LibModule(project(':" + desMacroYProc + "-dao-imp').jar.archiveName), \"java\")\r\n");
        out.write("\t\tmodule(new LibModule(project(':" + desMacroYProc + "-service-ifz').jar.archiveName), \"java\")\r\n");
        out.write("\t\tmodule(new LibModule(project(':" + desMacroYProc + "-service-imp').jar.archiveName), \"java\")\r\n");
        out.write("\t}\r\n");
        out.write("}\r\n");
        out.write("\r\n");
        out.write("task copyEar(dependsOn: ear) << {\r\n");
        out.write("\tprintln \"Copiar ear de ${libsDir.getPath()} hacia " + rutaCopiaEar + "\"\r\n");
        out.write("\tcopy{\r\n");
        out.write("\t\tfrom libsDir\r\n");
        out.write("\t\tinto \"" + rutaCopiaEar + "\"\r\n");
        out.write("\t\tinclude '*.ear'\r\n");
        out.write("\t}\r\n");
        out.write("}");
        
        out.close();
        fstream.close();
	}
	
	private static void agregarTextClaseJava(String nombreArch, String packageJava, String tipoClase, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbContenido = new StringBuilder();
        sbContenido.append("package ").append(packageJava).append(";\r\n");
        sbContenido.append("\r\n");
        
        if ("model".equals(tipoClase)) {
        	sbContenido.append("public class ").append(mapParam.get("clase-model")).append(" {\r\n");
        	sbContenido.append("\t\r\n");
        } else if ("dao-ifz".equals(tipoClase)) {
        	String packageJavaModel = packageJava.replaceAll(".dao", "");
        	
        	sbContenido.append("import java.util.List;\r\n");
        	sbContenido.append("import java.util.Map;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import ").append(packageJavaModel).append(".").append(mapParam.get("clase-model")).append(";\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("public interface ").append(mapParam.get("clase-dao-ifz")).append(" {\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("\tpublic List<").append(mapParam.get("clase-model")).append("> listar").append(mapParam.get("clase-model")).append("ByParameterMap(Map params);\r\n");
        	sbContenido.append("\r\n");
        } else if ("dao-imp".equals(tipoClase)) {
        	String packageJavaModel = packageJava.replaceAll(".dao.ibatis", "");
        	String packageJavaDao = packageJava.replaceAll(".ibatis", "");
        	
        	sbContenido.append("import java.util.List;\r\n");
        	sbContenido.append("import java.util.Map;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import ").append(packageJavaModel).append(".").append(mapParam.get("clase-model")).append(";\r\n");
        	sbContenido.append("import ").append(packageJavaDao).append(".").append(mapParam.get("clase-dao-ifz")).append(";\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("public class ").append(mapParam.get("clase-dao-imp")).append(" extends SqlMapClientDaoSupport implements ").append(mapParam.get("clase-dao-ifz")).append(" {\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("\t@Override\r\n");
        	sbContenido.append("\tpublic List<").append(mapParam.get("clase-model")).append(">  listar").append(mapParam.get("clase-model")).append("ByParameterMap(Map params) {\r\n");
        	sbContenido.append("\t\treturn getSqlMapClientTemplate().queryForList(\"").append(mapParam.get("entidad")).append(".listByParameterMap\", params);\r\n");
        	sbContenido.append("\t}\r\n");
        	sbContenido.append("\r\n");
        } else if ("service-ifz".equals(tipoClase)) {
        	String packageJavaProceso = packageJava.replaceAll(".service", "");
        	
        	sbContenido.append("import java.util.List;\r\n");
        	sbContenido.append("import java.util.Map;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import ").append(packageJavaProceso).append(".model.").append(mapParam.get("clase-model")).append(";\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("public interface ").append(mapParam.get("clase-service-ifz")).append(" {\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("\tpublic List<").append(mapParam.get("clase-model")).append("> listar").append(mapParam.get("clase-model")).append("ByParameterMap(Map params);\r\n");
        	sbContenido.append("\r\n");
        } else if ("service-imp".equals(tipoClase)) {
        	String packageJavaProceso = packageJava.replaceAll(".service", "");
        	String service = mapParam.get("clase-service-ifz").substring(0,1).toLowerCase() + mapParam.get("clase-service-ifz").substring(1);
        	String dao = mapParam.get("clase-dao-ifz").substring(0,1).toLowerCase() + mapParam.get("clase-dao-ifz").substring(1);
        	String daoVariable = "listar" + mapParam.get("clase-model");
        	
        	sbContenido.append("import java.util.ArrayList;\r\n");
        	sbContenido.append("import java.util.List;\r\n");
        	sbContenido.append("import java.util.Map;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import org.apache.commons.logging.Log;\r\n");
        	sbContenido.append("import org.apache.commons.logging.LogFactory;\r\n");
        	sbContenido.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
        	sbContenido.append("import org.springframework.stereotype.Service;\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("import ").append(packageJavaProceso).append(".model.").append(mapParam.get("clase-model")).append(";\r\n");
        	sbContenido.append("import ").append(packageJavaProceso).append(".model.dao.").append(mapParam.get("clase-dao-ifz")).append(";\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("@Service(\"").append(mapParam.get("proceso")).append(".").append(service).append("\")\r\n");
        	sbContenido.append("public class ").append(mapParam.get("clase-service-imp")).append(" implements ").append(mapParam.get("clase-service-ifz")).append(" {\r\n");
        	sbContenido.append("\tprivate static final Log log = LogFactory.getLog(").append(mapParam.get("clase-service-imp")).append(".class);\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("\t@Autowired\r\n");
        	sbContenido.append("\tprivate ").append(mapParam.get("clase-dao-ifz")).append(" ").append(dao).append(";\r\n");
        	sbContenido.append("\r\n");
        	sbContenido.append("\t@Override\r\n");
        	sbContenido.append("\tpublic List<").append(mapParam.get("clase-model")).append("> listar").append(mapParam.get("clase-model")).append("ByParameterMap(Map params) {\r\n");
        	sbContenido.append("\t\tList<").append(mapParam.get("clase-model")).append("> ").append(daoVariable);
        	sbContenido.append(" = new ArrayList<").append(mapParam.get("clase-model")).append(">();\r\n");
        	sbContenido.append("\t\t").append(daoVariable).append(" = ").append(dao).append(".listar").append(mapParam.get("clase-model")).append("ByParameterMap(params);\r\n");;
        	sbContenido.append("\t\treturn ").append(daoVariable).append(";\r\n");
        	sbContenido.append("\t}\r\n");
        }
        sbContenido.append("}\r\n");
        
        out.write(sbContenido.toString());
		
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoSettingsWebApp(String nombreArch, Map<String, String> mapParam, List<Map<String, String>> listMapContexto) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbTemp = new StringBuilder();
        sbTemp.append("include ");
        int cont = 0;
        for (Map<String, String> mapContexto : listMapContexto) {
        	if (cont == 0) {
        		sbTemp.append("'").append(mapContexto.get("nomWar")).append(".war',\r\n");
        	} else {
            	sbTemp.append("\t\t'").append(mapContexto.get("nomWar")).append(".war',\r\n");
        	}
        	cont++;
        }
        sbTemp.append("\t\t'").append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-controller.jar',\r\n");
        sbTemp.append("\t\t'").append(mapParam.get("megaproceso2")).append("-");
        if (mapParam.get("negocio") != null) {
        	sbTemp.append(mapParam.get("negocio")).append("-");
        }
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append(".ear'");
        sbTemp.append("\r\n");
        sbTemp.append("\r\n");
        for (Map<String, String> mapContexto : listMapContexto) {
        	sbTemp.append("project(':").append(mapContexto.get("nomWar")).append(".war').name='").append(mapContexto.get("nomWar")).append("'\r\n");
        }
        sbTemp.append("project(':").append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-controller.jar').name='");
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append("-controller'\r\n");
        sbTemp.append("project(':").append(mapParam.get("megaproceso2")).append("-");
        if (mapParam.get("negocio") != null) {
        	sbTemp.append(mapParam.get("negocio")).append("-");
        }
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append(".ear').name='");
        sbTemp.append(mapParam.get("megaproceso2")).append("-");
        if (mapParam.get("negocio") != null) {
        	sbTemp.append(mapParam.get("negocio")).append("-");
        }
        sbTemp.append(mapParam.get("macroproceso")).append("-");
        sbTemp.append(mapParam.get("proceso")).append(".ear'\r\n");

        out.write(sbTemp.toString());
        
        out.close();
        fstream.close();
	}

	private static void agregarTextoBuilGradleWebAppEar(String nombreArch, String desMacroYProc, String rutaCopiaEar, List<Map<String, String>> listMapContexto) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write("apply plugin: \"earApplicationConventions\"\r\n");
        out.write("\r\n");
        out.write("evaluationDependsOn(':" + desMacroYProc + "-controller')\r\n");
        for (Map<String, String> mapContexto : listMapContexto) {
            out.write("evaluationDependsOn(':" + mapContexto.get("nomWar") + "')\r\n");
        }
        out.write("\r\n");
        out.write("dependencies {\r\n");
        out.write("\tdeploy project(':" + desMacroYProc + "-controller')\r\n");
        for (Map<String, String> mapContexto : listMapContexto) {
        	out.write("\tdeploy project(path:':" + mapContexto.get("nomWar") + "',configuration:\"archives\")\r\n");
        }
        out.write("}\r\n");
        out.write("\r\n");
        out.write("import pe.gob.sunat.framework.build.ear.LibModule\r\n");
        out.write("\r\n");
        out.write("ear {\r\n");
        out.write("\tdeploymentDescriptor {\r\n");
        for (Map<String, String> mapContexto : listMapContexto) {
            out.write("\t\twebModule(project(':" + mapContexto.get("nomWar") + "').war.archiveName,'/" + mapContexto.get("contexto") + "')\r\n");
        }
        out.write("\t\tmodule(new LibModule(project(\":" + desMacroYProc + "-controller\").jar.archiveName), \"java\")\r\n");
        out.write("\t}\r\n");
        out.write("}\r\n");
        out.write("\r\n");
        out.write("task copyEar(dependsOn: ear) << {\r\n");
        out.write("\tprintln \"Copiar ear de ${libsDir.getPath()} hacia " + rutaCopiaEar + "\"\r\n");
        out.write("\tcopy {\r\n");
        out.write("\t\tfrom libsDir\r\n");
        out.write("\t\tinto \"" + rutaCopiaEar + "\"\r\n");
        out.write("\t\tinclude '*.ear'\r\n");
        out.write("\t}\r\n");
        out.write("}");
        
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoControllerWebApp(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        
		StringBuilder packageJava = new StringBuilder("pe.gob.sunat");
		packageJava.append(".").append(mapParam.get("megaproceso2"));
		if (mapParam.get("negocio") != null) {
			packageJava.append(".").append(mapParam.get("negocio"));
		}		
		packageJava.append(".").append(mapParam.get("macroproceso"));
		packageJava.append(".").append(mapParam.get("proceso"));
		
		String service = mapParam.get("clase-service-ifz").substring(0,1).toLowerCase() + mapParam.get("clase-service-ifz").substring(1);
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("package ").append(packageJava.toString()).append(".web.controller;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import javax.servlet.http.HttpSession;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import org.apache.commons.logging.Log;\r\n");
		sbContenido.append("import org.apache.commons.logging.LogFactory;\r\n");
		sbContenido.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
		sbContenido.append("import org.springframework.stereotype.Controller;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.RequestMapping;\r\n");
		sbContenido.append("import org.springframework.web.servlet.ModelAndView;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import ").append(packageJava.toString()).append(".service.").append(mapParam.get("clase-service-ifz")).append(";\r\n");
		sbContenido.append("import pe.gob.sunat.tecnologia.menu.bean.UsuarioBean;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("@Controller\r\n");
		sbContenido.append("@RequestMapping(\"/").append(mapParam.get("proceso")).append("\")\r\n");
		sbContenido.append("public class ").append(mapParam.get("clase-controller")).append(" {\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\tprotected final Log log = LogFactory.getLog(getClass());\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t@Autowired\r\n");
		sbContenido.append("\t").append(mapParam.get("clase-service-ifz")).append(" ").append(service).append(";\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t@RequestMapping(value=\"/inicio\")\r\n");
		sbContenido.append("\tpublic ModelAndView inicio(HttpSession session) {\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t\tUsuarioBean usuarioBean  = (UsuarioBean) session.getAttribute(\"usuarioBean\");\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t\tModelAndView m = new ModelAndView();\r\n");
		sbContenido.append("\t\tm.setViewName(\"home\");\r\n");
		sbContenido.append("\t\t//Retorna el home.jsp\r\n");
		sbContenido.append("\t\treturn m;\r\n");
		sbContenido.append("\t}\r\n");
		sbContenido.append("}\r\n");
		
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoBeanRefContext(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<beans xmlns=\"http://www.springframework.org/schema/beans\"\r\n");		
		sbContenido.append("\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("\txmlns:context=\"http://www.springframework.org/schema/context\"\r\n");
		sbContenido.append("\txsi:schemaLocation=\"http://www.springframework.org/schema/beans\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/beans/spring-beans.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context/spring-context.xsd\">\r\n");
		sbContenido.append("\r\n");
		
		sbContenido.append("\t<bean id=\"").append(mapParam.get("nomEar")).append(".context\" class=\"org.springframework.context.support.ClassPathXmlApplicationContext\">\r\n");
		sbContenido.append("\t\t<constructor-arg>\r\n");
		sbContenido.append("\t\t\t<list>\r\n");
		
		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("macroproceso")).append("-");
		sbTemp.append(mapParam.get("proceso")).append("-service.xml");
		
		sbContenido.append("\t\t\t\t<value>").append(sbTemp.toString()).append("</value>\r\n");
		
		sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2")).append("-");
		sbTemp.append(mapParam.get("macroproceso")).append("-service.xml");
		
		sbContenido.append("\t\t\t\t<value>").append(sbTemp.toString()).append("</value>\r\n");;
		sbContenido.append("\t\t\t</list>\r\n");
		sbContenido.append("\t\t</constructor-arg>\r\n");
		sbContenido.append("\t</bean>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("</beans>\r\n");
		
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoServiceXmlController(String nombreArch, Map<String, String> mapParam, String tipApp) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<beans xmlns=\"http://www.springframework.org/schema/beans\"\r\n");		
		sbContenido.append("\txmlns:cache=\"http://www.springframework.org/schema/cache\"\r\n");
		sbContenido.append("\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("\txmlns:context=\"http://www.springframework.org/schema/context\"\r\n");
		sbContenido.append("\txsi:schemaLocation=\"http://www.springframework.org/schema/beans\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/beans/spring-beans.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context/spring-context.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/cache http://www.springframework.org/schema/cache/spring-cache.xsd\">\r\n");
		sbContenido.append("\r\n");
		
		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2"));
		if (mapParam.get("negocio") != null) {
			sbTemp.append("-").append(mapParam.get("negocio"));
		}		
		sbTemp.append("-").append(mapParam.get("macroproceso"));
		sbTemp.append("-").append(mapParam.get("proceso"));
		
		
		sbContenido.append("\t<bean id=\"log4jInitialization\" class=\"org.springframework.beans.factory.config.MethodInvokingFactoryBean\">\r\n");
		sbContenido.append("\t\t<property name=\"targetClass\"  value=\"org.springframework.util.Log4jConfigurer\" />\r\n");
		sbContenido.append("\t\t<property name=\"targetMethod\" value=\"initLogging\" />\r\n");
		sbContenido.append("\t\t<property name=\"arguments\">\r\n");
		sbContenido.append("\t\t\t<list>\r\n");
		if (APLICACION_WEBAPP.equals(tipApp)) {
			sbContenido.append("\t\t\t\t<value>/logs/apps/config/").append(sbTemp.toString()).append(".config</value>\r\n");
		} else if (APLICACION_BACKEND.equals(tipApp)) {
			sbContenido.append("\t\t\t\t<value>/logs/apps/config/").append(sbTemp.toString()).append("-backend.config</value>\r\n");
		} else {//BATCH
			sbContenido.append("\t\t\t\t<value>/logs/apps/config/").append(sbTemp.toString()).append("-batch.config</value>\r\n");
		}
		sbContenido.append("\t\t\t</list>\r\n");
		sbContenido.append("\t\t</property>\r\n");
		sbContenido.append("\t</bean>\r\n");
		sbContenido.append("\r\n");
		if (APLICACION_BACKEND.equals(tipApp)) {
			sbContenido.append("\t<bean id=\"refreshPeriodParamCache\" class=\"java.lang.Integer\">\r\n");
			sbContenido.append("\t\t<constructor-arg value=\"3600\" />\r\n");
			sbContenido.append("\t</bean>\r\n");
			sbContenido.append("\r\n");
			sbContenido.append("\t<import resource=\"classpath:cacheparamconfig.xml\"/>\r\n");
			sbContenido.append("\r\n");
		}
		sbContenido.append("</beans>\r\n");
		
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoWeblogicApplicationApp(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);

		StringBuilder sbTemp = new StringBuilder();
		sbTemp.append(mapParam.get("megaproceso2"));
		if (mapParam.get("negocio") != null) {
			sbTemp.append("-").append(mapParam.get("negocio"));
		}		
		sbTemp.append("-").append(mapParam.get("macroproceso"));
		sbTemp.append("-").append(mapParam.get("proceso"));
		sbTemp.append("-sharedlib");
        
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<wls:weblogic-application xmlns:wls=\"http://xmlns.oracle.com/weblogic/weblogic-application\" ");
		sbContenido.append("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://java.sun.com/xml/ns/javaee ");
		sbContenido.append("http://java.sun.com/xml/ns/javaee/javaee_5.xsd http://xmlns.oracle.com/weblogic/weblogic-application ");
		sbContenido.append("http://xmlns.oracle.com/weblogic/weblogic-application/1.2/weblogic-application.xsd\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<!--weblogic-version:10.3.4-->\r\n");
		sbContenido.append("\t<wls:application-param>\r\n");
		sbContenido.append("\t\t<wls:param-name>webapp.encoding.default</wls:param-name>\r\n");
		sbContenido.append("\t\t<wls:param-value>UTF-8</wls:param-value>\r\n");
		sbContenido.append("\t</wls:application-param>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<!-- Libreria compartida de terceros(spring,ibatis,commons,etc...) -->\r\n");
		sbContenido.append("\t<wls:library-ref>\r\n");
		sbContenido.append("\t\t<wls:library-name>tecnologia-terceros-sharedlib</wls:library-name>\r\n");
		sbContenido.append("\t\t<wls:specification-version>").append(mapParam.get("sharedlib-tercero-spe-version")).append("</wls:specification-version>\r\n");
		sbContenido.append("\t\t<wls:implementation-version>").append(mapParam.get("sharedlib-tercero-imp-version")).append("</wls:implementation-version>\r\n");
		sbContenido.append("\t</wls:library-ref>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<wls:library-ref>\r\n");
		sbContenido.append("\t\t<wls:library-name>tecnologia-seguridad-sharedlib</wls:library-name>\r\n");
		sbContenido.append("\t\t<wls:specification-version>").append(mapParam.get("sharedlib-seguridad-spe-version")).append("</wls:specification-version>\r\n");
		sbContenido.append("\t\t<wls:implementation-version>").append(mapParam.get("sharedlib-seguridad-imp-version")).append("</wls:implementation-version>\r\n");
		sbContenido.append("\t</wls:library-ref>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<wls:library-ref>\r\n");
		sbContenido.append("\t\t<wls:library-name>tecnologia-framework2-sharedlib</wls:library-name>\r\n");
		sbContenido.append("\t\t<wls:specification-version>").append(mapParam.get("sharedlib-framework2-spe-version")).append("</wls:specification-version>\r\n");
		sbContenido.append("\t\t<wls:implementation-version>").append(mapParam.get("sharedlib-framework2-imp-version")).append("</wls:implementation-version>\r\n");
		sbContenido.append("\t</wls:library-ref>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<!-- sharedlibs de negocio -->\r\n");
		sbContenido.append("\t<wls:library-ref>\r\n");
		sbContenido.append("\t\t<wls:library-name>").append(sbTemp.toString()).append("</wls:library-name>\r\n");
		sbContenido.append("\t\t<wls:specification-version>1.0</wls:specification-version>\r\n");
		sbContenido.append("\t\t<wls:implementation-version>1.0.0</wls:implementation-version>\r\n");
		sbContenido.append("\t</wls:library-ref>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("</wls:weblogic-application>\r\n");
		
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoSecurityXml(String nombreArch, String nomWar) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
		String origen = nomWar.substring(0, 2);
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<beans xmlns=\"http://www.springframework.org/schema/beans\"\r\n");
		sbContenido.append("\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("\txmlns:context=\"http://www.springframework.org/schema/context\"\r\n");
		sbContenido.append("\txmlns:mvc=\"http://www.springframework.org/schema/mvc\"\r\n");
		sbContenido.append("\txsi:schemaLocation=\"http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<mvc:interceptors>\r\n");
		sbContenido.append("\t\t<mvc:interceptor>\r\n");
		sbContenido.append("\t\t\t<mvc:mapping path=\"/adeudos/inicio\" />\r\n");
		if ("it".equals(origen)) {
			sbContenido.append("\t\t\t<ref bean=\"menuInternetInterceptor\"/>\r\n");
		} else {
			sbContenido.append("\t\t\t<ref bean=\"menuIntranetInterceptor\"/>\r\n");
		}
		sbContenido.append("\t\t</mvc:interceptor>\r\n");
		sbContenido.append("\t</mvc:interceptors>\r\n");
		sbContenido.append("\r\n");
		if ("it".equals(origen)) {
			sbContenido.append("\t<bean name=\"menuInternetInterceptor\" class=\"pe.gob.sunat.tecnologia.menu.sso.web.controller.MenuInternetInterceptor\">\r\n");
		} else {
			sbContenido.append("\t<bean name=\"menuIntranetInterceptor\" class=\"pe.gob.sunat.tecnologia.menu.sso.web.controller.MenuIntranetInterceptor\">\r\n");
		}
		sbContenido.append("\t\t<property name=\"msgView\" ref=\"msgView\" />\r\n");
		sbContenido.append("\t</bean>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<bean id=\"msgView\" class=\"org.springframework.web.servlet.ModelAndView\">\r\n");
		sbContenido.append("\t\t<constructor-arg type=\"java.lang.String\" value=\"PagM\" />\r\n");
		sbContenido.append("\t</bean>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("</beans>\r\n");

		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoServletXml(String nombreArch, String packageProceso, String tipApp) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<beans xmlns=\"http://www.springframework.org/schema/beans\"\r\n");
		sbContenido.append("\txmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("\txmlns:context=\"http://www.springframework.org/schema/context\"\r\n");
		sbContenido.append("\txmlns:mvc=\"http://www.springframework.org/schema/mvc\"\r\n");
		sbContenido.append("\txsi:schemaLocation=\"http://www.springframework.org/schema/mvc http://www.springframework.org/schema/mvc/spring-mvc.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd\r\n");
		sbContenido.append("\t\thttp://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context.xsd\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<!-- Para el uso de  Anotaciones Spring MVC @Controller -->\r\n");
		if (APLICACION_BACKEND.equals(tipApp)) {
			sbContenido.append("\t<mvc:annotation-driven>\r\n");
			sbContenido.append("\t\t<mvc:message-converters register-defaults=\"true\">\r\n");
			sbContenido.append("\t\t\t<bean class=\"org.springframework.http.converter.json.MappingJackson2HttpMessageConverter\">\r\n");
			sbContenido.append("\t\t\t\t<property name=\"objectMapper\">\r\n");
			sbContenido.append("\t\t\t\t\t<bean class=\"com.fasterxml.jackson.databind.ObjectMapper\">\r\n");
			sbContenido.append("\t\t\t\t\t\t<property name=\"serializationInclusion\">\r\n");
			sbContenido.append("\t\t\t\t\t\t\t<!-- Para que el JsonMapper no devuelva atributos con valores nulos -->\r\n");
			sbContenido.append("\t\t\t\t\t\t\t<value type=\"com.fasterxml.jackson.annotation.JsonInclude.Include\">NON_NULL</value>\r\n");
			sbContenido.append("\t\t\t\t\t\t</property>\r\n");
			sbContenido.append("\t\t\t\t\t</bean>\r\n");
			sbContenido.append("\t\t\t\t</property>\r\n");
			sbContenido.append("\t\t\t</bean>\r\n");
			sbContenido.append("\t\t</mvc:message-converters>\r\n");
			sbContenido.append("\t</mvc:annotation-driven>\r\n");
		} else {
			sbContenido.append("\t<mvc:annotation-driven/>\r\n");
		}
		sbContenido.append("\r\n");
		if (APLICACION_BACKEND.equals(tipApp)) {
			sbContenido.append("\t<!-- Escanear solo los paquetes correspondientes al Controller y al Framework REST -->\r\n");
			sbContenido.append("\t<context:component-scan base-package=\"").append(packageProceso).append(".ws.rest, pe.gob.sunat.framework.spring.util.ws.rest\"/>\r\n");
		} else {
			sbContenido.append("\t<!-- Escanear solo los paquetes correspondientes al Controller -->\r\n");
			sbContenido.append("\t<context:component-scan base-package=\"").append(packageProceso).append(".web.controller\"/>\r\n");
		}
		sbContenido.append("\r\n");
		if (APLICACION_WEBAPP.equals(tipApp)) {
			sbContenido.append("\t<!-- View Resolver -->\r\n");
			sbContenido.append("\t<bean  class=\"org.springframework.web.servlet.view.InternalResourceViewResolver\">\r\n");
			sbContenido.append("\t\t<property name=\"prefix\" value=\"/WEB-INF/jsp/\" />\r\n");
			sbContenido.append("\t\t<property name=\"suffix\" value=\".jsp\" />\r\n");
			sbContenido.append("\t</bean>\r\n");
			sbContenido.append("\r\n");
		}
		sbContenido.append("</beans>\r\n");

		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}

	private static void agregarTextoWebXml(String nombreArch, String nomWar, Map<String, String> mapParam, String tipApp) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<web-app xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\r\n");
		sbContenido.append("\txmlns=\"http://java.sun.com/xml/ns/javaee\" xmlns:web=\"http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd\"\r\n");
		sbContenido.append("\txsi:schemaLocation=\"http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd\"\r\n");
		sbContenido.append("\tid=\"WebApp_ID\" version=\"2.5\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<display-name>").append(nomWar).append("</display-name>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<context-param>\r\n");
		sbContenido.append("\t\t<param-name>locatorFactorySelector</param-name>\r\n");
		sbContenido.append("\t\t<param-value>classpath:").append(mapParam.get("megaproceso2")).append("-").append(mapParam.get("macroproceso")).append("-beanRefContext.xml</param-value>\r\n");
		sbContenido.append("\t</context-param>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<context-param>\r\n");
		sbContenido.append("\t\t<param-name>parentContextKey</param-name>\r\n");
		sbContenido.append("\t\t<param-value>").append(mapParam.get("nomEar")).append(".context</param-value>\r\n");
		sbContenido.append("\t</context-param>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<context-param>\r\n");
		sbContenido.append("\t\t<param-name>contextConfigLocation</param-name>\r\n");
		sbContenido.append("\t\t<param-value>\r\n");
		sbContenido.append("\t\t\t/WEB-INF/").append(nomWar).append("-servlet.xml\r\n");
		if (APLICACION_WEBAPP.equals(tipApp)) {
			sbContenido.append("\t\t\t/WEB-INF/").append(nomWar).append("-security.xml\r\n");
		}
		sbContenido.append("\t\t</param-value>\r\n");
		sbContenido.append("\t</context-param>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<listener>\r\n");
		sbContenido.append("\t\t<listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>\r\n");
		sbContenido.append("\t</listener>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<filter>\r\n");
		sbContenido.append("\t\t<filter-name>requestContextFilter</filter-name>\r\n");
		sbContenido.append("\t\t<filter-class>org.springframework.web.filter.RequestContextFilter</filter-class>\r\n");
		sbContenido.append("\t</filter>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<filter-mapping>\r\n");
		sbContenido.append("\t\t<filter-name>requestContextFilter</filter-name>\r\n");
		sbContenido.append("\t\t<url-pattern>/</url-pattern>\r\n");
		sbContenido.append("\t</filter-mapping>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<servlet>\r\n");
		sbContenido.append("\t\t<servlet-name>").append(nomWar).append("</servlet-name>\r\n");
		sbContenido.append("\t\t<servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>\r\n");
		sbContenido.append("\t\t<load-on-startup>1</load-on-startup>\r\n");
		sbContenido.append("\t</servlet>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<servlet-mapping>\r\n");
		sbContenido.append("\t\t<servlet-name>").append(nomWar).append("</servlet-name>\r\n");
		sbContenido.append("\t\t<url-pattern>/</url-pattern>\r\n");
		sbContenido.append("\t</servlet-mapping>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<session-config>\r\n");
		sbContenido.append("\t\t<session-timeout>180</session-timeout>\r\n");
		sbContenido.append("\t</session-config>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("</web-app>\r\n");
		sbContenido.append("\r\n");

		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoWeblogicWebApp(String nombreArch, Map<String, String> mapContexto) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
		String cookieName = mapContexto.get("nomWar").toUpperCase();
		cookieName = cookieName.replace("-", "");
		cookieName = cookieName + "SESSION";
        
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
		sbContenido.append("<wls:weblogic-web-app xmlns:wls=\"http://xmlns.oracle.com/weblogic/weblogic-web-app\" ");
		sbContenido.append("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" ");
		sbContenido.append("xsi:schemaLocation=\"http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd ");
		sbContenido.append("http://xmlns.oracle.com/weblogic/weblogic-web-app http://xmlns.oracle.com/weblogic/weblogic-web-app/1.2/weblogic-web-app.xsd\">\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<wls:weblogic-version>10.3.4</wls:weblogic-version>\r\n");
		sbContenido.append("\t<wls:description><![CDATA[").append(mapContexto.get("contexto")).append("]]></wls:description>\r\n");
		sbContenido.append("\t<wls:context-root>").append(mapContexto.get("contexto")).append("</wls:context-root>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<wls:session-descriptor>\r\n");
		sbContenido.append("\t\t<wls:timeout-secs>5400</wls:timeout-secs>\r\n");
		sbContenido.append("\t\t<wls:invalidation-interval-secs>3600</wls:invalidation-interval-secs>\r\n");
		sbContenido.append("\t\t<wls:id-length>256</wls:id-length>\r\n");
		sbContenido.append("\t\t<wls:tracking-enabled>true</wls:tracking-enabled>\r\n");
		sbContenido.append("\t\t<wls:cookie-name>").append(cookieName).append("</wls:cookie-name>\r\n");
		sbContenido.append("\t\t<wls:persistent-store-type>replicated_if_clustered</wls:persistent-store-type>\r\n");
		sbContenido.append("\t</wls:session-descriptor>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t<wls:container-descriptor>\r\n");
		sbContenido.append("\t\t<wls:session-monitoring-enabled>true</wls:session-monitoring-enabled>\r\n");
		sbContenido.append("\t</wls:container-descriptor>\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("</wls:weblogic-web-app>\r\n");

		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoHomeJsp(String nombreArch) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbContenido = new StringBuilder();
        sbContenido.append("<%@ page language=\"java\" contentType=\"text/html; charset=ISO-8859-1\" pageEncoding=\"ISO-8859-1\"%>\r\n");
        sbContenido.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\r\n");
        sbContenido.append("<html>\r\n");
        sbContenido.append("<head>\r\n");
        sbContenido.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">\r\n");
        sbContenido.append("<title>Insert title here</title>\r\n");
        sbContenido.append("</head>\r\n");
        sbContenido.append("<body>\r\n");
        sbContenido.append("wellcome to home\r\n");
        sbContenido.append("</body>\r\n");
        sbContenido.append("</html>\r\n");
        
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoPagMJsp(String nombreArch) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbContenido = new StringBuilder();
        sbContenido.append("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
        sbContenido.append("<jsp:useBean id=\"beanM\" scope=\"request\" class=\"pe.gob.sunat.framework.spring.util.bean.MensajeBean\" />\r\n");
        sbContenido.append("<HTML>\r\n");
        sbContenido.append("<HEAD><TITLE>.:: Pagina de Mensajes ::.</TITLE></HEAD>\r\n");
        sbContenido.append("<style>\r\n");
        sbContenido.append("BODY {font-style:normal;font-size:10pt;font-family:Verdana,Arial,Helvetica,sans-serif;}\r\n");
        sbContenido.append("H1 {font-size:16pt;color:Navy;}\r\n");
        sbContenido.append("A {color:Navy;}\r\n");
        sbContenido.append(".msg {\r\n");
        sbContenido.append("\tfont-weight : bold;\r\n");
        sbContenido.append("\tfont-size:12pt;\r\n");
        sbContenido.append("\tcolor:Black;\r\n");
        sbContenido.append("\tbackground-image : url(/a/imagenes/msg/info.gif);\r\n");
        sbContenido.append("\tbackground-repeat : no-repeat;\r\n");
        sbContenido.append("\tbackground-position : left;\r\n");
        sbContenido.append("\tpadding-left : 50px;\r\n");
        sbContenido.append("\theight : 50px;\r\n");
        sbContenido.append("\tpadding-top : 10px;\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append(".msg2 {\r\n");
        sbContenido.append("\tfont-weight : bold;\r\n");
        sbContenido.append("\tfont-size:12pt;\r\n");
        sbContenido.append("\tcolor:Black;\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append(".error {font-style:bold;font-size:12pt;color:Blue;\r\n");
        sbContenido.append("\ttext-indent: 50px;\r\n");
        sbContenido.append("\ttext-align : justify;\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append(".soluc {font-size:12pt;}\r\n");
        sbContenido.append(".cuerpo {\r\n");
        sbContenido.append("\tborder : 1px solid Blue;\r\n");
        sbContenido.append("\tpadding : 10px 10px 10px 10px;\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append(".form-button {border-color:#69C;border-style:solid;border-width:1px;cursor:hand}\r\n");
        sbContenido.append("</style>\r\n");
        sbContenido.append("<script language=\"JavaScript1.2\">\r\n");
        sbContenido.append("function retornar(){\r\n");
        sbContenido.append("\t/* if (history.length>0){\r\n");
        sbContenido.append("\t\tdocument.write(\"<div align='LEFT'><input class='form-button' type='button' value='Anterior' onclick='parent.history.back()'></div>\");\r\n");
        sbContenido.append("\t} */\r\n");
        sbContenido.append("}\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("</script>\r\n");
        sbContenido.append("<BODY  bgcolor=\"#ffffff\">\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("<div class=\"cuerpo\">\r\n");
        sbContenido.append("\r\n");
        sbContenido.append("<div align=\"left\" class=\"msg\">La aplicaci&oacute;n ha retornado el siguiente mensaje :</div>\r\n");
        sbContenido.append("<p class=\"error\"><jsp:getProperty name=\"beanM\" property=\"mensajeerror\" /></p>\r\n");
        sbContenido.append("<HR size=\"1px\">\r\n");
        sbContenido.append("<div align=\"left\"  class=\"msg2\">Acci&oacute;n a realizar :</div>\r\n");
        sbContenido.append("<div align=\"left\" class=\"soluc\"><jsp:getProperty name=\"beanM\" property=\"mensajesol\" /></div>\r\n");
        sbContenido.append("<br>\r\n");
        sbContenido.append("<HR size=\"3px\" color=\"#0000ff\">\r\n");
        sbContenido.append("<script language=\"JavaScript1.2\" type=\"text/javascript\">\r\n");
        sbContenido.append("retornar();\r\n");
        sbContenido.append("</script>\r\n");
        sbContenido.append("</div>\r\n");
        sbContenido.append("</BODY>\r\n");
        sbContenido.append("</HTML>\r\n");
        
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}

	private static void agregarTextoSettingsBackend(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        StringBuilder sbTemp = new StringBuilder();
        sbTemp.append("include\t'").append(mapParam.get("nomWar")).append("',\r\n");
        sbTemp.append("\t\t'").append(mapParam.get("nomJar")).append("',\r\n");
        sbTemp.append("\t\t'").append(mapParam.get("nomEar")).append("'\r\n");
        sbTemp.append("\r\n");
        sbTemp.append("project(':").append(mapParam.get("nomWar")).append("').name='").append(mapParam.get("nomWar").replace(".war", "")).append("'\r\n");
        sbTemp.append("project(':").append(mapParam.get("nomJar")).append("').name='").append(mapParam.get("nomJar").replace(".jar", "")).append("'\r\n");
        sbTemp.append("project(':").append(mapParam.get("nomEar")).append("').name='").append(mapParam.get("nomEar")).append("'\r\n");

        out.write(sbTemp.toString());
        out.close();
        fstream.close();
	}
	
	private static void agregarTextoRestController(String nombreArch, Map<String, String> mapParam) throws IOException {
        FileWriter fstream = new FileWriter(nombreArch, true);
        BufferedWriter out = new BufferedWriter(fstream);
        
		String service = mapParam.get("clase-service-ifz").substring(0,1).toLowerCase() + mapParam.get("clase-service-ifz").substring(1);
		String entidad = mapParam.get("clase-model").substring(0,1).toLowerCase() + mapParam.get("clase-model").substring(1);
		
		StringBuilder sbContenido = new StringBuilder();
		sbContenido.append("package ").append(mapParam.get("packageProceso")).append(".ws.rest;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import java.util.ArrayList;\r\n");
		sbContenido.append("import java.util.HashMap;\r\n");
		sbContenido.append("import java.util.List;\r\n");
		sbContenido.append("import java.util.Map;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import org.apache.commons.logging.Log;\r\n");
		sbContenido.append("import org.apache.commons.logging.LogFactory;\r\n");
		sbContenido.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
		sbContenido.append("import org.springframework.http.MediaType;\r\n");
		sbContenido.append("import org.springframework.stereotype.Controller;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.RequestBody;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.RequestMapping;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.RequestMethod;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.RequestParam;\r\n");
		sbContenido.append("import org.springframework.web.bind.annotation.ResponseBody;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("import ").append(mapParam.get("packageProceso")).append(".model.Valores;\r\n");
		sbContenido.append("import ").append(mapParam.get("packageProceso")).append(".service.ConsultaValoresService;\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("@Controller\r\n");
		sbContenido.append("@RequestMapping(value=\"/").append(mapParam.get("recurso")).append("\")\r\n");
		sbContenido.append("public class ").append(mapParam.get("clase-rest-controller")).append(" {\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\tprotected final Log log = LogFactory.getLog(getClass());\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t@Autowired\r\n");
		sbContenido.append("\t").append(mapParam.get("clase-service-ifz")).append(" ").append(service).append(";\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t@RequestMapping(method = RequestMethod.GET,\r\n");
		sbContenido.append("\t\t\tproduces = MediaType.APPLICATION_JSON_VALUE)\r\n");
		sbContenido.append("\tpublic @ResponseBody List<").append(mapParam.get("clase-model")).append("> listar").append(mapParam.get("clase-model")).append("PorParametros(\r\n");
		sbContenido.append("\t\t\t@RequestParam Map<String, String> requestParams) {\r\n");
		sbContenido.append("\t\tList<").append(mapParam.get("clase-model")).append("> list").append(mapParam.get("clase-model")).append(" = new ArrayList<").append(mapParam.get("clase-model")).append(">();\r\n");
		sbContenido.append("\t\tif (requestParams != null && !requestParams.isEmpty()) {\r\n");
		sbContenido.append("\t\t\tif (requestParams.get(\"a1\") != null && requestParams.get(\"a2\") != null) {\r\n");
		sbContenido.append("\t\t\t\tMap<String,String> params = new HashMap<String, String>();\r\n");
		sbContenido.append("\t\t\t\tparams.put(\"a1_par\", requestParams.get(\"a1\").trim());\r\n");
		sbContenido.append("\t\t\t\tparams.put(\"a2_dep\", requestParams.get(\"a2\").trim());\r\n");
		sbContenido.append("\t\t\t\tlist").append(mapParam.get("clase-model")).append(" = ").append(service).append(".listar").append(mapParam.get("clase-model")).append("ByParameterMap(params);\r\n");
		sbContenido.append("\t\t\t} else {\r\n");
		sbContenido.append("\t\t\t\tlog.debug(\"LOS PARAMETROS NO ESTAN DEFINIDOS...\");\r\n");
		sbContenido.append("\t\t\t}\r\n");
		sbContenido.append("\t\t} else {\r\n");
		sbContenido.append("\t\t\tlog.debug(\"NO HAY PARAMETROS...\");\r\n");
		sbContenido.append("\t\t}\r\n");
		sbContenido.append("\t\treturn listValores;\r\n");
		sbContenido.append("\t}\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("\t@RequestMapping(method = RequestMethod.POST,\r\n");
		sbContenido.append("\t\t\tconsumes = MediaType.APPLICATION_JSON_VALUE,\r\n");
		sbContenido.append("\t\t\tproduces = MediaType.APPLICATION_JSON_VALUE)\r\n");
		sbContenido.append("\tpublic @ResponseBody ").append(mapParam.get("clase-model")).append(" registrar").append(mapParam.get("clase-model"));
		String requestParams = "request" + mapParam.get("clase-model");
		sbContenido.append("(@RequestBody ").append(mapParam.get("clase-model")).append(" ").append(requestParams).append(") {\r\n");
		sbContenido.append("\t\t").append(mapParam.get("clase-model")).append(" ").append(entidad).append(" = new ").append(mapParam.get("clase-model")).append("();\r\n");
		sbContenido.append("\t\tlog.debug(\"EXITO...\");\r\n");
		sbContenido.append("\t\t//").append(entidad).append(" = ").append(service).append(".registrar").append(mapParam.get("clase-model")).append("(").append(requestParams).append(");\r\n");
		sbContenido.append("\t\t").append(entidad).append(".setA1(").append(requestParams).append(".getA1());\r\n");
		sbContenido.append("\t\t").append(entidad).append(".setA2(").append(requestParams).append(".getA2());\r\n");
		sbContenido.append("\t\treturn ").append(entidad).append(";\r\n");
		sbContenido.append("\t}\r\n");
		sbContenido.append("\r\n");
		sbContenido.append("}\r\n");
		
		out.write(sbContenido.toString());
        out.close();
        fstream.close();
	}	
	
	
	
}
