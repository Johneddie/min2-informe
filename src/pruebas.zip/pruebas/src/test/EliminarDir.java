package test;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class EliminarDir {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String rutaOrigen="D:\\data0\\tempo";
//		String rutaOrigen1="D:\\geco_fuente7\\recurso2-documentacion-expvirtual-sharedlib.ear";
//		String rutaOrigen2="D:\\geco_fuente7\\recurso2-documentacion-expvirtual-webapp.ear";
//		String rutaOrigen3="D:\\geco_fuente7\\recurso2-documentacion-expvirtualws-webapp.ear";
//		String rutaOrigen4="D:\\geco_fuente\\recurso2-documentacion-expvirtual-batch.ear";
		try {
			System.out.println("*INICIO--->Eliminando :"+ rutaOrigen);
			delete(new File(rutaOrigen));
			System.out.println("*FIN--->Eliminando :"+ rutaOrigen);
//			System.out.println("*INICIO--->Eliminando :"+ rutaOrigen1);
//			delete(new File(rutaOrigen1));
//			System.out.println("*FIN--->Eliminando :"+ rutaOrigen1);
//			System.out.println("*INICIO--->Eliminando :"+ rutaOrigen2);
//			delete(new File(rutaOrigen2));
//			System.out.println("*FIN--->Eliminando :"+ rutaOrigen2);
//			System.out.println("*INICIO--->Eliminando :"+ rutaOrigen3);
//			delete(new File(rutaOrigen3));
//			System.out.println("*FIN--->Eliminando :"+ rutaOrigen3);
//			System.out.println("*INICIO--->Eliminando :"+ rutaOrigen4);
//			delete(new File(rutaOrigen4));
//			System.out.println("*FIN--->Eliminando :"+ rutaOrigen4);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
	static void delete(File f) throws IOException {
		  if (f.isDirectory()) {
		    for (File c : f.listFiles())
		      delete(c);
		  }
		  if (!f.delete())
		    throw new FileNotFoundException("Failed to delete file: " + f);
		}

}
